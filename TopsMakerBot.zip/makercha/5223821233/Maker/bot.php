<?php
ini_set("display_errors", 1);
ob_start();
define('API_KEY',"5654690206:AAEFP2niLfkgM5y5Wzn0kkpr_0YLOK4XGgE"); 
$bot = bot('getme',['bot'])->result->username;
$toga="5223821233";
$admin ="5223821233";
$adminuser = "Baszum";
$ch4 = file_get_contents("ch4.txt");

$botla= file_get_contents("ch4.txt");
include("bots.php");
include("pulli.php");
include("antiqa.php");
include("maxsus.php");
include("group.php");
include("panel.php");
include("index.php");
$adminuser = "Baszum";
$sayt="http://mamurov74.myxvest.ru/VipBuilder/";
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

function joinchat($id){
     global $message_id,$referalsum,$firstname;
$ch1 = file_get_contents("ch1.txt");
     $ret = bot("getChatMember",[
         "chat_id"=>"@".$ch1."",
         "user_id"=>$id,
         ]);
$stat = $ret->result->status;
$ch2 = file_get_contents("ch2.txt");
$rets = bot("getChatMember",[
         "chat_id"=>"@".$ch2."",
         "user_id"=>$id,
         ]);
$stats = $rets->result->status;
$ch3 = file_get_contents("ch3.txt");
$retus = bot("getChatMember",[
         "chat_id"=>"@".$ch3."",
         "user_id"=>$id,
         ]);
$status = $retus->result->status;
         if((($stat=="creator" or $stat=="administrator" or $stat=="member") and ($stats=="creator" or $stats=="administrator" or $stats=="member") and ($status=="creator" or $status=="administrator" or $status=="member"))){
      return true;
         }else{
             bot("sendMessage",[
         "chat_id"=>$id,
           'text'=>"❌Kechirasiz $name siz bizning kanallarimizga obuna boʻlmasangiz botdan foydalana olmaysiz!
🔰Obuna boʻlib botga qayta /start bosing!
 Shunday bot yaratish @By_konsbot
❗Bot ishlashi uchun ↩️Ortga qaytish 👈shuni kopirovat qilib botg yuboring❗",     "parse_mode"=>"html",
         "reply_to_message_id"=>$message_id,
"disable_web_page_preview"=>true,
    
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
      [['text'=>"🔰 Kanalimiz",'url'=>"https://t.me/$ch1"],['text'=>"🔰 Kanalimiz",'url'=>"https://t.me/$ch2"]],
                [['text'=>"🔰 Kanalimiz",'url'=>"https://t.me/$ch3"]],
[['text'=>"🔰 Maker bot yaratish",'url'=>"https://t.me/By_konsbot"]],
        ]
        ])
        ]);
        return false;
    }
}
$servername = "localhost";


$username = "mamurov74_maker_sayt";


$password = "maker2022";


$connect = new mysqli($servername, $username, $password, $username);




mysqli_query($connect,"CREATE TABLE `data` (

  `id` int(11) NOT NULL AUTO_INCREMENT,

  `name` varchar(100) NOT NULL,

  `doc_id` text NOT NULL,

  `size` varchar(15) NOT NULL,

  `type` varchar(10) NOT NULL,

  `top` int(20) NOT NULL,

  `creator` varchar(30) NOT NULL,

  PRIMARY KEY (`id`)

)");



mysqli_query($connect,"CREATE TABLE `bots` ( 
 `name` text,
)");



mysqli_query($connect,"CREATE TABLE `users` (

  `id` int(11) NOT NULL AUTO_INCREMENT,

  `user_id` varchar(30) NOT NULL,

  `reg` varchar(20) NOT NULL,

  `lang` int(11) NOT NULL,

  PRIMARY KEY (`id`)

)");

mysqli_query($connect,"CREATE TABLE `oddiy` (

  `id` int(11) NOT NULL AUTO_INCREMENT,

  `user_id` varchar(30) NOT NULL,

  `reg` varchar(20) NOT NULL,

  `lang` int(11) NOT NULL,

  PRIMARY KEY (`id`)

)");


$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$cid = $message->chat->id;
$tx = $message->text;
$referalim = file_get_contents("stat/channel_12.txt");
$Uzb61= file_get_contents("data/$from_id/uzb61.txt"); 
$from_id = $update->message->from->id;
$ch_mid = $message_ch->message_id;
$ch_cid = $message_ch->chat->id;
$message_ch = $update->channel_post;
$token = $message->text;
$chanel_vid = $channel->text; 
$from_id = $update->message->from->id;
$mid = $message->message_id;
$name = $message->from->first_name;
$fid = $message->from->id;
$callback = $update->callback_query;
$message = $update->message;
$mid = $message->message_id;
$data = $update->callback_query->data;
$type = $message->chat->type;
$text = $message->text;
$message_id = $callback->message->message_id;
$data = $update->callback_query->data;
$cid2 = $update->callback_query->message->chat->id;
$mid2 = $update->callback_query->message->message_id;
$fid2 = $update->callback_query->message->from->id;
$call = $update->callback_query;
$qid = $call->id;
$adstep = file_get_contents("admin/admin.step");
$uid= $message->from->id;
$message_ch = $update->channel_post;
$ch_mid = $message_ch->message_id;
$ch_cid = $message_ch->chat->id;
$chanel_vid = $channel->message; 
$gname = $message->chat->title;
$left = $message->left_chat_member;
$new = $message->new_chat_member;
$name = $message->from->first_name;
$message_ch = $update->channel_post;
$repid = $message->reply_to_message->from->id;
$repname = $message->reply_to_message->from->first_name;
$newid = $message->new_chat_member->id;
$leftid = $message->left_chat_member->id;
$newname = $message->new_chat_member->first_name;
$leftname = $message->left_chat_member->first_name;
$username = $message->from->username;
$cmid = $update->callback_query->message->message_id;
$cusername = $message->chat->username;
$repmid = $message->reply_to_message->message_id; 
$ccid = $update->callback_query->message->chat->id;
$cuid = $update->callback_query->message->from->id;
$cqid = $update->callback_query->id;
$ch_mid = $message_ch->message_id;
$ch_cid = $message_ch->chat->id;
$ch_user = $message_ch->chat->username; 
$photo = $update->message->photo;
$gif = $update->message->animation;
$cmid = $update->callback_query->message->message_id;
$cusername = $message->chat->username;
$repmid = $message->reply_to_message->message_id; 
$ccid = $update->callback_query->message->chat->id;
$cuid = $update->callback_query->message->from->id;
$cqid = $update->callback_query->id;
$data=$update->callback_query->data;
$callcid=$update->callback_query->message->chat->id;
$callmid=$update->callback_query->message->message_id;
$from_id = $message->from->id;
$video = $update->message->video;
$music = $update->message->audio;
$voice = $update->message->voice;
$sticker = $update->message->sticker;
$document = $update->message->document;
$for = $message->forward_from;
$forc = $message->forward_from_chat;
$data = $callback->data;
$callid = $callback->id;
$kanala = file_put_contents("kanal/chatid.kanal1","$text");

$kanalr = file_put_contents("kanal/chatid.kanal2","$text");

$kanals = file_put_contents("kanal/chatid.kanal3","$text");
$cname = $calback->message->from->first_name;
$ccid = $callback->message->chat->id;
$cmid = $callback->message->message_id;
$cfid = $callback->message->from->id;
$user = $message->from->username;
$botname = bot('getme',['bot'])->result->username; // @ belgisiz yozing
$inlinequery = $update->inline_query;
$inline_id = $inlinequery->id;
$inlineid = $inlinequery->from->id;
$inline_query = $inlinequery->query;
date_Default_timezone_set('Asia/Tashkent');
$soat = date('H:i');
$sana=date("d.m.Y");
$time=date('H:i');
$user = file_get_contents("Unknown_Blogger.ids");
$guruh = file_get_contents("pul/guruh.db");
$blocklar = file_get_contents("block.dat");
$getss= file_get_contents("admin/blocks.txt");
if(mb_stripos($getss, $fid)!==false){
	bot('sendMessage',[
	'chat_id' => $cid,
	'text' => "Kechirasiz <b>$name</b> siz bloklangansiz!",
	'parse_mode'=>'html',
	]); 
	return false;
	}

mkdir("referal");
mkdir("minus");
mkdir("stat");
mkdir("token");
mkdir("turi");
mkdir("boti");
mkdir("step");
mkdir("baza");
mkdir("user");
mkdir("bonus");
mkdir("baza/$fid");
mkdir("yangi");
mkdir("prouser");
mkdir("user/$fid");
mkdir("admin");
mkdir("prouser/$fid");
mkdir("prouser/$fid/usa");
mkdir("prouser/$fid/yandex/data");
mkdir("ban");
if(!file_exists("referal/$fid.txt")){  
    file_put_contents("referal/$fid.txt","0");
}

if(file_get_contents("stat/stat.txt")){
} else{
file_put_contents("stat/stat.txt", "0");
}

$referalsum = file_get_contents("referal/$fid.txt");
$referalid = file_get_contents("referal/$fid.referal");
$referalcid = file_get_contents("referal/$ccid.referal");
$userstep = file_get_contents("step/$fid.txt");
$tokeni = file_get_contents("token/$fid.txt");
$boti = file_get_contents("boti/$fid.txt");

$soni = file_get_contents("soni/$idi.soni");
if(!$soni) $soni = 0;

$botchala1r = json_encode([
"inline_keyboard"=>[
[["text"=>"👨🏻‍💻 Administrator","url"=>"https://t.me/$adminuser"],],

]

]);
$botchalaro = json_encode([
"inline_keyboard"=>[
[['text'=>"📕 Qoidalar",'callback_data'=>"qoida1"],],
[["text"=>"📋 Kanalimiz","url"=>"https://t.me/$ch2"],],
[["text"=>"👨🏻‍💻 Administrator","url"=>"https://t.me/$adminuser"],],


]

]);

$panel = json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[  
[['text'=>""],['text'=>"💰 Balans boshqaruvi"]],
    [['text'=>"🔐 Blok tizimi"],['text'=>"📝 Pochta tizimi"]],
[['text'=>""],['text'=>"🗄 Majburiy obuna"]],
[['text'=>"⚙ Bot sozlamalari"],['text'=>"↩️Ortga qaytish"]],
    ]
]);

$boshqar = json_encode([
     'resize_keyboard'=>true,
     'keyboard'=>[
[['text'=>"➕ Admin Qo'shish"],['text'=>"🗑 Admin O'chirish"]],
[['text'=>"📄 Admin Ro'yhati"],['text'=>"⬅️ ortga"]],
          ]
]);

$qayt_menu = json_encode([
     'resize_keyboard'=>true,
     'keyboard'=>[
          [['text'=>"⬅️ ortga"]],
          ]
          ]);

$main_menu = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🛠Botlarni boshqarish"]],
[['text'=>"📝 Kabinet"],['text'=>"💸 Pul to‘plash"]],
[['text'=>"📊 Statistika"],['text'=>"❓ Yordam"]],
[['text'=>"👨🏻‍💻 Administrator"],['text'=>"📋 Maʼlumotlar"]],
]
]);
$botts = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🛠Inline"],['text'=>"🤖Resize"]],
]
]);


$lan = json_encode([

'inline_keyboard'=>[

[["text"=>"🛠️Resize","callback_data"=>"1"],["text"=>"⚙️Inline","callback_data"=>"2"]],

[["text"=>"❌","callback_data"=>"del"]],

]

]);


$group = json_encode([
'inline_keyboard'=>[
[['text'=>"👮‍♂️ Posbon pro",'callback_data'=>"posbon"],['text'=>"🖇 Joinhider pro",'callback_data'=>"joinhider"]],
[['text'=>"📈 Reyting pro",'callback_data'=>"reyting"],['text'=>"🤓 Suhbatdosh pro",'callback_data'=>"suhbatdosh"]],
[['text'=>"🛠 Sanovchi pro",'callback_data'=>"sanovchi"],['text'=>"🔗 Join pro",'callback_data'=>"join"]],
[['text'=>"🔙 Orqaga",'callback_data'=>"shahzodga"]],
]
      ]);
$yordam_menu = json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
[['text'=>"📞Murojaat"],['text'=>"⚡Tizim yangiliklari"]],
[['text'=>"ℹ️Bot haqida"],['text'=>"📽️Video qoʻllanma"]],
[['text'=>""],['text'=>"↩️Ortga qaytish"]],
      ]
      ]);
      
$boshqar_menu = json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
    [['text'=>"➕ Bot qo'shish"]],
    [['text'=>"⚙️ Botni sozlash"]],
    [['text'=>"↩️Ortga qaytish"]],
    ]
    ]);
    
  

$pro_menu = json_encode([
'inline_keyboard'=>[
    [['text'=>"💰Pul bot (rubl)",'callback_data'=>"rubl"],['text'=>"💰Pul bot (so'm)",'callback_data'=>"som"]],
[['text'=>"📦Uc bot",'callback_data'=>"uc"],['text'=>"🇺🇸Usa bot",'callback_data'=>"usa"]],
[['text'=>"📦BC bot",'callback_data'=>"bc"],['text'=>"📦MB bot",'callback_data'=>"mb"]],
[['text'=>"🇺🇿AvtoRubl bot ",'callback_data'=>"avtorubl"],['text'=>"💰Pul bot (so'm) 4-Chanel",'callback_data'=>"sum4"]],
[['text'=>"🔙 Orqaga",'callback_data'=>"shahzodga"]],
    ]
    ]);
   
$antiqa_menu = json_encode([
'inline_keyboard'=>[
     [['text'=>"😍 Smile",'callback_data'=>"smile"],['text'=>"🎊Yandex",'callback_data'=>"yandex"]],
[['text'=>"Konspekt bot📝",'callback_data'=>"konspekt"],['text'=>"💫Nik Bot v.03",'callback_data'=>"nikv3"]],
[['text'=>"🔐Zip Bot",'callback_data'=>"zip"],['text'=>"🎛️Menu bot ",'callback_data'=>"menu"]],
[['text'=>"🔵Majburiy Azo",'callback_data'=>"majburiy"],['text'=>"🌙Islomiy Bot",'callback_data'=>"islomiy"]],
[['text'=>"📥 Down ",'callback_data'=>"down"]],
[['text'=>"🔙 Orqaga",'callback_data'=>"shahzodga"]],

    ]
    ]);



$sozlash_menu = json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
      [['text'=>"📋 Mening botim"],['text'=>"🗑️ Botni o'chirish"]],
      [['text'=>"🔄 Yangilash"],['text'=>"⬅️Orqaga"]],
      ]
      ]);
     
$back_menu = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"↩️Ortga qaytish"]]
]
]);

$bek_menu = json_encode([
      'resize_keyboard'=>true,
      'keyboard'=>[
          [['text'=>"⬅️Orqaga"]],
          ]
          ]);
          $shah = json_encode([
      'resize_keyboard'=>true,
      'keyboard'=>[
          [['text'=>"⬆️️Orqaga"]],
          ]
          ]) ;
          $hash = json_encode([
      'resize_keyboard'=>true,
      'keyboard'=>[
          [['text'=>"↩️Orqaga"]],
          ]
          ]);
       
$bekorgam = json_encode([
'inline_keyboard'=>[
[['text'=>"🚫 Bekor qilish", 'callback_data'=>"orqa"]],
]
]);

       $ketik_menu = json_encode([
         'resize_keyboard'=>true,
         'keyboard'=>[
           [['text'=>"🔙 Orqaga"]],
           ]
           ]);
           
$chiq_menu = json_encode([
     'resize_keyboard'=>true,
     'keyboard'=>[
          [['text'=>"⬅️ ortga"]],
          ]
          ]);
          
  $kar_menu = json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
      [['text'=>"⬅️ Orqaga"]],
      ]
      ]);

      $sprot1= json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
      [['text'=>"🔚Ortga"]],
      ]
      ]);
      
  
$bekor_menu = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"↩️Ortga qaytish"]]
]
]);


if(isset($message)){
    $get = file_get_contents("stat/usid.txt");
    if(mb_stripos($get,$fid)==false){
        file_put_contents("stat/usid.txt", "$get\n$fid");
        bot('sendMessage',[
          'chat_id'=>-"1005097612244",
          'text'=>"😄 Yangi aʼzo\n👤 Ismi: $name\n🆔 raqami: $fid\n✳️ Usernamesi: @$user\n💡 Lichka: <a href='tg://user?id=$fid'>$name</a>",
 'parse_mode'=>'html',
           'reply_markup'=>json_encode([
            'inline_keyboard'=>[
                [['text'=>"🛠️Bot ochish",'url'=>"https://t.me/$bot"]],
              ]
              ])
          ]);
    }
}

if($inlineid !== NULL){
bot('answerInlineQuery',[
    'inline_query_id'=>$inline_id,
    'cache_time'=>1,
    'results'=>json_encode([
    ['type'=>'article',
    'id'=>1,
    'title'=>"✅Referal havolangizni yuborish uchun bosing",
    'input_message_content'=>[
    'disable_web_page_preview'=>true,
    'parse_mode'=>'MarkDown',
    'message_text'=>"⚡️ Bir necha daqiqada o'z Telegram botingizga ega bo'ling!

⬇️ Buning uchun quyidagi botga kirish tugmasi orqali botimizga otib bot yarating!",
    ],
    'reply_markup'=>[
     'inline_keyboard'=>[
[['text'=>"➕ Botga kirish",'url'=>"https://t.me/$bot?start=$inlineid"]]
     ]
     ]
     ],
])
]);
}

if ($tx == "/start"){
    if(joinchat($fid)=="true"){
$result = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid'");

$row = mysqli_fetch_assoc($result);
$lang = $row['lang'];
if($row){
if($lang=="0"){
bot('sendmessage',[  
      'chat_id'=>$cid,
            'text'=>"☇ Salom $name
Sizni botda ko‘rib turganimdan xursandman!
  @$bot orqali siz o‘zingizning shaxsiy botlaringizni hech qanday qiyinchiliklarsiz yaratishingiz mumkin!
<b>⬇ Ishni boshlash uchun  /settings tugmasidan foydalaning!.</b>",
    'parse_mode'=>'html',       
]);                     
exit();
}elseif($lang=="1"){
bot('sendmessage',[
        'chat_id'=>$cid,
        'text'=>"☇ Salom $name
Sizni botda ko‘rib turganimdan xursandman!
  @$bot orqali siz o‘zingizning shaxsiy botlaringizni hech qanday qiyinchiliklarsiz yaratishingiz mumkin!
<b>⬇ Ishni boshlash uchun quyidagi tugmalardan foydalaning!.</b>",
    'parse_mode'=>'html',
    'reply_markup'=>$main_menu,      
        ]);
exit();
}elseif($lang=="2"){
bot('sendmessage',[
        'chat_id'=>$cid,
        'text'=>"☇ Salom $name

Sizni botda ko‘rib turganimdan xursandman!
  @$bot  orqali siz o‘zingizning shaxsiy botlaringizni hech qanday qiyinchiliklarsiz yaratishingiz mumkin!

<b>⬇ Ishni boshlash uchun quyidagi tugmalardan foydalaning!.</b>",
    'parse_mode'=>'html',
    'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🏗 Bot qurish",'callback_data'=>"boshqar"],['text'=>"🤖 Mening botim",'callback_data'=>"botim"]],
[['text'=>"⁉Qoidalar",'callback_data'=>"qoida"],['text'=>"🆘 Yordam",'callback_data'=>"yordam"]],
]
]),
]);
exit();
}
}else{
mysqli_query($connect, "INSERT INTO users(`user_id`,`reg`) VALUES ('$cid','$sana--$soat')");
$result = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid'");
$row = mysqli_fetch_assoc($result);
$lang = $row['lang'];
if($lang=="0"){
bot('sendmessage',[
        'chat_id'=>$cid,
           'text'=>"☇ Salom $name
Sizni botda ko‘rib turganimdan xursandman!
  @$bot   orqali siz o‘zingizning shaxsiy botlaringizni hech qanday qiyinchiliklarsiz yaratishingiz mumkin!
<b>⬇ Ishni boshlash uchun  /settings tugmasidan foydalaning!.</b>",
    'parse_mode'=>'html',          
]);
exit();
}elseif($lang=="1"){
bot('sendmessage',[
        'chat_id'=>$cid,
              'text'=>"☇ Salom $name
Sizni botda ko‘rib turganimdan xursandman!
  @$bot  orqali siz o‘zingizning shaxsiy botlaringizni hech qanday qiyinchiliklarsiz yaratishingiz mumkin!
<b>⬇ Ishni boshlash uchun quyidagi tugmalardan foydalaning!.</b>",
    'parse_mode'=>'html',
    'reply_markup'=>$main_menu,        
        ]);
exit();
}elseif($lang=="2"){
bot('sendmessage',[
        'chat_id'=>$cid,
        'text'=>"☇ Salom $name
Sizni botda ko‘rib turganimdan xursandman!
  @$bot  orqali siz o‘zingizning shaxsiy botlaringizni hech qanday qiyinchiliklarsiz yaratishingiz mumkin!
<b>⬇ Ishni boshlash uchun quyidagi tugmalardan foydalaning!.</b>",
    'parse_mode'=>'html',
    'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🏗 Bot qurish",'callback_data'=>"boshqar"],['text'=>"🤖 Mening botim",'callback_data'=>"botim"]],
[['text'=>"⁉Qoidalar",'callback_data'=>"qoida"],['text'=>"🆘 Yordam",'callback_data'=>"yordam"]],
]
]),
]);
exit();
}
}
}
}elseif (mb_stripos($tx, "/start")!==false) {
    if(joinchat($fid)=="true"){
    
        bot('sendMessage',[
        'chat_id' => $cid,
        'text' => "☇ Salom $name

Sizni botda ko‘rib turganimdan xursandman!
@$bot orqali siz o‘zingizning shaxsiy botlaringizni hech qanday qiyinchiliklarsiz yaratishingiz mumkin!

<b>⬇ Ishni boshlash uchun quyidagi /settings tugmasidan foydalaning!</b>",
        'parse_mode'=>'html',
      
        
        ]);
        
        if(mb_stripos($stat, $fid)==false){
        $ex = explode(" ", $tx);
        if($ex[1] == $cid){
        }else{
        $olmos = file_get_contents("referal/$ex[1].txt");      
        $referalim = $referalim / 1;
        $olmoslar = $olmos + $referalim;
        file_put_contents("referal/$ex[1].txt", $olmoslar);
        bot('sendMessage',[
        'chat_id'=>$ex[1],
        'text'=>"📡<i>Tabriklaymiz siz botimizga do'stingizni taklif qildingiz va do'stingiz kanalimizga a'zo bo'ldi buning uchun sizga $referalim  ta Raketa berildi</i>!",
        'parse_mode'=>'html'
        ]);
        }
        }

    }else{
        if(mb_stripos($stat, $fid)==false){      
        $ex = explode(" ", $tx);
        if($ex[1] == $cid){
        }else{
        bot('sendMessage',[
        'chat_id'=>$ex[1],
        'text'=>"📡<i>Tabriklaymiz siz botimizga do'stingizni taklif qildingiz! Ammo do'stingiz kanalimizga hali a'zo bo'lmadi. Do'stingiz kanalimizga a'zo bo'lsa sizga $referalim ta Raketa beriladi!</i>",
        'parse_mode'=>'html'
        ]);
        file_put_contents("referal/$fid.referal", $ex[1]);
    }
    }else{
        unlink("referal/$fid.referal");
    }
    }
}




        if($referalcid == true){
        $olmos = file_get_contents("referal/$referalcid.txt");
        $olmoslar = $olmos + $referalim;
        file_put_contents("referal/$referalcid.txt", $olmoslar);
         bot('sendMessage',[
        'chat_id'=>$referalcid,
        'text'=>"🔔<i>Tabriklaymiz do'stingiz kanalimizga a'zo bo'ldi va sizga  $referalim ta ta Raketa berildi!</i> ",
        'parse_mode'=>'html'
        ]);
         unlink("referal/$ccid.referal");
     }

    
if($tx == "↩️Ortga qaytish" or $data=="orqagaqaytish"){
    unlink("step/$fid.txt");
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"",
    'parse_mode'=>"html",
    'reply_markup'=>$main_menu
    ]);
}

if($tx == "⬅️Orqaga" and joinchat($fid)=="true"){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Quyidagi menyudan foydalaning👇",
        'parse_mode'=>"html",
        'reply_markup'=>$boshqar_menu,
        ]);
}
if($tx == "↩️Orqaga" and joinchat($fid)=="true"){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Quyidagi menyudan foydalaning👇",
        'parse_mode'=>"html",
        'reply_markup'=>$group,
        ]);
}

if($tx == "🔙 Orqaga" and joinchat($fid)=="true"){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Quyidagi menyudan foydalaning👇",
        'parse_mode'=>"html",
        'reply_markup'=>$sozlash_menu,
        ]);
}


if($tx == "⬅️ ortga" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Quyidagi menyudan foydalaning 👇",
    'parse_mode'=>"html",
    'reply_markup'=>$boshqar_menu
    ]);
}

if($tx == "⬅️ Orqaga" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Quyidagi botlardan foydalaning 👇",
    'parse_mode'=>"html",
    'reply_markup'=>$bots_menu
    ]);
}

if($tx == "🔚Ortga" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Quyidagi botlardan foydalaning 👇",
    'parse_mode'=>"html",
    'reply_markup'=>$antiqa_menu,
    ]);
}

if($tx == "⬆️️Orqaga" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Quyidagi botlardan foydalaning 👇",
    'parse_mode'=>"html",
    'reply_markup'=>$gr_menu,
    ]);
}


if($tx == "↩️Ortga qaytish" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"🖥 Bosh sahifaga qaytdingiz",
    'parse_mode'=>"html",
    'reply_markup'=>$main_menu
    ]);
}
if($data == "orqaga "){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"🖥 Bosh sahifaga qaytdingiz",
    'parse_mode'=>"html",
    'reply_markup'=>$main_menu
    ]);
}

if($tx == "🔄Xizmat Bots" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Bu boʻlimga xush kelibsiz ",
    'parse_mode'=>"html",
        'reply_markup'=>$xizmatbots,
    ]);
}

if($tx == "🛠Botlarni sozlash" and joinchat($fid)=="true"){
    $turi = file_get_contents("turi/$fid.txt");
if($turi == ""){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"🤖 Bot turi: Nomalum
🌍 Webhook holati: ❌
🗄 Bot Tokeni: Mavjud emas 🚫",
'reply_markup'=>$sozlash_menu,
]);
}else{
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"🤖 Bot turi: $turi Bot
🌍 Webhook holati: ✅
🗄 Bot Tokeni: $tokeni",
    'reply_markup'=>$sozlash_menu,
    ]);
    }
    }

if($tx == "🛠Botlarni boshqarish" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"ℹ️ Yangi bot yaratish uchun quyidagi tugmani bosing:
«➕ Bot qoʻshish»

ℹ️ Tayyor botni oʻchirish yoki sozlash uchun quyidagi tugmani bosing:
«⚙️Botni sozlash»",
    'parse_mode'=>'html',
    'reply_markup'=>$boshqar_menu
    ]);
}

if($tx == "➕ Bot qo'shish" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Qanday turdagi botlarni yaratamiz👇",
'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"🆓️ Bepul bot(13)",'callback_data'=>"tekin"]],
[['text'=>"🔥Antiqa botlar (9)",'callback_data'=>"antiqa"]],
[['text'=>"💵 Pul bot (8)",'callback_data'=>"pul"]],
[['text'=>"⭐ Maxsus boʻlim(1)",'callback_data'=>"maxsus"]],
[['text'=>"↩️Oqaga",'callback_data'=>"orqagaa"],],
]
]),
    ]);
}


if($tx == "⚙️ Botni sozlash" and joinchat($fid)=="true"){
$turi = file_get_contents("turi/$fid.txt");
if($turi == ""){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"🤖 Bot turi: Nomalum
🌍 Webhook holati: ❌
🗄 Bot Tokeni: Mavjud emas 🚫",
'reply_markup'=>$sozlash_menu,
]);
}else{
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"🤖 Bot turi: $turi Bot
🌍 Webhook holati: ✅
🗄 Bot Tokeni: $tokeni",
    'reply_markup'=>$sozlash_menu,
    ]);
    }
    }
if($tx == "📋 Mening botim" and joinchat($fid)=="true"){
 $botingiz = file_get_contents("boti/$fid.txt");
 if($botingiz == ""){
  bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Siz bot yaratmagansiz.",
    ]);
}else{
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Sizning botingiz @$botingiz .",
 'parse_mode'=>'html',
 'reply_markup'=>json_encode([
            'inline_keyboard'=>[
                [['text'=>"@$botingiz",'url'=>"https://t.me/$botingiz"]],
            ]
        ])
]);
}
}
$lichka=file_get_contents("shekih.db");
if($type=="private"){
if(strpos($lichka,"$cid") !==false){
}else{
file_put_contents("shekih.db","$lichka\n$cid");
}
}
if(mb_stripos($tx, "/del")!==false){
 $ex=explode(" ", $tx);
 $px=$ex[1];
  file_get_contents("https://api.telegram.org/bot$px/deletewebhook");
    $to = file_get_contents("https://api.telegram.org/bot$px/getme");
    $json = json_decode($to);
    $botus = $json->result->username;
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>"❗️Bot muvaffaqiyatli o'chirildi❗️

🔰Botingiz manzili: @$botus 👈

",
   'parse_mode' => 'html',
   'reply_markup'=>$back_menu,   
  ]);

}
if($tx =="/settings"){
$result7 = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid'");
$row7 = mysqli_fetch_assoc($result7);
$lang = $row7['lang'];
if($lang=="0"){
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"<b>Hech qanday rejim yoʻq</b>",
'parse_mode'=>'html',
'reply_markup'=>$lan,
]);
}elseif($lang=="1"){
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"<b>Hozirgi rejim Resize</b>",
'parse_mode'=>'html',
'reply_markup'=>$lan,
]);
exit();
}elseif($lang=="2"){
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"<b>Hozirgi rejim inline</b>",
'parse_mode'=>'html',
'reply_markup'=>$lan,
]);
exit();
}
}
if($tx == "🗑️ Botni o'chirish" and joinchat($fid)=="true"){
    $botingiz = file_get_contents("boti/$fid.txt");
 if($botingiz == ""){
  bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Siz bot yaratmagansiz.",
    ]);
}else{
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Sizning @$botingiz botingiz o'chirildi. ✅",
 'parse_mode'=>'html',
 'reply_markup'=>$sozlash_menu,
]);
}
unlink("boti/$fid.txt");
unlink("turi/$fid.txt");
unlink("token/$fid.txt");
rmdir("user/$fid");
rmdir("prouser/$fid");
}
if($tx == "🔄 Yangilash"){
$yangi = file_get_contents("yangi/$fid.txt");
$tur = file_get_contents("turi/$fid.txt");
if($yangi == ""){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"🌍 Yangilash uchun Bot yaratilmagan.",
'reply_markup'=>$sozlash_menu,
]);
}else{
bot('sendMessage',[
'chat_id'=>$cid,
   'text'=>"
<b>🤖 Bot turi: $tur Bot
🌍 Webhook holati: ✅
🗄 Bot Tokeni: $tokeni

📝 Botni yangilash uchun botning yangi Tokenini kiriting:</b>",
    'parse_mode'=>'html',
'reply_markup'=>$ketik_menu,
]);
file_put_contents("step/$fid.txt" ,$yangi);
}
}

if($tx == "📝 Kabinet" or $data=="kabinet"){
    $get = file_get_contents("referal/$fid.txt");
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"<i>🗄 Kabinetingizga xush kelibsiz!

💵 Sizning balansingiz: $get ta Raketa 
👥 Sizning takliflaringiz: $soni ta

❗❗Bot hisobingizni Qiwi orqali to‘ldiryotgangizda izoh qoldirishni unutmang!</i>",
     'parse_mode'=>"html",
'reply_markup'=>json_encode([
            'inline_keyboard'=>[
                [['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"],],
            ]
        ])
]);
}


if($data == "toldir"){
        bot('deleteMessage',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
]);
     bot('SendMessage',[
        'chat_id'=>$ccid,
        'text'=>"📋 Quyidagilardan birini tanlang:",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"💠 Click ",'callback_data'=>"qiwi"],['text'=>"🔥 Paynet",'callback_data'=>"paynet"]],
[['text'=>"🥝 Qiwi",'callback_data'=>"click"]],
]
])
]);
}


if($data == "orqas"){
        bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
        'text'=>"📋 Quyidagilardan birini tanlang:",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"💠 Click",'callback_data'=>"qiwi"],['text'=>"🔥 Paynet",'callback_data'=>"paynet"]],
[['text'=>"🥝 Qiwi",'callback_data'=>"click"]],
]
])
]);
}

$click = file_get_contents("click.txt");
if($data == "qiwi"){
	bot('editMessageText',[
	'chat_id'=>$ccid,
	'message_id'=>$cmid,
	'text'=>"📋 To'lov tizimi: Click
💡 Avto to'lov holati: OF

💳 Hamyon ( yoki karta ): $click
📝 Izoh: $ccid

Qo'shimcha: Diqqat! izoh kiritishni unutsangiz yoki noto'g'ri kiritsangiz hisobingizga pul tushmaydi! Bu kabi holatlarda, biz bilan bog'lanishingiz mumkin.",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"☎️ Tex. Yordam",'url'=>"https://t.me/$adminuser"]],
[['text'=>"◀️Ortga",'callback_data'=>"orqas"]],
]
])
]);
}

if($data == "orqa"){
	bot('editMessageText',[
	'chat_id'=>$ccid,
	'message_id'=>$cmid,
	'text'=>"Bekor qilindi. ❌",
'reply_markup'=>$main_menu,
]);
}
$paynet = file_get_contents("paynet.txt");
if($data == "paynet"){
	bot('editMessageText',[
	'chat_id'=>$ccid,
	'message_id'=>$cmid,
	'text'=>"📋 To'lov tizimi: Paynet
💡 Avto to'lov holati: OF

💳 Hamyon ( yoki karta ) -> $paynet
📝 Izoh: $ccid
📊 B. V. Kursi: 155

Qo'shimcha: To'lovni amalga oshirgach biz bilan bog'laning.",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"☎️ Tex. Yordam",'url'=>"https://t.me/$adminuser"]],
[['text'=>"◀️Ortga",'callback_data'=>"orqas"]],
]
])
]);
}
$qiwi = file_get_contents("qiwi.txt");
if($data == "click"){
	bot('editMessageText',[
	'chat_id'=>$ccid,
	'message_id'=>$cmid,
	'text'=>"📋 To'lov tizimi: Qiwi
💡 Avto to'lov holati: OF

💳 Hamyon (yoki hamyon) : $qiwi
📝 Izoh: $ccid

Qo'shimcha: Diqqat! izoh kiritishni unutsangiz yoki noto'g'ri kiritsangiz hisobingizga pul tushmaydi! Bu kabi holatlarda, biz bilan bog'lanishingiz mumkin.",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"☎️ Tex. Yordam",'url'=>"https://t.me/$adminuser"]],
[['text'=>"◀️Ortga",'callback_data'=>"orqas"]],
]
])
]);
}

if($tx == "💸 Pul to‘plash"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"⚠️ Diqqat botdan ishlagan pullaringiz sizga oʻtkazib berilmaydi pullarni faqat botni turli xil xizmatlari uchun ishlatishingiz mumkin!
Bu sizning referal havolangiz: https://t.me/$botname?start=$cid har bitta do'stingiz uchun $referalim ta Raketa beriladi.
    📋 Quyidagi boʻlimlardan birini tanlang!   " ,
      'reply_markup'=>json_encode([
    'inline_keyboard'=>[
[['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]]
]
]),
   ]);
}





if($tx=="📽️Video qoʻllanma"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/vertualbotmaker/234",
        'caption'=>"🤖Botimizning qo'lash videosi bu video bizning yotube kanalimizga hamda botimmizga ham joylanadi.✅

🛠Bot : @$bot

🎥Video mualifi : @$adminuser

🛠Qanday mumao bolsa : @$adminuser murojaat qing!", 
        'reply_markup'=>$back_menu,
]); 
}

if($tx =="📊 Statistika" and joinchat($fid)=="true"){
     

 $lang = $row7['lang'];
 $us = file_get_contents("stat/usid.txt");
    $uscount = substr_count($us, "\n");
    $bot = file_get_contents("stat/stat.txt");
    $botpro = file_get_contents("stat/statpro.txt");   
         $antiqa = file_get_contents("stat/statantiqa.txt");   
    $all = $bot + $botpro+$antiqa+$group;
    bot('sendMessage',[
    'chat_id' => $cid,
    'text'=>"📊Bot a'zolari soni: *$uscount* ta\n🆓️ Bepul botlar : *$bot* ta\n💵 Pul botlar : *$botpro* ta \n🔥Antiqa botlar  : *$antiqa* ta \n🔰Jami yasalgan botlar: *$all* ta\n⏰$time  📆$sana",
    'parse_mode'=>"markdown",
    'reply_markup'=>$main_menu
    ]);
}

if($tx == "❓ Yordam" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"❓Siz Yordam menusidasiz.\n\n📋 Yordam olish uchun buyruqlardan foydalaning:",
    'reply_markup'=>$yordam_menu
    ]);}
if($tx=="📞Murojaat" and joinchat($fid)=="true"){
	bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"📞 Sizda biror gʻoya, taklif yoki murojaat boʻlsa bizga murojaat qiling:
@$adminuser

📂 Texnik qoʻllab-quvvatlash uchun guruhimizga qoʻshiling:
@$adminuser",

	'parse_mode'=>'html',
	'reply_markup'=>$yordam_menu
	]);
}
if($tx=="⚡Tizim yangiliklari"and joinchat($fid)=="true"){
	bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"📂 Bot yuzasidagi barcha yangiliklar @$bot kanalida yetkazib boriladi.

🗄 Kanalga obuna boʻlishingizni soʻraymiz! Bu siz uchun muhim!",

	'parse_mode'=>'html',
	'reply_markup'=>$yordam_menu
	]);
}
if($tx=="ℹ️Bot haqida"and joinchat($fid)=="true"){
	bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"ℹ️ Ushbu bot orqali siz hech qanday dasturlash tillarini bilmasdan turib va hech qanday hostinglarsiz oson bot yasay olasiz.

✅ Imkoniyatlar
👉 Bepul hostingdan bot yarating
👉 Do'stlarni taklif qiling
👉 Har kunlik bonus oling
👉 Dasturlangan bot yarating.

🇺🇿 Hamma botlar soni: 40 ta

♻️ Bot versiyasi: 4.0

🛠 Dasturchi: @$adminuser",

	'parse_mode'=>'html',
	'reply_markup'=>$yordam_menu,
	]);
}



if($tx == "⬅️ Bekor"){
    unlink("step/admin.txt");
    bot('sendMessage',[
        'text'=>"<b>👨‍💻Admin panelga qaytdingiz.</b>",
        'chat_id'=>$admin,
        'parse_mode'=>"html",
        'reply_markup'=>$panel,
]);
}
    
$rpl = json_encode([
  'resize_keyboard'=>false,
  'force_reply'=>true,
  'selective'=>true,
]);








$ch2 = file_get_contents("ch2.txt");
if($tx=="👨🏻‍💻 Administrator"){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"📋 Bizga savollaringiz yoki taklif va muammolaringiz boʻlsa iltimos bizning qoʻllab-quvvatlash jamoamiz bilan bogʻlaning!
👨🏻‍💻 Administrator: @$adminuser
<i>📝 <a href='https://t.me/$adminuser'>Spamlar uchun bot!</a> </i>
",
'parse_mode'=>'html',
'reply_markup'=>$botchala1r,
     ]);
}
$ch2 = file_get_contents("ch2.txt");
if($tx=="📋 Maʼlumotlar"){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"📋 Quyidagi boʻlimlardan birini tanlang!",
'parse_mode'=>'html',
'reply_markup'=>$botchalaro,
     ]);
}

       if($data=="1" or $data=="2"){

       mysqli_query($connect,"UPDATE users SET  lang = '$data' WHERE user_id = '$cid2'");
$str = str_replace(["1","2"],["<b>Hozirgi rejim:</b> <i>🤖Resize rejimga oʻtdingiz qayta /start ni bosing</i>","<b>Hozirgi rejim :</b> <i>🛠Inline rejimga oʻtdingiz qayta /start ni bosing</i>"],$data);

bot('EditMessagetext',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
'text'=>"$str",
'parse_mode'=>'html',
'reply_markup'=>$lan,
]);
exit();
}

if((mb_stripos($text,"/send=")!==false) and $cid == $admin){
$e = explode("/send=",$text);
$e = $e[1];
$res = mysqli_query($connect,"SELECT * FROM `users` LIMIT 10000");
while($a = mysqli_fetch_assoc($res)){
$id = $a['user_id'];
bot('sendMessage',[
  'chat_id'=>$id,
  'text'=>$e,
 'parse_mode'=>'html',
        ]);
}
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"Yuborildi",
 'parse_mode'=>'html',
        ]);
exit();
}
$ch3 = file_get_contents("ch3.txt");
$bonus22 = file_get_contents("$admin.ttxt");
$bepul1 = file_get_contents("bonus2.txt");
$ch2 = file_get_contents("ch2.txt");
mkdir("rubl");

if($tx=="🚀Bonus yasash" and $cid==$admin){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"bonus dan qancha odam foydalanishini yozing?",
'reply_markup'=>json_encode([
 'remove_keyboard'=>true,
]),   
]);
file_put_contents("$admin.ttxt","bonusa");
unlink('rubl/olindi1.txt');
unlink('rubl/berildi1.txt');
}

if( $bonus22=="bonusa" and $cid==$admin){
file_put_contents("bonus2.txt","$text");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"@$ch2 kanaliga yuborildi",
'reply_markup'=>$panel,    
]);
unlink("$admin.ttxt");
$vaqt1=date('H:i',strtotime('-0 hour'));
bot('sendmessage',[
'chat_id'=>$botla, 
'text'=>"
🚀 O‘yin boshlandi!

⏩ Bonus olgan foydalanuvchilar: 0
🥝 Berilgan ta Raketa miqdori: 0 ta Raketa
✉️ Chatda muhokama qiling!
📂 Rasmiy kanal: @$ch2
🔰 Homiy kanal: @$ch3

⏳ Boshlangan vaqti: $vaqt1",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🚀 Bonusni olish","callback_data"=>"bo"]],
]
]),
]);
}

if($data == "bo"){
$olindi=file_get_contents("bonus2.txt");
$ee1 = file_get_contents("rubl/olindi1.txt");
$eea = substr_count($ee1,"\n"); 
if($eea==$olindi or $olindi==$eea){
bot('deleteMessage',[
'chat_id'=>$botla,
'message_id'=>$message_id,
]);
}else{
$id = $update->callback_query->id;
$frid= $update->callback_query->from->id;
$ee1 = file_get_contents("rubl/olindi1.txt");
if(mb_stripos($ee1,$frid)!==false){
bot('answerCallbackQuery',[
'callback_query_id'=>$id,
'text'=>"⚠️ Kechirasiz, siz bu o‘yindan bonusni olib bo‘ldingiz!",
"show_alert"=>true,
]);
}else{
$bonusrand = rand(10,30);
$vaqt1 = date('H:i',strtotime('2 hour'));
$id = $update->callback_query->id;
$pul = file_get_contents("referal/$frid.txt");
$bonus=$pul+$bonusrand;
file_put_contents("referal/$frid.txt","$bonus");
file_put_contents("rubl/$frid.txt",1);
$frid= $update->callback_query->from->id;
bot('answerCallbackQuery',[
'callback_query_id'=>$id,
'text'=>"
🎉 Tabriklaymiz sizga $bonusrand ta Raketa taqdim etildi! 
💵 Hisobingizda: $bonus ta Raketa boʻldi",
'show_alert'=>true,
]);
file_put_contents("rubl/olindi1.txt","\n".$frid, FILE_APPEND);
$ee1 = file_get_contents("rubl/olindi1.txt");
$eea = substr_count($ee1,"\n"); 
$mm1 = file_get_contents("rubl/berildi1.txt");
$mm3 = $mm1+$bonusrand;
file_put_contents("rubl/berildi1.txt","$mm3");
$mn2 = file_get_contents("rubl/berildi1.txt");
$olindi=file_get_contents("bonus2.txt");
bot('editMessageText',[
'chat_id'=>$botla, 
'message_id'=>$message_id,
'text'=>"
🚀 O‘yin boshlandi!

⏩ Bonus olgan foydalanuvchilar: $eea/$olindi
🥝 Berilgan ta Raketa miqdori: $mn2 ta Raketa
✉️ @$ch2 chatida muhokama qiling!
📂 Rasmiy kanal: @$ch2
🔰 Homiy kanal: @$ch3
",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🚀 Bonusni olish","callback_data"=>"bo"]],
      [['text'=>"👨‍💻Admin",'url'=>"https://t.me/$adminuser"]],
            [['text'=>"✅Bosh homiy",'url'=>"https://t.me/By_konsbot"]],
]
]),
]);
}
}
}

if($data == "tekin"){
	bot('editMessageText',[
	'chat_id'=>$ccid,
	'message_id'=>$cmid,
	'text'=>"📋 Quyidagi boʻlimlardan birini tanlang!",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🖋 Nik bot",'callback_data'=>"nikbot"],['text'=>"❤️ Channel like",'callback_data'=>"channellike"]],
    [['text'=>"🕋Quron bot",'callback_data'=>"quron"],['text'=>"⚡Webhook bot",'callback_data'=>"webhook"]],
    [['text'=>"📽️Gif bot",'callback_data'=>"gif"],['text'=>"☢️ Konvertor bot",'callback_data'=>"konvertor"]],
    [['text'=>"🖼️Logo bot",'callback_data'=>"logo"],['text'=>"👨‍👨‍👧‍👦Go'zalik test bot",'callback_data'=>"guzalliktest"]],
    [['text'=>"👤Obunachi v0.1",'callback_data'=>"obunachi"],['text'=>"🔰Universal bot",'callback_data'=>"universal"]],
    [['text'=>"Harfga video bot 📎",'callback_data'=>"harfga"],['text'=>"Test bot",'callback_data'=>"test"]],
   [['text'=>"📟 Kalkulyator",'callback_data'=>"kalkulyator"],['text'=>"🔙 Orqaga",'callback_data'=>"shahzodga"]],

    ]
]),
]);
}
if($data == "group"){
	bot('editMessageText',[
	'chat_id'=>$ccid,
	'message_id'=>$cmid,
	'text'=>"📋 Quyidagi boʻlimlardan birini tanlang!",
        'reply_markup'=>$group,


 

]);
}
if($data == "pul"){
	bot('editMessageText',[
	'chat_id'=>$ccid,
	'message_id'=>$cmid,
	'text'=>"📋 Quyidagi boʻlimlardan birini tanlang!",
        'reply_markup'=>$pro_menu,


 

]);
}
if($data == "shahzodga"){
     bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
        'text'=>"🅞︎🅡︎🅠︎🅐︎🅖︎🅐︎ 🅠︎🅐︎🅨︎🅣︎🅓︎🅘︎🅝︎🅖︎🅘︎🅩︎",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"🆓️ Bepul bot (13)",'callback_data'=>"tekin"]],
[['text'=>"🔥Antiqa botlar (9)",'callback_data'=>"antiqa"]],
[['text'=>"💵 Pul bot (8)",'callback_data'=>"pul"]],
[['text'=>"⭐ Maxsus boʻlim(1)",'callback_data'=>"maxsus"]],
[['text'=>"↩️Oqaga",'callback_data'=>"orqagaa"],],
]
]),
]);
}
if($data=="qoida1"){
     bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
        'text'=>"⚠️ Qoidalar:
    
1. Ushbu robot maker bot adminstratorlari va bot  dasturchisi foydalanuvchilardan quydagilarni o'z zimmasiga olmasligi haqida sizga eslatib o'tadi:
1.1 ushbu botdan foydalangan holda ochilgan barcha botlar sizga pul to'lashi yoki to'lamasligj bu bizga bog'liq emas va biz sizga pul to'lamaymiz!
1.2 agar sizga ushbu botlar server orqali pul to'laydi deyishsa ishonmang yoki o'zingizda shunday xayol bo'lsa buni uniting chunki bu aqilsiz gap!
1.3 ushbu robot orqali bot ochgan zahotingiz barcha shart va qoidalar bilan tanishganingizni va rozi ekanligingizni o'z zimangizga olasiz!

2. ⚠️Ogohlantiramiz:
2.1 Taniqli shaxslar, mashxur savdo belgilari, kampaniya tashkilot nomlari, telegram kanal va veb-saytlar nomidan soxta bot ochib ish yuritish taqiqlanadi bunga ko'ra sizga tashkilot tomonidan ogohlantirish berilmaydi va ish sud tartibida ko'rib chiqiladi.
2.2 Foydalanuvchi tomonidan kiritilgan xar qanday ma'lumot va manbalar uchinchi shaxsga oshkor etilmaydi.
2.3 Foydalanuvchi tomonidan yasalagan botlarda quydagilar qatiyan taqiqlanadi!
+18 manba kanal va guruhlarga obunachi yig'ishda foydalanish.
Diniy aqidaparastlik kanalarda foydalanish.
Davlat siyosatiga zid yoki yolg'on manbalar tarqatuvchi kanalarga ulash va boshqlar...

3. ❗Eslatib o'tamiz:
√ botlar 100% xafsiz va faqat O'zbekistondagi telegram foydalanuvchilari foydalana oladi
√ barcha raqamlar barcha xisoblar o'chirilishidan avval sizni ogohlantiramiz.
√ qo'llab - quvvatlash xizmati sizga 24/7 soat davomida xizmat ko'rsatadi.
√ Sizning ma'lumotlaringiz xech kim tomonidan qayta ko'rib chiqilmaydi (2.1 dan tashqari hollarda)",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"🔚Orqaga",'callback_data'=>"orqa1"]],
]
])
]);
}
if($data == "orqa1"){
        bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
        'text'=>"📋 Quyidagi boʻlimlardan birini tanlang!",
        'reply_markup'=>$botchalaro,
]);
}
if($data == "antiqa"){
        bot('editMessageText',[
        'chat_id'=>$ccid,
          'message_id'=>$cmid,
        'text'=>"📋 Quyidagi boʻlimlardan birini tanlang!",
        'reply_markup'=>$antiqa_menu,
]);
}

if($data == "orqagaa"){
        bot('sendMessage',[
        'chat_id'=>$ccid,
        
        'text'=>"📋 Quyidagi boʻlimlardan birini tanlang!",
        'reply_markup'=>$main_menu,
]);
}

if(($tx == "/panel") and $cid == $admin){
    bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid]);
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"<b>👨‍💻Admin panelga xush kelibsiz.</b>",
    'parse_mode'=>"html",
    'reply_markup'=>$panel,
]);
}
if($data == "maxsus"){

     bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
          'text'=>"📋 Quyidagi boʻlimlardan birini tanlang!",
        'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"➕Avto Nakrutka v0.4",'callback_data'=>"nak"]],

[['text'=>"🔙 Orqaga",'callback_data'=>"shahzodga"]],
  ]  
    ]),    
    ]);
    
}