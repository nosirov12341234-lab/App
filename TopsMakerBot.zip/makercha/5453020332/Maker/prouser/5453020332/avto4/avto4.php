<?php
ob_start();
error_reporting(0);
define('API_KEY','5414704960:AAFlCi2Djufccm4LU6TGN59Mqs8GAFvWuU0');  //bot tokeni
$key=""; //api key partner.soc-proof.su saytidan olamz
$admin = "5453020332";
$adminuser="negaekana";
$botname = bot('getme',['bot'])->result->username;
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
 curl_setopt($ch,CURLOPT_URL,$url);
 curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
 curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
 $res = curl_exec($ch);
 if(curl_error($ch)){
  var_dump(curl_error($ch));
 }else{
  return json_decode($res);
}
}

$rek = "Reklama: @$adminuser - Admin bilan bog'lanish";

$update = json_decode(file_get_contents("php://input"));
$message = $update->message;
$chat_id = $message->chat->id;
$cid = $message->chat->id;
$mid = $message->message_id;
$text = $message->text;  
$tx = $message->text;  
$firstname = $message->chat->first_name;
$lastname = $message->chat->last_name;
$uid= $message->from->id;
$callcid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$callmid = $update->callback_query->message->message_id;  
$mes_idi = $update->callback_query->message->message_id;  
$from_id = $update->callback_query->from->id;
$step = file_get_contents('step/$chat_id.txt');
$type = $message->chat->type;
$lichka = file_get_contents("lichka.txt");
$referalim = file_get_contents("stat/channel_12.txt");
$obun = file_get_contents("stat/channel_11.txt");

$tgob_id = file_get_contents("stat/tgob_id.txt");
$tgob_id1 = file_get_contents("stat/tgob_id1.txt");
$tgpm_id = file_get_contents("stat/tgpm_id.txt");
$tgpm_id2 = file_get_contents("stat/tgpm_id2.txt");
$tgpm_id3 = file_get_contents("stat/tgpm_id3.txt");
$tgob_pul = file_get_contents("stat/tgob_pul.txt");
$tgob_pul1 = file_get_contents("stat/tgob_pul1.txt");
$tgpm_pul = file_get_contents("stat/tgpm_pul.txt");
$tgpm_pul2 = file_get_contents("stat/tgpm_pul2.txt");
$tgpm_pul3 = file_get_contents("stat/tgpm_pul3.txt");

$insta_id = file_get_contents("stat/insta_id.txt");
$instapm_id = file_get_contents("stat/instapm_id.txt");
$insta_pul = file_get_contents("stat/insta_pul.txt");
$instapm_pul = file_get_contents("stat/instapm_pul.txt");

$tiktok_id = file_get_contents("stat/tiktok_id.txt");
$tiktokpm_id = file_get_contents("stat/tiktokpm_id.txt");
$tiktok_pul = file_get_contents("stat/tiktok_pul.txt");
$tiktokpm_pul = file_get_contents("stat/tiktokpm_pul.txt");

$yt_id = file_get_contents("stat/yt_id.txt");
$ytpm_id = file_get_contents("stat/ytpm_id.txt");
$yt_pul = file_get_contents("stat/yt_pul.txt");
$ytpm_pul = file_get_contents("stat/ytpm_pul.txt");






if($type=="private"){
if(stripos($lichka,"$cid") !==false){
}else{
file_put_contents("lichka.txt","$lichkan$cid");
}
}

$asosiy = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"➕ Buyurtma berish"]],
 [['text'=>"💰 Pul ishlash"],['text'=>"💳 Hisobim"]],
[['text'=>"📊 Buyurtmani kuzatish"]],
[['text'=>"📨 Yordam"],['text'=>"📚 Bot haqida"]],
]
]);
$orqa="◀️Orqaga";

$back = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"◀️Orqaga"]]
]
]);
if($text=="◀️Orqaga"){
  unlink("step/$chat_id.txt");
  bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*Asosiy menyuga qaytdingiz.*",
    'parse_mode'=>'markdown',
    'reply_markup'=>$asosiy,
    ]);
}
$haqida = json_encode([
'inline_keyboard'=>[
[['text'=>"📊 Statistika",'callback_data'=>"stat"]],
[['text'=>"📚 Qo'llanma",'callback_data'=>"qol"]],
[['text'=>"📝 Qoida",'callback_data'=>"qoid"]],
]
]);
$pay = json_encode([
'inline_keyboard'=>[
[['text'=>"💳 Sotib olish",'callback_data'=>"buy"]],
[['text'=>"🗣 Taklifnoma",'callback_data'=>"ref"]],
[['text'=>"🎟 Promokod",'callback_data'=>"promo"]],
]
]);
$chanel_3 = file_get_contents("stat/chanel_3.txt");


if (file_get_contents("pul/$chat_id.txt")){
    // code...
}else{
    file_put_contents("pul/$chat_id.txt","0");
}
if($tx=="/start" and $type=="private"){

$chanel_1 = file_get_contents("stat/chanel_1.txt");
$ret = bot("getChatMember",[
         "chat_id"=>"@$chanel_1",
         "user_id"=>$cid,
         ]);
$chanel_2 = file_get_contents("stat/chanel_2.txt");
$ret1 = bot("getChatMember",[
         "chat_id"=>"@$chanel_2",
         "user_id"=>$cid,
         ]);
$stat = $ret->result->status;
$stat1 = $ret1->result->status;
 if(($stat=="creator" or $stat=="administrator" or $stat=="member") and ($stat1=="creator" or $stat1=="administrator" or $stat1=="member")){
bot("sendMessage",[
         "chat_id"=>$cid,
'text'=>"
✋ Assalomu alaykum, @$botname Official-botiga xush kelibsiz!
🚀 Biz sizga Telegram, Instagram xizmatlarini taklif etamiz!
🌟 Sizning sahifalaringizni obunachilari professional darajada ko'paytirish uchun @$botname Official siz bilan birga!
🔽 Davom etish uchun quyidagi tugmalardan birini tanlang:
$reklama
👨‍💻Dasturchi: @$adminuser",
'parse_mode'=>'html',
'reply_markup'=>$asosiy,
]);  
}
else{
     bot('sendmessage',[
'chat_id'=>$cid,
"text"=>"<b>Quyidagi kanalimizga obuna bo`lib qayta /start bosing⤵
1. @$chanel_1
2. @$chanel_2</b>",
"parse_mode"=>"html",
"reply_to_message_id"=>$message_id,
"disable_web_page_preview"=>true,
"reply_markup"=>json_encode([
'remove_keyboard'=>true,
]),
]);
return false;
}
}










mkdir("soni");
if(strpos($tx,"/start")!==false){
$refid = explode(" ",$tx);
$refid = $refid[1];
if($refid){
if(strpos($lichka, "$refid") !==false ){
if(strpos($lichka, "$cid") !==false ){
SendMessage($cid,html,"❌Xatolik Botga O'zingizni taklif qila olmaysiz");
}else{
file_put_contents("lichka.txt","$lichkan$cid");
$ab = file_get_contents("soni/$refid.soni");
$ab = $ab + 1;
file_put_contents("soni/$refid.soni","$ab");
$usr = file_get_contents("pul/$refid.txt");
$usr = $usr + $referalim; 
file_put_contents("pul/$refid.txt", "$usr");
bot('sendMessage',[
'chat_id'=>$refid,
'parse_mode'=>'markdown',
'text'=>"*🎉Tabriklaymiz siz botimizga do'stingizni taklif qildingiz!
⚡️Sizga $referalim So'm taqdim etildi ✔*
      
_Yana do‘stlaringizni taklif qilishda davom eting 💪", 
]);
}
}
}
}


mkdir("pul");
mkdir("step");
mkdir("nakrutka");
mkdir("kanal");
$ssilka=file_get_contents("nakrutka/$chat_id.txt");
$step=file_get_contents("step/$chat_id.txt");
$pul = file_get_contents("pul/$chat_id.txt");
$nakrutka=json_encode([
  'inline_keyboard'=>[
    [['text'=>"🔴 Instagram",'callback_data'=>"nakrutka=Instagram"],['text'=>"🔵 Telegram",'callback_data'=>"nakrutka=Telegram"]],
    [['text'=>"🖤 TikTok",'callback_data'=>"nakrutka=TikTok"],['text'=>"❤️ YouTube",'callback_data'=>"nakrutka=YouTube"]],
    ]
    ]);
$Telegram=json_encode([
  'inline_keyboard'=>[
  [['text'=>"🔰 Obunachi [Real members] $tgob_pul So'm",'callback_data'=>"Telegram=Obuna=$tgob_id=$tgob_pul"]],
[['text'=>"🔸 Obunachi [Arzon] $tgob_pul1 So'm",'callback_data'=>"Telegram=Obuna=$tgob_id1=$tgob_pul1"]],
[['text'=>"👁Ko‘rish [Arzon] $tgpm_pul So'm",'callback_data'=>"Telegram=PM=$tgpm_id=$tgpm_pul"]],

  [['text'=>"👁Ko‘rish [Oxirgi 5 post uchun] $tgpm_pul 3So'm",'callback_data'=>"Telegram=PM=$tgpm_id3=$tgpm_pul3"]],
  [['text'=>"$orqa",'callback_data'=>"back"]],
  ]
  ]);
$TikTok=json_encode([
  'inline_keyboard'=>[
  [['text'=>"⚫ Obunachi [Arzon] $tiktok_pul So'm",'callback_data'=>"TikTok=Obuna=$tiktok_id=$tiktok_pul"]],
  [['text'=>"👁Ko‘rish [Real] $tiktokpm_pul So'm",'callback_data'=>"TikTok=PM=$tiktokpm_id=tiktokpm_pul"]],
  [['text'=>"$orqa",'callback_data'=>"back"]],
  ]
  ]);
$Instagram=json_encode([
  'inline_keyboard'=>[
  [['text'=>"🔒 Obunachi [Real] $insta_pul So'm",'callback_data'=>"Instagram=Obuna=$insta_id=$insta_pul"]],
  [['text'=>"👁 Ko'rish [Tez] $instapm_pul So'm",'callback_data'=>"Instagram=PM=$instapm_id=$instapm_pul"]],
  [['text'=>"$orqa",'callback_data'=>"back"]],
  ]
  ]);
$YouTube=json_encode([
  'inline_keyboard'=>[
  [['text'=>"❤️ Obunachi [Kafolatlangan] $yt_pul So'm",'callback_data'=>"YouTube=Obuna=$yt_id=$yt_pul"]],
  [['text'=>"👁 Ko'rish [video] $ytpm_pul So'm",'callback_data'=>"YouTube=PM=ytpm_id=$ytpm_pul"]],
  [['text'=>"$orqa",'callback_data'=>"back"]],
  ]
  ]);

if(mb_stripos($data,"nakrutka")!==false){
  bot('DeleteMessage',[
    'chat_id'=>$callcid,
    'message_id'=>$update->callback_query->message->message_id,
    ]);
    $ex=explode("=",$data)[1];
   if($ex=="Telegram"){
   $key=$Telegram;
}
   if($ex=="TikTok"){
   $key=$TikTok;
}
   if($ex=="Instagram"){
   $key=$Instagram;
}
   if($ex=="YouTube"){
   $key=$YouTube;
}
  bot('sendmessage',[
    'chat_id'=>$callcid,
    'text'=>"$ex nakrutka uchun kerakli turini tanlang n💰Narxlar 1000ta Buyurtma Hisobida Ko'rsatilayapti.",
    'parse_mode'=>'markdown',
    'reply_markup'=>$key,
    ]);
}
 /* @qobilbek1 */

if(mb_stripos($data,"=Like")!==false or mb_stripos($data,"=PM")!==false or mb_stripos($data,"=Obuna")!==false){
  bot('DeleteMessage',[
    'chat_id'=>$callcid,
    'message_id'=>$update->callback_query->message->message_id,
    ]);
  $tarmoq=explode("=",$data)[0];
   $tur=explode("=",$data)[1];
  $id=explode("=",$data)[2];
  $qb=explode("=",$data)[3];
file_put_contents("step/$callcid.txt","nak=$tarmoq=$tur=$id=$qb");
  bot('sendmessage',[
    'chat_id'=>$callcid,
    'text'=>"Kerakli miqdorni kirting",
    'reply_markup'=>json_encode([
      'inline_keyboard'=>[       
        [['text'=>"$orqa",'callback_data'=>"back"],],
        ]
      ])
    ]);
}
if(mb_stripos($step,"nak=")!==false){
  if(is_numeric($text) and $text>0){
  $ex=explode("=",$step);
  $tarmoq=$ex[1];
   $tur=$ex[2];
if($tarmoq=="Telegram"){
$min=1000;
$max=15000;
}
if($tarmoq=="YouTube"){
$min=100;
$max=25000;
}
if($tarmoq=="TikTok"){
$min=500;
$max=50000;
}

if($tarmoq=="Instagram"){
$min=20;
$max=15000;
}
  $tur=$ex[2];
  $id=$ex[3];
  $qb=$ex[4];
  $son=$text;
if($text>=$min and $text<=$max){
  unlink("step/$chat_id.txt");
file_put_contents("step/$chat_id.txt","havola=$tarmoq=$id=$son=$tur=$qb");
  bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"$tarmoq havolangizni yuboring(https:// bo'lishi shart)",
    'reply_markup'=>$back,
    ]);
}else{
bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"Minimal: $min Maximal: $max son oralig‘ida kiriting",
    'reply_markup'=>$back,
    ]);
}
}else{
bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"Faqat raqamdan tashkil topgan bo‘lsin",
    'reply_markup'=>$back,
    ]);
}
}
if(mb_stripos($step,"havola")!==false and $text!=$orqa){
  if(mb_stripos($text,"https:")!==false){
    $ex=explode("=",$step);
    $tarmoq=$ex[1];
    $id=$ex[2];
    $son=$ex[3];
    $tur=$ex[4];
    $qb=$ex[5];
    if($tarmoq=="TikTok"){
      $rak=$son/1000*$qb;
    }elseif($tarmoq=="YouTube"){
      $rak=$son/1000*$qb;
    }elseif($tarmoq=="Telegram"){
      $rak=$son/1000*$qb;
    }elseif($tarmoq=="Instagram"){
      $rak=$son/1000*$qb;
    }
    if($pul>$rak){
    $info=str_replace("$tarmoq","🌐 $tarmoq tarmog'i uchun $son buyurtmaga $rakSo'm hisobingizdan yechiladi ",$tarmoq);
    bot('sendMessage',[
      'chat_id'=>$chat_id,
      'text'=>"
<b>⭕️Buyurtma haqida
🌐Tarmoq: $tarmoq
🔤Miqdor: $son
🔢Havola: $text

<b>💢$info 💢</b>

❗Iltimos ko'rib chiqing hamma malumot to'g'ri bo'lsa ✅Tasdiqlang...!</b>",
      'parse_mode'=>"html",
          'disable_web_page_preview'=>true,
      'reply_markup'=>json_encode([
        'inline_keyboard'=>[          
          [['text'=>"✅Tasdiqlash",'callback_data'=>"tasdiq"],],
          [['text'=>"$orqa",'callback_data'=>"back"],],
          ]
        ])
      ]);
      unlink("step/$chat_id.txt");
file_put_contents("step/$chat_id.txt","uz=$tarmoq=$son=$rak=$id=$tur=$qb");
file_put_contents("nakrutka/$chat_id.txt","$text");
  }else{
    unlink("step/$chat_id.txt");
    bot('sendMessage',[
      'chat_id'=>$chat_id,
      'text'=>"<b>💸Mablag' yetarli emas....!</b>",
           'parse_mode'=>"html",
      'reply_markup'=>$asosiy,
      ]);
  }
  }else{
    bot('sendMessage',[
      'chat_id'=>$chat_id,
      'text'=>"<b>☹️Havola noto'g'ri.... To'g'rilab qayta yuboring!</b>",
      'parse_mode'=>"html",
      'reply_markup'=>$back,
      ]);
  }
}

if(mb_stripos($data,"tasdiq")!==false){
$step=file_get_contents("step/$callcid.txt");
 $ex=explode("=",$step);
 $tarmoq=$ex[1];
 $son=$ex[2];
 $rak=$ex[3];
 $id=$ex[4];
$url=file_get_contents("nakrutka/$callcid.txt");
$tur=$ex[5];
bot('DeleteMessage',[
    'chat_id'=>$callcid,
    'message_id'=>$update->callback_query->message->message_id,
    ]);
$urll=json_decode(file_get_contents("https://partner.soc-proof.su/api/v2?key=$chanel_3&action=add&link=$url&quantity=$son&service=$id"),true);
$order=$urll['order'];
$error=$urll['error'];
file_put_contents("nakrutka/$callcid.dat",file_get_contents('nakrutka/$callcid.dat')."n".$order);
if(isset($error)){
if($error=="Quantity must be multiple of 1000"){
bot('sendMessage',[
   'chat_id'=>$callcid,
   'text'=>"<b>⛔️Xatolik...
Buyurtma uchun sonlarni quyidagicha kiriting!👇</b>
<code>
1000
2000</code>",
      'parse_mode'=>"html",
      'reply_markup'=>$asosiy,
   ]);
}else{
bot('sendMessage',[
   'chat_id'=>$callcid,
   'text'=>"<b>🚫Ushbu manzil uchun buyurtma berilgan boshqa havola manzili kiriting yoki kuting</b>",
      'parse_mode'=>"html",
      'reply_markup'=>$asosiy,
   ]);
}
}else{
$balans= file_get_contents("pul/$callcid.txt");
     $plus=$balans-$rak;
  $b = file_put_contents("pul/$callcid.txt","$plus");
 $info=str_replace("$tarmoq","🌐 $tarmoq tarmog'i uchun $son buyurtmaga $rakSo'm hisobingizdan yechildi✅",$tarmoq);
 bot('sendMessage',[
   'chat_id'=>$callcid,
   'text'=>"
🔒<b>Buyurtma qabul qilindi!</b>
🆔<b>Buyurtma ID: $order</b>
✅<b>Holati: Bajarilmoqda...</b>
🌐<b>Tarmoq $tarmoq</b>
🔢<b>Buyurtma soni:</b> <b>$son</b>

<b>💢$info 💢</b>",
      'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>$asosiy,
   ]);
unlink("step/$callcid.txt");
unlink("nakrutka/$callcid.txt");
}
}

if($data=="back"){
  bot('DeleteMessage',[
    'chat_id'=>$callcid,
    'message_id'=>$update->callback_query->message->message_id,
    ]);
  bot('sendmessage',[
    'chat_id'=>$callcid,
    'text'=>"✅ Bizning xizmatlarimizni tanlaganingizdan xursandmiz!
👇 Quydagi Ijtimoiy tarmoqlardan birini tanlang.",
    'reply_markup'=>$nakrutka,
    ]);
}
 /* @qobilbek1 */


  if($text=="➕ Buyurtma berish"){
  unlink("step/$chat_id.txt");
  bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"✅ Bizning xizmatlarimizni tanlaganingizdan xursandmiz!
👇 Quydagi Ijtimoiy tarmoqlardan birini tanlang.",
    'reply_markup'=>$nakrutka,
    ]);
}
  
  if($text == "💰Balans"){
    $balans = file_get_contents("pul/$chat_id.txt");
bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"<b>👤 $firstnamen➳➳➳➳➳➳➳➳➳➳➳➳➳➳➳➳➳ n👤Hisobingizda $balansSo'm  Mavjud.n
➳➳➳➳➳➳➳➳➳➳➳➳➳➳➳➳➳</b>",
        'parse_mode'=>'html',
        'reply_markup'=>$olish,
]);
}


if($text=="🪙API Balans" and $chat_id==$admin){
$api_balance = json_decode(file_get_contents("https://partner.soc-proof.su/api/v2?key=$chanel_3&action=balance"),true);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"Sizning API Balansingizda
".$api_balance['balance']." Rubl",
'reply_markup'=>$panel,
]);
}

if($data=="promo"){
bot('editMessagetext',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
'text'=>"<b>🎫 Promokodni kiriting:</b>",
'parse_mode'=>"HTML",
]);
}         

if($text=="💰Sotib Olish"){
  bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"<b>💵 Qanday to'lov usulida So'm sotib olmoqchisiz?
Karta, Paynet va qiwi orqali toʻlovlar qilish tavsiya etiladi.
[1So'm = 94 soʻm] [10So'm = 940 soʻm]
QiWi orqali 
[1So'm = 1So'm] [10So'm = 10So'm]</b>
<b>Karta orqali:</b> <code>9860 0303 7635 3634</code>
<b>QiWi orqali:</b> <code>+998999713149</code>
<b>Paynet orqali:</b> <code>+998917350331</code>
<b>Tolov amalga oshiring va adminga murojaat qiling</b>",
'parse_mode'=>'html',
'reply_markup'=>$olish,
    ]);
}

if($text=="☎️"){
  bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*🔰 Bizga savollaringiz yoki muammolaringiz bo'lsa, iltimos, bizning qo'llab-quvvatlash jamoamiz bilan bog'laning.
Admin: @qobilbek1*",
'parse_mode'=>'markdown',
    ]);
}
$panel = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"📝Userga Xabar"],['text'=>"📋Userga Forward"]],
[['text'=>"➕So'm berish"],['text'=>"➖So'm ayirish"]],
[['text'=>"🪙API Balans"],['text'=>"📊Statistika"]],
[['text'=>"🛠 Sozlash"],['text'=>"💡 Promokod kanali"]],
[['text'=>"🎟 Promokod"]],
]
]);

$okstat=file_get_contents("status/$cid.status");
if($text=="📊 Buyurtmani kuzatish"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"Buyurtma ID-raqamini kiriting",
]);
mkdir("status");
file_put_contents("status/$cid.status","1");
}
if($okstat==1){
if(is_numeric($text)){
$orderstat=json_decode(file_get_contents("https://partner.soc-proof.su/api/v2?key=$chanel_3&action=status&order=$text"),true);
$miqdor=$orderstat['charge'];
if($orderstat['status'] !=null or $orderstat['remains'] !=null){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"
Buyurtma xolati: ".$orderstat['status']."
Buyurtma miqdori: ".$orderstat['remains']."",
]);unlink("status/$cid.status");
}else{
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>" Mavjud emas" ,
]);
unlink("status/$cid.status");
}
}
}

if($text=="🎟 Promokod"){
$hisob  = file_get_contents("pul/$chat_id.txt");
bot("sendmessage",[
'chat_id'=>$admin,
'text'=>" Promo kod yasash uchun
/promo promokod
masalan
/promo 79j585h67ht",
]);
}
$promo = file_get_contents("ch10.txt");
$ball = file_get_contents("ch22.txt");
$prm = file_get_contents("pro.txt");
$aa = "$prm";  //promokod yuboriladigan kanal id raqami
$ab = "$prm"; //promokod ishlatilganligi haqida yuboriladigan kanalid raqami
if(mb_stripos($text, "/promo")!==false){
	$m1 = explode(" ",$text);
 $m2 = $m1[1];
 file_put_contents("ch10.txt","$m2");
 bot('sendMessage',[
'chat_id'=>$admin,
'text'=>"Promokod $promo
qancha olmos berilsin
/ball olmos miqdori yozing
Masalan
/ball 40",
]);
}

if(mb_stripos($text, "/ball")!==false){
	$m1 = explode(" ",$text);
 $m2 = $m1[1];
 file_put_contents("ch22.txt","$m2");
$ball = file_get_contents("ch22.txt");
$prm = file_get_contents("pro.txt");
 bot('sendMessage',[
'chat_id'=>$admin,
'text'=>"<b>Tayyor, promokod $prm ga yuborildi!</b>",
"parse_mode"=>"html",
 ]);
 bot("sendmessage",[
 'chat_id'=>$aa,
 'text'=>"<b>💡 Yangi Promokod!</b>

<i>🎫 Promokod:</i> <code>O$promo</code>
<i>Promokod qiymati:</i> <b>$ball UZS</b>",
 'parse_mode'=>"html",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"🤖 Botga o'tish", "url"=>"https://t.me/$botname"]],
]
])
]);
}

if($text=="$promo"){
$hisob  = file_get_contents("pul/$chat_id.txt");
$plus = $hisob + $ball;
file_put_contents("pul/$chat_id.txt","$plus");
bot("sendmessage",[
'chat_id'=>$cid,
'text'=>"<i> <b>🎁 Promokod qabul qilindi!
💵 Hisobingizga $ball Uzs berildi</b> </i>",
'parse_mode'=>"html",
]);
unlink("ch10.txt");
bot('sendmessage',[
'chat_id'=>$ab,
'text'=>"<b>⚠️ Promokod ishlatildi</b>

<b>👤 Foydalanuvchi - ".$message->from->first_name."
➕ Unga $ball uzs berildi</b>",
'parse_mode'=>'html',
]);
unlink("ch22.txt");
}
$ss=file_get_contents("admin.txt");
if($text=="💡 Promokod kanali" and $cid==$admin){
file_put_contents("admin.txt","og");
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"Kanalingiz manzilini yuborishdan avval botni kanalingizga admin qilib olishingiz kerak!

<b>📢 Kerakli kanalni manzilini yuboring:</b>

Namuna: @By_php",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($ss=="og" and $cid==$admin){
file_put_contents("pro.txt","$text");
$pro = file_get_contents("pro.txt");
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"*$pro Ulandi!*",
"parse_mode"=>"markdown",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
}
if($text=="📚 Bot haqida"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>$text."<b>Malumot olish uchun quyidagi menyulardan birini tanlang-Bo'limi</b>",
      'parse_mode'=>"html",
'reply_markup'=>$haqida,
]);
}
if($data=="qoid"){
bot('editMessageText',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
'text'=>"<b>@$botname Qoidalari❗️
• Adminga yolgʻon xabar yubormang. Bu uchun botda ban olishingiz mumkin
• Yordam boʻlimidan foydalanayotganda adminga haqiratli soʻz yozmang. Bu uchun botda ban olishingiz mumkin.
• Buyurtma berilgan linkning buyurtmasi bajarilmasdan oʻsha link uchun yana buyurtma bermang. Bu holdagi xatolik uchun sizga pul qaytarilmaydi.
• Admindan tekinga yoki savob uchun hisobingizni toʻldirishni soʻramang.

Qoʻshimcha maʼlumotlar olish uchun @$adminuser bilan bogʻlaning.</b>  ",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🧑‍💻Admin",'url'=>"https://t.me/$adminuser"]],
]]),]);}
if($data=="qol"){
bot('editMessagetext',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
'text'=>"<b>@$botname dan foydalanish.
•Qanday buyurtma berish mumkin ?
Buyurtma berish boʻlimiga kiring. Oʻzingizga kerakli Ijtimoiy tarmoqni tanlang. Soʻng xizmatni tanlang. Kerakli obunachi miqdorini yozing va kerrakli linkni kiriting. 
•Hisobni qanday toʻldirish mumkin ?
Hisobim boʻlimiga kiring. U yerdan hisobni toʻldirish boʻlimini tanlang. Oʻzizga kerakli toʻlov usulini tanlang va bot bergan qoʻllanma boʻyicha ish tuting.

Sizda boshqacharoq savol va murojaatlar boʻlsa @$adminuser bilan bogʻlaning.</b> ",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🚀Bot admini",'url'=>"https://t.me/$adminuser"]],
]]),]);}
if($data=="stat"){
bot('editMessageText',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
'text'=>" 📊 <b>Bot foydalanuvchilari soni</b>:" .substr_count($lichka,"n")." ta",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🧑‍💻Admin",'url'=>"https://t.me/$adminuser"]],
]]),]);}
$nakpanel = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🔵 Telegram"],['text'=>"🔴 Instagram"]],
[['text'=>"🟠 YouTube"],['text'=>"⚫ TikTok"]],
]
]);

$step = file_get_contents("stat/$cid.step");
   if($tx=="💰 Narxlarni sozlash" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Assalomu alaykum
Bu bölimda siz Nakrutka Turlarini(Sifatli,sifatsis,Garant) va Narxlarini uzingiz sozlab olishingiz mumkun böladi.
Batafsil rasimda👇👇👇👇
1 - Bu amal orqali siz nakrutkaning qaysi tarmoqa xizmat körsatishini tallaysiz.
2 - Bu Nakrutkaning narxi.(har 1000ta uchun)
3 - Bu Id raqam bu orqali bot sayt orqali muloqot qiladi.
4 - Bu yerda batafsil ma'lumot berilgan yani siz tallagan xizmat qandayligi, necha daqiqada tugatilishi hamma hammasi 

https://t.me/Edit_Uz/57384

Panelga utish uchun
<b>/nakrutka</b> 👈 ushbu kók yozuvni ustiga bosing.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[

    ]
    ])
    ]);
    }


$step = file_get_contents("stat/$cid.step");
   if($tx=="🔵 Telegram" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Assalomu alaykum
<b>Bu bulimda siz nakrutka id rqamlarini va narxlarini uzingiz belgilashingiz mumkun buladi. Chap tomon id, Óng tomon Narxni uzgartiradi.</b> Kerakli tugmani tallang.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
[['text'=>"🆔TG Obuachi[Real]"],['text'=>"💰TG Obuachi[Real]"]],
[['text'=>"🆔TG Obuachi[Arzon]"],['text'=>"💰TG Obuachi[Arzon]"]],
[['text'=>"🆔TG Kórishlar[Arzon]"],['text'=>"💰TG Kórishlar[Arzon]"]],

[['text'=>"🆔TG Kórishlar[5Post]"],['text'=>"💰TG Kórishlar[5Post]"]],
[['text'=>"/start"],['text'=>"/nakrutka"]],
    ]
    ])
    ]);
    }

$step = file_get_contents("stat/$cid.step");
   if($tx=="⚫ TikTok" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Assalomu alaykum
<b>Bu bulimda siz nakrutka id rqamlarini va narxlarini uzingiz belgilashingiz mumkun buladi. Chap tomon id, Óng tomon Narxni uzgartiradi.</b> Kerakli tugmani tallang.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
[['text'=>"🆔TikTok Obuachi"],['text'=>"💰TikTok Obuachi"]],
[['text'=>"🆔TikTok Kórishlar[Tez]"],['text'=>"💰TikTok Kórishlar[Tez]"]],
[['text'=>"/start"],['text'=>"/nakrutka"]],
    ]
    ])
    ]);
    }
$step = file_get_contents("stat/$cid.step");
   if($tx=="🔴 Instagram" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Assalomu alaykum
<b>Bu bulimda siz nakrutka id rqamlarini va narxlarini uzingiz belgilashingiz mumkun buladi. Chap tomon id, Óng tomon Narxni uzgartiradi.</b> Kerakli tugmani tallang.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
[['text'=>"🆔Insta Obuachi"],['text'=>"💰Insta Obuachi"]],
[['text'=>"🆔Insta Kórishlar[Tez]"],['text'=>"💰Insta Kórishlar[Tez]"]],
[['text'=>"/start"],['text'=>"/nakrutka"]],
    ]
    ])
    ]);
    }

$step = file_get_contents("stat/$cid.step");
   if($tx=="🟠 YouTube" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Assalomu alaykum
<b>Bu bulimda siz nakrutka id rqamlarini va narxlarini uzingiz belgilashingiz mumkun buladi. Chap tomon id, Óng tomon Narxni uzgartiradi.</b> Kerakli tugmani tallang.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
[['text'=>"🆔 YouTube Obunachi"],['text'=>"💰 YouTube Obunachi"]],
[['text'=>"🆔 YouTube Kórishlar[Tez]"],['text'=>"💰 YouTube Kórishlar[Tez]"]],
[['text'=>"/start"],['text'=>"/nakrutka"]],
    ]
    ])
    ]);
    }
mkdir("stat");
if($tx == "🛠 Sozlash" and $cid == $admin){
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"<i>Majburiy a‘zolik kanallarini,Api kalitni va Narxlarni uzgartirish uchun Panel</i>

<b>Eslatma:</b> <i>Kerakli bólimni tallasangiz bas</i>",
    'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
[['text'=>"1⃣ - Kanal"],['text'=>"2⃣ - Kanal"]],
[['text'=>"❤️Api Sozlash"],['text'=>"💰 Narxlarni sozlash"]],
[['text'=>"👥 Referalni sozlash"],['text'=>"/start"]],

    ]
    ])
    ]);
    }
     $step = file_get_contents("stat/$cid.step");
   if($tx=="1⃣ - Kanal" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>1-kanalni sozlash uchun kanalingiz usernamesini yuboring, <b>e‘tibor bering kanalingiz useriga @ belgisini</b> qo‘shmasdan yuboring.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
file_put_contents("stat/$cid.step","chanel_1");
} 

if($step=="chanel_1" and $cid==$admin){ 
file_put_contents("stat/chanel_1.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning birinchi kanalingiz @$tx ga o‘zgartirildi.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
unlink("stat/$cid.step"); 
}
$step = file_get_contents("stat/$cid.step");
if($tx=="2⃣ - Kanal" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>2-kanalni sozlash uchun kanalingiz usernamesini yuboring, <b>e‘tibor bering kanalingiz useriga @ belgisini</b> qo‘shmasdan yuboring.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
file_put_contents("stat/$cid.step","chanel_2");
} 
 
if($step=="chanel_2" and $cid==$admin){ 
file_put_contents("stat/chanel_2.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning ikkinchi kanalingiz @$tx ga o‘zgartirildi.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
unlink("stat/$cid.step"); 
}
  $step = file_get_contents("stat/$cid.step");
   if($tx=="❤️Api Sozlash" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Api kalitni  sozlash uchun yuboring, <b>uni ushbu saytdan olasiz </b> ‼️.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
file_put_contents("stat/$cid.step","chanel_3");
} 

if($step=="chanel_3" and $cid==$admin){ 
file_put_contents("stat/chanel_3.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning api kalitingiz $tx ga o‘zgartirildi.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
unlink("stat/$cid.step"); 
}
$step = file_get_contents("stat/$cid.step");
if($tx=="👥 Referalni sozlash" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Referal narxini kiriting.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
file_put_contents("stat/$cid.step","channel_12");
} 

if($step=="channel_12" and $cid==$admin){ 
file_put_contents("stat/channel_12.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Referal narxi $tx ga o‘zgartirildi.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
unlink("stat/$cid.step"); 
}

if($step=="channel_11" and $cid==$admin){ 
file_put_contents("stat/channel_11.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Obuna narxi $tx ga o‘zgartirildi.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
unlink("stat/$cid.step"); 
}


  $step = file_get_contents("stat/$cid.step");
   if($tx=="🆔TG Obuachi[Real]" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Id Raqamni sozlashi uchun uni yuboring.
Taxminiy id raqam👉<b>457</b></i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","tgob_id");
} 

if($step=="tgob_id" and $cid==$admin){ 
file_put_contents("stat/tgob_id.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning id raqamingiz uzgartirildi.
Hozirgi id raqam👉<b>$tx</b> </i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}
  $step = file_get_contents("stat/$cid.step");
   if($tx=="🆔TG Obuachi[Arzon]" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Id Raqamni sozlashi uchun uni yuboring.
Taxminiy id raqam👉<b>457</b></i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","tgob_id1");
} 

if($step=="tgob_id1" and $cid==$admin){ 
file_put_contents("stat/tgob_id1.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning id raqamingiz uzgartirildi.
Hozirgi id raqam👉<b>$tx</b> </i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="🆔TG Kórishlar[Arzon]" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Id Raqamni sozlashi uchun uni yuboring.
Taxminiy id raqam👉<b>457</b></i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","tgpm_id");
} 

if($step=="tgpm_id" and $cid==$admin){ 
file_put_contents("stat/tgpm_id.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning id raqamingiz uzgartirildi.
Hozirgi id raqam👉<b>$tx</b> </i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="🆔TG Kórishlar[Tez]" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Id Raqamni sozlashi uchun uni yuboring.
Taxminiy id raqam👉<b>457</b></i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","tgpm_id2");
} 

if($step=="tgpm_id2" and $cid==$admin){ 
file_put_contents("stat/tgpm_id2.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning id raqamingiz uzgartirildi.
Hozirgi id raqam👉<b>$tx</b> </i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="🆔TG Kórishlar[5Post]" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Id Raqamni sozlashi uchun uni yuboring.
Taxminiy id raqam👉<b>457</b></i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","tgpm_id3");
} 

if($step=="tgpm_id3" and $cid==$admin){ 
file_put_contents("stat/tgpm_id3.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning id raqamingiz uzgartirildi.
Hozirgi id raqam👉<b>$tx</b> </i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="🆔Insta Obuachi" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Id Raqamni sozlashi uchun uni yuboring.
Taxminiy id raqam👉<b>457</b></i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","insta_id");
} 

if($step=="insta_id" and $cid==$admin){ 
file_put_contents("stat/insta_id.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning id raqamingiz uzgartirildi.
Hozirgi id raqam👉<b>$tx</b> </i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="🆔Insta Kórishlar[Tez]" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Id Raqamni sozlashi uchun uni yuboring.
Taxminiy id raqam👉<b>457</b></i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","instapm_id");
} 

if($step=="instapm_id" and $cid==$admin){ 
file_put_contents("stat/instapm_id.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning id raqamingiz uzgartirildi.
Hozirgi id raqam👉<b>$tx</b> </i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="🆔TikTok Obuachi" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Id Raqamni sozlashi uchun uni yuboring.
Taxminiy id raqam👉<b>457</b></i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","tiktok_id");
} 

if($step=="tiktok_id" and $cid==$admin){ 
file_put_contents("stat/tiktok_id.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning id raqamingiz uzgartirildi.
Hozirgi id raqam👉<b>$tx</b> </i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="🆔TikTok Kórishlar[Tez]" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Id Raqamni sozlashi uchun uni yuboring.
Taxminiy id raqam👉<b>457</b></i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","tiktokpm_id");
} 

if($step=="tiktokpm_id" and $cid==$admin){ 
file_put_contents("stat/tiktokpm_id.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning id raqamingiz uzgartirildi.
Hozirgi id raqam👉<b>$tx</b> </i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="🆔 YouTube Obunachi" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Id Raqamni sozlashi uchun uni yuboring.
Taxminiy id raqam👉<b>457</b></i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","yt_id");
} 

if($step=="yt_id" and $cid==$admin){ 
file_put_contents("stat/yt_id.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning id raqamingiz uzgartirildi.
Hozirgi id raqam👉<b>$tx</b> </i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="🆔 YouTube Kórishlar[Tez]" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Id Raqamni sozlashi uchun uni yuboring.
Taxminiy id raqam👉<b>457</b></i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","ytpm_id");
} 

if($step=="ytpm_id" and $cid==$admin){ 
file_put_contents("stat/ytpm_id.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning id raqamingiz uzgartirildi.
Hozirgi id raqam👉<b>$tx</b> </i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}
######Id tugadi endi pul#######

  $step = file_get_contents("stat/$cid.step");
   if($tx=="💰TG Obuachi[Real]" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Narxni sozlashi uchun uni yuboring.
Taxminiy narx👉<b>57</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","tgob_pul");
} 

if($step=="tgob_pul" and $cid==$admin){ 
file_put_contents("stat/tgob_pul.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning narxingiz uzgartirildi.
Hozirgi narx👉<b>$tx</b> </i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}
  $step = file_get_contents("stat/$cid.step");
   if($tx=="💰TG Obuachi[Arzon]" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Narxni sozlashi uchun uni yuboring.
Taxminiy narx👉<b>47</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","tgob_pul1");
} 

if($step=="tgob_pul1" and $cid==$admin){ 
file_put_contents("stat/tgob_pul1.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning narxingiz uzgartirildi.
Hozirgi narx👉<b>$tx</b> </i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="💰TG Kórishlar[Arzon]" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Narxni sozlashi uchun uni yuboring.
Taxminiy narx👉<b>45</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","tgpm_pul");
} 

if($step=="tgpm_pul" and $cid==$admin){ 
file_put_contents("stat/tgpm_pul.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning narxingiz uzgartirildi.
Hozirgi narx👉<b>$tx</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="💰TG Kórishlar[Tez]" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Narxini sozlashi uchun uni yuboring.
Taxminiy narx👉<b>7</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","tgpm_pul2");
} 

if($step=="tgpm_pul2" and $cid==$admin){ 
file_put_contents("stat/tgpm_id2.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning narxingiz uzgartirildi.
Hozirgi narx👉<b>$tx</b> </i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="💰TG Kórishlar[5Post]" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Narxni sozlashi uchun uni yuboring.
Taxminiy narx👉<b>4</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","tgpm_pul3");
} 

if($step=="tgpm_pul3" and $cid==$admin){ 
file_put_contents("stat/tgpm_pul3.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning narxingiz uzgartirildi.
Hozirgi narx👉<b>$tx</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="💰Insta Obuachi" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Narxni sozlashi uchun uni yuboring.
Taxminiy narx👉<b>47</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","insta_pul");
} 

if($step=="insta_pul" and $cid==$admin){ 
file_put_contents("stat/insta_pul.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning narxingiz uzgartirildi.
Hozirgi narx👉<b>$tx</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="💰Insta Kórishlar[Tez]" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Narxni sozlashi uchun uni yuboring.
Taxminiy narx👉<b>57</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","instapm_pul");
} 

if($step=="instapm_pul" and $cid==$admin){ 
file_put_contents("stat/instapm_pul.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning narxingiz uzgartirildi.
Hozirgi narx👉<b>$tx</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="💰TikTok Obuachi" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Narxni sozlashi uchun uni yuboring.
Taxminiy narx👉<b>57</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","tiktok_pul");
} 

if($step=="tiktok_pul" and $cid==$admin){ 
file_put_contents("stat/tiktok_pul.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning narxingiz uzgartirildi.
Hozirgi narx👉<b>$tx</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="💰TikTok Kórishlar[Tez]" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Narxni sozlashi uchun uni yuboring.
Taxminiy narx👉<b>4</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","tiktokpm_pul");
} 

if($step=="tiktokpm_pul" and $cid==$admin){ 
file_put_contents("stat/tiktokpm_pul.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning narxingiz uzgartirildi.
Hozirgi narx👉<b>$tx</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="💰 YouTube Obunachi" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Narxni sozlashi uchun uni yuboring.
Taxminiy narx👉<b>47</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","yt_pul");
} 

if($step=="yt_pul" and $cid==$admin){ 
file_put_contents("stat/yt_pul.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning narxingiz uzgartirildi.
Hozirgi narx👉<b>$tx</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}

  $step = file_get_contents("stat/$cid.step");
   if($tx=="💰 YouTube Kórishlar[Tez]" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Narxni sozlashi uchun uni yuboring.
Taxminiy narx👉<b>57</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
file_put_contents("stat/$cid.step","ytpm_pul");
} 

if($step=="ytpm_pul" and $cid==$admin){ 
file_put_contents("stat/ytpm_pul.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Sizning narxingiz uzgartirildi.
Hozirgi narx👉<b>$tx</b> So'm</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$nakpanel, 
]); 
unlink("stat/$cid.step"); 
}



if($text == "/panel" and $cid==$admin ){
	bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"<b>Assalamu alaykum <a href='tg://user?id=$uid'>Admin</a></b>nn<i>Kerakli boʻlimni tanlang!!</i>",
	'parse_mode'=>"html",
	'reply_markup'=>$panel,
]);
}
if($text == "/nakrutka" and $cid==$admin ){
	bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"<i>Assalomu alaykum
<b>Bu bulimda siz nakrutka id rqamlarini va narxlarini uzingiz belgilashingiz mumkun buladi.</b> Kerakli tugmani tallang.</i>",
	'parse_mode'=>"html",
	'reply_markup'=>$nakpanel,
]);
}


if($text=="📊Statistika" && $cid==$admin){
bot('deleteMessage',[
'chat_id'=>$cid,
'message_id'=>$mid,
]);
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"
@$botname statistikasi
Bot azolari ".substr_count($lichka,"n")." ta ",
'reply_markup'=>$panel,
]);
}

function send($c,$m,$p){
bot('sendMessage',[
'chat_id'=>$c,
'text'=>$m,
'parse_mode'=>$p,
]);
}

     
if($text == "📝Userga Xabar" and $cid == $admin){
      bot('sendMessage',[
      'chat_id'=>$cid,
      'text'=>"<b>Userlarga yuboriladigan habarni kiriting!!</b>",
      'parse_mode'=>"html",
      'reply_markup'=>$panel,
      ]);
      file_put_contents("step/$cid.step","user");
    }

    if($step == "user" and $cid == $admin){
      if($text == "/cancel"){
      unlink("step/$chat_id.step");
      }else{ 
      $idszs=explode("n",$lichka);
      foreach($idszs as $idlat){
     $userr = bot('sendMessage',[
      'chat_id'=>$idlat,
      'text'=>"<b>$text</b>",
      'parse_mode'=>'html',
      'disable_web_page_preview' => true,
      ]);  unlink("step/$cid.step");
      }
        if($userr){
          bot('sendmessage',[
          'chat_id'=>$admin,
          'text'=>"Habar Barcha Userlarga yuborildi!",
          ]);      
      unlink("step/$cid.step");
        }
      }
    }
     


if($text == "📋Userga Forward" and $cid == $admin){
 bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"✅ *Userlarga forward qilinadigan xabarni kiriting!
Bakor qilish uchun /cancel ni bosing*",
'parse_mode'=>'markdown',
]);
file_put_contents("step/$cid.step","forward");
}

if($step == "forward" and $cid == $admin){
if($text == "/cancel"){
unlink("stat/$chat_id.step");
}else{ 
$ids=explode("n",$lichka);
foreach($ids as $id){
$user = bot('forwardMessage', [
'chat_id'=>$id,
'from_chat_id'=>$admin,
'message_id'=>$mid,
]);unlink("step/$cid.step");
}

if($user){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"✅ Xabar yetkazildi!",
'parse_mode'=>"markdown",
]);     
unlink("step/$cid.step");
}
}
}

if($text=="💳 Hisobim"){

$dost = file_get_contents("pul/$refid.txt");
$soat=date('H:i:s',strtotime('2 hour'));
$sana=date("d-M-y",strtotime("2 hour"));
$hisob  = file_get_contents("pul/$chat_id.txt");
bot('deleteMessage',[
'chat_id'=>$cid,
'message_id'=>$mid,
]);
$dl = bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"
‍‍┌Sizning hisobingiz haqida:
├Mijoz: ".$message->from->first_name."
├Xisob raqam <code>$cid</code>
├Botdagi vazifa: Foydalanuvchi
├Do'stlaringiz: $dost ta
├Asosiy xisob: $hisob So'm

$rek",
'parse_mode'=>"HTML",
'reply_markup'=>$pay,
])->result->message_id;

}

if($text=="💰 Pul ishlash"){
bot('deleteMessage',[
'chat_id'=>$cid,
'message_id'=>$mid,
]);
$dl = bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"‍Marhamat, quyidagi menyudagi hisob to'ldirish usullardan birini tanlang: 

🗣 Taklifnoma: Siz ushbu bo'limdan foydalanib o'zingizning havolangizni olasiz va boshqalarga yuborish orqali tanga yig'asiz.

💳 Sotib olish: Siz ushbu bo'limdan tangalarni sotib olish va robotdan hech qanday muammosiz va ozgina pul to'lash orqali foydalanishingiz mumkin.‌‌

$rek
",
'reply_markup'=>$pay,
])->result->message_id;
}

if($data=="card"){
bot('editMessagetext',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
'text'=>"<b>⬇Quyidagi karta raqamiga tolov qiling va administratorga yozing</b>

💳Karta: <code>Lichkada</code>
💸Minimal tolov: 1000 so'm

<b>📊 Botdagi So'm kursi: 1 So'm - kursga qarab so'm</b>",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🧑‍💻Administrator",'url'=>"https://t.me/$adminuser"]],
]]),]);}

if($data=="qiwi"){
bot('editMessageText',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
'text'=>"<b>🥝 QIWI to'lov tizimi orqali yuborilgan pullaringiz bir necha daqiqada 
avtomatik ravishda hisobingizga tushadi.</b>

💳 QIWI: <code>Lichkada</code>
📝 Izoh: <code>$callcid</code>

<b>Diqqat! izoh kiritishni unutsangiz yoki noto'g'ri kiritsangiz hisobingizga pul tushmaydi! 
Bu kabi holatlarda, biz bilan bog'lanishingiz mumkin.</b>",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🧑‍💻Administrator",'url'=>"https://t.me/$adminuser"]],
]]),]);}

if($text=="⬅Orqaga"){
bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"Bekor qilindi!",
    'parse_mode'=>"html",
'reply_markup'=>$mem,
]);
unlink("step/$cid.step");
exit();
}

$step = file_get_contents("step/$cid.step");
$hisob = file_get_contents("pul/$cid.pul");
$types = file_get_contents("step/$cid.turi");



if($text=="📨 Yordam"){
bot('deleteMessage',[
'chat_id'=>$cid,
'message_id'=>$mid,
]);
$dl = bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"
🔰 Bizga savollaringiz yoki muammolaringiz bo'lsa, iltimos, bizning qo'llab-quvvatlash jamoamiz bilan bog'laning.
Admin: @$adminuser",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"☎️  Administrator","url"=>"https://t.me/$adminuser"]],
]]),])->result->message_id;}

if($data=="ref"){
bot('editMessagetext',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
'text'=>"
🎉 @$botname
✅ Telegram  va  Instagram sahifalarga obunachi qo'shish,
👥 Referal va sotib olish,
🔆 24/7 qo'llab-quvvatlash,
🔐 Qulay va 🚚Avto tolov(🥝QIWI),
💸 Tezkor o'tkazma qilish imkoniyati.
🇺🇿 O'zbek tilidagi boshqaruv.
👇 Hoziroq sinab ko'ring! Linkni bosing!

👉🏻 https://telegram.me/$botname?start=$callcid
👉🏻 tg://resolve?domain=$botname&start=$callcid
$reklama",
]);
bot('sendMessage',[
'chat_id'=>$callcid,
'text'=>"Yuqoridagi xabarni tarqating va xar bir referalingiz uchun $referalim So'm oling ",
]);
}


if($data=="buy"){
bot('editMessageText',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
'text'=>"
💵 Qaysi to'lov usulida hisobingizni toldirmoqchisiz?
Karta va qiwi orqali toʻlovlar qilish tavsiya etiladi.
👇 Tugmalardan tanlang:",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"💴Karta orqali",'callback_data'=>"card"],['text'=>"🥝QIWI Orqali(avto)",'callback_data'=>"qiwi"]],
]
]),
]);
}                            



$ss=file_get_contents("admin.txt");
if($text=="➕So'm berish" and $cid==$admin){
file_put_contents("admin.txt","coin");
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"Foydalanuvchi hisobini nechi pulga toʻldirmoqchisiz:",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($ss=="coin" and $cid==$admin){
file_put_contents("adminpul.coin",$text);
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"Foydalanuvchi ID raqamini kiriting:",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
file_put_contents("admin.txt","pay");
 }


if($ss=="pay" and $cid==$admin){
$summa = file_get_contents("adminpul.coin");
$sum =  file_get_contents("pul/$text.txt");
$jami = $sum + $summa;
file_put_contents("pul/$text.txt","$jami");
bot("sendMessage",[
   "chat_id"=>$text,
          "text"=>"
💰 Sizning hisobingiz admin tomonidan $summa so'mga toʻldirildi!

Hozirgi hisobingiz: $jami So'm",
]);
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"✅ Foydalanuvchi balansi toʻldirildi!",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
unlink("adminpul.txt");
}
////////
$ss=file_get_contents("admin.txt");
if($text=="➖So'm ayirish" and $cid==$admin){
file_put_contents("admin.txt","coin1");
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"Foydalanuvchi hisobidan qancha So'm ayirmoqchisiz:",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($ss=="coin1" and $cid==$admin){
file_put_contents("adminpul.coin",$text);
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"Foydalanuvchi ID raqamini kiriting:",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
file_put_contents("admin.txt","pay1");
 }


if($ss=="pay1" and $cid==$admin){
$summa = file_get_contents("adminpul.coin");
$sum =  file_get_contents("pul/$text.txt");
$jami = $sum - $summa;
$okminus=file_put_contents("pul/$text.txt","$jami");
bot("sendMessage",[
   "chat_id"=>$text,
          "text"=>"
💰 Sizning hisobingizdan admin tomonidan $summa So'm ayirildi!

Hozirgi hisobingiz: $jami So'm",
]);
}
if($okminus){
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"✅ Foydalanuvchi balansidan $summa So'm ayirildi!",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
unlink("adminpul.txt");
}

if($tx=="/stat"){
$lich = substr_count($lichka,"n");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"ʙᴏᴛɪᴍɪᴢ ᴀᴢᴏʟᴀʀɪ $lich ta
",
]);
}