<?php

ob_start();
define('API_KEY','5414704960:AAFlCi2Djufccm4LU6TGN59Mqs8GAFvWuU0'); 
$admin = "5453020332"; // admin IDsi
$botname = bot('getme',['bot'])->result->username;
$bot = "@$botname";
$kanalimiz = "negaekana";

function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$cid= $message->chat->id;
$text = $message->text;
$gid=$message->from->id;
$type = $message->chat->type;
$name = $message->from->first_name;
$mid = $message->message_id;
$uid = $update->callback_query->from->id;
$data = $update->callback_query->data;
$callmid = $update->callback_query->message->message_id;
$callcid = $update->callback_query->message->chat->id;

mkdir("calc");
$menu=json_encode([
'inline_keyboard'=>[
[['text'=>"ㅤ1ㅤ",'callback_data'=>"1"],['text'=>"ㅤ2ㅤ",'callback_data'=>"2"],['text'=>"ㅤ3ㅤ",'callback_data'=>"3"],['text'=>"ㅤ÷ㅤ",'callback_data'=>"÷"]],
[['text'=>"ㅤ4ㅤ",'callback_data'=>"4"],['text'=>"ㅤ5ㅤ",'callback_data'=>"5"],['text'=>"ㅤ6ㅤ",'callback_data'=>"6"],['text'=>"ㅤ×ㅤ",'callback_data'=>"×"]],
[['text'=>"ㅤ7ㅤ",'callback_data'=>"7"],['text'=>"ㅤ8ㅤ",'callback_data'=>"8"],['text'=>"ㅤ9ㅤ",'callback_data'=>"9"],['text'=>"ㅤ-ㅤ",'callback_data'=>"-"]],
[['text'=>"ㅤ.ㅤ",'callback_data'=>"."],['text'=>"ㅤ0ㅤ",'callback_data'=>"0"],['text'=>"ㅤCㅤ",'callback_data'=>"del1"],['text'=>"ㅤ+ㅤ",'callback_data'=>"+"]],
[['text'=>"ㅤ=ㅤ",'callback_data'=>"="]],
]
]);


if($text=="/start"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"Salom Kalkulator Botga Tashrif Buyurdingiz.

⬇️Marhamat Foydalanishni Boshlang!
",
'parse_mode'=>'html',
'reply_markup'=>$menu 
]);
}


if($data=="1"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$data",'reply_markup'=>$menu]);}  

if($data=="2"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  

if($data=="3"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  

if($data=="4"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  

if($data=="5"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  

if($data=="6"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  

if($data=="7"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  

if($data=="8"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  
if($data=="9"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  

if($data=="0"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  

if($data=="del"){
file_put_contents("calc/$uid.txt","  ");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
Marhamat Misol Kiriting!",'reply_markup'=>$menu]);}  

if($data=="del1"){
$calci=file_get_contents("calc/$uid.txt");
$get =  strlen($calci);
$get2= $get -1;
$resultt= substr($calci, 0, $get2);
file_put_contents("calc/$uid.txt","$resultt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>$resultt,'reply_markup'=>$menu]);} 

if($data=="÷"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci/");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  

if($data=="+"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  

if($data=="-"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  

if($data=="×"){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci*");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  

if($data=="."){
$calci=file_get_contents("calc/$uid.txt");
file_put_contents("calc/$uid.txt","$calci$data");
$calcii=file_get_contents("calc/$uid.txt");
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'text'=>"
$calcii",'reply_markup'=>$menu]);}  

if($data=="="){
$calci=file_get_contents("calc/$uid.txt");
$calcu = urlencode($calci);
$rs = file_get_contents('http://api.mathjs.org/v1/?expr='.$calcu);
bot('editMessageText',['chat_id'=>$callcid,'message_id'=>$callmid,'parse_mode'=>'html','text'=>"
<i>$calci=</i>

<b>Result:</b> $rs ",'reply_markup'=>json_encode(['inline_keyboard'=>[
[['text'=>"   C   ",'callback_data'=>"del"]],]]),]);}  

$lichka=file_get_contents("azolar.txt");
if($type=="private"){
if(strpos($lichka,"$cid") !==false){
}else{
file_put_contents("azolar.txt","$lichka\n$cid");
}
}
if($text=="/stat" and $cid==$admin){
$kanal=file_get_contents("kanal.txt");
$gruppa=file_get_contents("gruppa.txt");
$lichka=file_get_contents("azolar.txt");
$lich=substr_count($lichka,"\n");
$kn=substr_count($kanal,"\n");
$gr=substr_count($gruppa,"\n");
bot('sendMessage',[
'chat_id'=>$admin,
    'text'=> "<b>Bot statatistikasi:</b>    
├▶👤A'zolar: [ <b>$lich</b> ]
├
├▶📢Kanallar: <b>$kn</b>
├
└▶👥Guruxlar: <b>$gr</b>",
'parse_mode' => 'html',
]);
}


?>