<?php
$botchalar = json_encode([
"inline_keyboard"=>[
[["text"=>"Men ham bot ochaman 🙋‍♂","url"=>"https://t.me/$bot"],],

]

]);
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$cid = $message->chat->id;
$tx = $message->text;
$text = $message->text;
$ch_mid = $message_ch->message_id;
$ch_cid = $message_ch->chat->id;
$message_ch = $update->channel_post;
$token = $message->text;
$chanel_vid = $channel->text; 
$from_id = $update->message->from->id;
$mid = $message->message_id;
$name = $message->from->first_name;
$fid = $message->from->id;
$callback = $update->callback_query;
$message = $update->message;
$mid = $message->message_id;
$data = $update->callback_query->data;
$type = $message->chat->type;
$text = $message->text;
$cid = $message->chat->id;
$adstep = file_get_contents("admin/admin.step");
$uid= $message->from->id;
$message_ch = $update->channel_post;
$ch_mid = $message_ch->message_id;
$ch_cid = $message_ch->chat->id;
$chanel_vid = $channel->message; 
$gname = $message->chat->title;
$left = $message->left_chat_member;
$new = $message->new_chat_member;
$name = $message->from->first_name;
$repid = $message->reply_to_message->from->id;
$repname = $message->reply_to_message->from->first_name;
$newid = $message->new_chat_member->id;
$leftid = $message->left_chat_member->id;
$newname = $message->new_chat_member->first_name;
$leftname = $message->left_chat_member->first_name;
$username = $message->from->username;
$cmid = $update->callback_query->message->message_id;
$cusername = $message->chat->username;
$repmid = $message->reply_to_message->message_id; 
$ccid = $update->callback_query->message->chat->id;
$cuid = $update->callback_query->message->from->id;
$cqid = $update->callback_query->id;
$admins = file_get_contents("admins.txt");
$photo = $update->message->photo;
$gif = $update->message->animation;
$video = $update->message->video;
$music = $update->message->audio;
$voice = $update->message->voice;
$sticker = $update->message->sticker;
$document = $update->message->document;
$for = $message->forward_from;
$forc = $message->forward_from_chat;
$data = $callback->data;
$callid = $callback->id;
$cname = $calback->message->from->first_name;
$ccid = $callback->message->chat->id;
$cmid = $callback->message->message_id;
$cfid = $callback->message->from->id;
$user = $message->from->username;

$inlinequery = $update->inline_query;
$inline_id = $inlinequery->id;
$inlineid = $inlinequery->from->id;
$inline_query = $inlinequery->query;
$step = file_get_contents("step/$fid.txt");
$step1 = file_get_contents("minus/$fid.txt");
$time=date('H:i',strtotime('2 hour'));
$soat = date("H:i",strtotime("2 hour"));
$sana = date('d.m.Y',strtotime("2 hour"));
$user = file_get_contents("Unknown_Blogger.ids");
$guruh = file_get_contents("pul/guruh.db");
$blocklar = file_get_contents("block.dat");
$getss= file_get_contents("admin/blocks.txt");
if(mb_stripos($getss, $fid)!==false){
	bot('sendMessage',[
	'chat_id' => $cid,
	'text' => "Kechirasiz <b>$name</b> siz bloklangansiz!",
	'parse_mode'=>'html',
	]); 
	return false;
	}

mkdir("referal");
mkdir("bot");
mkdir("stat");
mkdir("token");
mkdir("turi");
mkdir("boti");
mkdir("step");
mkdir("baza");
mkdir("user");
mkdir("bonus");
mkdir("baza/$fid");
mkdir("yangi");
mkdir("prouser");
mkdir("user/$fid");
mkdir("admin");
mkdir("prouser/$fid");
mkdir("prouser/$fid/usa");
mkdir("prouser/$fid/yandex/data");
mkdir("ban");
if(!file_exists("referal/$fid.txt")){  
    file_put_contents("referal/$fid.txt","0");
}

if(file_get_contents("stat/stat.txt")){
} else{
file_put_contents("stat/stat.txt", "0");
}

$referalsum = file_get_contents("referal/$fid.txt");
$referalid = file_get_contents("referal/$fid.referal");
$referalcid = file_get_contents("referal/$ccid.referal");
$userstep = file_get_contents("step/$fid.txt");
$tokeni = file_get_contents("token/$fid.txt");
$boti = file_get_contents("boti/$fid.txt");

$soni = file_get_contents("soni/$idi.soni");
if(!$soni) $soni = 0;
$boshqar = json_encode([
     'resize_keyboard'=>true,
     'keyboard'=>[
[['text'=>"➕ Admin Qo'shish"],['text'=>"🗑 Admin O'chirish"]],
[['text'=>"📄 Admin Ro'yhati"],['text'=>"↩️ oqaga"]],
]
]);
$panel = json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[  
[['text'=>"💰 Balans boshqaruvi"]],
  [['text'=>"🔐 Blok tizimi"],['text'=>"📝 Pochta tizimi"]],
[['text'=>""],['text'=>"🗄 Majburiy obuna"]],
[['text'=>"⚙ Bot sozlamalari"],['text'=>"↩️Ortga qaytish"]],
    ]
]);



$balans=json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
  [['text'=>"💸 Pul berish"],['text'=>"💸 Pul ayirish"],['text'=>"🚀Bonus yasash"]],
[['text'=>"💳 Karta"],['text'=>"🥝 Qiwi"],['text'=>"📱Paynet"]],
[['text'=>"👥 Taklif narxi"],['text'=>"📤 Botlar narxi"],],
[['text'=>"↩️ oqaga"]],
]
]);
$narxini=json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🔥Antiqa botlar"]],
[['text'=>"💵 Pul bot"]],
[['text'=>"⭐Maxsus bot"]],
[['text'=>"↩️ oqaga"],],
]
]);
$kanalla=json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"1️⃣-Kanal"]],
[['text'=>"2️⃣-Kanal"],],
[['text'=>"3️⃣-Kanal"]],
[['text'=>"Bonus-Kanal"]],
[['text'=>"↩️ oqaga"],],
]
]);
$botsozlamasi=json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"✅ Yoqish"],['text'=>"❌ O'chirish"]],
[['text'=>"↩️ oqaga"]],
]
]);
$blocktizmi=json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
    [['text'=>"❌Bloklash"],['text'=>"✅Blokdan olish"]],
[['text'=>"↩️ oqaga"]],
]
]);
$pochta=json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"↗️ Xabar yubor"],['text'=>"📋 Userga Xabar"]],
[['text'=>"↩️ oqaga"]],
]
]);
$qayt_menu = json_encode([
     'resize_keyboard'=>true,
     'keyboard'=>[
          [['text'=>"↩️ oqaga"]],
          ]
          ]);
if($text == "📋 Userga Xabar"){
if($cid == $admin){
bot('sendMessage', [
'chat_id'=>$admin,
'text'=>"✔ Userga Xabar yuborish uchun
/sms 🆔️ Xabar 
shu tarzda yuboring!

👨‍💻Admin: $adminuser",
'reply_markup'=>$back4_menu,
]);
}else{
bot("sendmessage",[
'chat_id'=>$cid,
'text'=> "*🤪😂 Bu funksiyani Faqat men @$userR ishlata olaman.*",
'parse_mode'=>'Markdown',
]);
}
}
if(mb_stripos($text,"/sms") !== false){
if($cid == $admin){
$ex = explode(" ",$text);
$sms = str_replace("/sms $ex[1]","",$text);
$ismi = $message->from->first_name;

if(mb_stripos($ex[1],"@") !== false){
$ssl = str_replace("@","",$ex[1]);
$egasi = "t.me/$ssl";
}else{
$egasi = "tg://user?id=$ex[1]";
$eegasi = "$ex[1]";
}
bot('sendmessage',[
'chat_id'=>$ex[1],
'text'=>"📨*Yangi Xabar*

👤 [$ismi](tg://user?id=$uid)

*📨 Xabar: $sms

❄ @$bot*",
'parse_mode'=>"markdown", 
]);
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"👤[Foydalanuvchi]($egasi) ga Habaringiz Yuborildi📩",
'parse_mode'=>"markdown", 
'reply_markup'=>$panel
]);
}else{
bot("sendmessage",[
'chat_id'=>$cid,
'text'=> "*🤪😂 Bu funksiyani Faqat men $adminuser ishlata olaman.*",
'parse_mode'=>'Markdown',
]);
}
}


$xabar = file_get_contents("send.txt");
if($text == "↗️ Xabar yubor"){
if($cid == $admin){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"*Userlarga yuboriladigan xabar matnini kiriting! Bekor qilish uchun /cancel ni bosing.*",
'parse_mode'=>"markdown",
'reply_markup'=>$back4_menu,
]); file_put_contents("send.txt","user");
}else{
bot("sendmessage",[
'chat_id'=>$cid,
'text'=> "*🤪😂 Bu funksiyani Faqat men $adminuser ishlata olaman.*",
'parse_mode'=>'Markdown',
]);
}
}
if($xabar=="user" and $cid==$admin ){
if($text=="/cancel"){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Bekor qilindi!",
'parse_mode'=>"html",
]); unlink("send.txt");
}else{
$lich = file_get_contents("shekih.db");
$lichka = explode("\n",$lich);
foreach($lichka as $lichkalar){
$okuser=bot("sendmessage",[
'chat_id'=>$lichkalar,
'text'=>$text,
'parse_mode'=>'HTML'
]);
}
}
}

if($okuser){
bot("sendmessage",[
'chat_id'=>$admin,
'text'=>"<b>Hamma userlarga yuborildi</b>✅",
'parse_mode'=>'html',
'reply_markup'=>$panel,
]); unlink("send.txt");
}

//Xabar
if((mb_stripos($text, "/xabar")!==false) and $cid == $admin){
$id = explode(" ",$text);
$id1 = $id[1];
$id2 = $id[2];
$finish = bot('SendMessage', [
'chat_id'=>$id1,
'parse_mode'=>"markdown",
'text'=>"$id2

By: [@$bot]",
'disable_web_page_preview'=>true,
]);
}
if($finish){
bot('SendMessage', [
'chat_id'=>$admin,
'parse_mode'=>"markdown",
'text'=>"✔️ [$id1](tg://user?id=$id1) *Ga Xabar Yuborildi!✅*",
'parse_mode'=>'html',
'reply_markup'=>$panel
]);
}


//pul berish
if(mb_stripos($tx, "💸 Pul berish")!==false){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=> "<b>✅Pul berish uchun quyidagi buyruqni bajaring!
Bir qator pastga tushib id raqamni yozing, yana bir qator pastga tushib ta Raketa ni yozing!
Masalan:</b>
<code>/plus
$admin
1000</code>",
'parse_mode' => 'html',
'reply_markup'=>$back4_menu,
]);
}else
if(mb_stripos($tx, "/plus")!==false){
if($cid == $admin){
$id = explode("\n", $tx);
$id1 = $id[1]; $id2 = $id[2];
$olmos = file_get_contents("referal/$id1.txt");
$miqdor = $olmos+$id2;
file_put_contents("referal/$id1.txt","$miqdor");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=> "<b>🛠 Hisobi to'ldirildi.
🆔 Id raqami : $id1
💳 To'ldirildi : $id2 ta Raketa </b>",
'parse_mode' => 'html',
'reply_markup'=>$panel,
]);
bot("sendmessage",[
'chat_id'=>$id1,
'text'=> "*🛠 Hisobingiz $id2 ta Raketa ga to'ldirildi.*",
'parse_mode'=>'Markdown',
]);
}else{
bot("sendmessage",[
'chat_id'=>$cid,
'text'=> "<b>Bu bo‘limni faqat bot administratori ishlata oladi!</b>",
'parse_mode'=>'Markdown',
]);
}
}
if($tx=="🗄 Majburiy obuna" and $cid==$admin){ 
bot('sendMessage',[ 
   'chat_id'=>$admin,
    'text'=>"Tanlang yaratamiz👇",
'reply_markup'=>$kanalla, 
    ]);
}
//pul ayirish
if($text == "💸 Pul ayirish"){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=> "<b>✅Pul ayrish Uchun Quyidagi Buyruqni bajaring!
Bir qator pasga tushib id raqamni yozing, yana bur qator tushib pulni yozing!
Masalan:</b>
<code>/minus
$admin
1000</code>",
'parse_mode' => 'html',
'reply_markup'=>$back4_menu,
]);
}elseif(mb_stripos($text, "/minus")!==false){
if($cid == $admin){
$id = explode("\n", $tx);
$id1 = $id[1]; $id2 = $id[2];
$olmos = file_get_contents("referal/$id1.txt");
$miqdor = $olmos-$id2;
file_put_contents("referal/$id1.txt","$miqdor");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=> "<b>🛠 Hisobdan yechib olindi.
🆔 Id raqami : $id1
💳 Yechildi : $id2 ta Raketa </b>",
'parse_mode' => 'html',
'reply_markup'=>$panel,
]);
bot("sendmessage",[
'chat_id'=>$id1,
'text'=> "*🛠 Hisobingizdan $id2 ta Raketa ayirdi.*",
'parse_mode'=>'Markdown',
]);
}else{
	bot("sendmessage",[
'chat_id'=>$cid,
'text'=> "*🤪😂 Bu funksiyani Faqat men $adminuser ishlata olaman.*",
'parse_mode'=>'Markdown',
]);
}
}

//bot kodi


	if($tx == "❌Bloklash" and $cid == $admin){
	bot('sendmessage',[
	'chat_id'=>$admin,
	'text'=>"🚫Bloklanadigan foydalanuvchini ID raqamini kiriting!",
	]);
	file_put_contents("admin/admin.step", "blok");
	}
if($adstep == "blok" and $cid == $admin){
$get = file_get_contents("admin/blocks.txt");
if(mb_stripos($get, $tx)==false){
file_put_contents("admin/blocks.txt", "$get\n$tx");
	bot('sendmessage',[
	'chat_id'=>$admin,
	'text'=>"Foydalanuvchi bloklandi!✅",
	]);
	bot('sendmessage',[
	'chat_id'=>$tx,
	'text'=>"Siz bizning botimizdan 🚫bloklandingiz. Endi botni ishlata olmaysiz. Blokdan chiqish uchun 👨‍💻dasturchiga murojaat qiling!
👨‍💻Dasturchi: @$adminuser",
	]);
	unlink("admin/admin.step");
	}
	}
if($tx == "✅Blokdan olish" and $cid == $admin){
	bot('sendmessage',[
	'chat_id'=>$admin,
	'text'=>"🚫Blokdan olinadigan foydalanuvchini ID raqamini kiriting!",
	]);
	file_put_contents("admin/admin.step", "unblok");
	}
if($adstep == "unblok" and $cid == $admin){
$get = file_get_contents("admin/blocks.txt");
if(mb_stripos($get, $tx)==false){
	bot('sendmessage',[
	'chat_id'=>$admin,
	'text'=>"Foydalanuvchi bloklanmagan",
	]);
	unlink("admin/admin.step");
}else{
$bl = file_get_contents("admin/blocks.txt");
$bl = str_replace("$tx", " ", $bl);
file_put_contents("admin/blocks.txt", "$bl");
	bot('sendmessage',[
	'chat_id'=>$admin,
	'text'=>"Foydalanuvchi blokdan olindi✅",
	]);
	bot('sendmessage',[
	'chat_id'=>$tx,
	'text'=>"🎉Tabriklayman! Siz blokdan muvaffaqiyatli olindingiz! Yana botni ishlatishingiz mumkin. 🤖Botga qayta /start bosing.",
	]);
	unlink("admin/admin.step");
	}
	}

$on = file_get_contents("on.txt");
if ($on == "off" && $cid = "$admin"){
bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"⚠️<b>@$botname dam olish rejimida iltimos bezovta qilmang.\n\nHozir tamirda.📛</b>",
        'parse_mode'=>'html',
]);
}
if($text == "❌ O'chirish" && $cid == $admin){
    file_put_contents("on.txt","off");
    bot('sendmessage',[
        'chat_id'=>$cid,
        'text'=>"⚠️<b>Offline.</b>",
      'parse_mode'=>'html',
    ]);
    }
    //yoqish
    if($text == "✅ Yoqish" && $cid == $admin){
    file_put_contents("on.txt","on");
    bot('sendmessage',[
        'chat_id'=>$cid,
        'text'=>"⚠️<b>Online</b>",
      'parse_mode'=>'html',
    ]);
    }
//
$on = file_get_contents("on.txt");

if ($on == "off" && $from_id != "$admin") {

bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⚠️<b>@$bot da texnik ishlar olib borilmoqda, bir necha soatdan so‘ng botga qayta /start bosing!</b>",
        'parse_mode'=>'html',
]);


}

if(mb_stripos($text, "/click-")!==false){
        $m1 = explode("-",$text);
       $m2 = $m1[1];
file_put_contents("click.txt","$m2");
       bot('sendMessage',[
      'chat_id'=>$admin,
      'text'=>"CLICK $m2 ga o'zgardi!",
       ]);
      }

if(mb_stripos($text, "/qiwi-")!==false){
    $m1 = explode("-",$text);
       $m2 = $m1[1];
file_put_contents("qiwi.txt","$m2");
       bot('sendMessage',[
      'chat_id'=>$admin,
      'text'=>"QIWI $m2 ga o'zgardi!",
       ]);
}
if(mb_stripos($text, "/paynet-")!==false){
        $m1 = explode("-",$text);
       $m2 = $m1[1];
       file_put_contents("paynet.txt","$m2");
       bot('sendMessage',[
      'chat_id'=>$admin,
      'text'=>"CLICK $m2 ga o'zgardi!",
       ]);
      }

if($tx=="📋 Adminlar boshqaruvi"){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Quyidagilardan birini tanlang:",
'reply_markup'=>$boshqar,
    ]);
}
if($text=="↩️ oqaga"){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Quyidagilardan birini tanlang:",
'reply_markup'=>$panel,
    ]);
}

if($text=="➕ Admin Qo'shish" and $cid==$admin){
    file_put_contents("step/$cid.txt","add");
    bot('sendMessage',[
    'chat_id'=>$admin, 
    'text'=>"<i>Marhamat Admin qilmochi bo`lgan id raqamni yuboring</i>", 
    'parse_mode'=>'HTML', 
    ]);
    } 
    
    if($text=="🗑 Admin O'chirish" and $cid==$admin){
    file_put_contents("minus/$cid.txt","remove");
    bot('sendMessage',[
    'chat_id'=>$admin, 
    'text'=>"<i>Marhamat Admindan olmoqchi bo`lgan id raqamni yuboring</i>", 
    'parse_mode'=>'HTML', 
    ]);
}

if($step=="add"){
    unlink("step/$cid.txt");
    file_put_contents("admins.txt","\n".$text,FILE_APPEND);
    bot('sendMessage',[
    'chat_id'=>$cid, 
    'text'=>"<a href='tg://user?id=$text'>$text</a><i>botga Adminstrator qilib tayinandi.</i>", 
    'parse_mode'=>'HTML', 
    ]);
    bot('sendMessage',[
    'chat_id'=>$text, 
    'text'=>"_Tabriklaymiz siz ushbu botga adminstrator qilib tayinlandingiz_
    Sizning admin panelingiz /admin ", 
    'parse_mode'=>'markdown', 
    ]);
    } 
    
    if($step1=="remove"){
    unlink("minus/$cid.txt");
    $str = str_replace("$text","",$admins);
    file_put_contents("admins.txt","$str");
    bot('sendMessage',[
    'chat_id'=>$cid, 
    'text'=>"<a href='tg://user?id=$text'>$text</a><i> botda Adminstratorlikdan olib tashlandi</i>", 
    'parse_mode'=>'HTML', 
    ]);
    bot('sendMessage',[
    'chat_id'=>$text, 
    'text'=>"*Salom siz botmizda adminstratorlikdan olib tashlandingiz*", 
    'parse_mode'=>'markdown', 
    ]);
}


    if($text=="📄 Admin Ro'yhati" and $cid==$admin){
    $son = substr_count($admins,"\n");
    bot('sendMessage',[
    'chat_id'=>$admin, 
    'text'=>"<i>Bot adminlari idlari:\n\n $admins \n bot adminlari soni: $son ta.</i>", 
    'parse_mode'=>'HTML', 
    ]);
}
if($cid==$admin){

bot('sendMessage',[ 

'chat_id'=>$idi, 

'text'=>"📢 Adminlar: 

$admins",
]);
}
if($tx=="💰 Balans boshqaruvi"){
	bot('sendMessage',[
	'chat_id'=>$cid,
	'text'=>"💰 Balans boshqaruvi boʻlimidasiz!
	
📋 Quyidagi boʻlimlardan birini tanlang!",
'parse_mode'=>"Markdown",
	'reply_markup'=>$balans,
]);
}
if($tx=="⚙ Bot sozlamalari"){
	bot('sendMessage',[
	'chat_id'=>$cid,
	'text'=>"⚙ Bot sozlamalari boʻlimidasiz!
📋 Quyidagi boʻlimlardan birini tanlang!",
'parse_mode'=>"Markdown",
	'reply_markup'=>$botsozlamasi,
]);
}
if($tx=="🔐 Blok tizimi"){
	bot('sendMessage',[
	'chat_id'=>$cid,
	'text'=>" 🔐 Blok tizimi boʻlimidasiz!

	📋 Quyidagi boʻlimlardan birini tanlang!",
'parse_mode'=>"Markdown",
	'reply_markup'=>$blocktizmi,
]);
}
if($tx=="📝 Pochta tizimi"){
	bot('sendMessage',[
	'chat_id'=>$cid,
	'text'=>" 📝 Pochta tizimi boʻlimidasiz!

	📋 Quyidagi boʻlimlardan birini tanlang!",
'parse_mode'=>"Markdown",
	'reply_markup'=>$pochta,
]);
}
if($tx=="📢 Kanallar boshqaruvi"){
	bot('sendMessage',[
	'chat_id'=>$cid,
	'text'=>"📢 Kanallar boshqaruvi boʻlimidasiz!
	
📋 Quyidagi boʻlimlardan birini tanlang!
	/ch1-kanal useri @ siz

	/ch2-kanal useri @ siz bot yangiliklari tashaladi

	/ch3-kanal useri @ siz

	/set$ kanal id siz bonus tashaladi -100 bilan yuboring namuna: /set$-1001632660516",
'parse_mode'=>"Markdown",
	'reply_markup'=>$qayt_menu,
]);
}


if($tx=="💳 Karta"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"kartani ulash uchun /click- va karta raqmi",
'parse_mode'=>"Markdown",
]);
}
if($tx=="🥝 Qiwi"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"kartani ulash uchun /qiwi- va karta raqmi",
'parse_mode'=>"Markdown",
]);
}
if($tx=="📱Paynet"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"📱paynetni ozgartirish uchun /paynet- telefon raqam",
'parse_mode'=>"Markdown",
]);
}
$step12 = file_get_contents("stat/$cid.step");
if($tx=="👥 Taklif narxi" and $cid==$admin){ 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>💸 Taklif narxini kiriting!</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$qayt_menu, 
]); 
file_put_contents("stat/$cid.step","channel_12");
} 
if($step12=="channel_12" and $tx !== "↩️ oqaga" and $cid==$admin){ 
file_put_contents("stat/channel_12.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$admin, 
'text'=>"<i>Referal narxi $tx ga o‘zgartirildi.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
unlink("stat/$cid.step"); 
}
if($tx=="📤 Botlar narxi" and $cid==$admin){ 
bot('sendMessage',[ 
   'chat_id'=>$admin,
    'text'=>"Qanday turdagi botlarni yaratamiz👇",
'reply_markup'=>$narxini, 
    ]);
}
$step13 = file_get_contents("stat/antiqa.txt");
if($tx == "🔥Antiqa botlar"){
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📋 🔥Antiqa botlar uchun narxni kitirting :",
        'reply_markup'=>$qayt_menu, 
 
]);
file_put_contents("stat/antiqa.txt","channel_13");
}
if($step13=="channel_13" and $tx !== "↩️ oqaga" and $cid==$admin){ 
file_put_contents("stat/channel_13.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$cid, 
'text'=>"<i>🔥Antiqa botlar narxi $tx ga o‘zgartirildi.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
unlink("stat/antiqa.txt"); 
}
$shahzodbek1222 = file_get_contents("stat/maxsus.txt");
$shahzodbek122 = file_get_contents("stat/pul.txt");
$shahzodbek = file_get_contents("stat/group.txt");
if($tx == "👤 group bot"){
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"👤 group botlar uchun narxni kitirting :",
        'reply_markup'=>$qayt_menu, 
 
]);
file_put_contents("stat/group.txt","channel_14");
}
if($shahzodbek=="channel_14" and $tx !== "↩️ oqaga"){ 
file_put_contents("stat/channel_14.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$cid, 
'text'=>"<i>👤 group botlar narxi $tx ga o‘zgartirildi.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
unlink("stat/group.txt"); 
}

if($tx == "💵 Pul bot"){
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"💵 Pul botlar uchun narxni kitirting :",
        'reply_markup'=>$qayt_menu, 
 
]);
file_put_contents("stat/pul.txt","channel_15");
}
if($shahzodbek122=="channel_15" and $tx !== "↩️ oqaga"){ 
file_put_contents("stat/channel_15.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$cid, 
'text'=>"<i>💵 Pul botlar narxi $tx ga o‘zgartirildi.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
unlink("stat/pul.txt"); 
}


if($tx == "⭐Maxsus bot"){
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"⭐Maxsus botlar uchun narxni kitirting :",
        'reply_markup'=>$qayt_menu, 
 
]);
file_put_contents("stat/maxsus.txt","channel_17");
}
if($shahzodbek1222=="channel_17" and $tx !== "↩️ oqaga"){ 
file_put_contents("stat/channel_17.txt",$tx); 
bot('sendMessage',[ 
'chat_id'=>$cid, 
'text'=>"<i>⭐Maxsus botlar narxi $tx ga o‘zgartirildi.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
unlink("stat/maxsus.txt"); 
}
$ch1 = file_get_contents("stat/kanal1.txt");
if($tx == "1️⃣-Kanal"){
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"1️⃣-Kanal uchun kanal userni @ siz kitirting :",
        'reply_markup'=>$qayt_menu, 
 
]);
file_put_contents("stat/kanal1.txt","1");
}
if($ch1=="1" and $tx !== "↩️ oqaga"){ 
file_put_contents("ch1.txt",$tx);
bot('sendMessage',[ 
'chat_id'=>$cid, 
'text'=>"<i>1️⃣-Kanal @$tx ga o‘zgartirildi.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
unlink("stat/kanal1.txt"); 
}

$ch2 = file_get_contents("stat/kanal2.txt");
if($tx == "2️⃣-Kanal"){
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"2️⃣-Kanal uchun kanal userni @ siz kitirting :",
        'reply_markup'=>$qayt_menu, 
 
]);
file_put_contents("stat/kanal2.txt","2");
}
if($ch2=="2" and $tx !== "↩️ oqaga"){ 
file_put_contents("ch2.txt",$tx);
bot('sendMessage',[ 
'chat_id'=>$cid, 
'text'=>"<i>2️⃣Kanal @$tx ga o‘zgartirildi.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
unlink("stat/kanal2.txt"); 
}
$ch3 = file_get_contents("stat/kanal3.txt");
if($tx == "3️⃣-Kanal"){
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"3️⃣-Kanal uchun kanal userni @ siz kitirting :",
        'reply_markup'=>$qayt_menu, 
 
]);
file_put_contents("stat/kanal3.txt","3");
$ch4 = file_get_contents("stat/kanal4.txt");
}
if($ch3=="3" and $tx !== "↩️ oqaga"){ 
file_put_contents("ch3.txt",$tx);
bot('sendMessage',[ 
'chat_id'=>$cid, 
'text'=>"<i>3️⃣Kanal @$tx ga o‘zgartirildi.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
unlink("stat/kanal3.txt"); 
}

$ch4 = file_get_contents("stat/kanal4.txt");
if($tx == "Bonus-Kanal"){
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Bonus-Kanal uchun kanal userni @ bilan yoki kanal id sini -100 bilan kitirting :",
        'reply_markup'=>$qayt_menu, 
 
]);
file_put_contents("stat/kanal4.txt","4");
}
if($ch4=="4" and $tx !== "↩️ oqaga"){ 
file_put_contents("ch4.txt",$tx);
bot('sendMessage',[ 
'chat_id'=>$cid, 
'text'=>"<i>Bonus-Kanal $tx ga o‘zgartirildi.</i>", 
'parse_mode'=>'html', 
'reply_markup'=>$panel, 
]); 
unlink("stat/kanal4.txt");
}