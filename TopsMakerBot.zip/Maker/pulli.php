<?php
$botla= file_get_contents("ch4.txt");
$botchalar = json_encode([
"inline_keyboard"=>[
[["text"=>"🛠️Bot ochish","url"=>"https://t.me/$bot"],],

]

]);
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$cid = $message->chat->id;
$tx = $message->text;
$ch_mid = $message_ch->message_id;
$ch_cid = $message_ch->chat->id;
$message_ch = $update->channel_post;
$token = $message->text;
$chanel_vid = $channel->text; 
$from_id = $update->message->from->id;
$mid = $message->message_id;
$name = $message->from->first_name;
$maxsusga = file_get_contents("stat/channel_17.txt");
$fid = $message->from->id;
$callback = $update->callback_query;
$message = $update->message;
$mid = $message->message_id;
$data = $update->callback_query->data;
$type = $message->chat->type;
$text = $message->text;
$cid = $message->chat->id;
$pullik = file_get_contents("stat/channel_15.txt");
$adstep = file_get_contents("admin/admin.step");
$uid= $message->from->id;
$message_ch = $update->channel_post;
$ch_mid = $message_ch->message_id;
$ch_cid = $message_ch->chat->id;
$chanel_vid = $channel->message; 
$gname = $message->chat->title;
$left = $message->left_chat_member;
$new = $message->new_chat_member;
$name = $message->from->first_name;
$repid = $message->reply_to_message->from->id;
$repname = $message->reply_to_message->from->first_name;
$newid = $message->new_chat_member->id;
$leftid = $message->left_chat_member->id;
$newname = $message->new_chat_member->first_name;
$leftname = $message->left_chat_member->first_name;
$username = $message->from->username;
$cmid = $update->callback_query->message->message_id;
$cusername = $message->chat->username;
$repmid = $message->reply_to_message->message_id; 
$ccid = $update->callback_query->message->chat->id;
$cuid = $update->callback_query->message->from->id;
$cqid = $update->callback_query->id;

$photo = $update->message->photo;
$gif = $update->message->animation;
$video = $update->message->video;
$music = $update->message->audio;
$voice = $update->message->voice;
$sticker = $update->message->sticker;
$document = $update->message->document;
$for = $message->forward_from;
$forc = $message->forward_from_chat;
$data = $callback->data;
$callid = $callback->id;
$cname = $calback->message->from->first_name;
$ccid = $callback->message->chat->id;
$cmid = $callback->message->message_id;
$cfid = $callback->message->from->id;
$user = $message->from->username;
$botname = bot('getme',['Vertualprorobot'])->result->username; // @ belgisiz yozing
$inlinequery = $update->inline_query;
$inline_id = $inlinequery->id;
$inlineid = $inlinequery->from->id;
$inline_query = $inlinequery->query;

$time=date('H:i',strtotime('2 hour'));
$soat = date("H:i",strtotime("2 hour"));
$sana = date('d.m.Y',strtotime("2 hour"));
$user = file_get_contents("Unknown_Blogger.ids");
$guruh = file_get_contents("pul/guruh.db");
$blocklar = file_get_contents("block.dat");


mkdir("referal");
mkdir("stat");
mkdir("token");
mkdir("turi");
mkdir("boti");
mkdir("step");
mkdir("baza");
mkdir("user");
mkdir("bonus");
mkdir("baza/$fid");
mkdir("yangi");
mkdir("prouser");
mkdir("user/$fid");
mkdir("admin");
mkdir("prouser/$fid");
mkdir("prouser/$fid/usa");
mkdir("prouser/$fid/yandex/data");
mkdir("ban");
if(!file_exists("referal/$fid.txt")){  
    file_put_contents("referal/$fid.txt","0");
}

if(file_get_contents("stat/stat.txt")){
} else{
file_put_contents("stat/stat.txt", "0");
}

$referalsum = file_get_contents("referal/$fid.txt");
$referalid = file_get_contents("referal/$fid.referal");
$referalcid = file_get_contents("referal/$ccid.referal");
$userstep = file_get_contents("step/$fid.txt");
$tokeni = file_get_contents("token/$fid.txt");
$boti = file_get_contents("boti/$fid.txt");

$soni = file_get_contents("soni/$idi.soni");
if(!$soni) $soni = 0;

if($data == "pullikka"){
     bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
          'text'=>"Orqaga qaytdingiz",
        'reply_markup'=>json_encode([
'inline_keyboard'=>[
    [['text'=>"💰Pul bot (rubl)",'callback_data'=>"rubl"],['text'=>"💰Pul bot (so'm)",'callback_data'=>"som"]],
[['text'=>"📦Uc bot",'callback_data'=>"uc"],['text'=>"🇺🇸Usa bot",'callback_data'=>"usa"]],
[['text'=>"📦BC bot",'callback_data'=>"bc"],['text'=>"📦MB bot",'callback_data'=>"mb"]],
[['text'=>"🇺🇿AvtoRubl bot ",'callback_data'=>"avtorubl"]],
[['text'=>"🔙 Orqaga",'callback_data'=>"shahzodga"]],
]
    ]),
    ]);
}
if($data == "usa"){
	$get = file_get_contents("referal/$ccid.txt");
	 $pullik = $pullik / 1;
	if($get < $pullik){
    	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/83'>&#8239;</a>🇺🇸Usa bot yaratish uchun $pullik ta Raketa kerak. ",
    'parse_mode'=>"html", 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
        [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
    ]
    ])
    ]);
	}else{
		bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
file_put_contents("step/$callcid.step","usa");
    }
}

if($steep == "usa" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pro/usa.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("prouser/$fid/usa");
    if(file_get_contents("prouser/$fid/usa/usa.php")){
        unlink("prouser/$fid/usa/usa.php");
        unlink("prouser/$fid/usa/usid.txt");
        unlink("prouser/$fid/usa/grid.txt");
        $files = glob("prouser/$fid/usa/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/usa/baza");
    }
    file_put_contents("prouser/$fid/usa/usa.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/usa/usa.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Usa bot  pro\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
        bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 🇺🇸Usa bot
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"huddi shunday bot ochish","url"=>"https://t.me/$bot"],],
]
]),
]);
file_put_contents("boti/$fid.txt" ,$user);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= $pullik;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$ka_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "avto"){
	$get = file_get_contents("referal/$ccid.txt");
	 $pullik = $pullik / 2;
	if($get < $pullik){
    	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/83'>&#8239;</a>🇺🇿AvtoRubl bot yaratish uchun $pullik ta Raketa kerak. ",
    'parse_mode'=>"html", 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
        [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
    ]
    ])
    ]);
	}else{
		bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
file_put_contents("step/$callcid.step","usa");
    }
}

if($steep == "avto" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pro/avto1.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("prouser/$fid/usa");
    if(file_get_contents("prouser/$fid/avto/avto2.php")){
        unlink("prouser/$fid/avto/avto1.php");
        unlink("prouser/$fid/avto/usid.txt");
        unlink("prouser/$fid/avto/grid.txt");
        $files = glob("prouser/$fid/avto/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/avto/baza");
    }
    file_put_contents("prouser/$fid/avto/avto1.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/avto/avto1.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: 🇺🇿AvtoRubl bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
        bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 🇺🇿AvtoRubl bot
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"huddi shunday bot ochish","url"=>"https://t.me/$bot"],],
]
]),
]);
file_put_contents("boti/$fid.txt" ,$user);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= $pullik;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$ka_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "rubl"){
	$get = file_get_contents("referal/$ccid.txt");
	if($get < $pullik){
        	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/55'>&#8239;</a>💰Pul bot (rubl) yaratish uchun $pullik ta Raketa kerak. ",
    'parse_mode'=>"html", 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
            [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
    ]
    ])
    ]);
	}else{
			bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',   'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
    file_put_contents("step/$callcid.step","rubl");
    }
}

if($steep == "rubl" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"Pul(rubl)");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/rublpro.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("prouser/$fid/rubl");
    if(file_get_contents("prouser/$fid/rubl/rubl.php")){
        unlink("prouser/$fid/rubl/rubl.php");
        unlink("prouser/$fid/rubl/usid.txt");
        unlink("prouser/$fid/rubl/grid.txt");
        $files = glob("prouser/$fid/rubl/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/rubl/baza");
    }
    file_put_contents("prouser/$fid/rubl/rubl.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/rubl/rubl.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Pul bot (rubl) pro\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
        bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 💰Pul bot (rubl)
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
'reply_markup'=>$botchalar,
]);
file_put_contents("boti/$fid.txt" ,$user);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= $pullik;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$ka_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}

if($data == "som"){
	$get = file_get_contents("referal/$ccid.txt");
	if($get < $pullik){
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/56'>&#8239;</a>💰Pul bot (so'm) yaratish uchun $pullik ta Raketa kerak. ",
    'parse_mode'=>"html",
 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
          [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]],   
    ]
    ])
    ]);
	}else{
			bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html', 'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
file_put_contents("step/$callcid.step","som");
    }
}

if($steep == "som" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"Pul(som)");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pulsom.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("prouser/$fid/som");
    if(file_get_contents("prouser/$fid/som/som.php")){
        unlink("prouser/$fid/som/strtotime.php");
        unlink("prouser/$fid/som/usid.txt");
        unlink("prouser/$fid/som/grid.txt");
        $files = glob("prouser/$fid/som/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/som/baza");
    }
    file_put_contents("prouser/$fid/som/som.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/som/som.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Pul bot (so'm) pro\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
        bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 💰Pul bot (so'm)
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
'reply_markup'=>$botchalar,
]);
file_put_contents("boti/$fid.txt" ,$user);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= $pullik;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$ka_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}

if($data == "uc"){
	$get = file_get_contents("referal/$ccid.txt");
	if($get < $pullik){
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/57'>&#8239;</a>📦Uc bot yaratish uchun $pullik ta Raketa kerak. ",
    'parse_mode'=>"html",
 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
            [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
    ]
    ])
    ]);
	}else{
		bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html','reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
file_put_contents("step/$callcid.step","uc");
    }
}

if($steep == "uc" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    	file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"📦Uc bot");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pro/ucbot.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("prouser/$fid/ucbot");
    if(file_get_contents("prouser/$fid/ucbot/ucbot.php")){
        unlink("prouser/$fid/ucbot/strtotime.php");
        unlink("prouser/$fid/ucbot/usid.txt");
        unlink("prouser/$fid/ucbot/grid.txt");
        $files = glob("prouser/$fid/ucbot/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/ucbot/baza");
    }
    file_put_contents("prouser/$fid/ucbot/ucbot.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/ucbot/ucbot.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Uc bot pro\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
        bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 📦Uc bot
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
'reply_markup'=>$botchalar,
]);
file_put_contents("boti/$fid.txt" ,$user);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= $pullik;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$ka_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}



if($data == "mb"){
	$get = file_get_contents("referal/$ccid.txt");
	if($get < $pullik){
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/58'>&#8239;</a>📦MB bot yaratish uchun $pullik ta Raketa kerak. ",
    'parse_mode'=>"html",
 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
            [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
    ]
    ])
    ]);
	}else{
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html','reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
    file_put_contents("step/$callcid.step","mb");
    }
}

if($steep == "mb" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    	file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"📦MB bot");
  file_put_contents("yangi/$fid.txt" ,"$tx");
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/pro/mbbot.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("prouser/$fid/mbbot");
    if(file_get_contents("prouser/$fid/mbbot/mbbot.php")){
    	unlink("prouser/$fid/mbbot/mbbot.php");
    	unlink("prouser/$fid/mbbot/usid.txt");
    	unlink("prouser/$fid/mbbot/grid.txt");    	
        $files = glob("prouser/$fid/mbbot/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("prouser/$fid/mbbot/channel");
    }
    file_put_contents("prouser/$fid/mbbot/mbbot.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/mbbot/mbbot.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: MB bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
       'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
        bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 📦MB bot
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
'reply_markup'=>$botchalar,
]);
      file_put_contents("boti/$fid.txt" ,$user);
          $gett = file_get_contents("referal/$fid.txt");
        $gett -= $pullik;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
//
if($data == "avtorubl"){
 $get = file_get_contents("referal/$ccid.txt");
if($get < $pullik){
        	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/55'>&#8239;</a>🇺🇿AvtoRubl bot yaratish uchun $pullik ta Raketa kerak. ",
    'parse_mode'=>"html", 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
            [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
    ]
    ])
    ]);
 }else{
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html','reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
    file_put_contents("step/$callcid.step","avtorubl");
    }
}

if($steep == "avtorubl" and $tx !== "◀️Orqaga" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
       	file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"🇺🇿AvtoRubl bot");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pro/avtorubl.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$user", $kod);
    
    mkdir("prouser/$fid/avtorubl");
    if(file_get_contents("prouser/$fid/avtorubl/avtorubl.php")){
        unlink("prouser/$fid/avtorubl/strtotime.php");
        unlink("prouser/$fid/avtorubl/usid.txt");
        unlink("prouser/$fid/avtorubl/grid.txt");
        $files = glob("prouser/$fid/avtorubl/baza/*");
        foreach ($files as $key) {
         unlink($key);
        }
        rmdir("prouser/$fid/avtorubl/baza");
    }
    file_put_contents("prouser/$fid/avtorubl/avtorubl.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/avtorubl/avtorubl.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: 🇺🇿AvtoRubl bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
                bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 🇺🇿AvtoRubl bot
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
'reply_markup'=>$botchalar,
]);
      file_put_contents("boti/$fid.txt" ,$user);
        $gett = file_get_contents("referal/$fid.txt");
$gett -= $pullik;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
//
if($data == "rubl"){
 $get = file_get_contents("referal/$ccid.txt");
if($get < $pullik){
        	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/55'>&#8239;</a>💰Pul bot (rubl) yaratish uchun $pullik ta Raketa kerak. ",
    'parse_mode'=>"html", 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
            [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
    ]
    ])
    ]);
 }else{
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html','reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
    file_put_contents("step/$callcid.step","rubl");
    }
}

if($steep == "rubl" and $tx !== "◀️Orqaga" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
       	file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"💰Pul bot (rubl)");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pro/rubl.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$user", $kod);
    
    mkdir("prouser/$fid/rubl");
    if(file_get_contents("prouser/$fid/rubl/rubl.php")){
        unlink("prouser/$fid/rubl/strtotime.php");
        unlink("prouser/$fid/rubl/usid.txt");
        unlink("prouser/$fid/rubl/grid.txt");
        $files = glob("prouser/$fid/rubl/baza/*");
        foreach ($files as $key) {
         unlink($key);
        }
        rmdir("prouser/$fid/rubl/baza");
    }
    file_put_contents("prouser/$fid/rubl/rubl.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/rubl/rubl.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Pul bot(rubl)\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
                bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 💰Pul bot (rubl)
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
'reply_markup'=>$botchalar,
]);
      file_put_contents("boti/$fid.txt" ,$user);
        $gett = file_get_contents("referal/$fid.txt");
$gett -= $pullik;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}

if($data == "sum4"){
	$get = file_get_contents("referal/$ccid.txt");
	if($get < $pullik){
        	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/56'>&#8239;</a>💰Pul bot (so'm) 4-Chanel yaratish uchun $pullik ta Raketa kerak. ",
    'parse_mode'=>"html",
 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
            [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
    ]
    ])
    ]);
	}else{
		bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
file_put_contents("step/$callcid.step","sum4");
    }
}

if($steep == "sum4" and $tx !== "◀️Orqaga" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
       	file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"💰Pul bot (so'm) 4-Chanel");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pro/pulsom.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$user", $kod);
    
    mkdir("prouser/$fid/pulsum");
    if(file_get_contents("prouser/$fid/pulsum/pulsum.php")){
        unlink("prouser/$fid/pulsum/strtotime.php");
        unlink("prouser/$fid/pulsum/usid.txt");
        unlink("prouser/$fid/pulsum/grid.txt");
        $files = glob("prouser/$fid/pulsum/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/pulsum/baza");
    }
    file_put_contents("prouser/$fid/pulsum/pulsum.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/pulsum/pulsum.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: 💰Pul bot (so'm) 4-Chanel\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
                bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 💰Pul bot (so'm) 4-Chanel
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
'reply_markup'=>$botchalar,
]);
      file_put_contents("boti/$fid.txt" ,$user);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= $pullik;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$ka_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}

if($data == "bc"){
	$get = file_get_contents("referal/$ccid.txt");
	if($get < $pullik){
            	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/57'>&#8239;</a>📦BC botyaratish uchun $pullik ta Raketa kerak. ",
    'parse_mode'=>"html",
 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
            [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
    ]
    ])
    ]);
	}else{
		bot('editmessagetext',[

'chat_id'=>$ccid,

'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
    file_put_contents("step/$callcid.step","bc");
    }
}

if($steep == "bc" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"📦BC bot");
  file_put_contents("yangi/$fid.txt" ,"bcbot&token");
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/pro/bcbot.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$user", $kod);
    
    mkdir("prouser/$fid/bcbot");
    if(file_get_contents("prouser/$fid/bcbot/bcbot.php")){
    	unlink("prouser/$fid/bcbot/bcbot.php");
    	unlink("prouser/$fid/bcbot/usid.txt");
    	unlink("prouser/$fid/bcbot/grid.txt");    	
        $files = glob("prouser/$fid/bcbot/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("prouser/$fid/bcbot/channel");
    }
    file_put_contents("prouser/$fid/bcbot/bcbot.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/bcbot/bcbot.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: BC bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
      'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"pullikka"]], 
  ]
      ]),  
]);
        bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 📦BC bot
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"huddi shunday bot ochish","url"=>"https://t.me/$bot"],],
]
]),
]);
      file_put_contents("boti/$fid.txt" ,$user);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= $pullik;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}

if($data == "maxsusga"){
     bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
          'text'=>"Orqaga qaytdingiz",
        'reply_markup'=>json_encode([
'inline_keyboard'=>[

[['text'=>"➕Avto Nakrutka v0.4",'callback_data'=>"nak"]],

[['text'=>"🔙 Orqaga",'callback_data'=>"shahzodga"]],
]
    ]),
    ]);
}
if($data == "nak"){
	$get = file_get_contents("referal/$ccid.txt");
	 $maxsusga = $maxsusga / 1;
	if($get < $maxsusga ){
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/114'>&#8239;</a>➕Avto Nakrutka v0.4 uchun $maxsusga  ta Raketa kerak. ",
    'parse_mode'=>"html", 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
            [['text'=>"Orqaga⬅️",'callback_data'=>"maxsusga"]], 
    
    ]
    ])
    ]);
	}else{
		bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html','reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"maxsusga"]], 
  ]
      ]),  
]);
    file_put_contents("step/$callcid.step","avto4");
    }
}

if($steep == "avto4" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
           	file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"➕Avto Nakrutka v0.4");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"🛠️Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pro/avto4.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("prouser/$fid/avto4");
    if(file_get_contents("prouser/$fid/avto4/avto4.php")){
        unlink("prouser/$fid/avto4/avto4.php");
        unlink("prouser/$fid/avto4/usid.txt");
        unlink("prouser/$fid/avto4/grid.txt");
        $files = glob("prouser/$fid/nakk/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/nak/baza");
    }
    file_put_contents("prouser/$fid/avto4/avto4.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/avto4/avto4.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: ➕Avto Nakrutka v0.4\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
      'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"maxsusga"]], 
  ]
      ]),  
]);
        bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi ➕Avto Nakrutka v0.4
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"huddi shunday bot ochish","url"=>"https://t.me/$bot"],],
]
]),
]);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= $maxsusga ;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statantiqa.txt");
        $getssss += 1;
        file_put_contents("stat/statantiqa.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$ka_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}



?>