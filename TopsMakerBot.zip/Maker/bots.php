<?php
$botla= file_get_contents("ch4.txt");
$botchalar = json_encode([
"inline_keyboard"=>[
[["text"=>"🛠️Bot ochish","url"=>"https://t.me/$bot"],],

]

]);

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$cid = $message->chat->id;
$tx = $message->text;
$ch_mid = $message_ch->message_id;
$ch_cid = $message_ch->chat->id;
$message_ch = $update->channel_post;
$token = $message->text;
$chanel_vid = $channel->text; 
$from_id = $update->message->from->id;
$data = $callback->data;
$callid = $callback->id;
$message = $update->message;
$cid = $message->chat->id;
$tx = $message->text;
$from_id = $update->message->from->id;
$mid = $message->message_id;
$name = $message->from->first_name;
$fid = $message->from->id;
$callback = $update->callback_query;
$message = $update->message;
$mid = $message->message_id;
$data = $update->callback_query->data;
$type = $message->chat->type;
$text = $message->text;
$cid = $message->chat->id;
$uid= $message->from->id;
$gname = $message->chat->title;
$left = $message->left_chat_member;
$new = $message->new_chat_member;
$name = $message->from->first_name;
$repid = $message->reply_to_message->from->id;
$repname = $message->reply_to_message->from->first_name;
$newid = $message->new_chat_member->id;
$leftid = $message->left_chat_member->id;
$newname = $message->new_chat_member->first_name;
$leftname = $message->left_chat_member->first_name;
$username = $message->from->username;
$cmid = $update->callback_query->message->message_id;
$cusername = $message->chat->username;
$repmid = $message->reply_to_message->message_id; 
$ccid = $update->callback_query->message->chat->id;
$cuid = $update->callback_query->message->from->id;
$cqid = $update->callback_query->id;
$data=$update->callback_query->data;
$callcid=$update->callback_query->message->chat->id;
$callmid=$update->callback_query->message->message_id;
$from_id = $message->from->id;
$steep = file_get_contents("step/$from_id.step");
$userstep = file_get_contents("step/$from_id.step");
$photo = $update->message->photo;
$gif = $update->message->animation;
$video = $update->message->video;
$music = $update->message->audio;
$voice = $update->message->voice;
$sticker = $update->message->sticker;
$document = $update->message->document;
$for = $message->forward_from;
$forc = $message->forward_from_chat;
$data = $callback->data;
$callid = $callback->id;
$cname = $calback->message->from->first_name;
$ccid = $callback->message->chat->id;
$cmid = $callback->message->message_id;
$cfid = $callback->message->from->id;
$user = $message->from->username;

$inlinequery = $update->inline_query;
$inline_id = $inlinequery->id;
$inlineid = $inlinequery->from->id;
$inline_query = $inlinequery->query;
$cname = $calback->message->from->first_name;
$ccid = $callback->message->chat->id;
$cmid = $callback->message->message_id;
$cfid = $callback->message->from->id;
$user = $message->from->username;
$mid = $message->message_id;
$name = $message->from->first_name;
$fid = $message->from->id;
$callback = $update->callback_query;
$message = $update->message;
$mid = $message->message_id;
$data = $update->callback_query->data;
$type = $message->chat->type;
$text = $message->text;
$cid = $message->chat->id;
$adstep = file_get_contents("admin/admin.step");
$uid= $message->from->id;
$message_ch = $update->channel_post;
$ch_mid = $message_ch->message_id;
$ch_cid = $message_ch->chat->id;
$chanel_vid = $channel->message; 
$gname = $message->chat->title;
$left = $message->left_chat_member;
$new = $message->new_chat_member;
$name = $message->from->first_name;
$repid = $message->reply_to_message->from->id;
$repname = $message->reply_to_message->from->first_name;
$newid = $message->new_chat_member->id;
$leftid = $message->left_chat_member->id;
$newname = $message->new_chat_member->first_name;
$leftname = $message->left_chat_member->first_name;
$username = $message->from->username;
$cmid = $update->callback_query->message->message_id;
$cusername = $message->chat->username;
$repmid = $message->reply_to_message->message_id; 
$ccid = $update->callback_query->message->chat->id;
$cuid = $update->callback_query->message->from->id;
$cqid = $update->callback_query->id;

$photo = $update->message->photo;
$gif = $update->message->animation;
$video = $update->message->video;
$music = $update->message->audio;
$voice = $update->message->voice;
$sticker = $update->message->sticker;
$document = $update->message->document;
$for = $message->forward_from;
$forc = $message->forward_from_chat;
$data = $callback->data;
$callid = $callback->id;
$cname = $calback->message->from->first_name;
$ccid = $callback->message->chat->id;
$cmid = $callback->message->message_id;
$cfid = $callback->message->from->id;
$user = $message->from->username;
$callcid=$update->callback_query->message->chat->id;
$callmid=$update->callback_query->message->message_id;
$from_id = $message->from->id;

$inlinequery = $update->inline_query;
$inline_id = $inlinequery->id;
$inlineid = $inlinequery->from->id;
$inline_query = $inlinequery->query;

$time=date('H:i',strtotime('0 hour'));
$soat = date("H:i",strtotime("0 hour"));
$sana = date('d.m.Y',strtotime("0 hour"));
$user = file_get_contents("Unknown_Blogger.ids");
$guruh = file_get_contents("pul/guruh.db");
$blocklar = file_get_contents("block.dat");


mkdir("referal");
mkdir("stat");
mkdir("token");
mkdir("turi");
mkdir("boti");
mkdir("step");
mkdir("baza");
mkdir("user");
mkdir("bonus");
mkdir("baza/$fid");
mkdir("yangi");
mkdir("prouser");
mkdir("user/$fid");
mkdir("admin");
mkdir("prouser/$fid");
mkdir("prouser/$fid/usa");
mkdir("prouser/$fid/yandex/data");
mkdir("ban");
if(!file_exists("referal/$fid.txt")){  
    file_put_contents("referal/$fid.txt","0");
}

if(file_get_contents("stat/stat.txt")){
} else{
file_put_contents("stat/stat.txt", "0");
}

$referalsum = file_get_contents("referal/$fid.txt");
$referalid = file_get_contents("referal/$fid.referal");
$referalcid = file_get_contents("referal/$ccid.referal");
$userstep = file_get_contents("step/$fid.txt");
$tokeni = file_get_contents("token/$fid.txt");
$boti = file_get_contents("boti/$fid.txt");

$soni = file_get_contents("soni/$idi.soni");
if(!$soni) $soni = 0;

if($data == "bepulbulimga"){
     bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
        'text'=>"B̆̈Ĕ̈P̆̈Ŭ̈L̆̈ B̆̈Ŏ̈T̆̈L̆̈Ă̈R̆̈ B̆̈Ŏ̈'L̆̈Ĭ̈M̆̈Ĭ̈Ğ̈Ă̈ Q̆̈Ă̈Y̆̈T̆̈D̆̈Ĭ̈Ğ̈Ĭ̈Z̆̈",
        'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🖋 Nik bot",'callback_data'=>"nikbot"],['text'=>"❤️ Channel like",'callback_data'=>"channellike"]],
    [['text'=>"🕋Quron bot",'callback_data'=>"quron"],['text'=>"⚡Webhook bot",'callback_data'=>"webhook"]],
    [['text'=>"📽️Gif bot",'callback_data'=>"gif"],['text'=>"☢️ Konvertor bot",'callback_data'=>"konvertor"]],
    [['text'=>"🖼️Logo bot",'callback_data'=>"logo"],['text'=>"👨‍👨‍👧‍👦Go'zalik test bot",'callback_data'=>"guzalliktest"]],
    [['text'=>"👤Obunachi v0.1",'callback_data'=>"obunachi"],['text'=>"🔰Universal bot",'callback_data'=>"universal"]],
    [['text'=>"Harfga video bot 📎",'callback_data'=>"harfga"],['text'=>"Test bot",'callback_data'=>"test"]],
   [['text'=>"📟 Kalkulyator",'callback_data'=>"kalkulyator"],['text'=>"🔙 Orqaga",'callback_data'=>"shahzodga"]],

    ]
    ]),
    ]);
}

$stat = file_get_contents("stat/usid.txt");
if($data == "guzalliktest" ){

		bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html', 
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
        
    ]);
file_put_contents("step/$callcid.step","guzalliktest");;
}

if($steep == "guzalliktest" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    file_put_contents("token/$fid.txt" ,$tx);
file_put_contents("turi/$fid.txt" ,"👨‍👨‍👧‍👦Go'zalik test bot");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"⚔️Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/test.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("user/$fid/test");
    if(file_get_contents("user/$fid/test/test.php")){
        unlink("user/$fid/test/test.php");
    }
    file_put_contents("user/$fid/test/test.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/test/test.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Go'zalik test bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
        ]);
        bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 👨‍👨‍👧‍👦Go'zalik test bot
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
"reply_markup"=>$botchalar
]);
file_put_contents("boti/$fid.txt" ,$user);
        
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$bek_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}


if($data == "quron"){
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html', 
               'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
    ]);
file_put_contents("step/$callcid.step","quron");
}

if($steep == "quron" and $tx !== "⬅️ Bekor qilish" ){
    if(mb_stripos($tx, ":")!==false){
    file_put_contents("token/$fid.txt" ,"$tx");
file_put_contents("turi/$fid.txt" ,"🕋Quron bot");
  file_put_contents("yangi/$fid.txt" ,"quron");
        $getid = bot('editmessagetext',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
        'text'=>"⚔️Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/quron.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    $kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("user/$fid/quron");
    if(file_get_contents("user/$fid/quron/quron.php")){
        unlink("user/$fid/quron/quron.php");
    }
    file_put_contents("user/$fid/quron/quron.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/quron/quron.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
bot('Sendmessage',[
'chat_id'=>$cid,
'message_id'=>$mid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Quron bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
        ]);
        bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 🕋Quron bot
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
"reply_markup"=>$botchalar
]);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
file_put_contents("boti/$fid.txt" ,$user);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"?? Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$bek_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}

if($data == "channellike"){
    	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',  
                'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
    ]);
file_put_contents("step/$callcid.step","channellike");
}

if($steep == "channellike" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    file_put_contents("token/$fid.txt" ,$tx);
file_put_contents("turi/$fid.txt" ,"❤️ Channel like");
file_put_contents("step/$from_id.txt","$tx");
  file_put_contents("yangi/$fid.txt" ,"tx");
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/like.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("user/$fid/like");
    if(file_get_contents("user/$fid/like/like.php")){
        $files = glob("user/$fid/like/like/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/like/like");
        $files = glob("user/$fid/like/baza/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/like/baza");
    }
    file_put_contents("user/$fid/like/like.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/like/like.php"))->result;

    if($get==true){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Channel like bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
                'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
        ]);
        bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi ❤️ Channel like
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
"reply_markup"=>$botchalar
]);
$getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}


if($data == "nikbot"){
     	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
       'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',   
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
    ]);
    file_put_contents("step/$callcid.step","nikbot");;
}

if($steep == "nikbot" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    	file_put_contents("step/$from_id.txt","$tx");;
file_put_contents("turi/$fid.txt" ,"🖋 Nik bot");
  file_put_contents("yangi/$fid.txt" ,"$tx");
          bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        
    $kod = file_get_contents("bots/nick.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("user/$fid/nick");
    if(file_get_contents("user/$fid/nick/nick.php")){
        unlink("user/$fid/nick/nick.php");
    }
    file_put_contents("user/$fid/nick/nick.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/nick/nick.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;

        	bot('sendmessage',[
'chat_id'=>$cid,
'message_id'=>$mid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Nick bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
                'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
    
]);
bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi  🖋 Nik bot
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a> $sana $time $sana $time",
'parse_mode'=>'html',
'reply_markup'=>$botchalar,
]);
file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {     
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);   
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}


if($data == "webhook"){
		bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',  
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])]);
    file_put_contents("step/$callcid.step","webhook");
}

if($steep == "webhook" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($token, ":")!==false){
file_put_contents("token/$fid.txt" ,$tx);
file_put_contents("turi/$fid.txt" ,"Webhook");
 file_put_contents("yangi/$fid.txt" ,"$tx"); 
 
  $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/web.php");
    $kod = str_replace("API_TOKEN", "$token", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("user/$fid/web");
    if(file_get_contents("user/$fid/web/web.php")){
        $files = glob("user/$fid/web/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/web/channel");
    }
    file_put_contents("user/$fid/web/web.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/web/web.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Webhook bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
        ]);
        bot('sendmessage',[ 
        'chat_id'=>$botla, 
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi:⚡Webhook bot
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
        file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
    }
unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}

if($data=="gif"){
		bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',   
          'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])  ]);
   file_put_contents("step/$callcid.step","gif");
}

if($steep == "gif" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($token, ":")!==false){
file_put_contents("token/$fid.txt" ,$tx);
file_put_contents("yangi/$fid.txt" ,"$tx"); 
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/gif.php");
    $kod = str_replace("API_TOKEN", "$token", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("user/$fid/gif");
    if(file_get_contents("user/$fid/gif/gif.php")){
        $files = glob("user/$fid/gif/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/gif/channel");
    }
    file_put_contents("user/$fid/gif/gif.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/gif/gif.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Gif bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
                'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
        ]);
        bot('sendmessage',[ 
        'chat_id'=>$botla,   
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi: 📽️Gif bot
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
        file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }
    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}



if($data=="konvertor"){
    	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',           'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
    ]);
    file_put_contents("step/$callcid.step","konvertor");
}

if($steep == "konvertor" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($token, ":")!==false){
file_put_contents("token/$fid.txt" ,$tx);
file_put_contents("turi/$fid.txt" ,"☢️ Konvertor bot");
file_put_contents("yangi/$fid.txt" ,"$tx"); 
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/konvertor.php");
    $kod = str_replace("API_TOKEN", "$token", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("user/$fid/konver");
    if(file_get_contents("user/$fid/konver/konvertor.php")){
        $files = glob("user/$fid/konvero/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/konver/channel");
    }
    file_put_contents("user/$fid/konver/konvertor.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/konver/konvertor.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi:☢️ Konvertor bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
                'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
        ]);
        bot('sendmessage',[ 
        'chat_id'=>$botla, 
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi ☢️ Konvertor bot
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
        file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "universal"){
    	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',         'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])  
    ]);
    file_put_contents("step/$callcid.step","universal");
}

if($steep == "universal" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($token, ":")!==false){
file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"🔰Universal bot");
file_put_contents("yangi/$fid.txt" ,"$token"); 
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/uni.php");
    $kod = str_replace("API_TOKEN", "$token", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
$kod = str_replace("BOTNAME", "$user", $kod);
    
    mkdir("user/$fid/uni");
    if(file_get_contents("user/$fid/uni/uni.php")){
        $files = glob("user/$fid/uni/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/uni/channel");
    }
    file_put_contents("user/$fid/uni/uni.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/uni/uni.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi:🔰Universal bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
        ]);
        bot('sendmessage',[ 
        'chat_id'=>$botla, 
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi🔰Universal bot
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
        file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "harfga" ){
    		bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',          'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
    ]);
file_put_contents("step/$callcid.step","harfga");
}

if($steep == "harfga" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($token, ":")!==false){
file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"Harfga video bot 📎");
file_put_contents("yangi/$fid.txt" ,"$token"); 
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/harf.php");
    $kod = str_replace("API_TOKEN", "$token", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
$kod = str_replace("BOTNAME", "$user", $kod);
    
    mkdir("user/$fid/harf");
    if(file_get_contents("user/$fid/harf/harf.php")){
        $files = glob("user/$fid/harf/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/harf/channel");
    }
    file_put_contents("user/$fid/harf/harf.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/harf/harf.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi:Harfga video bot 📎\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
        ]);
        bot('sendmessage',[ 
        'chat_id'=>$botla, 
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi:Harfga video bot 📎
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
        file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "test") {
    		bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',          'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
    ]);
file_put_contents("step/$callcid.step","test");
}

if($steep == "test" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($token, ":")!==false){
file_put_contents("token/$fid.txt" ,$tx);
file_put_contents("turi/$fid.txt" ,"Test bot");
file_put_contents("yangi/$fid.txt" ,"$token"); 
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/testt.php");
    $kod = str_replace("API_TOKEN", "$token", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
$kod = str_replace("BOTNAME", "$user", $kod);
    
    mkdir("user/$fid/test");
    if(file_get_contents("user/$fid/test/testt.php")){
        $files = glob("user/$fid/test/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/test/channel");
    }
    file_put_contents("user/$fid/test/testt.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/test/testt.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Test bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
                'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
        ]);
        bot('sendmessage',[ 
        'chat_id'=>$botla, 
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi: Test bot
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
        file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "kalkulyator" ){
   	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',          'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
]) 
    ]);
    file_put_contents("step/$callcid.step","kalkulyator");
}

if($steep == "kalkulyator" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($token, ":")!==false){
file_put_contents("token/$fid.txt" ,$tx);
file_put_contents("turi/$fid.txt" ," 📟 Kalkulyator");
file_put_contents("yangi/$fid.txt" ,"$token"); 
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/kalc.php");
    $kod = str_replace("API_TOKEN", "$token", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
$kod = str_replace("BOTNAME", "$user", $kod);
    
    mkdir("user/$fid/kalc");
    if(file_get_contents("user/$fid/kalc/kalc.php")){
        $files = glob("user/$fid/kalc/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/kalc/channel");
    }
    file_put_contents("user/$fid/kalc/kalc.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/kalc/kalc.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi:  📟 Kalkulyator\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
        ]);
        bot('sendmessage',[ 
        'chat_id'=>$botla, 
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi: 📟 Kalkulyator
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
        file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "obunachi"){
			bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
    ]);
    file_put_contents("step/$callcid.step","obunachi");
    
}

if($steep == "obunachi" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    file_put_contents("token/$fid.txt" ,$tx);
file_put_contents("turi/$fid.txt" ,"👤Obunachi v0.1");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $botuser = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"✅ Siz yuborgan bot tokeni qabul qilindi!"
        ])->result->message_id;
    $kod = file_get_contents("bots/obunachi.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    $kod = str_replace("ADMIN_USER", "$user", $kod);

    
    mkdir("prouser/$fid/obunachi");
    if(file_get_contents("prouser/$fid/obunachi/obunachi.php")){
        unlink("prouser/$fid/obunachi/obunachi.php");
        unlink("prouser/$fid/obunachi/usid.txt");
        unlink("prouser/$fid/obunachi/grid.txt");
    }
    file_put_contents("prouser/$fid/obunachi/obunachi.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/obunachi/obunachi.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',[
'chat_id'=>$cid,
'message_id'=>$getid
]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"ℹ️ Botingiz tayyor. Quyidagi tugma orqali botingizga o'tishingiz mumkin.
<code>/panel</code> - Ushbu buyrug' orqali botingizni sozlab olishingiz mumkin\n✳️ Useri: @$user.",
        'parse_mode'=>"html",
        
            'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
]);
bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 👤Obunachi v0.1
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"huddi shunday bot ochish","url"=>"https://t.me/$bot"],],
]
]),
]);
       file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } 

    unlink("step/$fid.txt");
   }
}
if($data=="logo" and $text !="/start"){

bot('editmessagetext',[

'chat_id'=>$callcid,

'message_id'=>$callmid,
  
      'text'=>" <a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',          'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])  
    ]);  file_put_contents("step/$callcid.step","logo");
}

if($steep == "logo" and $text !="/start"){
if(mb_stripos($tx, ":")!==false){
file_put_contents("step/$from_id.txt","$tx");
file_put_contents("turi/$fid.txt" ,"👨‍👨‍👧‍👦Go'zalik test bot");
  file_put_contents("yangi/$fid.txt" ,"$tx");
bot('sendMessage',[
'chat_id'=>$from_id,
        'text'=>""
        ])->result->message_id; 
    $kod = file_get_contents("bots/logo.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$user", $kod);
    
    mkdir("user/$fid/logo");
    if(file_get_contents("user/$fid/logo/logo.php")){
        $files = glob("user/$fid/logo/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/logo/channel");
    }
    file_put_contents("user/$fid/logo/logo.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/logo/logo.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        ]);
        bot('sendMessage',[
        'chat_id'=>$from_id,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Logo bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga"]],
]
])
        ]);
          bot('sendmessage',[ 
        'chat_id'=>$botla, 
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi 🖼️Logo bot
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
        file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("$callcid.step");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}

?>