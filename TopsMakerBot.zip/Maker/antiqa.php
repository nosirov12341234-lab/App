<?php
$botla= file_get_contents("ch4.txt");
$botchalar = json_encode([
"inline_keyboard"=>[
[["text"=>"🛠️Bot ochish","url"=>"https://t.me/$bot"],],

]

]);
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$cid = $message->chat->id;
$tx = $message->text;
$ch_mid = $message_ch->message_id;
$ch_cid = $message_ch->chat->id;
$message_ch = $update->channel_post;
$token = $message->text;
$chanel_vid = $channel->text; 
$from_id = $update->message->from->id;
$mid = $message->message_id;
$ch2 = file_get_contents("ch2.txt");
$name = $message->from->first_name;
$fid = $message->from->id;
$callback = $update->callback_query;
$message = $update->message;
$mid = $message->message_id;
$data = $update->callback_query->data;
$type = $message->chat->type;
$text = $message->text;
$antiqam = file_get_contents("stat/channel_13.txt");
$cid = $message->chat->id;
$adstep = file_get_contents("admin/admin.step");
$uid= $message->from->id;
$message_ch = $update->channel_post;
$ch_mid = $message_ch->message_id;
$ch_cid = $message_ch->chat->id;
$chanel_vid = $channel->message; 
$gname = $message->chat->title;
$left = $message->left_chat_member;
$new = $message->new_chat_member;
$name = $message->from->first_name;
$repid = $message->reply_to_message->from->id;
$repname = $message->reply_to_message->from->first_name;
$newid = $message->new_chat_member->id;
$leftid = $message->left_chat_member->id;
$newname = $message->new_chat_member->first_name;
$leftname = $message->left_chat_member->first_name;
$username = $message->from->username;
$cmid = $update->callback_query->message->message_id;
$cusername = $message->chat->username;
$repmid = $message->reply_to_message->message_id; 
$ccid = $update->callback_query->message->chat->id;
$cuid = $update->callback_query->message->from->id;
$cqid = $update->callback_query->id;

$photo = $update->message->photo;
$gif = $update->message->animation;
$video = $update->message->video;
$music = $update->message->audio;
$voice = $update->message->voice;
$sticker = $update->message->sticker;
$document = $update->message->document;
$for = $message->forward_from;
$forc = $message->forward_from_chat;
$data = $callback->data;
$callid = $callback->id;
$cname = $calback->message->from->first_name;
$ccid = $callback->message->chat->id;
$cmid = $callback->message->message_id;
$cfid = $callback->message->from->id;
$user = $message->from->username;
$botname = bot('getme',['Vertualprorobot'])->result->username; // @ belgisiz yozing
$inlinequery = $update->inline_query;
$inline_id = $inlinequery->id;
$inlineid = $inlinequery->from->id;
$inline_query = $inlinequery->query;

$time=date('H:i',strtotime('0 hour'));
$soat = date("H:i",strtotime("0 hour"));
$sana = date('d.m.Y',strtotime("0 hour"));
$user = file_get_contents("Unknown_Blogger.ids");
$guruh = file_get_contents("pul/guruh.db");
$blocklar = file_get_contents("block.dat");
$getss= file_get_contents("admin/blocks.txt");
if(mb_stripos($getss, $fid)!==false){
	bot('sendMessage',[
	'chat_id' => $cid,
	'text' => "Kechirasiz <b>$name</b> siz bloklangansiz!",
	'parse_mode'=>'html',
	]); 
	return false;
	}

mkdir("referal");
mkdir("stat");
mkdir("token");
mkdir("turi");
mkdir("boti");
mkdir("step");
mkdir("baza");
mkdir("user");
mkdir("bonus");
mkdir("baza/$fid");
mkdir("yangi");
mkdir("prouser");
mkdir("user/$fid");
mkdir("admin");
mkdir("prouser/$fid");
mkdir("prouser/$fid/usa");
mkdir("prouser/$fid/yandex/data");
mkdir("ban");
if(!file_exists("referal/$fid.txt")){  
    file_put_contents("referal/$fid.txt","0");
}

if(file_get_contents("stat/stat.txt")){
} else{
file_put_contents("stat/stat.txt", "0");
}

$referalsum = file_get_contents("referal/$fid.txt");
$referalid = file_get_contents("referal/$fid.referal");
$referalcid = file_get_contents("referal/$ccid.referal");
$userstep = file_get_contents("step/$fid.txt");
$tokeni = file_get_contents("token/$fid.txt");
$boti = file_get_contents("boti/$fid.txt");

$soni = file_get_contents("soni/$idi.soni");
if(!$soni) $soni = 0;

if($data == "antiqaga"){
     bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
          'text'=>"Orqaga qaytdingiz",
        'reply_markup'=>json_encode([
'inline_keyboard'=>[
     [['text'=>"😍 Smile",'callback_data'=>"smile"],['text'=>"🎊Yandex",'callback_data'=>"yandex"]],
[['text'=>"Konspekt bot📝",'callback_data'=>"konspekt"],['text'=>"💫Nik Bot v.03",'callback_data'=>"nikv3"]],
[['text'=>"🔐Zip Bot(tamirda)",'callback_data'=>"zip"],['text'=>"🎛️Menu bot ",'callback_data'=>"menu"]],
[['text'=>"🔵Majburiy Azo",'callback_data'=>"majburiy"],['text'=>"🌙Islomiy Bot",'callback_data'=>"islomiy"]],
     [['text'=>"🎵Vkm bot",'callback_data'=>"vkm"]],
[['text'=>"📥 Down ",'callback_data'=>"down"]],
[['text'=>"🔙 Orqaga",'callback_data'=>"shahzodga"]],
]
    ]),
    ]);
}

if($data == "smile"){
	$get = file_get_contents("referal/$ccid.txt");
	 $antiqam = $antiqam / 1;
	if($get < $antiqam){
    	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/63'>&#8239;</a>😍 Smile bot  yaratish uchun $antiqam ta Raketa kerak.
Quyidagi havolani do'stlaringizga tarqatib Raketa yig'ing:
<code>https://t.me/$botname?start=$fid</code>
!\Do'stingiz kanalimizga a'zo bo'lmasa sizga Raketa berilmaydi!
Yoki $adminuser'ga murojaat qilib Raketa sotib oling!.
Quyidagi havolani do'stlaringizga tarqatib Raketa yig'ing:\n<code>https://t.me/$botname?start=$fid</code>\n!\Do'stingiz kanalimizga a'zo bo'lmasa sizga Raketa berilmaydi!\nYoki $adminuser'ga murojaat qilib Raketa sotib oling! ",
    'parse_mode'=>"html",
 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
        [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
    ]
    ])
    ]);
	}else{
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
    
    file_put_contents("step/$callcid.step","smile");
    }
}

if($steep == "smile" and $tx !== "🔚Ortga" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    	file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"😍 Smile");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pro/smile.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("prouser/$fid/smilebot");
    if(file_get_contents("prouser/$fid/smilebot/smilebot.php")){
        unlink("prouser/$fid/smilebot/strtotime.php");
        unlink("prouser/$fid/smilebot/usid.txt");
        unlink("prouser/$fid/smilebot/grid.txt");
        $files = glob("prouser/$fid/smilebot/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/smilebot/baza");
    }
    file_put_contents("prouser/$fid/smilebot/smilebot.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/smilebot/smilebot.php"))->result;     

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: 😍 Smile bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
       
bot('sendmessage',[
        'chat_id'=>$botla,
       
'text'=>"Diqqat yangi bot yaratildi
🤖 Bot turi:😍 Smile
🤖 Bot nomi $nomi
🤖 Useri @$user
🗄 Id raqami $id
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
'reply_markup'=>$botchalar,
]);
file_put_contents("boti/$fid.txt" ,$user);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= $antiqam;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statantiqa.txt");
        $getssss += 1;
        file_put_contents("stat/statantiqa.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}

if($data == "zip"){
 $get = file_get_contents("referal/$ccid.txt");
 if($get < $antiqam){
    	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/60'>&#8239;</a>🔐Zip Bot yaratish uchun $antiqam  ta Raketa kerak. ",
    'parse_mode'=>"html",
 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
        [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
    
    ]
    ])
    ]);
 }else{
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
    
file_put_contents("step/$callcid.step","zip");
    }
}

if($steep == "zip" and $tx !== "🔚Ortga" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    	file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"🔐Zip Bot");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pro/file.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("prouser/$fid/filebot");
    if(file_get_contents("prouser/$fid/filebot/filebot.php")){
        unlink("prouser/$fid/filebot/strtotime.php");
        unlink("prouser/$fid/filebot/usid.txt");
        unlink("prouser/$fid/filebot/grid.txt");
        $files = glob("prouser/$fid/filebot/baza/*");
        foreach ($files as $key) {
         unlink($key);
        }
        rmdir("prouser/$fid/filebot/baza");
    }
    file_put_contents("prouser/$fid/filebot/filebot.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/filebot/filebot.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi:🔐Zip Bot bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n admin panel mavjud emas",
        'parse_mode'=>"html",
         'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 🔐Zip Bot
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
'reply_markup'=>$botchalar,
]);
file_put_contents("boti/$fid.txt" ,$user);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= $antiqam;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statantiqa.txt");
        $getssss += 1;
        file_put_contents("stat/statantiqa.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "nikv3"){
	$get = file_get_contents("referal/$ccid.txt");
	if($get < $antiqam){
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/62'>&#8239;</a>💫Nik Bot v.03  yaratish uchun $antiqam ta Raketa kerak.
Quyidagi havolani do'stlaringizga tarqatib Raketa yig'ing:
<code>https://t.me/$botname?start=$fid</code>
!\Do'stingiz kanalimizga a'zo bo'lmasa sizga Raketa berilmaydi!
Yoki $adminuser'ga murojaat qilib Raketa sotib oling!. ",
    'parse_mode'=>"html",
 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
        [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
    
    ]
    ])
    ]);
	}else{
		bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
    
    
file_put_contents("step/$callcid.step","nikv3");
    }
}

if($steep == "nikv3" and $tx !== "🔚Ortga" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    	file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"💫Nik Bot v.03");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pro/udarnick.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("prouser/$fid/udarnickbot");
    if(file_get_contents("prouser/$fid/udarnickbot/udarnickbot.php")){
        unlink("prouser/$fid/udarnickbot/strtotime.php");
        unlink("prouser/$fid/udarnickbot/usid.txt");
        unlink("prouser/$fid/udarnickbot/grid.txt");
        $files = glob("prouser/$fid/udarnickbot/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/udarnickbot/baza");
    }
    file_put_contents("prouser/$fid/udarnickbot/udarnickbot.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/udarnickbot/udarnickbot.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi:💫Nik Bot v.03 bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
         'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
        bot('sendmessage',[
        'chat_id'=>$botla,
       
'text'=>"Diqqat yangi bot yaratildi
🤖 Bot turi:💫Nik Bot v.03
🤖 Bot nomi $nomi
🤖 Useri @$user
🗄 Id raqami $id
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
'reply_markup'=>$botchalar,
]);
file_put_contents("boti/$fid.txt" ,$user);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= $antiqam;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statantiqa.txt");
        $getssss += 1;
        file_put_contents("stat/statantiqa.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "yandex"){
	$boti = file_get_contents("referal/$ccid.txt");
	if($boti  <$antiqam){
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/61'>&#8239;</a>🎊Yandex  yaratish uchun $antiqam ta Raketa kerak.
Quyidagi havolani do'stlaringizga tarqatib Raketa yig'ing:
<code>https://t.me/$botname?start=$fid</code>
!\Do'stingiz kanalimizga a'zo bo'lmasa sizga Raketa berilmaydi!
Yoki $adminuser'ga murojaat qilib Raketa sotib oling!. ",
    'parse_mode'=>"html",
 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
        [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
    
    ]
    ])
    ]);
	}else{
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',     'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
    file_put_contents("step/$callcid.step","yandex");
    }
}

if($steep == "yandex" and $tx !== "🔚Ortga" and joinchat($fid)=="true"){
    if(mb_stripos($token, ":")!==false){
file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"yandex");
file_put_contents("yangi/$fid.txt" ,"$tx");
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/yandex.php");
    $kod = str_replace("API_TOKEN", "$token", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    $kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("prouser/$fid/yandex");
    if(file_get_contents("prouser/$fid/yandex/yandex.php")){
        unlink("prouser/$fid/shahzod/yandex.php");
        unlink("prouser/$fid/shahzod/usid.txt");
        unlink("prouser/$fid/shahzod/grid.txt");
        $files = glob("prouser/$fid/shahzod/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/yandex/baza");
    }
    file_put_contents("prouser/$fid/yandex/yandex.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/yandex/yandex.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: 🎊Yandex bot \n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
        bot('sendmessage',[ 
        'chat_id'=>$botla,  
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi:🎊Yandex
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
file_put_contents("boti/$fid.txt" ,$user);
        file_put_contents("boti/$fid.txt" );
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= $antiqam;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statantiqa.txt");
        $getssss += 1;
        file_put_contents("stat/statantiqa.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html",
        'reply_markup'=>$ka_menu
        ]);
    }

 unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "majburiy"){
	$get = file_get_contents("referal/$ccid.txt");
	if($get < $antiqam){
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/59'>&#8239;</a>🔵Majburiy Azo  yaratish uchun $antiqam ta Raketa kerak.
Quyidagi havolani do'stlaringizga tarqatib Raketa yig'ing:
<code>https://t.me/$botname?start=$fid</code>
!\Do'stingiz kanalimizga a'zo bo'lmasa sizga Raketa berilmaydi!
Yoki $adminuser'ga murojaat qilib Raketa sotib oling!. ",
    'parse_mode'=>"html",
 
  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
        [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
    ]
    ])
    ]);
	}else{
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
    
file_put_contents("step/$callcid.step","majburiy");
    }
}

if($steep == "majburiy" and $tx !== "🔚Ortga" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    	file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"🔵Majburiy Azo");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/kanalgakir.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$user", $kod);
$kod = str_replace("KANAL",$name,$kod);    
    mkdir("prouser/$fid/kanalgakir");
    if(file_get_contents("prouser/$fid/kanalgakir/kanalgakir.php")){
        unlink("prouser/$fid/kanalgakir/strtotime.php");
        unlink("prouser/$fid/kanalgakir/usid.txt");
        unlink("prouser/$fid/kanalgakir/grid.txt");
        $files = glob("prouser/$fid/kanalgakir/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/kanalgakir/baza");
    }
    file_put_contents("prouser/$fid/kanalgakir/kanalgakir.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/kanalgakir/kanalgakir.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: 🔵Majburiy Azo\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n /panel mavjud emas ",
        'parse_mode'=>"html",
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
bot('sendmessage',[
        'chat_id'=>$botla,
       
'text'=>"Diqqat yangi bot yaratildi
🤖 Bot turi:🔵Majburiy Azo
🤖 Bot nomi $nomi
🤖 Useri @$user
🗄 Id raqami $id
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
'reply_markup'=>$botchalar,
]);
file_put_contents("boti/$fid.txt" ,$user);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= $antiqam;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statantiqa.txt");
        $getssss += 1;
        file_put_contents("stat/statantiqa.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "menu"){
	$get = file_get_contents("referal/$ccid.txt");
	if($get < $antiqam){
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/90'>&#8239;</a>🎛️Menu bot   yaratish uchun $antiqam ta Raketa kerak.
Quyidagi havolani do'stlaringizga tarqatib Raketa yig'ing:
<code>https://t.me/$botname?start=$fid</code>
!\Do'stingiz kanalimizga a'zo bo'lmasa sizga Raketa berilmaydi!
Yoki $adminuser'ga murojaat qilib Raketa sotib oling!. ",
    'parse_mode'=>"html",
 
  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
        [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
    ]
    ])
    ]);
	}else{
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
file_put_contents("step/$callcid.step","menu");
    }
}

if($steep == "menu" and $tx !== "🔚Ortga" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    	file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"🎛️Menu bot ");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/menu.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
$kod = str_replace("KANAL",$name,$kod);    
    mkdir("prouser/$fid/menu");
    if(file_get_contents("prouser/$fid/menu/menu.php")){
        unlink("prouser/$fid/menu/strtotime.php");
        unlink("prouser/$fid/menu/usid.txt");
        unlink("prouser/$fid/menu/grid.txt");
        $files = glob("prouser/$fid/menu/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/menu/baza");
    }
    file_put_contents("prouser/$fid/menu/menu.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/menu/menu.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: 🎛️Menu bot \n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n   ",
        'parse_mode'=>"html",
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
bot('sendmessage',[
        'chat_id'=>$botla,
       
'text'=>"Diqqat yangi bot yaratildi
🤖 Bot turi:🎛️Menu bot 
🤖 Bot nomi $nomi
🤖 Useri @$user
🗄 Id raqami $id
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
'reply_markup'=>$botchalar,
]);
file_put_contents("boti/$fid.txt" ,$user);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= $antiqam;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statantiqa.txt");
        $getssss += 1;
        file_put_contents("stat/statantiqa.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "konspekt"){
	$get = file_get_contents("referal/$ccid.txt");
	if($get < $antiqam){
        	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/91'>&#8239;</a>Konspekt bot📝  yaratish uchun $antiqam ta Raketa kerak.
Quyidagi havolani do'stlaringizga tarqatib Raketa yig'ing:
<code>https://t.me/$botname?start=$fid</code>
!\Do'stingiz kanalimizga a'zo bo'lmasa sizga Raketa berilmaydi!
Yoki $adminuser'ga murojaat qilib Raketa sotib oling!. ",
    'parse_mode'=>"html",
 
  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
        [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
    ]
    ])
    ]);
	}else{
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
    
file_put_contents("step/$callcid.step","konspekt");
    }
}

if($steep == "konspekt" and $tx !== "🔚Ortga" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    	file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"Konspekt bot📝");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/konspekt.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
$kod = str_replace("KANAL",$name,$kod);    
    mkdir("prouser/$fid/konspekt");
    if(file_get_contents("prouser/$fid/konspekt/konspekt.php")){
        unlink("prouser/$fid/konspekt/strtotime.php");
        unlink("prouser/$fid/konspekt/usid.txt");
        unlink("prouser/$fid/konspekt/grid.txt");
        $files = glob("prouser/$fid/konspekt/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/konspekt/baza");
    }
    file_put_contents("prouser/$fid/konspekt/konspekt.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/konspekt/konspekt.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Konspekt bot📝 \n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n   ",
        'parse_mode'=>"html",
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
bot('sendmessage',[
        'chat_id'=>$botla,
       
'text'=>"Diqqat yangi bot yaratildi
🤖 Bot turi: Konspekt bot📝
🤖 Bot nomi $nomi
🤖 Useri @$user
🗄 Id raqami $id
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
'reply_markup'=>$botchalar,
]);
       file_put_contents("boti/$fid.txt" ,$user);
         $gett = file_get_contents("referal/$fid.txt");
        $gett -=$antiqam;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statantiqa.txt");
        $getssss += 1;
        file_put_contents("stat/statantiqa.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "islomiy"){
	$get = file_get_contents("referal/$ccid.txt");
if($get < $antiqam){
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/95'>&#8239;</a>🌙Islomiy Bot  yaratish uchun $antiqam ta Raketa kerak.
Quyidagi havolani do'stlaringizga tarqatib Raketa yig'ing:
<code>https://t.me/$botname?start=$fid</code>
!\Do'stingiz kanalimizga a'zo bo'lmasa sizga Raketa berilmaydi!
Yoki $adminuser'ga murojaat qilib Raketa sotib oling!. ",
    'parse_mode'=>"html",
 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
        [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
    
    ]
    ])
    ]);
	}else{
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
    
file_put_contents("step/$callcid.step","islomiy");
    }
}

if($steep == "islomiy" and $tx !== "◀️Orqaga" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
        	file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"🌙Islomiy Bot");
  file_put_contents("yangi/$fid.txt" ,"$tx");
   
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pro/islom.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("prouser/$fid/islombot");
    if(file_get_contents("prouser/$fid/islombot/islombot.php")){
        unlink("prouser/$fid/islombot/strtotime.php");
        unlink("prouser/$fid/islombot/usid.txt");
        unlink("prouser/$fid/islombot/grid.txt");
        $files = glob("prouser/$fid/islombot/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/islombot/baza");
    }
    file_put_contents("prouser/$fid/islombot/islombot.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/islombot/islombot.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: 🌙Islomiy Bot bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 🌙Islomiy Bot
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"huddi shunday bot ochish","url"=>"https://t.me/$bot"],],
]
]),
]);
    file_put_contents("boti/$fid.txt" ,$user);
            $gett = file_get_contents("referal/$fid.txt");
        $gett -= $antiqam;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statantiqa.txt");
        $getssss += 1;
        file_put_contents("stat/statantiqa.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$sprot1
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "down"){
	$get = file_get_contents("referal/$ccid.txt");
if($get < $antiqam){
    	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/98'>&#8239;</a>📥 Down  yaratish uchun $antiqam ta Raketa kerak.
Quyidagi havolani do'stlaringizga tarqatib Raketa yig'ing:
<code>https://t.me/$botname?start=$fid</code>
!\Do'stingiz kanalimizga a'zo bo'lmasa sizga Raketa berilmaydi!
Yoki $adminuser'ga murojaat qilib Raketa sotib oling!. ",
    'parse_mode'=>"html",
 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
        [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
    ]
    ])
    ]);
	}else{
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
    
    file_put_contents("step/$callcid.step","down");
    }
}

if($steep == "down" and $tx !== "◀️Orqaga" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
        	file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"📥 Down ");
  file_put_contents("yangi/$fid.txt" ,"$tx");
   
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pro/down.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("prouser/$fid/down");
    if(file_get_contents("prouser/$fid/down/down.php")){
        unlink("prouser/$fid/down/strtotime.php");
        unlink("prouser/$fid/down/usid.txt");
        unlink("prouser/$fid/down/grid.txt");
        $files = glob("prouser/$fid/down/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/down/baza");
    }
    file_put_contents("prouser/$fid/down/down.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/down/down.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: 📥 Down bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 📥 Down 
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"huddi shunday bot ochish","url"=>"https://t.me/$bot"],],
]
]),
]);
    file_put_contents("boti/$fid.txt" ,$user);
            $gett = file_get_contents("referal/$fid.txt");
        $gett -= $antiqam;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statantiqa.txt");
        $getssss += 1;
        file_put_contents("stat/statantiqa.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$sprot1
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}

if($data == "search"){
	$get = file_get_contents("referal/$ccid.txt");
if($get < $antiqam){
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/109'>&#8239;</a>🔎Search php  yaratish uchun $antiqam ta Raketa kerak.
Quyidagi havolani do'stlaringizga tarqatib Raketa yig'ing:
<code>https://t.me/$botname?start=$fid</code>
!\Do'stingiz kanalimizga a'zo bo'lmasa sizga Raketa berilmaydi!
Yoki $adminuser'ga murojaat qilib Raketa sotib oling!. ",
    'parse_mode'=>"html",
 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
        [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
    ]
    ])
    ]);
	}else{
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
    
file_put_contents("step/$callcid.step","search");
    }
}

if($steep == "search" and $tx !== "◀️Orqaga" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
        	file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"🔎Search php");
  file_put_contents("yangi/$fid.txt" ,"$tx");
   
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pro/index.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("prouser/$fid/search");
    if(file_get_contents("prouser/$fid/search/index.php")){
        unlink("prouser/$fid/search/strtotime.php");
        unlink("prouser/$fid/search/usid.txt");
        unlink("prouser/$fid/search/grid.txt");
        $files = glob("prouser/$fid/down/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/search/baza");
    }
    file_put_contents("prouser/$fid/search/index.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/search/index.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: 🔎Search php\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
            'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi🔎Search php
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"huddi shunday bot ochish","url"=>"https://t.me/$bot"],],
]
]),
]);
    file_put_contents("boti/$fid.txt" ,$user);
            $gett = file_get_contents("referal/$fid.txt");
        $gett -= $antiqam;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statantiqa.txt");
        $getssss += 1;
        file_put_contents("stat/statantiqa.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$sprot1
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}

if($data == "vkm"){
	$get = file_get_contents("referal/$ccid.txt");
if($get < $antiqam){
    	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/Omonboyevshahzod/109'>&#8239;</a>🎧Vkm bot yaratish uchun $antiqam ta Raketa kerak.
Quyidagi havolani do'stlaringizga tarqatib Raketa yig'ing:
<code>https://t.me/$botname?start=$fid</code>
!\Do'stingiz kanalimizga a'zo bo'lmasa sizga Raketa berilmaydi!
Yoki $adminuser'ga murojaat qilib Raketa sotib oling!. ",
    'parse_mode'=>"html",
 
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"],['text'=>"💳Hisobni to'ldirish",'callback_data'=>"toldir"]],
        [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
    
    ]
    ])
    ]);
	}else{
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
    
file_put_contents("step/$callcid.step","vkm");
    }
}

if($steep == "vkm" and $tx !== "◀️Orqaga" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
        	file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"🎧Vkm bot");
  file_put_contents("yangi/$fid.txt" ,"$tx");
   
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pro/index1.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("prouser/$fid/vkm");
    if(file_get_contents("prouser/$fid/vkm/index1.php")){
        unlink("prouser/$fid/vkm/strtotime.php");
        unlink("prouser/$fid/vkm/usid.txt");
        unlink("prouser/$fid/vkm/grid.txt");
        $files = glob("prouser/$fid/down/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/vkm/baza");
    }
    file_put_contents("prouser/$fid/vkm/index1.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://mamurov74.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/vkm/index1.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: 🎧Vkm bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Orqaga⬅️",'callback_data'=>"antiqaga"]], 
  ]
      ]),  
]);
bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi🎧Vkm bot
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"huddi shunday bot ochish","url"=>"https://t.me/$bot"],],
]
]),
]);
    file_put_contents("boti/$fid.txt" ,$user);
            $gett = file_get_contents("referal/$fid.txt");
        $gett -= $antiqam;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statantiqa.txt");
        $getssss += 1;
        file_put_contents("stat/statantiqa.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$sprot1
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}

?>