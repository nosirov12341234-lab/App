<?php

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$cid = $message->chat->id;
$tx = $message->text;
$from_id = $update->message->from->id;
$mid = $message->message_id;
$name = $message->from->first_name;
$fid = $message->from->id;
$callback = $update->callback_query;
$message = $update->message;
$mid = $message->message_id;
$data = $update->callback_query->data;
$type = $message->chat->type;
$text = $message->text;
$cid = $message->chat->id;
$token = $message->text;
$uid= $message->from->id;
$gname = $message->chat->title;
$left = $message->left_chat_member;
$new = $message->new_chat_member;
$name = $message->from->first_name;
$repid = $message->reply_to_message->from->id;
$repname = $message->reply_to_message->from->first_name;
$newid = $message->new_chat_member->id;
$leftid = $message->left_chat_member->id;
$newname = $message->new_chat_member->first_name;
$leftname = $message->left_chat_member->first_name;
$username = $message->from->username;
$cmid = $update->callback_query->message->message_id;
$cusername = $message->chat->username;
$repmid = $message->reply_to_message->message_id; 
$ccid = $update->callback_query->message->chat->id;
$cuid = $update->callback_query->message->from->id;
$cqid = $update->callback_query->id;
$data=$update->callback_query->data;
$callcid=$update->callback_query->message->chat->id;
$callmid=$update->callback_query->message->message_id;
$from_id = $message->from->id;
$steep = file_get_contents("$from_id.step");
$userstep = file_get_contents("step/$from_id.step");
$photo = $update->message->photo;
$gif = $update->message->animation;
$video = $update->message->video;
$music = $update->message->audio;
$voice = $update->message->voice;
$sticker = $update->message->sticker;
$document = $update->message->document;
$for = $message->forward_from;
$forc = $message->forward_from_chat;
$botla= file_get_contents("ch4.txt");
$data = $callback->data;
$callid = $callback->id;
$cname = $calback->message->from->first_name;
$ccid = $callback->message->chat->id;
$cmid = $callback->message->message_id;
$cfid = $callback->message->from->id;
$user = $message->from->username;
$adminuser = "ADMIN_USER";

$inlinequery = $update->inline_query;
$inline_id = $inlinequery->id;
$inlineid = $inlinequery->from->id;
$inline_query = $inlinequery->query;
$adminuser = "ADMIN_USER";
$time=date('H:i');
$soat = date("H:i");
$sana = date('d.m.Y');
mkdir("referal");
mkdir("stat");
mkdir("step");
mkdir("user");
mkdir("prouser");
mkdir("user/$fid");
mkdir("prouser/$fid");
mkdir("ban");
if(!file_exists("referal/$fid.txt")){  
    file_put_contents("referal/$fid.txt","0");
}

if(file_get_contents("stat/stat.txt")){
} else{
file_put_contents("stat/stat.txt", "0");
}


$userstep = file_get_contents("step/$fid.txt");

$soni = file_get_contents("soni/$idi.soni");
if(!$soni) $soni = 0;

$stat = file_get_contents("stat/usid.txt");



$main_menu = json_encode([
'inline_keyboard'=>[
[['text'=>"🏗 Bot qurish",'callback_data'=>"boshqar"],['text'=>"🤖 Mening botim",'callback_data'=>"botim"]],
[['text'=>"⁉Qoidalar",'callback_data'=>"qoida"],['text'=>"🆘 Yordam",'callback_data'=>"yordam"]],
]
]);






if($data == "boshmenu"){
     bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
        'text'=>"🔝 Bosh Menyuga Qaytdik.Biz bilan ekanligingizdan bahoyatda xursandmiz.\n$bot",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"🏗 Bot qurish",'callback_data'=>"boshqar"],['text'=>"🤖 Mening botim",'callback_data'=>"botim"]],
[['text'=>"⁉Qoidalar",'callback_data'=>"qoida"],['text'=>"🆘 Yordam",'callback_data'=>"yordam"]],
]
])
]);
}

if($data == "botim"){
     bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
        'text'=>"📋 Agar botda ishlashga tushunmasangiz guruhimizga qo'shiling.",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"📋 Mening botim",'callback_data'=>"botimm"]],
[['text'=>"🗑️ Botni o'chirish",'callback_data'=>"uchir"]],
[['text'=>"⬅️Orqaga",'callback_data'=>"boshmenu"]],
]
])
]);
}
if($data == "uchir" ){
    $botingiz = file_get_contents("boti/$fid.txt");
 if($botingiz == ""){
  bot('editMessageText',[
    'chat_id'=>$ccid,
        'message_id'=>$cmid,
    'text'=>"Siz bot yaratmagansiz.",
            'reply_markup'=>json_encode([
        'inline_keyboard'=>[[['text'=>"⬅️Orqaga",'callback_data'=>"boshmenu"]],
        
]
        ])

    ]);
}else{
	bot('editMessageText',[
    'chat_id'=>$ccid,
        'message_id'=>$cmid,
    'text'=>"Sizning @$botingiz botingiz o'chirildi. ✅",
 'parse_mode'=>'html',
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[[['text'=>"⬅️Orqaga",'callback_data'=>"boshmenu"]],
 ]       
])
]);
}
unlink("boti/$fid.txt");
unlink("turi/$fid.txt");
unlink("token/$fid.txt");
rmdir("user/$fid");
rmdir("prouser/$fid");
}
if($data == "botimm" ){
 $botingiz = file_get_contents("boti/$fid.txt");
 if($botingiz == ""){
  bot('editMessageText',[
'chat_id'=>$ccid,
        'message_id'=>$cmid,
    'text'=>"Siz bot yaratmagansiz.",
            'reply_markup'=>json_encode([
        'inline_keyboard'=>[[['text'=>"⬅️Orqaga",'callback_data'=>"boshmenu"]],
]
])
    ]);
}else{
	bot('editMessageText',[
    'chat_id'=>$ccid,
        'message_id'=>$cmid,
    'text'=>"Sizning botingiz @$botingiz .",
 'parse_mode'=>'html',
 'reply_markup'=>json_encode([
            'inline_keyboard'=>[
                [['text'=>"@$botingiz",'url'=>"https://t.me/$botingiz"]],
            ]
        ])
]);
}
}
if($data=="boshqar"){
     bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
        'text'=>"Endi qanday robot yasamoqchi ekaningiz tanlang!?
🆓 Bepul botlar boʻlimi orqali yasalagan botlar mutlaqo bepul va siz bob ammo unda bizning doimiy reklamalar mavjud!
🆕 VIP botlar boʻlimi orqali yasalagan botlarni sotib olishingiz mumkin va siz sifatli qulay boshqaruvli botga ega boʻlasiz unda bizning doimiy reklamalar mavjud emas!.",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"🆓Bepul Bot",'callback_data'=>"tekinn1"],['text'=>"🆕 Vip Bot",'callback_data'=>"vipbot"]],
[['text'=>"◀️Ortga",'callback_data'=>"boshmenu"]],
]
])
]);
}
if($data=="shahzodg"){
     bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
        'text'=>"ㄖ尺Ҩ卂ᘜ卂 Ҩ卂ㄚㄒᗪ|几ᘜ|乙",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"🆓Bepul Bot",'callback_data'=>"tekinn1"],['text'=>"🆕 Vip Bot",'callback_data'=>"vipbot"]],
[['text'=>"◀️Ortga",'callback_data'=>"boshmenu"]],
]
])
]);
}

if($data=="yordam"){
     bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
        'text'=>"🔰 Bizga savollaringiz yoki muammolaringiz bo'lsa, iltimos, bizning qo'llab-quvvatlash jamoamiz bilan bog'laning.
Admin: @$adminuser
Xabaringizni shu yerga yuboring:‌‌",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"🔚Ortga",'callback_data'=>"boshmenu"]],
]
])
]);
}

if($data=="qoida"){
     bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
        'text'=>"⚠️ Qoidalar:
    
1. Ushbu robot maker bot adminstratorlari va bot  dasturchisi foydalanuvchilardan quydagilarni o'z zimmasiga olmasligi haqida sizga eslatib o'tadi:
1.1 ushbu botdan foydalangan holda ochilgan barcha botlar sizga pul to'lashi yoki to'lamasligj bu bizga bog'liq emas va biz sizga pul to'lamaymiz!
1.2 agar sizga ushbu botlar server orqali pul to'laydi deyishsa ishonmang yoki o'zingizda shunday xayol bo'lsa buni uniting chunki bu aqilsiz gap!
1.3 ushbu robot orqali bot ochgan zahotingiz barcha shart va qoidalar bilan tanishganingizni va rozi ekanligingizni o'z zimangizga olasiz!

2. ⚠️Ogohlantiramiz:
2.1 Taniqli shaxslar, mashxur savdo belgilari, kampaniya tashkilot nomlari, telegram kanal va veb-saytlar nomidan soxta bot ochib ish yuritish taqiqlanadi bunga ko'ra sizga tashkilot tomonidan ogohlantirish berilmaydi va ish sud tartibida ko'rib chiqiladi.
2.2 Foydalanuvchi tomonidan kiritilgan xar qanday ma'lumot va manbalar uchinchi shaxsga oshkor etilmaydi.
2.3 Foydalanuvchi tomonidan yasalagan botlarda quydagilar qatiyan taqiqlanadi!
+18 manba kanal va guruhlarga obunachi yig'ishda foydalanish.
Diniy aqidaparastlik kanalarda foydalanish.
Davlat siyosatiga zid yoki yolg'on manbalar tarqatuvchi kanalarga ulash va boshqlar...

3. ❗Eslatib o'tamiz:
√ botlar 100% xafsiz va faqat O'zbekistondagi telegram foydalanuvchilari foydalana oladi
√ barcha raqamlar barcha xisoblar o'chirilishidan avval sizni ogohlantiramiz.
√ qo'llab - quvvatlash xizmati sizga 24/7 soat davomida xizmat ko'rsatadi.
√ Sizning ma'lumotlaringiz xech kim tomonidan qayta ko'rib chiqilmaydi (2.1 dan tashqari hollarda)",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"🔚Orqaga",'callback_data'=>"orqa"]],
]
])
]);
}

if($data == "orqa"){
        bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
        'text'=>"🏡Asosiy menyuga qaytdik biz bilan ekanligingizdan hursandmiz. @$bot dunyoga reallik bilan yondosh!",
        'reply_markup'=>$main_menu,
]);
}




if($data == "yarat1"){
	bot('editMessageText',[
	'chat_id'=>$ccid,
	'message_id'=>$cmid,
	'text'=>"Bolimlardan birini tanlang.",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🆓Bepul Bot",'callback_data'=>"tekin"],['text'=>"💵VIP Bot",'callback_data'=>"vipbot"]],
[['text'=>"◀️Orqga",'callback_data'=>"orqa"]],
]
])
]);
}

if($data == "vipbot"){
	bot('editMessageText',[
	'chat_id'=>$ccid,
	'message_id'=>$cmid,
	'text'=>"Hozircha tamirda ✋😨",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"◀️Ortga",'callback_data'=>"orqa"]],
]
])
]);
}

if($data == "tekinn1"){
	bot('editMessageText',[
	'chat_id'=>$ccid,
	'message_id'=>$cmid,
	'text'=>"Oʻzingiz xohlagan robot turini tanlang!?",

'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🖋 Nik bot",'callback_data'=>"nikbot1"],['text'=>"❤️ Channel like",'callback_data'=>"channellike1"]],
    [['text'=>"🕋Quron bot",'callback_data'=>"quron1"],['text'=>"⚡Webhook bot",'callback_data'=>"webhook1"]],
    [['text'=>"📽️Gif bot",'callback_data'=>"gif1"],['text'=>"☢️ Konvertor bot",'callback_data'=>"konvertor1"]],
    [['text'=>"🖼️Logo bot",'callback_data'=>"logo1"],['text'=>"👨‍👨‍👧‍👦Go'zalik test bot",'callback_data'=>"guzalliktest1"]],
    [['text'=>"👤Obunachi v0.1",'callback_data'=>"obunachi1"],['text'=>"🔰Universal bot",'callback_data'=>"universal1"]],
    [['text'=>"Harfga video bot 📎",'callback_data'=>"harfga1"],['text'=>"Test bot",'callback_data'=>"test1"]],
   [['text'=>"📟 Kalkulyator",'callback_data'=>"kalkulyator1"],['text'=>"🔙 Orqaga",'callback_data'=>"shahzodg"]],

    ]

    ]),
]);
}




$rpl = json_encode([
  'resize_keyboard'=>false,
  'force_reply'=>true,
  'selective'=>true,
]);


if($tx == "/start" and $cid == $admin){
unlink("$callcid.step");
bot('sendmessange',[
'chat_id'=>$admin,
'caption'=>"",
]);
unlink("$callcid.step");
}

if($data == "bepulbulimga1"){
     bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid,
        'text'=>"B̆̈Ĕ̈P̆̈Ŭ̈L̆̈ B̆̈Ŏ̈T̆̈L̆̈Ă̈R̆̈ B̆̈Ŏ̈'L̆̈Ĭ̈M̆̈Ĭ̈Ğ̈Ă̈ Q̆̈Ă̈Y̆̈T̆̈D̆̈Ĭ̈Ğ̈Ĭ̈Z̆̈",
        'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🖋 Nik bot",'callback_data'=>"nikbot1"],['text'=>"❤️ Channel like",'callback_data'=>"channellike1"]],
    [['text'=>"🕋Quron bot",'callback_data'=>"quron1"],['text'=>"⚡Webhook bot",'callback_data'=>"webhook1"]],
    [['text'=>"📽️Gif bot",'callback_data'=>"gif1"],['text'=>"☢️ Konvertor bot",'callback_data'=>"konvertor1"]],
    [['text'=>"🖼️Logo bot",'callback_data'=>"logo1"],['text'=>"👨‍👨‍👧‍👦Go'zalik test bot",'callback_data'=>"guzalliktest1"]],
    [['text'=>"👤Obunachi v0.1",'callback_data'=>"obunachi1"],['text'=>"🔰Universal bot",'callback_data'=>"universal1"]],
    [['text'=>"Harfga video bot 📎",'callback_data'=>"harfga1"],['text'=>"Test bot",'callback_data'=>"test1"]],
   [['text'=>"📟 Kalkulyator",'callback_data'=>"kalkulyator1"],['text'=>"🔙 Orqaga",'callback_data'=>"shahzodg"]],
    ]
    ]),
    ]);
}

$stat = file_get_contents("stat/usid.txt");
if($data == "guzalliktest1" ){
		bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html', 
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
        
    ]);
file_put_contents("step/$callcid.step","guzalliktest");;
}

if($steep == "guzalliktest" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    file_put_contents("token/$fid.txt" ,$tx);
file_put_contents("turi/$fid.txt" ,"👨‍👨‍👧‍👦Go'zalik test bot");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"⚔️Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/test.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("user/$fid/test");
    if(file_get_contents("user/$fid/test/test.php")){
        unlink("user/$fid/test/test.php");
    }
    file_put_contents("user/$fid/test/test.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://samvlogs04.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/test/test.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Go'zalik test bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
        ]);
        bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 👨‍👨‍👧‍👦Go'zalik test bot
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
"reply_markup"=>$botchalar
]);
file_put_contents("boti/$fid.txt" ,$user);
        
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$bek_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}


if($data == "quron1"){
	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html', 
               'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
    ]);
file_put_contents("step/$callcid.step","quron");
}

if($steep == "quron" and $tx !== "⬅️ Bekor qilish" ){
    if(mb_stripos($tx, ":")!==false){
    file_put_contents("token/$fid.txt" ,"$tx");
file_put_contents("turi/$fid.txt" ,"🕋Quron bot");
  file_put_contents("yangi/$fid.txt" ,"quron");
        $getid = bot('editmessagetext',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
        'text'=>"⚔️Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/quron.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    $kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("user/$fid/quron");
    if(file_get_contents("user/$fid/quron/quron.php")){
        unlink("user/$fid/quron/quron.php");
    }
    file_put_contents("user/$fid/quron/quron.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://samvlogs04.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/quron/quron.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
bot('Sendmessage',[
'chat_id'=>$cid,
'message_id'=>$mid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Quron bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
        ]);
        bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 🕋Quron bot
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
"reply_markup"=>$botchalar
]);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
file_put_contents("boti/$fid.txt" ,$user);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"?? Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$bek_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}

if($data == "channellike1"){
    	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',  
                'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
    ]);
file_put_contents("step/$callcid.step","channellike");
}

if($steep == "channellike" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    file_put_contents("token/$fid.txt" ,$tx);
file_put_contents("turi/$fid.txt" ,"❤️ Channel like");
file_put_contents("step/$from_id.txt","$tx");
  file_put_contents("yangi/$fid.txt" ,"tx");
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/like.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("user/$fid/like");
    if(file_get_contents("user/$fid/like/like.php")){
        $files = glob("user/$fid/like/like/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/like/like");
        $files = glob("user/$fid/like/baza/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/like/baza");
    }
    file_put_contents("user/$fid/like/like.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://samvlogs04.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/like/like.php"))->result;

    if($get==true){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Channel like bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
                'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
        ]);
        bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi ❤️ Channel like
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
"reply_markup"=>$botchalar
]);
$getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}


if($data == "nikbot1"){
     	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
       'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',   
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
    ]);
    file_put_contents("step/$callcid.step","nikbot");;
}

if($steep == "nikbot" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    	file_put_contents("step/$from_id.txt","$tx");;
file_put_contents("turi/$fid.txt" ,"🖋 Nik bot");
  file_put_contents("yangi/$fid.txt" ,"$tx");
          bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        
    $kod = file_get_contents("bots/nick.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("user/$fid/nick");
    if(file_get_contents("user/$fid/nick/nick.php")){
        unlink("user/$fid/nick/nick.php");
    }
    file_put_contents("user/$fid/nick/nick.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://samvlogs04.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/nick/nick.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;

        	bot('sendmessage',[
'chat_id'=>$cid,
'message_id'=>$mid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Nick bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
                'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
    
]);
bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi  🖋 Nik bot
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a> $sana $time $sana $time",
'parse_mode'=>'html',
'reply_markup'=>$botchalar,
]);
file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {     
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);   
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}


if($data == "webhook1"){
		bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',  
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])]);
    file_put_contents("step/$callcid.step","webhook");
}

if($steep == "webhook" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($token, ":")!==false){
file_put_contents("token/$fid.txt" ,$tx);
file_put_contents("turi/$fid.txt" ,"Webhook");
 file_put_contents("yangi/$fid.txt" ,"$tx"); 
 
  $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/web.php");
    $kod = str_replace("API_TOKEN", "$token", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("user/$fid/web");
    if(file_get_contents("user/$fid/web/web.php")){
        $files = glob("user/$fid/web/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/web/channel");
    }
    file_put_contents("user/$fid/web/web.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=https://samvlogs04.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/web/web.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Webhook bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga11"]],
]
])
        ]);
        bot('sendmessage',[ 
        'chat_id'=>$botla, 
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi:⚡Webhook bot
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
        file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
    }
unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}

if($data=="gif1"){
		bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',   
          'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])  ]);
   file_put_contents("step/$callcid.step","gif");
}

if($steep == "gif" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($token, ":")!==false){
file_put_contents("token/$fid.txt" ,$tx);
file_put_contents("yangi/$fid.txt" ,"$tx"); 
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/gif.php");
    $kod = str_replace("API_TOKEN", "$token", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("user/$fid/gif");
    if(file_get_contents("user/$fid/gif/gif.php")){
        $files = glob("user/$fid/gif/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/gif/channel");
    }
    file_put_contents("user/$fid/gif/gif.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=https://samvlogs04.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/gif/gif.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Gif bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
                'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
        ]);
        bot('sendmessage',[ 
        'chat_id'=>$botla,   
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi: 📽️Gif bot
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
        file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }
    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}



if($data=="konvertor1"){
    	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',           'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
    ]);
    file_put_contents("step/$callcid.step","konvertor");
}

if($steep == "konvertor" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($token, ":")!==false){
file_put_contents("token/$fid.txt" ,$tx);
file_put_contents("turi/$fid.txt" ,"☢️ Konvertor bot");
file_put_contents("yangi/$fid.txt" ,"$tx"); 
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/konvertor.php");
    $kod = str_replace("API_TOKEN", "$token", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
    
    mkdir("user/$fid/konver");
    if(file_get_contents("user/$fid/konver/konvertor.php")){
        $files = glob("user/$fid/konvero/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/konver/channel");
    }
    file_put_contents("user/$fid/konver/konvertor.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=https://samvlogs04.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/konver/konvertor.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi:☢️ Konvertor bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
                'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
        ]);
        bot('sendmessage',[ 
        'chat_id'=>$botla, 
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi ☢️ Konvertor bot
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
        file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "universal1"){
    	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',         'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])  
    ]);
    file_put_contents("step/$callcid.step","universal");
}

if($steep == "universal" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($token, ":")!==false){
file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"🔰Universal bot");
file_put_contents("yangi/$fid.txt" ,"$token"); 
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/uni.php");
    $kod = str_replace("API_TOKEN", "$token", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
$kod = str_replace("BOTNAME", "$user", $kod);
    
    mkdir("user/$fid/uni");
    if(file_get_contents("user/$fid/uni/uni.php")){
        $files = glob("user/$fid/uni/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/uni/channel");
    }
    file_put_contents("user/$fid/uni/uni.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=https://samvlogs04.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/uni/uni.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi:🔰Universal bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
        ]);
        bot('sendmessage',[ 
        'chat_id'=>$botla, 
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi🔰Universal bot
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
        file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "harfga1" ){
    		bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',          'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
    ]);
file_put_contents("step/$callcid.step","harfga");
}

if($steep == "harfga" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($token, ":")!==false){
file_put_contents("token/$fid.txt" ,$token);
file_put_contents("turi/$fid.txt" ,"Harfga video bot 📎");
file_put_contents("yangi/$fid.txt" ,"$token"); 
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/harf.php");
    $kod = str_replace("API_TOKEN", "$token", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
$kod = str_replace("BOTNAME", "$user", $kod);
    
    mkdir("user/$fid/harf");
    if(file_get_contents("user/$fid/harf/harf.php")){
        $files = glob("user/$fid/harf/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/harf/channel");
    }
    file_put_contents("user/$fid/harf/harf.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=https://samvlogs04.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/harf/harf.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi:Harfga video bot 📎\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
        ]);
        bot('sendmessage',[ 
        'chat_id'=>$botla, 
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi:Harfga video bot 📎
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
        file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "test1") {
    		bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',          'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
    ]);
file_put_contents("step/$callcid.step","test");
}

if($steep == "test" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($token, ":")!==false){
file_put_contents("token/$fid.txt" ,$tx);
file_put_contents("turi/$fid.txt" ,"Test bot");
file_put_contents("yangi/$fid.txt" ,"$token"); 
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/testt.php");
    $kod = str_replace("API_TOKEN", "$token", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
$kod = str_replace("BOTNAME", "$user", $kod);
    
    mkdir("user/$fid/test");
    if(file_get_contents("user/$fid/test/testt.php")){
        $files = glob("user/$fid/test/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/test/channel");
    }
    file_put_contents("user/$fid/test/testt.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=https://samvlogs04.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/test/testt.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Test bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
                'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
        ]);
        bot('sendmessage',[ 
        'chat_id'=>$botla, 
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi: Test bot
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
        file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "kalkulyator1" ){
   	bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',          'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
]) 
    ]);
    file_put_contents("step/$callcid.step","kalkulyator");
}

if($steep == "kalkulyator" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($token, ":")!==false){
file_put_contents("token/$fid.txt" ,$tx);
file_put_contents("turi/$fid.txt" ," 📟 Kalkulyator");
file_put_contents("yangi/$fid.txt" ,"$token"); 
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/kalc.php");
    $kod = str_replace("API_TOKEN", "$token", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$username", $kod);
$kod = str_replace("BOTNAME", "$user", $kod);
    
    mkdir("user/$fid/kalc");
    if(file_get_contents("user/$fid/kalc/kalc.php")){
        $files = glob("user/$fid/kalc/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/kalc/channel");
    }
    file_put_contents("user/$fid/kalc/kalc.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=https://samvlogs04.myxvest.ru/VipBuilder/makercha/$admin/Maker/user/$fid/kalc/kalc.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi:  📟 Kalkulyator\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
        ]);
        bot('sendmessage',[ 
        'chat_id'=>$botla, 
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi: 📟 Kalkulyator
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
        file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
if($data == "obunachi1"){
			bot('editmessagetext',[
'chat_id'=>$ccid,
'message_id'=>$cmid,
    'text'=>"<a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
    ]);
    file_put_contents("step/$callcid.step","obunachi");
    
}

if($steep == "obunachi" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    file_put_contents("token/$fid.txt" ,$tx);
file_put_contents("turi/$fid.txt" ,"👤Obunachi v0.1");
  file_put_contents("yangi/$fid.txt" ,"$tx");
        $botuser = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"✅ Siz yuborgan bot tokeni qabul qilindi!"
        ])->result->message_id;
    $kod = file_get_contents("bots/obunachi.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    $kod = str_replace("ADMIN_USER", "$user", $kod);

    
    mkdir("prouser/$fid/obunachi");
    if(file_get_contents("prouser/$fid/obunachi/obunachi.php")){
        unlink("prouser/$fid/obunachi/obunachi.php");
        unlink("prouser/$fid/obunachi/usid.txt");
        unlink("prouser/$fid/obunachi/grid.txt");
    }
    file_put_contents("prouser/$fid/obunachi/obunachi.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://samvlogs04.myxvest.ru/VipBuilder/makercha/$admin/Maker/prouser/$fid/obunachi/obunachi.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',[
'chat_id'=>$cid,
'message_id'=>$getid
]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"ℹ️ Botingiz tayyor. Quyidagi tugma orqali botingizga o'tishingiz mumkin.
<code>/panel</code> - Ushbu buyrug' orqali botingizni sozlab olishingiz mumkin\n✳️ Useri: @$user.",
        'parse_mode'=>"html",
        
            'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
]);
bot('sendmessage',[
        'chat_id'=>$botla,
        'text'=>"Diqqat yangi bot yaratildi
turi 👤Obunachi v0.1
bot nomi $nomi
useri @$user
id raqami $id
yaratuvchi <a href='tg://user?id=$fid'>$name</a>
$sana $time",
'parse_mode'=>'html',
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"huddi shunday bot ochish","url"=>"https://t.me/$bot"],],
]
]),
]);
       file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } 

    unlink("step/$fid.txt");
   }
}
if($data=="logo" and $text !="/start"){

bot('editmessagetext',[

'chat_id'=>$callcid,

'message_id'=>$callmid,
  
      'text'=>" <a href='https://t.me/vertualbotmaker/234'>&#8239;</a>1️⃣ @BotFather-ga o'ting.  Buning uchun uning ismini bosing.
2️⃣ U bilan yangi bot yarating.  Buning uchun @BotFather ichidagi /newbot buyrug'idan foydalaning.
3️⃣ @BotFather sizga beradigan API tokenidan nusxa oling.
4️⃣ @$bot -ga qaytib, nusxalangan API tokenini shu botga yuboring.
💥Taxminiy API Token:
 126521644:AAGlXut7dgde4jr94X8PNM1WXHhPwlLA",
        'parse_mode'=>'html',          'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])  
    ]);  file_put_contents("step/$callcid.step","logo");
}

if($steep == "logo1" and $text !="/start"){
if(mb_stripos($tx, ":")!==false){
file_put_contents("step/$from_id.txt","$tx");
file_put_contents("turi/$fid.txt" ,"👨‍👨‍👧‍👦Go'zalik test bot");
  file_put_contents("yangi/$fid.txt" ,"$tx");
bot('sendMessage',[
'chat_id'=>$from_id,
        'text'=>""
        ])->result->message_id; 
    $kod = file_get_contents("bots/logo.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
$kod = str_replace("ADMIN_USER", "$user", $kod);
    
    mkdir("user/$fid/logo");
    if(file_get_contents("user/$fid/logo/logo.php")){
        $files = glob("user/$fid/logo/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/logo/channel");
    }
    file_put_contents("user/$fid/logo/logo.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://samvlogs04.myxvest.ru/robot/makercha/$admin/Maker/user/$fid/logo/logo.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        ]);
        bot('sendMessage',[
        'chat_id'=>$from_id,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Logo bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>"⬅️Orqaga",'callback_data'=>"bepulbulimga1"]],
]
])
        ]);
          bot('sendmessage',[ 
        'chat_id'=>$botla, 
'text'=>"Diqqat yangi bot yaratildi 
🤖 Bot turi 🖼️Logo bot
🤖 Bot nomi $nomi 
🤖 Useri @$user 
🗄 Id raqami $id 
🧑‍💻Yaratuvchi <a href='tg://user?id=$fid'>$name</a> 
$sana $time", 
'parse_mode'=>'html', 
'reply_markup'=>$botchalar, 
]);
        file_put_contents("boti/$fid.txt" ,$user);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("$callcid.step");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"",
        'parse_mode'=>"html"
        ]);
   }
}
?>