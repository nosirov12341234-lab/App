<?php
ob_start();
define('API_KEY',"API_TOKEN");
$admin = 'ADMIN_ID';
$users =  "ADMIN_USER";
$botname =  "BOT_USER";
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/$method";
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}



$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$mid = $message->message_id;
$data = $update->callback_query->data;
$type = $message->chat->type;
$text = $message->text;
$cid = $message->chat->id;
$uid= $message->from->id;
$message = $update->message;
$cid = $message->chat->id;
$cidtyp = $message->chat->type;
$miid = $message->message_id;
$name = $message->chat->first_name;
$user1 = $message->from->username;
$tx = $message->text;
$callback = $update->callback_query;
$mmid = $callback->inline_message_id;
$mes = $callback->message;
$mid = $mes->message_id;
$cmtx = $mes->text;
$mmid = $callback->inline_message_id;
$idd = $callback->message->chat->id;
$cbid = $callback->from->id;
$cbuser = $callback->from->username;
$data = $callback->data;
$ida = $callback->id;
$cqid = $update->callback_query->id;
$cbins = $callback->chat_instance;
$cbchtyp = $callback->message->chat->type;
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$mid = $message->message_id;
$msgs = json_decode(file_get_contents('msgs.json'),true);
$data = $update->callback_query->data;
$type = $message->chat->type;
$text = $message->text;
$cid = $message->chat->id;
$uid= $message->from->id;
$gname = $message->chat->title;
$left = $message->left_chat_member;
$new = $message->new_chat_member;
$name = $message->from->first_name;
$bio = $messenge->from->about;
$repid = $message->reply_to_message->from->id;
$repname = $message->reply_to_message->from->first_name;
$newid = $message->new_chat_member->id;
$leftid = $message->left_chat_member->id;
$newname = $message->new_chat_member->first_name;
$leftname = $message->left_chat_member->first_name;
$username = $message->from->username;
$callmid = $update->callback_query->message->message_id;
$cusername = $message->chat->username;
$repmid = $message->reply_to_message->message_id; 
$callcid = $update->callback_query->message->chat->id;
$cuid = $update->callback_query->message->from->id;
$tx = $message->text;
$text= $message->text;
$name = $message->from->first_name;
$user = $message->from->username;
$message_id = $update->message->message_id;
$from_id = $update->message->from->id;
$edname = $editm ->from->first_name;
$message = $update->message;
$mesid = $message->message_id;
$mid = $message->message_id;
$chat_id = $message->chat->id;
if(file_get_contents("pul/$cid.pul")){
}else{file_put_contents("pul/$cid.pul","0");
}
if(file_get_contents("pul/$cid.ref")){
}else{file_put_contents("pul/$cid.ref","0");
}
if(file_get_contents("key1.txt")){
}else{file_put_contents("key1.txt","Arzon Obunachi");
}
if(file_get_contents("key2.txt")){
}else{file_put_contents("key2.txt","Tezkor Obunachi");
}
if(file_get_contents("key3.txt")){
}else{file_put_contents("key3.txt","ARABIC Obunachi");
}
if(file_get_contents("key4.txt")){
}else{file_put_contents("key4.txt","CHINA Obunachi");
}
if(file_get_contents("arzonmin.txt")){
}else{file_put_contents("arzonmin.txt","500");
}
if(file_get_contents("arzonmax.txt")){
}else{file_put_contents("arzonmax.txt","10000");
}
if(file_get_contents("tezkormin.txt")){
}else{file_put_contents("tezkormin.txt","500");
}
if(file_get_contents("tezkormax.txt")){
}else{file_put_contents("tezkormax.txt","10000");
}
if(file_get_contents("arzbicmin.txt")){
}else{file_put_contents("arzbicmin.txt","500");
}
if(file_get_contents("arzbicmax.txt")){
}else{file_put_contents("arzbicmax.txt","10000");
}
if(file_get_contents("chinamin.txt")){
}else{file_put_contents("chinamin.txt","500");
}
if(file_get_contents("chinamax.txt")){
}else{file_put_contents("chinamax.txt","10000");
}
if(file_get_contents("referal.txt")){
}else{file_put_contents("referal.txt","100");
}
if(file_get_contents("teznarx.txt")){
}else{file_put_contents("teznarx.txt","5");
}
if(file_get_contents("arzonnax.txt")){
}else{file_put_contents("arzonnax.txt","3");
}
if(file_get_contents("arabicnarx.txt")){
}else{file_put_contents("arabicnarx.txt","9");
}
if(file_get_contents("chinnarx.txt")){
}else{file_put_contents("chinnarx.txt","9");
}
if(file_get_contents("qiwiham.txt")){
}else{file_put_contents("qiwiham.txt","Kiritilmagan");
}
if(file_get_contents("clickham.txt")){
}else{file_put_contents("clickham.txt","Kiritilmagan");
}
$qiwiham=file_get_contents("qiwiham.txt");
$clickham=file_get_contents("clickham.txt");
$tugma=file_get_contents("key1.txt");
$tugma1=file_get_contents("key2.txt");
$tugma2=file_get_contents("key3.txt");
$tugma3=file_get_contents("key4.txt");
$arzonmin=file_get_contents("arzonmin.txt");
$arzonmax=file_get_contents("arzonmax.txt");
$tezkormin=file_get_contents("tezkormin.txt");
$tezkormax=file_get_contents("tezkormax.txt");
$arzbicmin=file_get_contents("arzbicmin.txt");
$arzbicmax=file_get_contents("arzbicmax.txt");
$chinamin=file_get_contents("chinamin.txt");
$chinamax=file_get_contents("chinamax.txt");
$arzonnarx=file_get_contents("arzonnax.txt");
$tezkornarx=file_get_contents("teznarx.txt");
$arabicnarx=file_get_contents("arabicnarx.txt");
$chinanarx=file_get_contents("chinnarx.txt");
$refnarx=file_get_contents("referal.txt");
$apikey=file_get_contents("apikey.txt");
$cid = $message->chat->id;
$chat_id = $message->chat->id;
$text1 = $message->text;
$name = $message->from->first_name;
$username = $message->from->username;
$data = $update->callback_query->data;
$cid2 = $update->callback_query->message->chat->id; 
$cqid = $update->callback_query->id;
$clcid = $update->callback_query->message->chat->id;
$ch_user2 = $update->callback_query->message->chat->username;
$msgid = $update->callback_query->message->message_id;
$fadmin2 = $update->callback_query->from->id;
$fadmin = $message->from->id;
$cty = $message->chat->type;
$step = file_get_contents("step/$cid.step");
$mid = $message->message_id;
$tx = $message->text;
$id1 = $message->reply_to_message->from->id;   
$repmid = $message->reply_to_message->message_id; 
$repname = $message->reply_to_message->from->first_name;
$repuser = $message->reply_to_message->from->username;
$reply = $message->reply_to_message;
$sreply = $message->reply_to_message->text;
$name2 = $update->callback_query->from->first_name;
$username2 = $update->callback_query->from->username;
$about2 = $update->callback_query->from->about;
$lname2 = $update->callback_query->from->last_name;
$channel = file_get_contents("channel.txt");
$kanal = file_get_contents("kanal.txt");
$step = file_get_contents("step.txt");

if(isset($update) and ($channel == "true")){
$ids = explode("\n",$kanal);
$soni = substr_count($kanal,"@");

foreach($ids as $ki){
$keyboards = [];
$k=[];
for ($for = 1; $for <= $soni; $for++) {
$kanall=str_replace("@","",$ids[$for]);

$keyboards[]=["text"=>"$for  - Kanal","url"=>"https://t.me/$kanall"];
}



$data = $update->callback_query->data;
$qid = $update->callback_query->id;
$callcid = $update->callback_query->message->chat->id;
$calltext = $update->callback_query->message->text;
$clid = $update->callback_query->from->id;
$callmid = $update->callback_query->message->message_id;
$gid = $update->callback_query->message->chat->id;
$cqid = $update->callback_query->id;
$chpost = $update->channel_post;
$chuser = $chpost->chat->username;
$chpmesid = $chpost->message_id;
$chcaption = $chpost->caption;
$orqa = '⬅️ Orqaga';
$step = file_get_contents("step/$cid.step");
$userlar = file_get_contents("stat/users.txt");
mkdir("bot");
mkdir("step");
mkdir("stat");
mkdir("ref");
mkdir("pul");



$keyboard2=array_chunk($keyboards, 1);
$keyboard=json_encode([
'inline_keyboard'=>$keyboard2,
]);
}




$menu = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"➕ Buyurtma berish"],],
[['text'=>"📲 Kabinet"],['text'=>"🔎 Kuzatish"],],
[['text'=>"📚 Bot haqida"],],
]
]);


$haqida = json_encode([
'inline_keyboard'=>[
[['text'=>"📊 Statistika",'callback_data'=>"stat"]],
[['text'=>"📚 Qo'llanma",'callback_data'=>"qol"]],
[['text'=>"📝 Qoida",'callback_data'=>"qoid"]],
]
]);




$mem = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"📨 Telegram"],],
[['text'=>"$orqa"]],
]
]);

$pay = json_encode([
'inline_keyboard'=>[
[['text'=>"💳 Pul kiritish",'callback_data'=>"buy"],['text'=>"🖇 Takliflar",'callback_data'=>"ref"]],
]
]);

if($text=="$orqa"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"*🖥 Asosiy menyuga qaytdingiz*",
'parse_mode'=>'markdown',
'reply_markup'=>$menu,
]);
unlink("status/$cid.status");
unlink("fayl/$cid.step");
unlink("fayl/$cid.id");
unlink("fayl/$cid.coin");unlink("step/$cid.turi");
}

if(mb_stripos($text,"/start $cid")!==false){
mkdir("pul");
mkdir("ref");
bot('sendMessage',[
      'chat_id'=>$cid,
      'text'=>"Siz botga o'zingizni taklif qila olmaysiz!",
      'parse_mode'=>'html',
      'reply_markup'=>$menu,
      ]);
}else{
$idref = "pul/$ex.db";
$idref2 = file_get_contents($idref);
$id = "$cidn";
$handle = fopen($idref, 'a+');
fwrite($handle, $id);
fclose($handle);
if(mb_stripos($idref2,$cid) !== false ){
}else{
$pub=explode(" ",$text);
$ex=$pub[1];
file_put_contents("ref/$cid.txt", "$ex");
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"",
'parse_mode'=>'html',
]);
}
}


if($tx and $type=="private"){
$userlar = file_get_contents("stat/users.txt");
if(mb_stripos($userlar,"$cid")!==false){
}else{
file_put_contents("stat/users.txt","n".$cid,FILE_APPEND);
}
}

if($data=="buy"){
bot('editMessageText',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
'text'=>"<b>Quidagilardan birini tanlang!</b>",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"💴 CLICK Hamyon",'callback_data'=>"card"],['text'=>"🥝 Qiwi",'callback_data'=>"qiwi"]],
]
]),
]);
}

if($data=="card"){
bot('editMessagetext',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
'text'=>"<b>⬇Quyidagi click hamyon raqamiga tolov qiling va administratorga yozing</b>

💳 Karta: <code>$clickham</code>
💸 Minimal tolov: 5000 UZS",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🧑‍💻Administrator",'url'=>"https://t.me/$users"]],
]]),]);}

if($data=="qiwi"){
bot('editMessageText',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
'text'=>"
<b>🥝 QIWI to'lov tizimi orqali yuborilgan pullaringiz bir necha daqiqada 
avtomatik ravishda hisobingizga tushadi.</b>

💳 QIWI: <code>$qiwiham</code>
📝 Izoh: <code>$callcid</code>

<b>Diqqat! izoh kiritishni unutsangiz yoki noto'g'ri kiritsangiz hisobingizga pul tushmaydi! 
Bu kabi holatlarda, biz bilan bog'lanishingiz mumkin.</b>",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🧑‍💻Administrator",'url'=>"https://t.me/$users"]],
]]),]);}

if($data=="ref"){
$ok = bot('editMessagetext',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
'text'=>"*✅ Telegram  sahifalarga obunachi qo'shish
👥 Referal va sotib olish,
🔆 24/7 qo'llab-quvvatlash,
🇺🇿 O'zbek tilidagi boshqaruv.
👇 Hoziroq sinab ko'ring! Linkni bosing!*

👉🏻 https://telegram.me/$botname?start=$callcid",
'parse_mode'=>'markdown',
])->result->message_id;
bot('sendMessage',[
'chat_id'=>$callcid,
'text'=>"*Yuqoridagi xabarni tarqating va xar bir referalingiz uchun $refnarx uzs oling*",
'parse_mode'=>'markdown',
'reply_to_message_id'=>$ok, 
]);
}

$get = bot('getChatMember',[
'chat_id'=>$ki,
'user_id'=>$cid,
])->result->status;

if($get == "member" or $get == "administrator" or $get == "creator"){
}else{
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"<b>❌ Kechirasiz siz bizning kanallarimizga obuna boʻlmasangiz botdan foydalana olmaysiz!
🔰 Obuna boʻlib botga qayta /start bosing!</b>",
'parse_mode'=>'html',
'reply_markup'=>$keyboard,
]); 
return false;
}
}

if($text=="/start"){
bot("sendMessage",[
         "chat_id"=>$cid,
'text'=>"<b>✋ Assalomu alaykum, botimizga xush kelibsiz!
🚀 Biz sizga Telegram xizmatlarini taklif etamiz!
🌟 Sizning sahifalaringizni kuzatuvchilarini hamda obunachilaringiz professional darajada ko'paytirish uchun bizning bot siz bilan birga!
🔽 Davom etish uchun quyidagi tugmalardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>$menu,
]);  
$kele = file_get_contents("ref/$cid.txt");
bot('sendmessage',[
'chat_id'=>$kele,
'text'=>"📳 Sizda yangi taklif mavjud va sizga $refnarx UZS berildi",
]);
$refpuli = file_get_contents("pul/$kele.pul");
$ballplus = $refpuli + $refnarx;
file_put_contents("pul/$kele.pul", "$ballplus");
unlink("ref/$cid.txt");
}

$panel = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"⚒ Kanallarni sozlash"]],
[['text'=>"📊 Statistika"],['text'=>"⚙️ Asosiy Sozlanmalar"]],
[['text'=>"➕ Pul berish"],['text'=>"➖ Pul ayirish"]],
[['text'=>"📨 Xabar yuborish"],['text'=>"/start"]],
]
]);

$assoza = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"☢️ Api kalit"],['text'=>"*️⃣ Referal narxni"]],
[['text'=>"🛍 Buyurtmani sozlash"],['text'=>"💳 Hamyonlar"]],
[['text'=>"/panel"]],
]
]);

$xabarpa= json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"Oddiy xabar"],['text'=>"Forward xabar"]],
[['text'=>"/panel"]],
]
]);

$apkan = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"Api Kalit kiritish"],['text'=>"Api balans"]],
[['text'=>"/panel"]],
]
]);

if($text == "📨 Xabar yuborish" and $cid==$admin ){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"<b>Xabar turini tanlang!</b>",
'parse_mode'=>"html",
'reply_markup'=>$xabarpa,
]);
}

if($text == "⚙️ Asosiy Sozlanmalar" and $cid==$admin ){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"<b>⚙️ Asosiy Sozlanmalar</b>",
'parse_mode'=>"html",
'reply_markup'=>$assoza,
]);
}



if($text == "*️⃣ Referal narxni" and $cid == $admin) {
bot("sendmessage", [
"chat_id"=>$cid, 
"text"=>"*️⃣ Referal narxni yuboring",
'reply_markup'=>$panel
]);
file_put_contents("step/$cid.step",1063);
}

if($step == 1063 and $tx !== "↩️ Orqaga") {
bot("sendmessage", [
"chat_id"=>$cid, 
"text"=>"Saqlandi!",
'reply_markup'=>json_encode([
"resize_keyboard"=>true, 
"keyboard"=>[
[["text"=>"/panel"]], 
]]), 
]);
unlink("step/$cid.step");
file_put_contents("referal.txt",$text);
}

$ss=file_get_contents("admin.txt");
if($text=="💳 Hamyonlar" and $cid==$admin){
file_put_contents("admin.txt","hamyons");
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Qiwi hamyoni yuboring:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($ss=="hamyons" and $cid==$admin){
file_put_contents("qiwiham.txt",$text);
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Click hamyoni yuboring:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
file_put_contents("admin.txt","gopik");
 }


if($ss=="gopik" and $cid==$admin){
file_put_contents("clickham.txt",$text);
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"✅ Sozlandi!",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
unlink("adminpul.txt");
}

if($text == "☢️ Api kalit" and $cid==$admin ){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"<b>☢️ Api kalit</b>",
'parse_mode'=>"html",
'reply_markup'=>$apkan,
]);
}

if($text == "Api Kalit kiritish" and $cid == $admin) {
bot("sendmessage", [
"chat_id"=>$cid, 
"text"=>"@ApiSeenUzBot dan olingan ap keyni yuboring",
'reply_markup'=>$panel
]);
file_put_contents("step/$cid.step",960);
}

if($step == 960 and $tx !== "↩️ Orqaga") {
bot("sendmessage", [
"chat_id"=>$cid, 
"text"=>"Saqlandi!",
'reply_markup'=>json_encode([
"resize_keyboard"=>true, 
"keyboard"=>[
[["text"=>"/panel"]], 
]]), 
]);
unlink("step/$cid.step");
file_put_contents("apikey.txt",$text);
}

$buyso = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"1 - $tugma"],['text'=>"2 - $tugma1"]],
[['text'=>"3 - $tugma2"],['text'=>"4 - $tugma3"]],
[['text'=>"/start"]],
]
]);

if($text == "🛍 Buyurtmani sozlash" and $cid==$admin ){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"<b>🛍 Buyurtmani sozlash</b>",
'parse_mode'=>"html",
'reply_markup'=>$buyso,
]);
}

$minmaxi = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"Min-Max sozlash"],['text'=>"🔹Obunachi narxi"]],
[['text'=>"/start"]],
]
]);

if($text == "1 - $tugma" and $cid==$admin ){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"<b>1 - $tugma sozlash</b>",
'parse_mode'=>"html",
'reply_markup'=>$minmaxi,
]);
}

if($text == "🔹Obunachi narxi" and $cid == $admin) {
bot("sendmessage", [
"chat_id"=>$cid, 
"text"=>"🔹Obunachi narxi yuboring",
'reply_markup'=>$panel 
]);
file_put_contents("step/$cid.step",504);
}

if($step == 504 and $tx !== "↩️ Orqaga") {
bot("sendmessage", [
"chat_id"=>$cid, 
"text"=>"Saqlandi!",
'reply_markup'=>json_encode([
"resize_keyboard"=>true, 
"keyboard"=>[
[["text"=>"/panel"]], 
]]), 
]);
unlink("step/$cid.step");
file_put_contents("arzonnax.txt",$text);
}


$ss=file_get_contents("admin.txt");
if($text=="Min-Max sozlash" and $cid==$admin){
file_put_contents("admin.txt","mini");
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Minimal buyurtmani kiriting:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($ss=="mini" and $cid==$admin){
file_put_contents("arzonmin.txt",$text);
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Maksimal buyurtmani kiriting:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
file_put_contents("admin.txt","kkokoo");
 }


if($ss=="kkokoo" and $cid==$admin){
file_put_contents("arzonmax.txt",$text);
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"✅ Sozlandi!",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
unlink("adminpul.txt");
}

$minmaxi1 = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"Min - Max sozlash"],['text'=>"🔹 Obunachi narxi"]],
[['text'=>"/start"]],
]
]);

if($text == "2 - $tugma1" and $cid==$admin ){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"<b>2 - $tugma1 sozlash</b>",
'parse_mode'=>"html",
'reply_markup'=>$minmaxi1,
]);
}


if($text == "🔹 Obunachi narxi" and $cid == $admin) {
bot("sendmessage", [
"chat_id"=>$cid, 
"text"=>"🔹 Obunachi narxi yuboring",
'reply_markup'=>$panel
]);
file_put_contents("step/$cid.step",666);
}

if($step == 666 and $tx !== "↩️ Orqaga") {
bot("sendmessage", [
"chat_id"=>$cid, 
"text"=>"Saqlandi!",
'reply_markup'=>json_encode([
"resize_keyboard"=>true, 
"keyboard"=>[
[["text"=>"/panel"]], 
]]), 
]);
unlink("step/$cid.step");
file_put_contents("tezkornarx.txt",$text);
}


$ss=file_get_contents("admin.txt");
if($text=="Min - Max sozlash" and $cid==$admin){
file_put_contents("admin.txt","mini1");
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Minimal buyurtmani kiriting:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($ss=="mini1" and $cid==$admin){
file_put_contents("tezkormin.txt",$text);
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Maksimal buyurtmani kiriting:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
file_put_contents("admin.txt","kkokoo1");
 }


if($ss=="kkokoo1" and $cid==$admin){
file_put_contents("tezkormax.txt",$text);
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"✅ Sozlandi!",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
unlink("adminpul.txt");
}

$minmaxi2 = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"Min- Max sozlash"],['text'=>"🔸 Obunachi narxi"]],
[['text'=>"/start"]],
]
]);

if($text == "3 - $tugma2" and $cid==$admin ){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"<b>3 - $tugma2 sozlash</b>",
'parse_mode'=>"html",
'reply_markup'=>$minmaxi2,
]);
}




if($text == "🔸 Obunachi narxi" and $cid == $admin) {
bot("sendmessage", [
"chat_id"=>$cid, 
"text"=>"🔸 Obunachi narxi yuboring",
'reply_markup'=>$panel 
]);
file_put_contents("step/$cid.step",0202);
}

if($step == 0202 and $tx !== "↩️ Orqaga") {
bot("sendmessage", [
"chat_id"=>$cid, 
"text"=>"Saqlandi!",
'reply_markup'=>json_encode([
"resize_keyboard"=>true, 
"keyboard"=>[
[["text"=>"/panel"]], 
]]), 
]);
unlink("step/$cid.step");
file_put_contents("arabicnarx.txt",$text);
}

$ss=file_get_contents("admin.txt");
if($text=="Min- Max sozlash" and $cid==$admin){
file_put_contents("admin.txt","mini2");
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Minimal buyurtmani kiriting:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($ss=="mini2" and $cid==$admin){
file_put_contents("arzbicmin.txt",$text);
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Maksimal buyurtmani kiriting:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
file_put_contents("admin.txt","kkokoo2");
 }


if($ss=="kkokoo2" and $cid==$admin){
file_put_contents("arzbicmax.txt",$text);
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"✅ Sozlandi!",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
unlink("adminpul.txt");
}

$minmaxi3 = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"Min -Max sozlash"],['text'=>"🔸Obunachi narxi"]],
[['text'=>"/start"]],
]
]);

if($text == "4 - $tugma3" and $cid==$admin ){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"<b>4 - $tugma3 sozlash</b>",
'parse_mode'=>"html",
'reply_markup'=>$minmaxi3,
]);
}

if($text == "🔸Obunachi narxi" and $cid == $admin) {
bot("sendmessage", [
"chat_id"=>$cid, 
"text"=>"🔸Obunachi narxi yuboring",
'reply_markup'=>$panel 
]);
file_put_contents("step/$cid.step",110);
}

if($step == 110 and $tx !== "↩️ Orqaga") {
bot("sendmessage", [
"chat_id"=>$cid, 
"text"=>"Saqlandi!",
'reply_markup'=>json_encode([
"resize_keyboard"=>true, 
"keyboard"=>[
[["text"=>"/panel"]], 
]]), 
]);
unlink("step/$cid.step");
file_put_contents("chinnarx.txt",$text);
}

$ss=file_get_contents("admin.txt");
if($text=="Min- Max sozlash" and $cid==$admin){
file_put_contents("admin.txt","mini3");
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Minimal buyurtmani kiriting:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($ss=="mini3" and $cid==$admin){
file_put_contents("chinamin.txt",$text);
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Maksimal buyurtmani kiriting:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
file_put_contents("admin.txt","kkokoo3");
 }


if($ss=="kkokoo3" and $cid==$admin){
file_put_contents("chinamax.txt",$text);
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"✅ Sozlandi!",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
unlink("adminpul.txt");
}


$kanalpa = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"📢 Kanal qoʻshish"],['text'=>"📢 Kanalni oʻchirish"]],
[['text'=>"/panel"]],
]
]);

if($text == "⚒ Kanallarni sozlash" and $cid==$admin ){
	bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"<b>⚒ Kanallarni sozlash</b>",
	'parse_mode'=>"html",
	'reply_markup'=>$kanalpa,
]);
}


$st=file_get_contents("step.txt");
if($text == "📢 Kanal qoʻshish" and $cid == $admin){
file_put_contents("step.txt","kanal");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"<b>📡 Kanal qo‘shish uchun kanal havolasini yuboring!
🔰 Masalan: @LiveBlogs</b>",
'parse_mode'=>'html',
'reply_markup'=>$ortga,
]);
}

if($st == "kanal"){
if(mb_stripos($kanal,"$text")){
}else{
file_put_contents("kanal.txt","$kanal\n$text");
file_put_contents("channel.txt","true");
unlink("step.txt");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"<b>📡 Kanalingiz botga muvaffaqiyatli qo‘shildi!
🤖 Endi botni kanalingizga admin qiling!</b>",
'parse_mode'=>'html',
'reply_markup'=>$panel,
]);
}
}


$st=file_get_contents("step.txt");
if($text == "📢 Kanalni oʻchirish" and $cid == $admin){
file_put_contents("step.txt","delete");
$ids = explode("\n",$kanal);
$soni = substr_count($kanal,"@");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"<b>📡Kanalni oʻchirish uchun kanal havolasini yuboring!

🔰Masalan: @LiveBlogs

👇Botga ulangan kanallar:
$kanal

📝Jami kanallar soni: $soni ta
</b>",
'parse_mode'=>'html',
'reply_markup'=>$ortga,
]);
}

if($st == "delete" and $text!=$back){
if(mb_stripos($kanal,"$text")!==false){
$k = str_replace("\n".$text."","",$kanal);
file_put_contents("kanal.txt",$k);
unlink("step.txt");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"<b>🔰$text muvaffaqiyatli oʻchirildi!✅</b>",
'parse_mode'=>'html',
'reply_markup'=>$panel,
]);
}
}

$okstat=file_get_contents("status/$cid.status");
if($text=="🔎 Kuzatish"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"*Buyurtma ID-raqamini kiriting*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,'keyboard'=>[[['text'=>$orqa]],
]]),
]);
mkdir("status");
file_put_contents("status/$cid.status","1");
}
if($okstat==1){
if(is_numeric($tx)){
$orderstat=json_decode(file_get_contents("https://u6182.xvest4.ru/api/?kalit=$apikey&act=status&id=$tx"),true);
if($orderstat['error'] !="Incorrect order ID"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"
Buyurtma xolati: ".$orderstat['status']."
Buyurtma miqdori: ".$orderstat['remains']."-ta",'reply_markup'=>$menu,
]);unlink("status/$cid.status");
}else{
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>" Mavjud emas",
'reply_markup'=>$menu,
]);unlink("status/$cid.status");
}
}
}

if($text == "/panel" and $cid==$admin){
	bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"<i>Kerakli boʻlimni tanlang!!</i>",
	'parse_mode'=>"html",
	'reply_markup'=>$panel,
]);
}


if($text=="Api balans" and $cid==$admin){
$api_balance = json_decode(file_get_contents("https://u6182.xvest4.ru/api/?kalit=$apikey&act=hisob"),true);
bot('deleteMessage',[
'chat_id'=>$cid,
'message_id'=>$mid,
]);
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"Sizning API Balansingizda
".$api_balance['hisob']." USD",
'reply_markup'=>$panel,
]);
}

if($text=="📊 Statistika" && $cid==$admin){
bot('deleteMessage',[
'chat_id'=>$cid,
'message_id'=>$mid,
]);
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"Bot azolari ".substr_count($userlar,"n")." ta ",
'reply_markup'=>$panel,
]);
}


$s=file_get_contents("step/$cid.step");
    if($text == "Oddiy xabar" and $cid == $admin){
      bot('sendMessage',[
      'chat_id'=>$cid,
      'text'=>"<b>Userlarga yuboriladigan habarni kiriting!!</b>",
      'parse_mode'=>"html",
      'reply_markup'=>$panel,
      ]);
      file_put_contents("step/$cid.step","user");
    }

    if($s == "user" and $cid == $admin){
      if($text == "/cancel"){
      unlink("stat/$chat_id.step");
      }else{ 
      $idszs=explode("n",$userlar);
      foreach($idszs as $idlat){
     $userr = bot('sendMessage',[
      'chat_id'=>$idlat,
      'text'=>"<b>$text</b>",
      'parse_mode'=>'html',
      'disable_web_page_preview' => true,
      ]);  unlink("step/$cid.step");
      }
        if($userr){
          bot('sendmessage',[
          'chat_id'=>$admin,
          'text'=>"Habar Barcha Userlarga yuborildi!",
          ]);      
      unlink("step/$cid.step");
        }
      }
    }
     


if($text == "Forward xabar" and $cid == $admin){
 bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"✅ *Userlarga forward qilinadigan xabarni kiriting!
Bakor qilish uchun /cancel ni bosing*",
'parse_mode'=>'markdown',
]);
file_put_contents("step/$cid.step","forward");
}

if($s == "forward" and $cid == $admin){
if($text == "/cancel"){
unlink("stat/$cid.step");
}else{ 
$ids=explode("\n",$userlar);
foreach($ids as $id){
$user = bot('forwardMessage', [
'chat_id'=>$id,
'from_chat_id'=>$admin,
'message_id'=>$mid,
]);unlink("step/$cid.step");
}

if($user){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"✅ Xabar yetkazildi!",
'parse_mode'=>"markdown",
]);     
unlink("step/$cid.step");
}
}
}   

if($text=="📚 Bot haqida"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>$text."<b>Malumot olish uchun quyidagi menyulardan birini tanlang-Bo'limi</b>",
      'parse_mode'=>"html",
'reply_markup'=>$haqida,
]);
}
if($data=="qoid"){
bot('editMessageText',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
'text'=>"<b>@$botname Qoidalari❗️
• Adminga yolgʻon xabar yubormang. Bu uchun botda ban olishingiz mumkin
• Yordam boʻlimidan foydalanayotganda adminga haqiratli soʻz yozmang. Bu uchun botda ban olishingiz mumkin.
• Buyurtma berilgan linkning buyurtmasi bajarilmasdan oʻsha link uchun yana buyurtma bermang. Bu holdagi xatolik uchun sizga pul qaytarilmaydi.
• Admindan tekinga yoki savob uchun hisobingizni toʻldirishni soʻramang.

Qoʻshimcha maʼlumotlar olish uchun @$adminuser bilan bogʻlaning.</b>  ",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🧑‍💻Admin",'url'=>"https://t.me/$adminuser"]],
]]),]);}
if($data=="qol"){
bot('editMessagetext',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
'text'=>"<b>@$botname dan foydalanish.
•Qanday buyurtma berish mumkin ?
Buyurtma berish boʻlimiga kiring. Oʻzingizga kerakli Ijtimoiy tarmoqni tanlang. Soʻng xizmatni tanlang. Kerakli obunachi miqdorini yozing va kerrakli linkni kiriting. 
•Hisobni qanday toʻldirish mumkin ?
Hisobim boʻlimiga kiring. U yerdan hisobni toʻldirish boʻlimini tanlang. Oʻzizga kerakli toʻlov usulini tanlang va bot bergan qoʻllanma boʻyicha ish tuting.

Sizda boshqacharoq savol va murojaatlar boʻlsa @$adminuser bilan bogʻlaning.</b> ",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🚀Bot admini",'url'=>"https://t.me/$adminuser"]],
]]),]);}
if($data=="stat"){
bot('editMessageText',[
'chat_id'=>$callcid,
'message_id'=>$callmid,
'text'=>" 📊 <b>Bot foydalanuvchilari soni</b>:".substr_count($userlar,"\n")." ta",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🧑‍💻Admin",'url'=>"https://t.me/$adminuser"]],
]]),]);}

if($text=="📲 Kabinet"){
$dost = file_get_contents("pul/$cid.ref");
$soat=date('H:i:s',strtotime('4 hour'));
$sana=date("d-M-20y",strtotime("3 hour"));
$hisob  = file_get_contents("pul/$cid.pul");
bot('deleteMessage',[
'chat_id'=>$cid,
'message_id'=>$mid,
]);
$dl = bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"<b>🔑 Sizning ID raqamingiz: <code>$cid</code>

💵 Umumiy balansingiz: ".floor($hisob)." uzs

Statusingiz: Oddiy</b>",
'parse_mode'=>"HTML",
'reply_markup'=>$pay,
])->result->message_id;
}

if($text=="📨 Telegram"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"*🛍 Buyurtma tarifini tanlang:*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🤵 Obunachi"]],
[['text'=>$orqa]],
]
]),
]);file_put_contents("step/$cid.turi",1);
}

if($text=="📨 Iznstagram"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"*Tez kunda...*",
'parse_mode'=>'markdown',
'reply_markup'=>$mem
]);
}

if($text=="⬅Orqaga"){
bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"Bekor qilindi!",
    'parse_mode'=>"html",
'reply_markup'=>$mem,
]);
unlink("step/$cid.step");
exit();
}

$step = file_get_contents("step/$cid.step");
$hisob = file_get_contents("pul/$cid.pul");
$types = file_get_contents("step/$cid.turi");
if($text=="🤵 Obunachi" and $types==1){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"Telegram 🤵 Obunachi bolimidasiz servislarni tanlang",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"$tugma"],['text'=>"$tugma1"],],
[['text'=>"$tugma2"],['text'=>"$tugma3"],],
[['text'=>$orqa]],
]
]),
]);
}

if($text== "$tugma" and $types=="1"){
$status = file_get_contents("status.txt");
if($status== "off"){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"obunachi qoshish vaxtincha admin tomonidan ochirilgan",
]);
}else{
mkdir("data");
mkdir("data/zakaz");
bot("deleteMessage",[
'chat_id'=>$cid,
'message_id'=>$mid,
]);
bot("sendMessage",[
'chat_id'=>$cid,
'text'=>"*🔗 Kanalingiz manzilini yuboring:

❕ Namuna: https://t.me/havola*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"⬅Orqaga"],],
]
]),
]);
file_put_contents("step/$cid.turi","telegram_url");
file_put_contents("step/$cid.step","tg_url");
}
}
if($step=="tg_url" and $types=="telegram_url"){
$miqdor1 = $hisob / 2.40;
$sumasi = $arzonmin * $arzonnarx;
$sumasi1 = $arzonmax * $arzonnarx;
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"*Kanalingiz saqlandi

Minimal buyurtma: $arzonmin ta
Maksimal buyurtma: $arzonmax ta
$arzonmin obunachi narxi: $sumasi so'm
$arzonmax ta obunachi narxi $sumasi1 so'm

Kerakli obunachilar miqdorini kiriting:*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"⬅Orqaga"],],
]
]),
]);
unlink("step/$cid.turi");
unlink("step/$cid.step");
file_put_contents("step/$cid.step","tg_pm");
file_put_contents("step/$cid.turi","telegram_pm");
file_put_contents("data/zakaz/$cid.kan","$text");
}

if($step=="tg_pm" and $types=="telegram_pm"){
$min = "$arzonmin";
$max = "$arzonmax";
if($text=="⬅Orqaga"){
bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"Bekor qilindi!",
    'parse_mode'=>"html",
'reply_markup'=>$mem,
]);
unlink("step/$cid.step");
exit();
}
if(is_numeric($text)){
if($text>=$min and $text<=$max){
$zakchan = file_get_contents("data/zakaz/$cid.kan");
file_put_contents("data/zakaz/$cid.son","$text");
file_put_contents("step/$cid.step","none");
bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"<b>✅ Qabul qilindi!

⚠️ Buyurtmani tasdiqlashdan oldin, quyidagi ma'lumotlarni tekshirib chiqing:
    
Buyurtma turi: $tugma
🔗 Kanal manzili: $zakchan
👤 Buyurtma miqdori: $text ta
    
❔ Barchasi to'g'ri kiritilganiga ishonchingiz komilmi? ✅ Tasdiqlash tugmasini bosgan buyurtma yuboriladi!</b>",
    'parse_mode'=>"html",
'reply_markup'=>json_encode([
"resize_keyboard"=>true,
'keyboard'=>[
[["text"=>"✅ Tasdiqlash"],["text"=>"❌ Bekor qilish"],],
]
]),
]);
file_put_contents("step/$cid.tur","tgok");
}else{
bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"❌Xatolik
Minimal: $min
Maksimal: $max",
    'parse_mode'=>"html",
'reply_markup'=>$bekor,
]);
}
}
}
$ctypes = file_get_contents("step/$cid.tur");
if($text=="❌ Bekor qilish" and $ctypes=="tgok"){
unlink("step/$cid.step");
unlink("step/$cid.tur");
unlink("data/type/$cid.txt");
unlink("data/zakaz/$cid.kan");
unlink("data/zakaz/$cid.son");
bot('sendmessage',[
                'chat_id'=>$cid,
 'text'=>"🚫 Bekor qilindi",
'reply_markup'=>$menu,
]);
return false;
}

$ctypes = file_get_contents("step/$cid.tur");
$data = $update->callback_query->data;
if($text=="✅ Tasdiqlash" and $ctypes=="tgok"){
$sumid =  file_get_contents("pul/$cid.pul");
$max = $sumid / $arzonnarx;
$maxmember = floor($max);
$czakchan = file_get_contents("data/zakaz/$cid.kan");
$czakson = file_get_contents("data/zakaz/$cid.son");
$czakid = file_get_contents("data/zakaz/$cid.rid");
if($maxmember>=$czakson){
$zakazcount = file_get_contents("zakaz.txt");
$zakidq = $zakazcount + 1;
file_put_contents("zakaz.txt","$zakidq");
$pluscoin = $czakson * $arzonnarx;
$coinplus = $sumid - $pluscoin;
file_put_contents("pul/$cid.pul","$coinplus");
$zkq = json_decode(file_get_contents("https://u6182.xvest4.ru/api/?kalit=$apikey&act=obunachi&id=1&manzil=$czakchan&miqdor=$czakson"),1);
$zkq2=$zkq["order"];
bot("deleteMessage",[
'chat_id'=>$cid,
]);
bot('sendMessage',[
                'chat_id'=>$cid,
 'text'=>"<b>Buyurtma qabul qilindi!

Buyurtma ID si:</b> <code>$zkq2</code>
 
<i>Yuqoridagi ID orqali buyurtmangiz haqida ma'lumot olishingiz mumkin!</i>",
'parse_mode'=>"html",
'reply_markup'=>$menu,
]);
unlink("step/$cid.tur");
unlink("step/$cid.step");
}else{
unlink("step/$cid.step");
unlink("data/zakaz/$cid.kan");
unlink("data/zakaz/$cid.son");
unlink("step/$cid.tur");
bot("deleteMessage",[
'chat_id'=>$cid,
'message_id'=>$mid,
]);
$miqdor2= $sumid / $arzonnarx;
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*❗️ Balans yetarli emas.*",
'parse_mode'=>'markdown',
'reply_markup'=>$menu,
]);
}
}

if($text== "$tugma1" and $types=="1"){
$status = file_get_contents("status.txt");
if($status== "off"){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"obunachi qoshish vaxtincha admin tomonidan ochirilgan",
]);
}else{
mkdir("data");
mkdir("data/zakaz");
bot("deleteMessage",[
'chat_id'=>$cid,
'message_id'=>$mid,
]);
bot("sendMessage",[
'chat_id'=>$cid,
'text'=>"*🔗 Kanalingiz manzilini yuboring:

❕ Namuna: https://t.me/havola*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"⬅Orqaga"],],
]
]),
]);
file_put_contents("step/$cid.turi","sek_url");
file_put_contents("step/$cid.step","sek_url");
}
}
if($step=="sek_url" and $types=="sek_url"){
$miqdor1 = $hisob / 2.40;
$sumasi2 = $tezkormin * $tezkornarx;
$sumasi3 = $tezkormax * $tezkornarx;
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"*Kanalingiz saqlandi

Minimal buyurtma: $tezkormin ta
Maksimal buyurtma: $tezkormax ta
$tezkormin obunachi narxi: $sumasi2 so'm
$tezkormax ta obunachi narxi $sumasi3 so'm

Kerakli obunachilar miqdorini kiriting:*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"⬅Orqaga"],],
]
]),
]);
unlink("step/$cid.turi");
unlink("step/$cid.step");
file_put_contents("step/$cid.step","sek_pm");
file_put_contents("step/$cid.turi","sekram_pm");
file_put_contents("data/zakaz/$cid.kan","$text");
}

if($step=="sek_pm" and $types=="sekram_pm"){
$min = "$tezkormin";
$max = "$tezkormax";
if($text=="⬅Orqaga"){
bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"Bekor qilindi!",
    'parse_mode'=>"html",
'reply_markup'=>$mem,
]);
unlink("step/$cid.step");
exit();
}
if(is_numeric($text)){
if($text>=$min and $text<=$max){
$zakchan = file_get_contents("data/zakaz/$cid.kan");
file_put_contents("data/zakaz/$cid.son","$text");
file_put_contents("step/$cid.step","none");
bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"<b>✅ Qabul qilindi!

⚠️ Buyurtmani tasdiqlashdan oldin, quyidagi ma'lumotlarni tekshirib chiqing:
    
Buyurtma turi: $tugma1
🔗 Kanal manzili: $zakchan
👤 Buyurtma miqdori: $text ta
    
❔ Barchasi to'g'ri kiritilganiga ishonchingiz komilmi? ✅ Tasdiqlash tugmasini bosgan buyurtma yuboriladi!</b>",
    'parse_mode'=>"html",
'reply_markup'=>json_encode([
"resize_keyboard"=>true,
'keyboard'=>[
[["text"=>"✅ Tasdiqlash"],["text"=>"❌ Bekor qilish"],],
]
]),
]);
file_put_contents("step/$cid.tur","sekok");
}else{
bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"❌Xatolik
Minimal: $min
Maksimal: $max",
    'parse_mode'=>"html",
'reply_markup'=>$bekor,
]);
}
}
}
$ctypes = file_get_contents("step/$cid.tur");
if($text=="❌ Bekor qilish" and $ctypes=="sekok"){
unlink("step/$cid.step");
unlink("step/$cid.tur");
unlink("data/type/$cid.txt");
unlink("data/zakaz/$cid.kan");
unlink("data/zakaz/$cid.son");
bot('sendmessage',[
                'chat_id'=>$cid,
 'text'=>"🚫 Bekor qilindi",
'reply_markup'=>$menu,
]);
return false;
}

$ctypes = file_get_contents("step/$cid.tur");
$data = $update->callback_query->data;
if($text=="✅ Tasdiqlash" and $ctypes=="sekok"){
$sumid =  file_get_contents("pul/$cid.pul");
$max = $sumid / $tezkornarx;
$maxmember = floor($max);
$czakchan = file_get_contents("data/zakaz/$cid.kan");
$czakson = file_get_contents("data/zakaz/$cid.son");
$czakid = file_get_contents("data/zakaz/$cid.rid");
if($maxmember>=$czakson){
$zakazcount = file_get_contents("zakaz.txt");
$zakidq = $zakazcount + 1;
file_put_contents("zakaz.txt","$zakidq");
$pluscoin = $czakson * $tezkornarx;
$coinplus = $sumid - $pluscoin;
file_put_contents("pul/$cid.pul","$coinplus");
$zkq = json_decode(file_get_contents("https://u6182.xvest4.ru/api/?kalit=$apikey&act=obunachi&id=2&manzil=$czakchan&miqdor=$czakson"),1);
bot("deleteMessage",[
'chat_id'=>$cid,
]);
bot('sendMessage',[
"buyurtma"=>$zkq["order"],
                'chat_id'=>$cid,
 'text'=>"<b>Buyurtma qabul qilindi!

Buyurtma ID si:</b> <code>$zkq</code>
 
<i>Yuqoridagi ID orqali buyurtmangiz haqida ma'lumot olishingiz mumkin!</i>",
'parse_mode'=>"html",
'reply_markup'=>$menu,
]);
unlink("step/$cid.tur");
unlink("step/$cid.step");
}else{
unlink("step/$cid.step");
unlink("data/zakaz/$cid.kan");
unlink("data/zakaz/$cid.son");
unlink("step/$cid.tur");
bot("deleteMessage",[
'chat_id'=>$cid,
'message_id'=>$mid,
]);
$miqdor2= $sumid / $tezkornarx;
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*❗️ Balans yetarli emas.*",
'parse_mode'=>'markdown',
'reply_markup'=>$menu,
]);
}
}


if($text== "$tugma2" and $types=="1"){
$status = file_get_contents("status.txt");
if($status== "off"){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"obunachi qoshish vaxtincha admin tomonidan ochirilgan",
]);
}else{
mkdir("data");
mkdir("data/zakaz");
bot("deleteMessage",[
'chat_id'=>$cid,
'message_id'=>$mid,
]);
bot("sendMessage",[
'chat_id'=>$cid,
'text'=>"*🔗 Kanalingiz manzilini yuboring:

❕ Namuna: https://t.me/havola*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"⬅Orqaga"],],
]
]),
]);
file_put_contents("step/$cid.turi","tezkor_url");
file_put_contents("step/$cid.step","teg_url");
}
}
if($step=="teg_url" and $types=="tezkor_url"){
$miqdor1 = $hisob / 2.40;
$sumasi4 = $arzbicmin * $arabicnarx;
$sumasi5 = $arzbicmax * $arabicnarx;
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"*Kanalingiz saqlandi

Minimal buyurtma: $arzbicmin ta
Maksimal buyurtma: $arzbicmax ta
$arzbicmin obunachi narxi: $sumasi4 so'm
$arzbicmax ta obunachi narxi $sumasi5 so'm

Kerakli obunachilar miqdorini kiriting:*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"⬅Orqaga"],],
]
]),
]);
unlink("step/$cid.turi");
unlink("step/$cid.step");
file_put_contents("step/$cid.step","teeg_pm");
file_put_contents("step/$cid.turi","tezpmmm");
file_put_contents("data/zakaz/$cid.kan","$text");
}

if($step=="teeg_pm" and $types=="tezpmmm"){
$min = "$arzbicmin";
$max = "$arzbicmax";
if($text=="⬅Orqaga"){
bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"Bekor qilindi!",
    'parse_mode'=>"html",
'reply_markup'=>$mem,
]);
unlink("step/$cid.step");
exit();
}
if(is_numeric($text)){
if($text>=$min and $text<=$max){
$zakchan = file_get_contents("data/zakaz/$cid.kan");
file_put_contents("data/zakaz/$cid.son","$text");
file_put_contents("step/$cid.step","none");
bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"<b>✅ Qabul qilindi!

⚠️ Buyurtmani tasdiqlashdan oldin, quyidagi ma'lumotlarni tekshirib chiqing:
    
Buyurtma turi: $tugma2
🔗 Kanal manzili: $zakchan
👤 Buyurtma miqdori: $text ta
    
❔ Barchasi to'g'ri kiritilganiga ishonchingiz komilmi? ✅ Tasdiqlash tugmasini bosgan buyurtma yuboriladi!</b>",
    'parse_mode'=>"html",
'reply_markup'=>json_encode([
"resize_keyboard"=>true,
'keyboard'=>[
[["text"=>"✅ Tasdiqlash"],["text"=>"❌ Bekor qilish"],],
]
]),
]);
file_put_contents("step/$cid.tur","tezkogok");
}else{
bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"❌Xatolik
Minimal: $min
Maksimal: $max",
    'parse_mode'=>"html",
'reply_markup'=>$bekor,
]);
}
}
}
$ctypes = file_get_contents("step/$cid.tur");
if($text=="❌ Bekor qilish" and $ctypes=="tezkogok"){
unlink("step/$cid.step");
unlink("step/$cid.tur");
unlink("data/type/$cid.txt");
unlink("data/zakaz/$cid.kan");
unlink("data/zakaz/$cid.son");
bot('sendmessage',[
                'chat_id'=>$cid,
 'text'=>"🚫 Bekor qilindi",
'reply_markup'=>$menu,
]);
return false;
}

$ctypes = file_get_contents("step/$cid.tur");
$data = $update->callback_query->data;
if($text=="✅ Tasdiqlash" and $ctypes=="tezkogok"){
$sumid =  file_get_contents("pul/$cid.pul");
$max = $sumid / $arabicnarx;
$maxmember = floor($max);
$czakchan = file_get_contents("data/zakaz/$cid.kan");
$czakson = file_get_contents("data/zakaz/$cid.son");
$czakid = file_get_contents("data/zakaz/$cid.rid");
if($maxmember>=$czakson){
$zakazcount = file_get_contents("zakaz.txt");
$zakidq = $zakazcount + 1;
file_put_contents("zakaz.txt","$zakidq");
$pluscoin = $czakson * $arabicnarx;
$coinplus = $sumid - $pluscoin;
file_put_contents("pul/$cid.pul","$coinplus");
$zkq = json_decode(file_get_contents("https://u6182.xvest4.ru/api/?kalit=$apikey&act=obunachi&id=3&manzil=$czakchan&miqdor=$czakson"),1);
$zkq2=$zkq["order"];
bot("deleteMessage",[
'chat_id'=>$cid,
]);
bot('sendMessage',[
                'chat_id'=>$cid,
 'text'=>"<b>Buyurtma qabul qilindi!

Buyurtma ID si:</b> <code>$zkq2</code>
 
<i>Yuqoridagi ID orqali buyurtmangiz haqida ma'lumot olishingiz mumkin!</i>",
'parse_mode'=>"html",
'reply_markup'=>$menu,
]);
unlink("step/$cid.tur");
unlink("step/$cid.step");
}else{
unlink("step/$cid.step");
unlink("data/zakaz/$cid.kan");
unlink("data/zakaz/$cid.son");
unlink("step/$cid.tur");
bot("deleteMessage",[
'chat_id'=>$cid,
'message_id'=>$mid,
]);
$miqdor2= $sumid / 4;
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*❗️ Balans yetarli emas.*",
'parse_mode'=>'markdown',
'reply_markup'=>$menu,
]);
}
}

if($text== "$tugma3" and $types=="1"){
$status = file_get_contents("status.txt");
if($status== "off"){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"obunachi qoshish vaxtincha admin tomonidan ochirilgan",
]);
}else{
mkdir("data");
mkdir("data/zakaz");
bot("deleteMessage",[
'chat_id'=>$cid,
'message_id'=>$mid,
]);
bot("sendMessage",[
'chat_id'=>$cid,
'text'=>"*🔗 Kanalingiz manzilini yuboring:

❕ Namuna: https://t.me/havola*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"⬅Orqaga"],],
]
]),
]);
file_put_contents("step/$cid.turi","chiqma_url");
file_put_contents("step/$cid.step","chiq_url");
}
}
if($step=="chiq_url" and $types=="chiqma_url"){
$miqdor1 = $hisob / 2.40;
$sumasi6 = $chinamin * $chinanarx;
$sumasi7 = $chinamax * $chinanarx;
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"*Kanalingiz saqlandi

Minimal buyurtma: $chinamin ta
Maksimal buyurtma: $chinamax ta
$chinamin obunachi narxi: $sumasi6 so'm
$chinamax ta obunachi narxi $sumai7 so'm

Kerakli obunachilar miqdorini kiriting:*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"⬅Orqaga"],],
]
]),
]);
unlink("step/$cid.turi");
unlink("step/$cid.step");
file_put_contents("step/$cid.step","chiqma_url");
file_put_contents("step/$cid.turi","chiqmapmm");
file_put_contents("data/zakaz/$cid.kan","$text");
}

if($step=="chiqma_url" and $types=="chiqmapmm"){
$min = "$chinamin";
$max = "$chinamax";
if($text=="⬅Orqaga"){
bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"Bekor qilindi!",
    'parse_mode'=>"html",
'reply_markup'=>$mem,
]);
unlink("step/$cid.step");
exit();
}
if(is_numeric($text)){
if($text>=$min and $text<=$max){
$zakchan = file_get_contents("data/zakaz/$cid.kan");
file_put_contents("data/zakaz/$cid.son","$text");
file_put_contents("step/$cid.step","none");
bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"<b>✅ Qabul qilindi!

⚠️ Buyurtmani tasdiqlashdan oldin, quyidagi ma'lumotlarni tekshirib chiqing:
    
Buyurtma turi: $tugma3
🔗 Kanal manzili: $zakchan
👤 Buyurtma miqdori: $text ta
    
❔ Barchasi to'g'ri kiritilganiga ishonchingiz komilmi? ✅ Tasdiqlash tugmasini bosgan buyurtma yuboriladi!</b>",
    'parse_mode'=>"html",
'reply_markup'=>json_encode([
"resize_keyboard"=>true,
'keyboard'=>[
[["text"=>"✅ Tasdiqlash"],["text"=>"❌ Bekor qilish"],],
]
]),
]);
file_put_contents("step/$cid.tur","chiqmapmmm");
}else{
bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"❌Xatolik
Minimal: $min
Maksimal: $max",
    'parse_mode'=>"html",
'reply_markup'=>$bekor,
]);
}
}
}
$ctypes = file_get_contents("step/$cid.tur");
if($text=="❌ Bekor qilish" and $ctypes=="chiqmapmmm"){
unlink("step/$cid.step");
unlink("step/$cid.tur");
unlink("data/type/$cid.txt");
unlink("data/zakaz/$cid.kan");
unlink("data/zakaz/$cid.son");
bot('sendmessage',[
                'chat_id'=>$cid,
 'text'=>"🚫 Bekor qilindi",
'reply_markup'=>$menu,
]);
return false;
}

$ctypes = file_get_contents("step/$cid.tur");
$data = $update->callback_query->data;
if($text=="✅ Tasdiqlash" and $ctypes=="chiqmapmmm"){
$sumid =  file_get_contents("pul/$cid.pul");
$max = $sumid / $chinanarx;
$maxmember = floor($max);
$czakchan = file_get_contents("data/zakaz/$cid.kan");
$czakson = file_get_contents("data/zakaz/$cid.son");
$czakid = file_get_contents("data/zakaz/$cid.rid");
if($maxmember>=$czakson){
$zakazcount = file_get_contents("zakaz.txt");
$zakidq = $zakazcount + 1;
file_put_contents("zakaz.txt","$zakidq");
$pluscoin = $czakson * $chinanarx;
$coinplus = $sumid - $pluscoin;
file_put_contents("pul/$cid.pul","$coinplus");
$zkq = json_decode(file_get_contents("https://u6182.xvest4.ru/api/?kalit=$apikey&act=obunachi&id=4&manzil=$czakchan&miqdor=$czakson"),1);
$zkq2=$zkq["order"];
bot("deleteMessage",[
'chat_id'=>$cid,
]);
bot('sendMessage',[
                'chat_id'=>$cid,
 'text'=>"<b>Buyurtma qabul qilindi!

Buyurtma ID si:</b> <code>$zkq2</code>
 
<i>Yuqoridagi ID orqali buyurtmangiz haqida ma'lumot olishingiz mumkin!</i>",
'parse_mode'=>"html",
'reply_markup'=>$menu,
]);
unlink("step/$cid.tur");
unlink("step/$cid.step");
}else{
unlink("step/$cid.step");
unlink("data/zakaz/$cid.kan");
unlink("data/zakaz/$cid.son");
unlink("step/$cid.tur");
bot("deleteMessage",[
'chat_id'=>$cid,
'message_id'=>$mid,
]);
$miqdor2= $sumid / 5;
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*❗️ Balans yetarli emas.*",
'parse_mode'=>'markdown',
'reply_markup'=>$menu,
]);
}
}

if($text=="➕ Buyurtma berish"){
bot('deleteMessage',[
'chat_id'=>$cid,
'message_id'=>$mid,
]);
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"*📱 Ijtimoiy tarmoqni tanlang:*",
'parse_mode'=>'markdown',
'reply_markup'=>$mem,
]);
}

$ss=file_get_contents("admin.txt");
if($text=="➕ Pul berish" and $cid==$admin){
file_put_contents("admin.txt","coin");
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"Foydalanuvchi hisobini nechi pulga toʻldirmoqchisiz:",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($ss=="coin" and $cid==$admin){
file_put_contents("adminpul.coin",$text);
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"Foydalanuvchi ID raqamini kiriting:",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
file_put_contents("admin.txt","pay");
 }


if($ss=="pay" and $cid==$admin){
$summa = file_get_contents("adminpul.coin");
$sum =  file_get_contents("pul/$text.pul");
$jami = $sum + $summa;
file_put_contents("pul/$text.pul","$jami");
bot("sendMessage",[
   "chat_id"=>$text,
          "text"=>"<b>Sizning hisobingizga admin tomonidan $summa uzs toʻldirildi!</b>",
"parse_mode"=>"html",
]);
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"✅ Foydalanuvchi balansi toʻldirildi!",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
unlink("adminpul.txt");
}
////////
$ss=file_get_contents("admin.txt");
if($text=="➖ Pul ayirish" and $cid==$admin){
file_put_contents("admin.txt","coin1");
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"Foydalanuvchi hisobidan qancha pul ayirmoqchisiz:",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($ss=="coin1" and $cid==$admin){
file_put_contents("adminpul.coin",$text);
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"Foydalanuvchi ID raqamini kiriting:",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
file_put_contents("admin.txt","pay1");
 }


if($ss=="pay1" and $cid==$admin){
$summa = file_get_contents("adminpul.coin");
$sum =  file_get_contents("pul/$text.pul");
$jami = $sum - $summa;
$okminus=file_put_contents("pul/$text.pul","$jami");
bot("sendMessage",[
   "chat_id"=>$text,
          "text"=>"Sizning hisobingizga admin tomonidan $summa uzs yechildi",
]);
}
if($okminus){
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"✅ Foydalanuvchi balansidan $summa UZS ayirildi!",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("admin.txt");
unlink("adminpul.txt");
}