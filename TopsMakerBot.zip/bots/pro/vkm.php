<?php
date_default_timezone_set("asia/Tashkent");
$token = 'API_TOKEN';
$admin = array("ADMIN_ID","ADMIN_ID");
$adminn = array("ADMIN_ID","ADMIN_ID");
$adminuser="ADMIN_USER";
include("admin.php");

function bot($method,$datas=[]){
global $token;
    $url = "https://api.telegram.org/bot".$token."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}


function put($joy,$matn){
$saqla=file_put_contents($joy, $matn);
return $saqla;
}

function mb($joy,$matn){
$sss = mb_stripos($joy,$matn);
return $sss;
}


function get($ccc){
$tek=file_put_contents($ccc);
return $tek;
}

function del($content){
unlink($content);
}
$servername = "localhost";
$username = "samvlogs04_salom_04";
$password = "salom_04";
$connect = new mysqli($servername, $username, $password, $username);

mysqli_query($connect,"CREATE TABLE `data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `doc_id` text NOT NULL,
  `size` varchar(15) NOT NULL,
  `type` varchar(10) NOT NULL,
  `top` int(20) NOT NULL,
  `creator` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
)");



mysqli_query($connect,"CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(30) NOT NULL,
  `reg` varchar(20) NOT NULL,
  `lang` int(11) NOT NULL,
  PRIMARY KEY (`id`)
)");






$update = json_decode(file_get_contents('php://input'));
//inline_uchun_methodlar
$data = $update->callback_query->data;
$cid2 = $update->callback_query->message->chat->id;
$mid2 = $update->callback_query->message->message_id;
$fid2 = $update->callback_query->message->from->id;
$call = $update->callback_query;
$qid = $call->id;
//oddiy_knopka_uchun_methodlar
$xabar = $update->message;
$xabar_id = $xabar->message_id;
$chat_id = $xabar->chat->id;
$cid = $xabar->chat->id;
$mid = $xabar->message_id;
$text = $xabar->text;
$doc = $xabar->audio;
$doc_id = $doc->file_id;
$doc_f = $doc->file_name;
$doc_s = $doc->file_size;
$doc_m = $doc->mime_type;
$fid = $xabar->from->id;
$fname = $xabar->from->first_name;
$fuser = $xabar->from->username;
$sana = date('d.m.Y');
$soat = date('H:i:s');
$call = $update->callback_query;
$qid = $call->id;
$type = $xabar->chat->type;
$k1 = json_encode([
'inline_keyboard'=>[
[["text"=>"❤️/💔","callback_data"=>"my"],["text"=>"�?","callback_data"=>"del"]],
]
]);

$ball = json_encode([

'inline_keyboard'=>[
[["text"=>"⭐️","callback_data"=>"01"]],
[["text"=>"⭐️⭐️","callback_data"=>"02"]],
[["text"=>"⭐️⭐️⭐️","callback_data"=>"03"]],
[["text"=>"⭐️⭐️⭐️⭐️","callback_data"=>"04"]],
[["text"=>"⭐️⭐️⭐️⭐️⭐️","callback_data"=>"05"]],
]
]);
$reklama = "Reklama: @By_konsbot";

if($text=="/speed"){
$start_time = round(microtime(true) * 1000);
      $send=  bot('sendmessage', [
                'chat_id' => $cid,
                'text' =>"Loading...",
            ])->result->message_id;

                    $end_time = round(microtime(true) * 1000);
                    $time_taken = $end_time - $start_time;
                    bot('editMessagetext',[
                        "chat_id" => $cid,
                        "message_id" => $send,
                        "text" => "Bot Tezligi: " . $time_taken .  "Ms",
]);
}


$lan = json_encode([
'inline_keyboard'=>[
[["text"=>"🇺🇿O`zbek tili","callback_data"=>"0"],["text"=>"🇷🇺Русский язык","callback_data"=>"1"]],
[["text"=>"�?","callback_data"=>"del"]],
]
]);

$txt = "<b>Sizga istalgan turdagi fayllarni izlashda yordamlashaman !

/top - Eng ko`p yuklab olingan fayllar.
/rand - Tasodifiy kodlar.
/last - Eng oxirgi qo`shilgan fayllar.
/add - Botga fayl yuklash buyicha yo`riqnoma.
/lang - Tilni o`zgartirish
/inline - Inline izlash</b>


🔎<i> Kerakli fayl nomini yozib yuboring...</i>

$reklama";


$txt2 = "<b>Я могу помочь вам найти файлы любого типа!

/top - Самые скачиваемые файлы.
/rand - Случайные коды.
/last - Последние добавленные файлы.
/add - Инструкция по загрузке файлов в бот.
/lang - Изменить язык
/inline - Inline поиск</b>


🔎<i> Введите имя файла ...</i>

$reklama";


$topilmadi = "Topilmadi 😔nIltimos siz yuborayotgan matndi aniqroq yozib yuboringnMisol uchun: Megabotnn$reklamannSiz ham o`z fayllaringizni yuklashingiz mumkinn👉 /add";

$topilmadi2 = "Не найдено 😔 n
Попробуй другое словоnПример: Megabotnn$reklamannТакже вы можете загружать свои собственные файлыn👉 /add";


if($text=="/start"  or $text=="/start@$bot" or $text=="/start php"){
$result = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid'");
$row = mysqli_fetch_assoc($result);
$lang = $row['lang'];
if($row){
if($lang=="0"){
bot('sendmessage',[
        'chat_id'=>$cid,
        'text'=>$txt,
        'parse_mode'=>'html',
        ]);
exit();
}elseif($lang=="1"){
bot('sendmessage',[
        'chat_id'=>$cid,
        'text'=>$txt2,
        'parse_mode'=>'html',
        ]);
exit();
}
}else{
mysqli_query($connect, "INSERT INTO users(`user_id`,`reg`) VALUES ('$cid','$sana--$soat')");
$result = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid'");
$row = mysqli_fetch_assoc($result);
$lang = $row['lang'];
if($lang=="0"){
bot('sendmessage',[
        'chat_id'=>$cid,
        'text'=>$txt,
        'parse_mode'=>'html',
        ]);
exit();
}elseif($lang=="1"){
bot('sendmessage',[
        'chat_id'=>$cid,
        'text'=>$txt2,
        'parse_mode'=>'html',
        ]);
exit();
}
}
}


if($text=="/add"  or $text=="/add@$bot"){
$result = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid'");
$row = mysqli_fetch_assoc($result);
$lang = $row['lang'];
if($lang=="0"){
bot('sendmessage',[
        'chat_id'=>$cid,
        'text'=>"<a href='https://admin2.zooo.uz/bot/SearchDoc_bot/photo/add.jpg'>&#8239;</a>Botga barcha foydalanuchilar fayl yuklashi mumkin !
Faylni yuklamoqchi bo`lsangi shunchaki botga faylni yuboring...

$reklama",
        'parse_mode'=>'html',
        ]);
exit();
}elseif($lang=="1"){
bot('sendmessage',[
        'chat_id'=>$cid,
        'text'=>"<a href='https://admin2.zooo.uz/bot/SearchDoc_bot/photo/add.jpg'>&#8239;</a>Все пользователи могут загружать файлы в бота!
Если вы хотите загрузить файл, просто отправьте файл на боту ...

$reklama",
        'parse_mode'=>'html',
        ]);
exit();
}
}









if($data=="my"){
$result = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid2'");
$row = mysqli_fetch_assoc($result);
$lang = $row['lang'];
if($lang=="0"){
bot ('answerCallbackQuery', [
'callback_query_id'=> $qid,
'text'=>"Tez kunda...
$reklama",
'show_alert'=>false,
]);
exit();
}elseif($lang=="1"){
bot ('answerCallbackQuery', [
'callback_query_id'=> $qid,
'text'=>"Скоро...",
'show_alert'=>false,
]);
exit();
}
}





$size = fsize($doc_s);
function fsize($size,$round=2)
{
$sizes=array(' Bytes',' Kb',' Mb',' Gb',' Tb');
$total=count($sizes)-1;
for($i=0;$size>1024 && $i<$total;$i++){
$size/=1024;
}
return round($size,$round).$sizes[$i];
}

if($doc and $type=="private"){
$result7 = mysqli_query($connect,"SELECT * FROM `users` WHERE `user_id` = '$cid'");
$row7 = mysqli_fetch_assoc($result7);
$lang = $row7['lang'];
$result = mysqli_query($connect,"SELECT * FROM `data` WHERE `name` = '$doc_f'");
$row = mysqli_fetch_assoc($result);
if($row){
if($lang=="0"){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"<b>Ushbu $doc_f fayl bazada mavjud
Iltimos boshqa fayl yuboring yoki fayl nomiga qo`shimchalar qo`shing !</b>

$reklama",
 'parse_mode'=>'html',
        ]);
exit();
}elseif($lang=="1"){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"<b>Этот файл $doc_f доступен в базе данных
Пожалуйста, отправьте другой файл или добавьте вложения к имени файла!</b>

$reklama",
 'parse_mode'=>'html',
        ]);
exit();
}
}else{
$a = mysqli_query($connect, "INSERT INTO data (`name`,`doc_id`,`size`,`creator`,`type`) VALUES ('$doc_f','$doc_id','$size','$fid','')");
$eror = mysqli_error($connect);
if($a){
$result7 = mysqli_query($connect,"SELECT * FROM `users` WHERE `user_id` = '$cid'");
$row7 = mysqli_fetch_assoc($result7);
$lang = $row7['lang'];
if($lang=="0"){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"✅Fayl yuklandi !
$doc_f-$size
$reklama",
 'parse_mode'=>'html',
        ]);
}elseif($lang=="1"){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"✅Фай�? загружен!
$doc_f- $size
",
 'parse_mode'=>'html',
        ]);
}
bot('senddocument',[
  'chat_id'=>$admin,
  'document'=>$doc_id,
  'caption'=>"✅Fayl yuklandi !
<code>$doc_f-$size</code>
===================
$fname
@$fuser
$fid

$soat--$sana",
  'parse_mode'=>'html',
        ]);
exit();
}else{
$result7 = mysqli_query($connect,"SELECT * FROM `users` WHERE `user_id` = '$fid'");
$row7 = mysqli_fetch_assoc($result7);
$lang = $row7['lang'];
if($lang=="0"){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"<b>Baza bilan aloqa yo`q</b>

Iltimos @$adminuser ga xabar bering !",
 'parse_mode'=>'html',
        ]);
exit();
}elseif($lang=="1"){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"<b>Нет подключения к базе данных </b>

Пожалуйста, сообщите @$adminuser",
 'parse_mode'=>'html',
        ]);
exit();
}
}
}
}

if($text=="/stat1"  or $text=="/st1at@$bot"){
$res = mysqli_query($connect, "SELECT * FROM `users`");
$stat = mysqli_num_rows($res);
$res2 = mysqli_query($connect, "SELECT * FROM `data`");
$stat2 = mysqli_num_rows($res2);
/*$res = mysqli_query($connect,"SELECT * FROM `data` ORDER BY RAND() LIMIT 1");
$a = mysqli_fetch_assoc($res);
$id = $a['doc_id'];*/
$result7 = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid'");
$row7 = mysqli_fetch_assoc($result7);
$lang = $row7['lang'];
if($lang=="0"){
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"📊<b>�? STATISTIKA
👥�? A`zolar: <code>$stat</code>
💾�? Yuklangan fayllar soni: <code>$stat2</code></b>

$reklama",
'parse_mode'=>'html',
]);
exit();
}elseif($lang=="1"){
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"📊<b>�? СТАТИСТИКА
👥�? Члены: <code>$stat</code>
💾�? Количество загруженных файлов: <code>$stat2</code> </b>

$reklama",
'parse_mode'=>'html',
]);
exit();
}
}

if($text=="/lang"  or $text=="/lang@$bot"){
$result7 = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid'");
$row7 = mysqli_fetch_assoc($result7);
$lang = $row7['lang'];
if($lang=="0"){
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"<b>Hozirgi til:</b> <i>🇺🇿O`zbek tili</i>

$reklama",
'parse_mode'=>'html',
'reply_markup'=>$lan,
]);
exit();
}elseif($lang=="1"){
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"<b>Текущий язык:</b> <i>🇷🇺Русский язык</i>

$reklama",
'parse_mode'=>'html',
'reply_markup'=>$lan,
]);
exit();
}
}


if($text=="/news"  or $text=="/news@$bot"){
$result7 = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid'");
$row7 = mysqli_fetch_assoc($result7);
$lang = $row7['lang'];
if($lang=="0"){
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"🇺🇿<b>Yangilanish:</b> [0.3]
1- Bot endilikda 2 ta tilda faoliyat olib borish imkoni mavjud (🇺🇿O`zbek tili & 🇷🇺Русский язык).
2- /last eng oxirgi qo`shilgan fayllar ro`yxati. (yangi bo`limni kutib oling bot bazasiga eng oxirgi qo`shilgan fayllar ro`yxatini chiqarib beradi).

13:26 (14.02.2021)

======================

🇺🇿<b>Yangilanish:</b> [0.2]
1- 🔍Id raqam orqali izlash ( Endilikda do`stingiz yoki ma`lum bir siz tanigan insonlarning botga yuklagan fayllarini ko`rish imkoni mavjud).

❗️Shunchaki Siz qidirayotgan odamni ID-raqamini botga yozib yuboring.
Misol uchun: $admik

20:29 (13.02.2021)


$reklama",
'parse_mode'=>'html',
]);
exit();
}elseif($lang=="1"){
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"🇷🇺<b>Обновления:</b> [0.3]
1- 1- Бот теперь доступен на 2 языках (🇺🇿Узбекский язык и 🇷🇺Русский язык).
2- /last Список недавно добавленных файлов.(Бот отобразит список последних добавленных файлов в базу).

13:26 (14.02.2021)

======================

🇷🇺<b>Обновления:</b> [0.2]
1- 🔍Поиск по номеру id (теперь вы можете увидеть файлы, загруженные в бот вашим другом или определенным знакомым).

❗️ Просто отправьте боту идентификационный номер человека, которого вы ищете.
Например: $admin

20:29 (13.02.2021)


$reklama",
'parse_mode'=>'html',
]);
exit();
}
}

if($data=="0" or $data=="1"){
mysqli_query($connect,"UPDATE users SET  lang = '$data' WHERE user_id = '$cid2'");
$str = str_replace(["0","1"],["<b>Hozirgi til:</b> <i>🇺🇿O`zbek tili</i>","<b>Текущий язык:</b> <i>🇷🇺Русский язык</i>"],$data);
bot('EditMessagetext',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
'text'=>"$str

$reklama",
'parse_mode'=>'html',
'reply_markup'=>$lan,
]);
exit();
}




if((mb_stripos($text,"/del=")!==false) and (in_array($cid,$admin))){
$e = explode("/del=",$text);
$e = $e[1];
$r = mysqli_query($connect,"DELETE FROM `data` WHERE `name` = '$e'");
if($r){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"🗑<b>O`chirildi</b>
$e",
 'parse_mode'=>'html',
        ]);
exit();
}else{
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"<b>Fayl topilmadi baza bilan aloqa yo`q</b>
$e",
 'parse_mode'=>'html',
        ]);
exit();
}
exit();
}

if($text=="/inline" or $text=="/inline@$bot"){
    bot ('sendmessage',[
        'chat_id'=>$cid,
        'text'=>"✌️👇👇✌️

        $reklama",
        'parse_mode'=>'html',
        'disable_web_page_preview'=>true,
        'reply_markup'=>json_encode(['inline_keyboard'=>[
        [["text"=>"🔅inline🔅","switch_inline_query"=>"php"],],
        ]
        ])
    ]);
exit();
}


if((mb_stripos($text,"/send=")!==false) and (in_array($cid,$admin))){
$e = explode("/send=",$text);
$e = $e[1];
$res = mysqli_query($connect,"SELECT * FROM `users` LIMIT 1000");
while($a = mysqli_fetch_assoc($res)){
$id = $a['user_id'];
bot('sendMessage',[
  'chat_id'=>$id,
  'text'=>$e,
 'parse_mode'=>'html',
        ]);
}
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"Yuborildi",
 'parse_mode'=>'html',
        ]);
exit();
}

if((mb_stripos($text,"/ovoz=")!==false) and (in_array($cid,$admin))){
$e = explode("/ovoz=",$text);
$e = $e[1];
//$res = mysqli_query($connect,"SELECT * FROM `users`");
//while($a = mysqli_fetch_assoc($res)){
//$id = $a['user_id'];
bot('sendMessage',[
  'chat_id'=>$e,
  'text'=>"✔️Botimizga baxo bering !

 🚀tezligi,
 ✅sifat darajasi,
 🔐kodlarning havfsizlik darajasi,
 💎tashqi ko`rinishini baxolashga o`z hissangizni qo`shasiz degan umiddamiz.",
 'parse_mode'=>'html',
 'reply_markup'=>$ball,
        ]);
//}
bot('sendMessage',[
  'chat_id'=>$admin,
  'text'=>"Yuborildi",
 'parse_mode'=>'html',
        ]);
exit();
}



if($data=="01" or $data=="02"  or $data=="03"  or $data=="04"  or $data=="05"){
$b = file_get_contents("ball.txt");
file_put_contents("ball.txt","$bn$data");
bot('SendMessage',[
'chat_id'=>$admin,
'text'=>"<b><a href='tg://user?id=$cid2'>$cid2</a> - Ovoz berdi. $data</b>",
'parse_mode'=>'html',
]);

bot('EditMessagetext',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
'text'=>"<i>Biz bilan ekanligingizdan xursandmiz🙂
Ovoz  berganingiz uchun raxmat !</i>",
'parse_mode'=>'html',
]);
exit();
}



if($text=="/top" or $text=="/top@$bot"){
$res = mysqli_query($connect,"SELECT * FROM `data`ORDER BY top DESC LIMIT 10");
while($a = mysqli_fetch_assoc($res)){
$vid = $a['doc_id'];
$f = $a['name'];
$size = $a['size'];
$id = $a['id'];
$k .= "$f-<i>$size</i>n";
$u .= "$idn";
}
$g = substr_count($k,"n");
$g = $g - 1;
for ($i=0; $i <=$g; $i++){
$ii = $i + 1;
$a = explode("n",$k);
$a1 = explode("n",$u);
$b .="$ii. $a[$i]n";
$b1 .="$a1[$i]n";
}

$b1 = "".$b1."del";

$knopka = explode("n",$b1);
$so = explode("n",$so);
$f = count($knopka);
for($s=0;$s<$f;$s++){
$ss = $s + 1;
if($s==10){
$ss = "�?";
}
$uz[]=["text"=>"$ss","callback_data"=>"data_$knopka[$s]"];
}
$key=array_chunk($uz, 5);

$keyboard=json_encode([
'inline_keyboard'=>$key,
]);

bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"<b>Top 10:</b>

$b

$reklama",
'reply_markup'=>$keyboard,
 'parse_mode'=>'html',
        ]);
exit();
}

if($text=="/last"  or $text=="/last@$bot"){
$result7 = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid'");
$row7 = mysqli_fetch_assoc($result7);
$lang = $row7['lang'];
$res = mysqli_query($connect,"SELECT * FROM `data`ORDER BY id DESC LIMIT 10");
while($a = mysqli_fetch_assoc($res)){
$vid = $a['doc_id'];
$f = $a['name'];
$size = $a['size'];
$id = $a['id'];
$k .= "$f-<i>$size</i>n";
$u .= "$idn";
}
$g = substr_count($k,"n");
$g = $g - 1;
for ($i=0; $i <=$g; $i++){
$ii = $i + 1;
$a = explode("n",$k);
$a1 = explode("n",$u);
$b .="$ii. $a[$i]n";
$b1 .="$a1[$i]n";
}

$b1 = "".$b1."del";

$knopka = explode("n",$b1);
$so = explode("n",$so);
$f = count($knopka);
for($s=0;$s<$f;$s++){
$ss = $s + 1;
if($s==10){
$ss = "�?";
}
$uz[]=["text"=>"$ss","callback_data"=>"data_$knopka[$s]"];
}
$key=array_chunk($uz, 5);

$keyboard=json_encode([
'inline_keyboard'=>$key,
]);
if($lang=="0"){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"<b>Eng Oxirgi fayllar:</b>

$b

$reklama",
'reply_markup'=>$keyboard,
 'parse_mode'=>'html',
        ]);
exit();
}elseif($lang=="1"){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"<b>Последние файлы:</b>

$b",
'reply_markup'=>$keyboard,
 'parse_mode'=>'html',
        ]);
exit();
}
}

if($text=="/rand" or $text=="/rand@$bot"){
$res = mysqli_query($connect,"SELECT * FROM `data` ORDER BY RAND() LIMIT 15");
while($a = mysqli_fetch_assoc($res)){
$vid = $a['doc_id'];
$f = $a['name'];
$size = $a['size'];
$id = $a['id'];
$k .= "$f-<i>$size</i>n";
$u .= "$idn";
}
$g = substr_count($k,"n");
$g = $g - 1;
for ($i=0; $i <=$g; $i++){
$ii = $i + 1;
$a = explode("n",$k);
$a1 = explode("n",$u);
$b .="$ii. $a[$i]n";
$b1 .="$a1[$i]n";
}

$b1 = "".$b1."del";

$knopka = explode("n",$b1);
$so = explode("n",$so);
$f = count($knopka);
for($s=0;$s<$f;$s++){
$ss = $s + 1;
if($s==15){
$ss = "�?";
}
$uz[]=["text"=>"$ss","callback_data"=>"data_$knopka[$s]"];
}
$key=array_chunk($uz, 5);

$keyboard=json_encode([
'inline_keyboard'=>$key,
]);

bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"<b>Rand 15:</b>

$b

$reklama",
'reply_markup'=>$keyboard,
 'parse_mode'=>'html',
        ]);
exit();
}



if($type=="supergroup" or $type=="group"){
if(mb_stripos($text,"/s ")!==false){
$p = explode("/s ",$text)[1];
$result7 = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid'");
$row7 = mysqli_fetch_assoc($result7);
$lang = $row7['lang'];
$son = mb_strlen($p);
if($son>1){
$res = mysqli_query($connect,"SELECT * FROM `data` WHERE `name`  LIKE '%$p%' OR `creator` LIKE '%$p%'");
if(mysqli_fetch_assoc($res)){
$stat = mysqli_num_rows($res);
$res = mysqli_query($connect,"SELECT * FROM `data` WHERE `name`  LIKE '%$p%' OR `creator` LIKE '%$p%' LIMIT 0,10");
while($a = mysqli_fetch_assoc($res)){
$vid = $a['doc_id'];
$f = $a['name'];
$size = $a['size'];
$id = $a['id'];
$k .= "$f-<i>$size</i>n";
$u .= "$idn";
}
$g = substr_count($k,"n");
$g = $g - 1;
for ($i=0; $i <=$g; $i++){
$ii = $i + 1;
$a = explode("n",$k);
$a1 = explode("n",$u);
$b .="$ii. $a[$i]n";
$b1 .="$a1[$i]n";
$so .= "$iin";
}
$r = substr_count($b,"n");

$so = "".$so."⬅️n❌n➡️n";
$b1 = "".$b1."back_0ndelngo_0_".$p."_1_".$stat."n";

$knopka = explode("n",$b1);
$so = explode("n",$so);
$f = count($knopka);
$f = $f - 1;
for($s=0;$s<$f;$s++){
$uz[]=["text"=>"$so[$s]","callback_data"=>"data_$knopka[$s]"];
}
$key=array_chunk($uz, 5);

$keyboard=json_encode([
'inline_keyboard'=>$key,
]);
if($lang=="0"){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"<b>Natijalar: 1-$r из $stat</b>

$b

$reklama",
'reply_markup'=>$keyboard,
 'parse_mode'=>'html',
        ]);
exit();
}elseif($lang=="1"){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"<b>Резултаты: 1-$r из $stat</b>

$b

$reklama",
'reply_markup'=>$keyboard,
 'parse_mode'=>'html',
        ]);
exit();
}
}else{
if($lang=="0"){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"Topilmadi 😔

  $reklama",
        ]);
}elseif($lang=="1"){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"Не найдено 😔

  $reklama",
        ]);
}
exit();
}
}else{
if($lang=="0"){
bot('sendmessage',[
  'chat_id'=>$cid,
  'text'=>"Matn kamida 2 ta belgidan iborat bo`lsin!",
 'parse_mode'=>'html',
        ]);
exit();
}elseif($lang=="1"){
bot('sendmessage',[
  'chat_id'=>$cid,
  'text'=>"Убедитесь, что текст содержит не менее 2 символов!",
 'parse_mode'=>'html',
        ]);
exit();
}
}
}
exit();
}
if($type=="private"){
if($text){
$p = $text;
$result7 = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid'");
$row7 = mysqli_fetch_assoc($result7);
$lang = $row7['lang'];
$son = mb_strlen($p);
if($son>1){
$res = mysqli_query($connect,"SELECT * FROM `data` WHERE `name`  LIKE '%$p%' OR `creator` LIKE '%$p%'");
if(mysqli_fetch_assoc($res)){
$stat = mysqli_num_rows($res);
$res = mysqli_query($connect,"SELECT * FROM `data` WHERE `name`  LIKE '%$p%' OR `creator` LIKE '%$p%' LIMIT 0,10");
while($a = mysqli_fetch_assoc($res)){
$vid = $a['doc_id'];
$f = $a['name'];
$size = $a['size'];
$id = $a['id'];
$k .= "$f-<i>$size</i>n";
$u .= "$idn";
}
$g = substr_count($k,"n");
$g = $g - 1;
for ($i=0; $i <=$g; $i++){
$ii = $i + 1;
$a = explode("n",$k);
$a1 = explode("n",$u);
$b .="$ii. $a[$i]n";
$b1 .="$a1[$i]n";
$so .= "$iin";
}
$r = substr_count($b,"n");

$so = "".$so."⬅️n❌n➡️n";
$b1 = "".$b1."back_0ndelngo_0_".$p."_1_".$stat."n";

$knopka = explode("n",$b1);
$so = explode("n",$so);
$f = count($knopka);
$f = $f - 1;
for($s=0;$s<$f;$s++){
$uz[]=["text"=>"$so[$s]","callback_data"=>"data_$knopka[$s]"];
}
$key=array_chunk($uz, 5);

$keyboard=json_encode([
'inline_keyboard'=>$key,
]);
if($lang=="0"){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"<b>Natijalar: 1-$r из $stat</b>

$b

$reklama",
'reply_markup'=>$keyboard,
 'parse_mode'=>'html',
        ]);
exit();
}elseif($lang=="1"){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"<b>Резултаты: 1-$r из $stat</b>

$b

$reklama",
'reply_markup'=>$keyboard,
 'parse_mode'=>'html',
        ]);
exit();
}
}else{

if($lang=="0"){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>$topilmadi,
        ]);
}elseif($lang=="1"){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>$topilmadi2,
        ]);
}
bot('sendMessage',[
  'chat_id'=>$admin,
  'text'=>"Topilmadi !
<i>$text</i>
===================
$fname
@$fuser
$fid",
  'parse_mode'=>'html',
        ]);
exit();
}
}else{
if($lang=="0"){
bot('sendmessage',[
  'chat_id'=>$cid,
  'text'=>"Matn kamida 2 ta belgidan iborat bo`lsin!

$reklama",
 'parse_mode'=>'html',
        ]);
exit();
}elseif($lang=="1"){
bot('sendmessage',[
  'chat_id'=>$cid,
  'text'=>"Убедитесь, что текст содержит не менее 2 символов!

  $reklama",
 'parse_mode'=>'html',
        ]);
exit();
}
}
}
exit();
}






if($data=="data_back_0"){
$result7 = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid2'");
$row7 = mysqli_fetch_assoc($result7);
$lang = $row7['lang'];
if($lang=="0"){
bot ('answerCallbackQuery', [
'callback_query_id'=> $qid,
'text'=>"Siz 1-sahifadasiz !
$reklama",
'show_alert'=>false,
]);
exit();
}elseif($lang=="1"){
bot ('answerCallbackQuery', [
'callback_query_id'=> $qid,
'text'=>"Вы на странице 1 !
$reklama",
'show_alert'=>false,
]);
exit();
}
}

if (mb_stripos($data,"data_go_")!==false){
$d = explode("_", $data);
$result7 = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid2'");
$row7 = mysqli_fetch_assoc($result7);
$lang = $row7['lang'];
$son = $d[2];
$son = explode("_",$son);
$son = $son[0];
$name = $d[3];
$name = explode("_",$name);
$name = $name[0];
$sn = $d[4];
$sn = explode("_",$sn);
$sn = $sn[0];
$stat = $d[5];
$stat = explode("_",$stat);
$stat = $stat[0];
$r = $d[6];

/////////////////
$son = $son + 10;
$sonn = $son - 10;
$sn = $sn + 1;
$snn = $sn - 1;
$res = mysqli_query($connect,"SELECT * FROM `data` WHERE `name`  LIKE '%$name%' OR `creator` LIKE '%$name%'");
if(mysqli_fetch_assoc($res)){
$res = mysqli_query($connect,"SELECT * FROM `data` WHERE name LIKE '%$name%' OR `creator` LIKE '%$name%' LIMIT $son,10");
while($a = mysqli_fetch_assoc($res)){
$vid = $a['doc_id'];
$f = $a['name'];
$size = $a['size'];
$id = $a['id'];
$k .= "$f-<i>$size</i>n";
$u .= "$idn";
}
$g = substr_count($k,"n");
$g = $g - 1;
for ($i=0; $i <=$g; $i++){
$ii = $i + 1;
$a = explode("n",$k);
$a1 = explode("n",$u);
$b .="$ii. $a[$i]n";
$b1 .="$a1[$i]n";
$so .= "$iin";
}
$r = substr_count($b,"n");
if(!$r=="0"){

$so = "".$so."⬅️n❌n➡️n";
$b1 = "".$b1."back_".$sonn."_".$name."_".$snn."_".$stat."ndelngo_".$son."_".$name."_".$sn."_".$stat."n";

$knopka = explode("n",$b1);
$so = explode("n",$so);
$f = count($knopka);
$f = $f - 1;
for($s=0;$s<$f;$s++){
$uz[]=["text"=>"$so[$s]","callback_data"=>"data_$knopka[$s]"];
}
$key=array_chunk($uz, 5);

$keyboard=json_encode([
'inline_keyboard'=>$key,
]);
if($lang=="0"){
bot('EditMessagetext',[
  'chat_id'=>$cid2,
  'message_id'=>$mid2,
  'text'=>"<b>Natijalar: $sn-$r из $stat</b>

$b

$reklama",
'reply_markup'=>$keyboard,
 'parse_mode'=>'html',
        ]);
exit();
}elseif($lang=="1"){
bot('EditMessagetext',[
  'chat_id'=>$cid2,
  'message_id'=>$mid2,
  'text'=>"<b>Результаты: $sn-$r из $stat</b>

$b

$reklama",
'reply_markup'=>$keyboard,
 'parse_mode'=>'html',
        ]);
exit();
}
}else{
if($lang=="0"){
bot ('answerCallbackQuery', [
'callback_query_id'=> $qid,
'text'=>"Siz oxirgi sahifadasiz !
$reklama",
'show_alert'=>false,
]);
exit();
}elseif($lang=="1"){
bot ('answerCallbackQuery', [
'callback_query_id'=> $qid,
'text'=>"Вы на последней странице!
$reklama",
'show_alert'=>false,
]);
exit();
}
}
}else{
if($lang=="0"){
bot('sendMessage',[
  'chat_id'=>$cid2,
  'text'=>"$topilmadi",
        ]);
exit();
}elseif($lang=="1"){
bot('sendMessage',[
  'chat_id'=>$cid2,
  'text'=>"$topilmadi2",
        ]);
exit();
}
}
exit();
}


if (mb_stripos($data,"data_back_")!==false){
$result7 = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid2'");
$row7 = mysqli_fetch_assoc($result7);
$lang = $row7['lang'];
$d = explode("_", $data);
if($d[4]==0){
if($lang=="0"){
bot ('answerCallbackQuery', [
'callback_query_id'=> $qid,
'text'=>"Siz 1-sahifadasiz !
$reklama",
'show_alert'=>false,
]);
exit();
}elseif($lang=="1"){
bot ('answerCallbackQuery', [
'callback_query_id'=> $qid,
'text'=>"Вы на странице 1 !
$reklama",
'show_alert'=>false,
]);
exit();
}
}
}

if (mb_stripos($data,"data_back_")!==false){
$d = explode("_", $data);
$son = $d[2];
$son = explode("_",$son);
$son = $son[0];
$name = $d[3];
$name = explode("_",$name);
$name = $name[0];
$sn = $d[4];
$sn = explode("_",$sn);
$sn = $sn[0];
$stat = $d[5];
$stat = explode("_",$stat);
$stat = $stat[0];
$r = $d[6];

$sonn = $son - 10;
$snn = $sn - 1;
$result7 = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid2'");
$row7 = mysqli_fetch_assoc($result7);
$lang = $row7['lang'];
$res = mysqli_query($connect,"SELECT * FROM `data` WHERE `name`  LIKE '%$name%' OR `creator` LIKE '%$name%'");
if(mysqli_fetch_assoc($res)){
$res = mysqli_query($connect,"SELECT * FROM `data` WHERE name LIKE '%$name%' OR `creator` LIKE '%$name%' LIMIT $son,10");
while($a = mysqli_fetch_assoc($res)){
$vid = $a['doc_id'];
$f = $a['name'];
$size = $a['size'];
$id = $a['id'];
$k .= "$f-<i>$size</i>n";
$u .= "$idn";
}
$g = substr_count($k,"n");
$g = $g - 1;
for ($i=0; $i <=$g; $i++){
$ii = $i + 1;
$a = explode("n",$k);
$a1 = explode("n",$u);
$b .="$ii. $a[$i]n";
$b1 .="$a1[$i]n";
$so .= "$iin";
}
$so = "".$so."⬅️n❌n➡️n";
$b1 = "".$b1."back_".$sonn."_".$name."_".$snn."_".$stat."ndelngo_".$son."_".$name."_".$sn."_".$stat."n";

$knopka = explode("n",$b1);
$so = explode("n",$so);
$f = count($knopka);
$f = $f - 1;
for($s=0;$s<$f;$s++){
$uz[]=["text"=>"$so[$s]","callback_data"=>"data_$knopka[$s]"];
}
$key=array_chunk($uz, 5);

$keyboard=json_encode([
'inline_keyboard'=>$key,
]);
$r = substr_count($b,"n");
if($lang=="0"){
bot('EditMessagetext',[
  'chat_id'=>$cid2,
  'message_id'=>$mid2,
  'text'=>"<b>Natijalar: $sn-$r из $stat</b>

$b

$reklama",
'reply_markup'=>$keyboard,
 'parse_mode'=>'html',
        ]);
exit();
}elseif($lang=="1"){
bot('EditMessagetext',[
  'chat_id'=>$cid2,
  'message_id'=>$mid2,
  'text'=>"<b>Результаты: $sn-$r из $stat</b>

$b

$reklama",
'reply_markup'=>$keyboard,
 'parse_mode'=>'html',
        ]);
exit();
}
}else{
if($lang=="0"){
bot('sendMessage',[
  'chat_id'=>$cid2,
  'text'=>"$topilmadi !",
        ]);
exit();
}elseif($lang=="1"){
bot('sendMessage',[
  'chat_id'=>$cid2,
  'text'=>"$topilmadi2 !",
        ]);
exit();
}
}
}


if($data=="data_del" or $data=="del"){
bot('Deletemessage',[
  'chat_id'=>$cid2,
'message_id'=>$mid2
        ]);
exit();
}

if (mb_stripos($data,"data")!==false){
$d = explode("_", $data);
$dgh = $d[1];
$dh = explode("_",$dgh);
$d1 = $dh[0];
$sql = "SELECT * FROM `data` WHERE id = '$d1'";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_assoc($result);
$id = $row["doc_id"];
$f = $row["name"];
$t = $row["top"];
$c = $row["creator"];
$t = $t + 1;
mysqli_query($connect,"UPDATE data SET  top = '$t' WHERE id = '$d1'");

$result7 = mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid2'");
$row7 = mysqli_fetch_assoc($result7);
$lang = $row7['lang'];
$get= bot ('getChat', [
'chat_id'=>$c,
]);
$g = $get->result->first_name;
if($lang=="0"){
bot('senddocument',[
  'chat_id'=>$cid2,
'document'=>"$id",
  'caption'=>"<i>$f</i>

Faylni yuklagan: <a href='tg://user?id=$c'>$c</a>

$reklama

@$bot",
 'parse_mode'=>'html',
'reply_markup'=>$k1,
        ]);
exit();
}elseif($lang=="1"){
bot('senddocument',[
  'chat_id'=>$cid2,
'document'=>"$id",
  'caption'=>"<i>$f</i>

Загрузил: <a href='tg://user?id=$c'>$c</a>

@$bot",
 'parse_mode'=>'html',
'reply_markup'=>$k1,
        ]);
exit();
}
}

/////////////////////////////////////////



$inline = $update->inline_query;
$inline_query = $update->inline_query->query;
if($inline){
    if($inline_query=="/rand"){
    $res = mysqli_query($connect,"SELECT * FROM `data` ORDER BY RAND() LIMIT 40");
    }elseif($inline_query=="/top"){
    $res = mysqli_query($connect,"SELECT * FROM `data`ORDER BY top DESC LIMIT 40");
    }else{
    $sql = "SELECT * FROM `data` WHERE name LIKE '%$inline_query%' OR `creator` LIKE '%$inline_query%' LIMIT 50";
    $res = mysqli_query($connect,$sql);
}
    while($a = mysqli_fetch_assoc($res)){
        $u = $a['id'];
        $c = $a['creator'];
        $size = $a['size'];
        $vid = $a['doc_id'];
        $t = $a["top"];
        $f = $a['name'];
        if($c){
        $uz [] = ["type"=>"document","id"=>$u,"title"=>"$f",'document_file_id'=>"$vid","description"=>"🆔$c-📥$t-$size",'caption'=>"<i>$f-$size</i>nnFaylni yuklagan: <a href='tg://user?id=$c'>$c</a>nn$reklamann@$bot",'parse_mode'=>'html'];
        }else{
         $uz [] = ["type"=>"document","id"=>$u,"title"=>"$f",'document_file_id'=>"$vid","description"=>"📥$t-$size",'caption'=>"<i>$f-$size</i>nn$reklamann@$bot",'parse_mode'=>'html'];
        }
    }
    $key = json_encode($uz);
    bot("answerInlineQuery",[
    "inline_query_id"=>$update->inline_query->id,
    "cache_time"=>1,
    "results"=>$key,
    'switch_pm_text'=>"Botga o`tish->",
    'switch_pm_parameter'=>"php",
    ]);
$t = $t + 1;
mysqli_query($connect,"UPDATE data SET  top = '$t' WHERE id = '$u'");
}
$panel = json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
        [['text'=>"↗️ Xabar yuborish"]],
        [['text'=>"/start"]],
           ]
           ]);
        
        if(($tx == "/panel") and $cid == $admin){
    bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid]);
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"<b>👨‍💻Admin panelga xush kelibsiz.</b>",
    'parse_mode'=>"html",
    'reply_markup'=>$panel,
]);
}
$xabar = file_get_contents("send.txt");
if($text == "↗️ Xabar yuborish"){
if($cid == $admin){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"*Userlarga yuboriladigan xabar matnini kiriting! Bekor qilish uchun /cancel ni bosing.*",
'parse_mode'=>"markdown",
'reply_markup'=>$back4_menu,
]); file_put_contents("send.txt","user");
}else{
bot("sendmessage",[
'chat_id'=>$cid,
'text'=> "*🤪😂 Bu funksiyani Faqat men $adminuser ishlata olaman.*",
'parse_mode'=>'Markdown',
]);
}
}
if($xabar=="user" and $cid==$admin){
if($text=="/cancel"){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Bekor qilindi!",
'parse_mode'=>"html",
]); unlink("send.txt");
}else{
$lich = file_get_contents("shekih.db");
$lichka = explode("n",$lich);
foreach($lichka as $lichkalar){
$okuser=bot("sendmessage",[
'chat_id'=>$lichkalar,
'text'=>$text,
'parse_mode'=>'HTML'
]);
}
}
}
if($okuser){
bot("sendmessage",[
'chat_id'=>$admin,
'text'=>"<b>Hamma userlarga yuborildi</b>✅",
'parse_mode'=>'html',
'reply_markup'=>$panel,
]); unlink("send.txt");
}