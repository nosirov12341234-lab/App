<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

define('API_KEY','API_TOKEN'); 
$admin = "ADMIN_ID";
$botname = bot('getme',['bot'])->result->username;
$userR = "ADMIN_USER"; 
$bot="@$botname";
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}   

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$cid = $message->chat->id;
$uid = $message->from->id;
$cidtyp = $message->chat->type;
$miid = $message->message_id;
$name = $message->chat->first_name;
$user1 = $message->from->username;
$text = $message->text;
$tx = $message->text;
$callback = $update->callback_query;
$mmid = $callback->inline_message_id;
$mes = $callback->message;
$mid = $mes->message_id;
$cmtx = $mes->text;
$mmid = $callback->inline_message_id;
$idd = $callback->message->chat->id;
$cbid = $callback->from->id;
$cbuser = $callback->from->username;
$data = $callback->data;
$ida = $callback->id;
$cqid = $update->callback_query->id;
$cbins = $callback->chat_instance;
$cbchtyp = $callback->message->chat->type;
$step = file_get_contents("step/$cid.step");
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$mid = $message->message_id;
$msgs = json_decode(file_get_contents('msgs.json'),true);
$data = $update->callback_query->data;
$type = $message->chat->type;
$text = $message->text;
$cid = $message->chat->id;
$uid= $message->from->id;
$gname = $message->chat->title;
$left = $message->left_chat_member;
$new = $message->new_chat_member;
$name = $message->from->first_name;
$replytx = $message->reply_to_message->text;
$reply = $message->reply_to_message->text;
$bio = $messenge->from->about;
$repid = $message->reply_to_message->from->id;
$repname = $message->reply_to_message->from->first_name;
$newid = $message->new_chat_member->id;
$leftid = $message->left_chat_member->id;
$newname = $message->new_chat_member->first_name;
$leftname = $message->left_chat_member->first_name;
$username = $message->from->username;
$cmid = $update->callback_query->message->message_id;
$cusername = $message->chat->username;
$repmid = $message->reply_to_message->message_id; 
$ccid = $update->callback_query->message->chat->id;
$cuid = $update->callback_query->message->from->id;
$photo = $message->photo;
$gif = $message->animation;
$video = $message->video;
$music = $message->audio;
$voice = $message->voice;
$sticker = $message->sticker;
$document = $message->document;
$fayl = $message->fayl;
$for = $message->forward_from;
$forc = $message->forward_from_chat;
$user_id = $update->message->from->id;
$ufname = $update->message->from->first_name;
$chat_id = $message->chat->id;
$blocklar = file_get_contents("block.dat");

$harf = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"A❤️🔐"],['text'=>"B❤️🔐"],['text'=>"D❤️🔐"],['text'=>"E❤️🔐"]],
[['text'=>"F❤️🔐"],['text'=>"G❤️🔐"],['text'=>"H❤️🔐"],['text'=>"I❤️🔐"]],
[['text'=>"J❤️🔐"],['text'=>"K❤️🔐"],['text'=>"L❤️🔐"],['text'=>"M❤️🔐"]],
[['text'=>"N❤️🔐"],['text'=>"O❤️🔐"],['text'=>"P❤️🔐"],['text'=>"Q❤️🔐"]],
[['text'=>"R❤️🔐"],['text'=>"S❤️🔐"],['text'=>"T❤️🔐"],['text'=>"U❤️🔐"]],
[['text'=>"V❤️🔐"],['text'=>"X❤️🔐"],['text'=>"Y❤️🔐"],['text'=>"Z❤️🔐"]],
[['text'=>"Oʻ❤️🔐"],['text'=>"Gʻ❤️🔐"],['text'=>"Sh❤️🔐"],['text'=>"Ch❤️🔐"]],
]
]);

if(mb_stripos($text,"/start")!==false){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>" 👋Salom <a href='tg:user?id=$cid'>$name</a>

$bot ga Hush Kelibsiz ☺️

Ismingizni Bosh harfiga Video Yasabb olishingiz mumkin!

Video Tayyorlash uchun Knopkalardan birini tanlang

Botda muammo Sezsangiz @$adminuser ga murojaat qiling!",
'parse_mode'=>'html',
'reply_markup'=>$harf,
]);
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"Diqqat  botda $lich A'zo!
🤖Botga hozir /start bosdi!
<b>🔔 Usernamesi:</b> $user1
<b>🆔️ Raqami:</b> <code>$cid</code>
👮‍♂️ Profiliga kirish:⤵️
<a href = 'tg://user?id=$cid'>$cid</a>

Bot $bot",
'parse_mode'=>'html',
]);
}
if($tx=="A❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/5",
        'caption'=>"tayyorladi $bot",
        'reply_markup'=>$harf,
    ]); 
    }
if($tx=="B❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/6",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
if($tx=="D❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/7",
        'caption'=>"tayyorladi $bot
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
if($tx=="E❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/8",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
if($tx=="F❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/9",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
if($tx=="G❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/10",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }   
if($tx=="H❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/11",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
if($tx=="I❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/12",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }    
if($tx=="J❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/13",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
if($tx=="K❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/14",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
if($tx=="L❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/15",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
  if($tx=="M❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/16",
        'caption'=>"tayyorladi $bot
        
        $caption", 
        'reply_markup'=>$harf,
    ]); 
    }
 if($tx=="N❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/17",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }   
if($tx=="O❤️🔐"){
      bot('sendVideo',[ 
        'chat_id'=>$cid,
'video'=>"https://t.me/kerakli_ovozlar/18",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
   if($tx=="P❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/19",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    } 
 if($tx=="Q❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/37",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }   
 


if($tx=="R❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/20",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
if($tx=="S❤️🔐"){
      bot('sendVideo',[ 
        'chat_id'=>$cid,
'video'=>"https://t.me/Omonboyevshahzod/79",

        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
if($tx=="T❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/22",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
if($tx=="U❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/23",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
if($tx=="V❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/24",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }

if($tx=="X❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/38",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
if($tx=="Y❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/25",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
  if($tx=="Z❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/Omonboyevshahzod/77",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }  
    
if($tx=="Oʻ❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
'video'=>"https://t.me/Omonboyevshahzod/81",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
    
    if($tx=="Gʻ❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/29",
        'caption'=>"tayyorladi $bot 
 
$caption", 
        'reply_markup'=>$harf,
    ]); 
    }
    
    
   if($tx=="Ch❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/kerakli_ovozlar/33",
        'caption'=>"tayyorladi $bot 
$caption", 
        'reply_markup'=>$harf,
]);
    }

   

if($tx=="Sh❤️🔐"){ 
      bot('sendVideo',[ 
        'chat_id'=>$cid,
        'video'=>"https://t.me/Omonboyevshahzod/76",
        'caption'=>"tayyorladi $bot 
$caption", 
        'reply_markup'=>$harf,
]);
}
