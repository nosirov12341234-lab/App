<?php

ob_start();
define('API_KEY','API_TOKEN'); //token uchun joy

if(true){
error_reporting(E_ALL & ~(E_NOTICE | E_USER_NOTICE | E_DEPRECATED));
ini_set('display_errors', 1);
}
function del($nomi){
   array_map('unlink', glob("$nomi"));
   }
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
$yangilash = json_decode(file_get_contents('php://input'));
$uzkmm = $yangilash->message;
$cid = $uzkmm->chat->id;
$text= $uzkmm->text;
$Muhiddin= $uzkmm->text;
$data = $yangilash->callback_query->data;
$mmid = $yangilash->callback_query->message->message_id;
$ccid = $yangilash->callback_query->message->chat->id;

//Mualliflik huquqi mavjud!

$name=$uzkmm->from->first_name;
$data = $yangilash->callback_query->data;
$cqid = $yangilash->callback_query->id;
$id=$uzkmm->from->id;
$familiya=$uzkmm->from->last_name;
$cbid = $yangilash->callback_query->from->id;
$cname = $yangilash->callback_query->message->from->first_name;
$cuid = $yangilash->callback_query->message->from->id;
$sreplyd = $uzkmm->reply_to_message->document;
$edname = $editm ->from->first_name;
$uzkmm = $yangilash->message;
$mesid = $uzkmm->message_id;
$mid = $uzkmm->message_id;
$chat_id = $uzkmm->chat->id;
$forward = $yangilash->message->forward_from;
$editm = $yangilash->edited_message;
$fadmin = $uzkmm->from->id;
$tx = $uzkmm->text;
$mesid = $uzkmm->message_id;
$mid = $uzkmm->message_id;
$name = $uzkmm->from->first_name;
$user1 = $uzkmm->from->username;
$id = $uzkmm->reply_to_message->from->id;   
$repmid = $uzkmm->reply_to_message->message_id; 
$repname = $uzkmm->reply_to_message->from->first_name;
$repulogin = $uzkmm->reply_to_message->from->username;
$reply = $uzkmm->reply_to_message;
$sreply = $uzkmm->reply_to_message->text;
$edname = $editm ->from->first_name;
$forward2 = $yangilash->message->forward_from;
$editm = $yangilash->edited_message;
mkdir("data");
mkdir("data/$fadmin");
$uid = $uzkmm->from->id;
$reply = $uzkmm->reply_to_message->text;
$replymenu = json_encode([
            'resize_keyboard'=>false,
            'force_reply'=>true,
            'selective'=>true
        ]);
 $inline = $yangilash->callback_query->data;
$cid2 = $yangilash->callback_query->message->chat->id; 
$reply = $uzkmm->reply_to_message->text;  

$rpl = json_encode([
    'resize_keyboard'=>false,
    'force_reply'=>true,
    'selective'=>true
     ]);

mkdir("matn");
$nazad="💫Orqaga";
$admin = "ADMIN_ID"; // admin id Raqami
$boot=bot('getme',['bot'])->result->username;
$mkm="🥀Bot: @$boot";
$CM="ADMIN_USER";
$timeusa = date("H:i",strtotime("-6 hour")); 
$timerus=date("H:i",strtotime("1 hour"));
$timebra=date("H:i",strtotime("-5 hour"));
$timepor=date("H:i",strtotime("-1 hour"));
$timedub=date("H:i",strtotime("2 hour"));
$timearb=date("H:i",strtotime("0 hour"));
$timeisp=date("H:i",strtotime("0 hour"));
$timeger=date("H:i",strtotime("0 hour"));
$timeqir=date("H:i",strtotime("4 hour"));
$timeyap=date("H:i",strtotime("+7 hour"));
$okun=date("n");
$oynoms = "1Yanvar1 2Fevral2 3Mart3 4Aprel4 5May5 6Iyun6 7Iyul7 8Avgust8 9Sentabr9 10Oktabr10 11Noyabr11 12Dekabr12";
$ex2 = explode("$okun",$oynoms);
$oy = "$ex2[1]";
$kun = date("d",strtotime("hour"));
$kunlar = date("d.m",strtotime(" hour"));
$soat = date("H:i:s",strtotime("hour"));
$yil = date('Y',strtotime(' hour'));
$sana="📆Hozir: $yil-Yil, $kun-$oy, $soat";




$cid = $uzkmm->chat->id;
$udar = $uzkmm->text;
$uid = $uzkmm->from->id;
$reply = $uzkmm->reply_to_message->text;
$adminMuhiddin = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"📛Blok Qilish📛"],['text'=>"📛Blokdan olish✅"]],
[['text'=>"📧Xabar Jo'natish"]],
[['text'=>"📊Statistika"],['text'=>" "]],
[['text'=>"💫Ortga"]]]
]);

$bowmenu = json_encode([
	'inline_keyboard'=>[
	[['text'=>"🕌Namoz Vaqtlari",'callback_data'=>"namozV"],['text'=>"🕋Quron Haqida🕋",'callback_data'=>"quron"]],
[['text'=>"💰Valyutalar💰",'callback_data'=>"valyuta"],['text'=>"🗞Yangiliklar🗞",'callback_data'=>"yangiliklar"]],
[['text'=>"❄️YaNGi YiL❄️",'callback_data'=>"newyear"],],
[['text'=>"☪️Ramazon☪️",'callback_data'=>"ramazon"],['text'=>"🤲Ro'za duosi🤲",'callback_data'=>"rozaduo"]],
[['text'=>"⛅Ob-Havo⛅",'callback_data'=>"pogoda"],['text'=>"🖍️Nik Yasash🖍️",'callback_data'=>"nikyasaw"]],
[['text'=>"🔍Rasm Izlash🔎",'callback_data'=>"rasmqidiruv"],['text'=>"🔵QR Kod🔵",'callback_data'=>"qrkod"]],
[['text'=>"🌉Telegram Fon🌉",'callback_data'=>"fonga"],['text'=>"🎌Telegram tillari🎌",'callback_data'=>"tgtil"]],
[['text'=>"⏰Davlatlar Soati⏰",'callback_data'=>"davlatsoat"],['text'=>"✈Tezlik✈",'callback_data'=>"tezligini"]],
[['text'=>"📚Ismlar Ma'nosi",'callback_data'=>"isming"],['text'=>"🔄Yangilash🔄",'callback_data'=>"restart"]],
[['text'=>"☎️Bog'lanish☎️",'callback_data'=>"xabarmuhiddin"],['text'=>"🤓Matematika🔢",'callback_data'=>"matem"]],
[['text'=>"🔂Teskari So'z",'callback_data'=>"tessoz"],['text'=>"👨‍💻Admin👨‍💻",'callback_data'=>"bratan"]],
]
	]);
	$qayt=json_encode([
'inline_keyboard'=>[
[['text'=>"$nazad",'callback_data'=>"ort"]],
]
]);
$backs=json_encode([
'inline_keyboard'=>[
[['text'=>"$nazad",'callback_data'=>"ortinga"]],
]
]);
$covidort=json_encode([
'inline_keyboard'=>[
[['text'=>"$nazad",'callback_data'=>"karort"]],
]
]);
$karonakey=json_encode([
'inline_keyboard'=>[
[['text'=>"🌍Dunyo Covid",'callback_data'=>"DunyoCovid"],
['text'=>"🇺🇿O'zb Covid",'callback_data'=>"UzbCovid"]],
[['text'=>"🌐Davlatlar Covid",'callback_data'=>"davlatlarCovid"]],
[['text'=>"⏪Orqaga",'callback_data'=>"inline"]],
]
]);

if($data=="ortinga"){
bot('deleteMessage',[
'chat_id'=>$ccid,
'message_id'=>$mmid,
]);
bot('sendMessage',[
'chat_id'=>$ccid,
'text'=>"⤵️Marhamat Kerakli Menyuni Tanlang!",
'reply_markup'=>$bowmenu, 
]);
}

 
if($data=="ort"){
bot('editMessageText',[
'chat_id'=>$ccid,
'message_id'=>$mmid,
'text'=>"⤵️O'zingizga kerakli menyuni Tanlang!",
'parse_mode'=>'html',
	'reply_markup'=>$bowmenu,
]);
	}

if($data=="karort"){
bot('editMessageText',[
'chat_id'=>$ccid,
'message_id'=>$mmid,
'text'=>"⤵️O'zingizga kerakli menyuni Tanlang!",
'parse_mode'=>'html',
	'reply_markup'=>$karonakey,
]);
	}


if($data=="inline"){
	bot('editMessageText',[
	'chat_id'=>$ccid,
	'message_id'=>$mmid,
	'text'=>"⤵️O'zingizga kerakli bo'limni tanlang!",
	'parse_mode'=>'html',
	'reply_markup'=>$bowmenu,
]);
	}

if($text=="💫Ortga"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"♏[$name](tg://user?id=$id) , Bosh Menuga Qaytdingiz!",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'remove_keyboard'=>true,
]), 
]);
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"⤵️O'zingizga kerakli bo'limni tanlang!",
'parse_mode'=>'markdown',
'reply_markup'=>$bowmenu, 
]);
}


if(mb_stripos($tx,"/start")!==false){

   $baza=file_get_contents("azo.dat");
   if(mb_stripos($baza,$chat_id) !==false){
   }else{
   $txt="\n$chat_id";
   $file=fopen("azo.dat","a");
   fwrite($file,$txt);
   fclose($file);
   }
}
if(mb_stripos($tx,"📊Statistika")!==false){
      $baza=file_get_contents("azo.dat");
      $all=substr_count($baza,"\n");
      $gr=substr_count($baza,"-");
      $us=$all-$gr;
      $txx = "<i>🚀Jami foydalanuvchilari: $all nafar
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖
👤 - Botdan Foydalanuvchilar $us nafar 
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖
👥 - Guruhlar $gr nafar </i>
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖
📅$sana  
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖
$mkm";
  bot('sendmessage',[
   'chat_id'=>$chat_id,
   'parse_mode'=>'html',
'reply_to_message_id'=> $mid, 
   'text'=>$txx,
  ]);
}

if(isset($uzkmm->new_chat_member) or isset($message->left_chat_member)){
 bot('deleteMessage',[
  'chat_id'=>$chat_id,
  'message_id'=>$mid,
    ]);
}


if($tx == "/panel" || $tx == "/Panel"){
     bot('sendMessage',[
     'chat_id'=>$admin,
     'text'=>"
😘 Assalomu alaykum
$CM Aka | Panel | ga
Xush kelibsiz!
Men sizni sevaman❤️
◾Marxamat Pastdagi Menyulardan
♏O'zingizga Kerakligini Bosing",
     'reply_markup'=> $adminMuhiddin,
     ]);
}
$tex = $uzkmm->text;
$lichka = file_get_contents("azo.dat");
$xabar = file_get_contents("send.txt");


if($tex=="📧Xabar Jo'natish" and $cid==$admin){
  bot('sendmessage',[
    'chat_id'=>$admin,
    'text'=>"Yuboriladigan xabar matnini kiriting!",
    'parse_mode'=>"html",
]);
    file_put_contents("send.txt","user");
}
if($xabar=="user" and $cid==$admin){
if($text=="/bekorqilish"){
  file_put_contents("send.txt","");
}else{
  $lich = file_get_contents("azo.dat");
  $lichka = explode("\n",$lich);
  foreach($lichka as $lichkalar){
  $okuser=bot("forwardMessage",[
  'from_chat_id'=>$admin,
    'chat_id'=>$lichkalar,
    'message_id'=>$mid,
]);
}
if($okuser){
  bot("sendmessage",[
    'chat_id'=>$admin,
    'text'=>"✔️Hamma userlarga bexato yuborildi!",
    'parse_mode'=>'html',
]);
  file_put_contents("send.txt","");
}
}
}

$replymenu = json_encode([
            'resize_keyboard'=>false,
            'force_reply'=>true,
            'selective'=>true
        ]);
    

$reply = $uzkmm->reply_to_message->text;  
$rpl = json_encode([
            'resize_keyboard'=>false,
            'force_reply'=>true,
            'selective'=>true
        ]);


if($text == "/start"){
bot('sendMessage', [
'chat_id'=>$cid,
'text'=>"🖐Assalomu alaykum  botimizga xush kelibsiz.

⚡Botimizda ko'plab foydali funksiyalar mavjud va undan foydalaning!

❄️Ko'proq ma'lumot olish uchun botni ishlatishda davom eting.

📛Agar botimizga juda ko'p buyruq bersangiz, botimizda 🚫bloklanishingiz mumkin!

✔️O'zingizga kerakli menyuni tanlang!


♏Admin: @$adminuser",
    'parse_mode'=>'html',
'reply_to_message_id'=> $mid, 
 'reply_markup'=>$bowmenu,
	]);
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"⚠️Diqqat <a href = 'tg://user?id=$cid'>$name</a> Botga🤖 /start Bosdi!
<b>✍ Usernamesi:</b> @$userini
<b>🆔️ Raqami:</b> <code>$cid</code>",
'parse_mode'=>'html',
]);
}



if($data=="valyuta"){
function kurs(){
       $response = "";
       $xml = file_get_contents("http://cbu.uz/uzc/arkhiv-kursov-valyut/xml/");
       $m = new SimpleXMLElement($xml);
       foreach ($m as $val) {
           if($val->Ccy == 'USD'){
               $response .= "♻️💰1 Aqsh Dollari - " . $val->Rate . "so'm\n";
           }
           if($val->Ccy == 'EUR'){
               $response .= "♻️💰1 Evro - " . $val->Rate . "so'm\n";
           }
           if($val->Ccy == 'RUB'){
               $response .= "♻️💰1 Rossiya Rubli - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'AED'){
               $response .= "♻️💰1 Arab Dirhami - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'AUD'){
               $response .= "♻️💰1 Avstraliya Dollari - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'BRL'){
               $response .= "♻️💰1 Braziliya Reali - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'CAD'){
               $response .= "♻️💰1 Kanada Dollari - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'JPY'){
               $response .= "♻️💰1 Yaponiya Iyenasi - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'AED'){
               $response .= "♻️💰1 BAA dirhami - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'KRW'){
               $response .= "♻️💰1 Korea voni - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'AZN'){
               $response .= "♻️💰1 Manat - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'ZAR'){
               $response .= "♻️💰1 Jan.Afrika Randi - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'CHF'){
               $response .= "♻️💰1 Franki - " . $val->Rate . "so'm\n";
           }
           if($val->Ccy == 'YER'){
               $response .= "♻️💰1 Yaman Riali - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'VND'){
               $response .= "♻️💰1 Vetnam Songi - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'VES'){
               $response .= "♻️💰1 Venesuela Bolivari - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'UAH'){
               $response .= "♻️💰1 Ukraina Hrivnasi - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'UYU'){
               $response .= "♻️💰1 Urugvay Pesosi - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'TRY'){
               $response .= "♻️💰1 Turkiya Lirasi - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'ARS'){
               $response .= "♻️💰1 Argentina pessosi - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'BDT'){
               $response .= "♻️💰1 Bangladesh takasi - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'BYN'){
               $response .= "♻️💰1 Belorus rubli - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'TJS'){
               $response .= "♻️💰1 Tojik somonisi - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'KGS'){
               $response .= "♻️💰1 Qirg‘iz so'mi - " . $val->Rate . " so'm\n";
           }
           if($val->Ccy == 'TND'){
               $response .= "♻️💰1 Tunis Dinori - " . $val->Rate . " so'm\n";
           }
       }
      return $response;
   }   function Parse($p1, $p2, $p3) {
$num1 = strpos($p1, $p2);
if($num1 === false) return 0;
$num2 = substr($p1, $num1);
return strip_tags(substr($num2, 0, strpos($num2, $p3)));
}
bot('EditMessageText',[
'chat_id'=>$ccid,
'message_id'=>$mmid,
'text'=>kurs(),"💱💱💱💱💱💱💱💱💱💱💱💱💱💱💱

🔄So'nggi Yangilanishlar: $kunlar.$yil

📆$sana

$mkm",
'reply_markup'=>$qayt,
]);
}


if($data=="karona"){
bot('editMessageText',[
   'chat_id'=>$ccid,
'message_id'=>$mmid,
'text'=>"👇Marxamat Kerakli 🦠*Statistika*ni Tanlang!",
'parse_mode'=>'markdown',
  'reply_markup'=>$karonakey,
]);
}

if($data=="pogoda"){
bot('editMessageText',[
'chat_id'=>$ccid,
'message_id'=>$mmid,
'text'=>"⛅Siz Ob-Havo bolimidasiz!
Iltimos Viloyatingizni tanlang!⤵️",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'⛅Namangan','callback_data'=>"ob=namangan"],
['text'=>'⛅Toshkent','callback_data'=>"ob=tashkent"]],
[['text'=>"⛅Farg'ona",'callback_data'=>"ob=ferghana"],
['text'=>'⛅Samarqand','callback_data'=>"ob=samarkand"]],
[['text'=>'⛅Buxoro','callback_data'=>"ob=bukhara"], 
['text'=>'⛅Jizzax','callback_data'=>"ob=jizzakh"]],
[['text'=>'⛅Andijon','callback_data'=>"ob=andijan"],
['text'=>'⛅Nukus','callback_data'=>"ob=nukus"]],
[['text'=>'⛅Guliston','callback_data'=>"ob=gulistan"],
['text'=>'⛅Navoiy','callback_data'=>"ob=navoi"]],
[['text'=>'⛅Xiva','callback_data'=>"ob=khiva"],
['text'=>'⛅Termiz','callback_data'=>"ob=termez"]],
[['text'=>'⛅Qarshi','callback_data'=>"ob=karshi"],
['text'=>'⛅Urganch','callback_data'=>"ob=urgench"]],
[['text'=>'⛅Zarafshon','callback_data'=>"ob=zarafshan"],
['text'=>'↩Ortga','callback_data'=>"inline"]],
]
])
]);
}

if(mb_stripos($data,"ob")!==false){
$szs = explode("=",$data);
$arrContextOptions=array(
    "ssl"=>array(
        "verify_peer"=>false,
        "verify_peer_name"=>false,
    ),
);
$masterbek = file_get_contents("http://obhavo.uz/$szs[1]", false, stream_context_create($arrContextOptions));
$ex1=explode("\n",$masterbek);
$kungr=str_replace('<p class="forecast">',' ',$ex1[98]);
$kungr=str_replace('</p>',' ',$kungr);
$oqgr=str_replace('<p class="forecast">',' ',$ex1[103]);
$oqgr=str_replace('</p>',' ',$oqgr);
$tongr=str_replace('<p class="forecast">',' ',$ex1[93]);
$tongr=str_replace('</p>',' ',$tongr);
$bugun=str_replace('<div class="current-day">',' ',$ex1[61]);
$bugun=str_replace('</div>',' ',$bugun);
$bugun = trim($bugun);
$vil=str_replace('<h2>',' ',$ex1[60]);
$vil=str_replace('</h2>',' ',$vil);
$vil=str_replace('&#039;','`',$vil);
$vil = trim($vil);
$tongr = trim($tongr);
$oqgr = trim($oqgr);
$kungr = trim($kungr); 
$havo1=str_replace('<div class="current-forecast-desc">',' ',$ex1[71]);
$havo1=str_replace('</div>',' ',$havo1);
$havo1=str_replace('&#039;','`',$havo1);
$havo1 = trim($havo1);
$gr1=str_replace('<span><strong>',' ',$ex1[67]);
$gr1=str_replace('</strong></span>',' ',$gr1);
$gr1= trim($gr1);
$gr2=str_replace('<span>',' ',$ex1[68]);
$gr2=str_replace('</span>',' ',$gr2);
$gr2= trim($gr2);
$nam=str_replace('<p>',' ',$ex1[75]);
$nam=str_replace('</p>',' ',$nam);
$nam= trim($nam);
$bosim=str_replace('<p>',' ',$ex1[77]);
$bosim=str_replace('</p>',' ',$bosim);
$bosim= trim($bosim);
$shamol=str_replace('<p>',' ',$ex1[76]);
$shamol=str_replace('</p>',' ',$shamol);
$shamol=str_replace('&#039;','`',$shamol);
$shamol= trim($shamol);
$oy=str_replace('<p>',' ',$ex1[80]);
$oy=str_replace('</p>',' ',$oy);
$oy=str_replace('&#039;','`',$oy);
$oy= trim($oy);
$qch=str_replace('<p>',' ',$ex1[81]);
$qch=str_replace('</p>',' ',$qch);
$qch= trim($qch);
$qb=str_replace('<p>',' ',$ex1[82]);
$qb=str_replace('</p>',' ',$qb);
$qb= trim($qb);
	bot('editMessageText',[
        'chat_id'=>$ccid,
        'message_id'=>$mmid,
    'text'=>"*📌Bugun 🏰$vil shahrida:⤵️
➖➖➖➖➖➖➖➖➖➖➖➖➖➖

🌓Bugun: $gr1 ... $gr2, ☀️$havo1
➖➖➖➖➖➖➖➖➖➖➖➖➖➖

🌄Tong: ☁️ $tongr C
🏙Kun: ☀️ $kungr C
🌃Oqshom: 🌤 $oqgr C
➖➖➖➖➖➖➖➖➖➖➖➖➖➖

🌬️ $shamol
💧 $nam
🌡$bosim
➖➖➖➖➖➖➖➖➖➖➖➖➖➖

🌙$oy
➖➖➖➖➖➖➖➖➖➖➖➖➖➖

🌝$qch
🌚$qb
➖➖➖➖➖➖➖➖➖➖➖➖➖➖

$sana*
➖➖➖➖➖➖➖➖➖➖➖➖➖➖

$mkm
",
'parse_mode' => 'markdown',
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard' => [
[['text'=>"↩Orqaga",'callback_data'=>"pogoda"]]
]
]),
]);
}

if($data=="davlatlarCovid"){

$tuzalga=file_get_contents("https://corona.lmao.ninja/v2/countries/USA");
$ex=explode('"cases":',$tuzalga);
$exp=explode(",","$ex[1]");
$k=explode('"todayCases":',$tuzalga);
$ka=explode(",","$k[1]");
$o=explode('"deaths":',$tuzalga);
$ol=explode(",","$o[1]");
$ob=explode('"todayDeaths":',$tuzalga);
$olb=explode(",","$ob[1]");
$p=explode('"tests":',$tuzalga);
$te=explode(",","$p[1]");
$et=explode('"todaytests":',$tuzalga);
$tes=explode(",","$et[1]");
$t=explode('"recovered":',$tuzalga);
$tu=explode(",","$t[1]");

$karonavirus1 = "
🇺🇸Amerika - 1️⃣
 🦠AQSh Karonavirus statistikasi
🤧Kasallananlar : $exp[0] ta
💀Vafot etganlar : $ol[0] ta
🙂Tuzalganlar : $tu[0] ta
 🧪Testdan o'tganlar : $te[0] ta";
 
 
$tuzalga=file_get_contents("https://corona.lmao.ninja/v2/countries/Brazil");
$ex=explode('"cases":',$tuzalga);
$exp=explode(",","$ex[1]");
$k=explode('"todayCases":',$tuzalga);
$ka=explode(",","$k[1]");
$o=explode('"deaths":',$tuzalga);
$ol=explode(",","$o[1]");
$ob=explode('"todayDeaths":',$tuzalga);
$olb=explode(",","$ob[1]");
$p=explode('"tests":',$tuzalga);
$te=explode(",","$p[1]");
$et=explode('"todaytests":',$tuzalga);
$tes=explode(",","$et[1]");
$t=explode('"recovered":',$tuzalga);
$tu=explode(",","$t[1]");

$karonavirus2 = "
🇧🇷Braziliya - 2️⃣
 🦠Braziliya Karonavirus statistikasi
🤧Kasallananlar : $exp[0] ta
💀Vafot etganlar : $ol[0] ta
🙂Tuzalganlar : $tu[0] ta
 🧪Testdan o'tganlar : $te[0] ta";
 

$tuzalga=file_get_contents("https://corona.lmao.ninja/v2/countries/India");
$ex=explode('"cases":',$tuzalga);
$exp=explode(",","$ex[1]");
$k=explode('"todayCases":',$tuzalga);
$ka=explode(",","$k[1]");
$o=explode('"deaths":',$tuzalga);
$ol=explode(",","$o[1]");
$ob=explode('"todayDeaths":',$tuzalga);
$olb=explode(",","$ob[1]");
$p=explode('"tests":',$tuzalga);
$te=explode(",","$p[1]");
$et=explode('"todaytests":',$tuzalga);
$tes=explode(",","$et[1]");
$t=explode('"recovered":',$tuzalga);
$tu=explode(",","$t[1]");

$karonavirus3 = "
🇮🇳Hindiston - 3️⃣
 🦠Hindiston Karonavirus statistikasi
🤧Kasallananlar : $exp[0] ta
💀Vafot etganlar : $ol[0] ta
🙂Tuzalganlar : $tu[0] ta
 🧪Testdan o'tganlar : $te[0] ta";
 

$tuzalga=file_get_contents("https://corona.lmao.ninja/v2/countries/Russia");
$ex=explode('"cases":',$tuzalga);
$exp=explode(",","$ex[1]");
$k=explode('"todayCases":',$tuzalga);
$ka=explode(",","$k[1]");
$o=explode('"deaths":',$tuzalga);
$ol=explode(",","$o[1]");
$ob=explode('"todayDeaths":',$tuzalga);
$olb=explode(",","$ob[1]");
$p=explode('"tests":',$tuzalga);
$te=explode(",","$p[1]");
$et=explode('"todaytests":',$tuzalga);
$tes=explode(",","$et[1]");
$t=explode('"recovered":',$tuzalga);
$tu=explode(",","$t[1]");

$karonavirus4 = "
🇷🇺Rossiya - 4️⃣
🦠Rassiya Karonavirus statistikasi
🤧Kasallananlar : $exp[0] ta
💀Vafot etganlar : $ol[0] ta
🙂Tuzalganlar : $tu[0] ta
  🧪Testdan o'tganlar : $te[0] ta";
  

$tuzalga=file_get_contents("https://corona.lmao.ninja/v2/countries/China");
$ex=explode('"cases":',$tuzalga);
$exp=explode(",","$ex[1]");
$k=explode('"todayCases":',$tuzalga);
$ka=explode(",","$k[1]");
$o=explode('"deaths":',$tuzalga);
$ol=explode(",","$o[1]");
$ob=explode('"todayDeaths":',$tuzalga);
$olb=explode(",","$ob[1]");
$p=explode('"tests":',$tuzalga);
$te=explode(",","$p[1]");
$et=explode('"todaytests":',$tuzalga);
$tes=explode(",","$et[1]");
$t=explode('"recovered":',$tuzalga);
$tu=explode(",","$t[1]");

$karonavirus5 = "
 🇨🇳Xitoy - 5️⃣
 🦠Xitoy Karonavirus statistikasi
 🤧Kasallananlar : $exp[0] ta
 ??Vafot etganlar : $ol[0] ta
 🙂Tuzalganlar : $tu[0] ta
  🧪Testdan o'tganlar : $te[0] ta";

$tuzalga=file_get_contents("https://corona.lmao.ninja/v2/countries/Turkey");
$ex=explode('"cases":',$tuzalga);
$exp=explode(",","$ex[1]");
$k=explode('"todayCases":',$tuzalga);
$ka=explode(",","$k[1]");
$o=explode('"deaths":',$tuzalga);
$ol=explode(",","$o[1]");
$ob=explode('"todayDeaths":',$tuzalga);
$olb=explode(",","$ob[1]");
$p=explode('"tests":',$tuzalga);
$te=explode(",","$p[1]");
$et=explode('"todaytests":',$tuzalga);
$tes=explode(",","$et[1]");
$t=explode('"recovered":',$tuzalga);
$tu=explode(",","$t[1]");

$karonavirus6 = "
🇹🇷Turkiya - 6️⃣
🦠Turkiya Karonavirus statistikasi
🤧Kasallananlar : $exp[0] ta
💀Vafot etganlar : $ol[0] ta 
🙂Tuzalganlar : $tu[0] ta
 🧪Testdan o'tganlar : $te[0] ta";


 $tuzalga=file_get_contents("https://corona.lmao.ninja/v2/countries/spain");
$ex=explode('"cases":',$tuzalga);
$exp=explode(",","$ex[1]");
$k=explode('"todayCases":',$tuzalga);
$ka=explode(",","$k[1]");
$o=explode('"deaths":',$tuzalga);
$ol=explode(",","$o[1]");
$ob=explode('"todayDeaths":',$tuzalga);
$olb=explode(",","$ob[1]");
$p=explode('"tests":',$tuzalga);
$te=explode(",","$p[1]");
$et=explode('"todaytests":',$tuzalga);
$tes=explode(",","$et[1]");
$t=explode('"recovered":',$tuzalga);
$tu=explode(",","$t[1]");

$karonavirus7 = "
 🇪🇸Ispaniya - 7️⃣
 🦠Ispaniya Karonavirus statistikasi
 🤧Kasallananlar : $exp[0] ta
 💀Vafot etganlar : $ol[0] ta
 🙂Tuzalganlar : $tu[0] ta
  🧪Testdan o'tganlar : $te[0] ta";
bot('editMessageText',[
   'chat_id'=>$ccid,
'message_id'=>$mmid,
'text'=>"📅$kun-$oy holatiga ko'ra

➖➖➖➖➖➖➖➖➖➖➖➖➖➖

$karonavirus1

➖➖➖➖➖➖➖➖➖➖➖➖➖➖

$karonavirus2

➖➖➖➖➖➖➖➖➖➖➖➖➖➖

$karonavirus3

➖➖➖➖➖➖➖➖➖➖➖➖➖➖

$karonavirus4

➖➖➖➖➖➖➖➖➖➖➖➖➖➖

$karonavirus5

➖➖➖➖➖➖➖➖➖➖➖➖➖➖

$karonavirus6

➖➖➖➖➖➖➖➖➖➖➖➖➖➖

$karonavirus7

➖➖➖➖➖➖➖➖➖➖➖➖➖➖


$sana

$mkm",
'parse_mode'=>'markdown',
  'reply_markup'=>$covidort,
]);
}

if($data == "UzbCovid"){   

$tuzalga=file_get_contents("https://corona.lmao.ninja/v2/countries/Uzbekistan");
$ex=explode('"cases":',$tuzalga);
$exp=explode(",","$ex[1]");
$k=explode('"todayCases":',$tuzalga);
$ka=explode(",","$k[1]");
$o=explode('"deaths":',$tuzalga);
$ol=explode(",","$o[1]");
$ob=explode('"todayDeaths":',$tuzalga);
$olb=explode(",","$ob[1]");
$p=explode('"tests":',$tuzalga);
$te=explode(",","$p[1]");
$et=explode('"todaytests":',$tuzalga);
$tes=explode(",","$et[1]");
$t=explode('"recovered":',$tuzalga);
$tu=explode(",","$t[1]");
bot('editMessageText',[
   'chat_id'=>$ccid,
'message_id'=>$mmid,
'text'=>"
📅$kun-$oy holatiga ko'ra

🇺🇿Oʻzbekistonda 
🦠Karonavirus statistikasi!

➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖
🤒Kasallananlar : $exp[0] ta
☠Vafot etganlar : $ol[0] ta
😷Tuzalganlar : $tu[0] ta
➖➖➖➖➖
➖➖➖➖➖➖➖➖➖➖➖➖➖

$sana

$mkm",
'parse_mode'=>'markdown',
  'reply_markup'=>$covidort,
]);
}

if($data == "DunyoCovid"){   
$stat = file_get_contents("https://m.aniq.uz/statistika/coronavirus/");
$ex1=explode("\n",$stat);
$kasal=str_replace('<td',' ',$ex1[211]);  
$kasal=str_replace('</td>',' ',$kasal);
$kasal = trim($kasal);
$kasalplus=str_replace('<td',' ',$ex1[214]);  
$kasalplus=str_replace('</td>',' ',$kasalplus);
$kasalplus = trim($kasalplus);
$sog=str_replace('<td',' ',$ex1[223]);  
$sog=str_replace('</td>',' ',$sog);
$sog = trim($sog);
$olim=str_replace('<td',' ',$ex1[217]);  
$olim=str_replace('</td>',' ',$olim);
$olim = trim($olim);
$olimplus=str_replace('<td',' ',$ex1[220]);  
$olimplus=str_replace('</td>',' ',$olimplus);
$olimplus = trim($olimplus);
bot('editMessageText',[
   'chat_id'=>$ccid,
'message_id'=>$mmid,
'text'=>"
📅$kun-$oy holatiga ko'ra

🌐Butun Jahon Karonavirus Statistikasi!

🤧Virusga Chalinganlar: $kasal $kasalplus

😷Tuzalganlar: $sog

😓O'lganlar: $olim $olimplus

$sana

$mkm",
'parse_mode'=>'markdown',
  'reply_markup'=>$covidort,
]);
}


if($data == "newyear"){   
  $kun1 = date('z ',strtotime('3 hour')); 
  $a = 365;
  $c2 = $a-$kun1;
  $d = date('L ',strtotime('3 hour'));
  $b = $c2+$d;
  $f = $b+81;
  $e = $b+240;
  $kun2 = date('H ',strtotime('3 hour')); 
  $a2 = 23;
  $b2 = $a2-$kun2;
  $kun3 = date('i ',strtotime('3 hour')); 
  $a3 = 59;
  $b3 = $a3-$kun3;
  $kun4 = date('s ',strtotime('3 hour')); 
  $a4 = 60;
  $b4 = $a4-$kun4;
bot('answerCallbackQuery',[
'callback_query_id'=>$yangilash->callback_query->id,
'text'=>"
☃️Yangi yilga Bayramiga

 🎄$b kun 
 🎊$b2 soat
 🎁 $b3 minut
 ❄️$b4 sekund qoldi!

🎅🏽Hurmatli '$name' 
🎉Kirib kelayotgan
🎁Yangi yil bilan!",
'show_alert'=>true,
]);   
}


if($data == "ramazon") {   
$kun1 = date('z',strtotime('3 hour'));
$a = 113;
$c2 = $a-$kun1;
$kun2 = date('H',strtotime('3 hour'));
$b = 03;
$c3 = $b-$kun2;
$kun3 = date('i',strtotime('3 hour'));
$c = 34;
$c1 = $c-$kun3;
$kun4 = date('s',strtotime('3 hour'));
$d = 59;
$d1 = $d-$kun4;
bot('answerCallbackQuery',[
'callback_query_id'=>$yangilash->callback_query->id,
'text'=>"
➖➖➖➖➖➖➖➖➖➖➖➖➖
🌙Ramazonga

├📅$c2-Kun
├⏰$c3-Soat
├⌛$c1-Minut 
└🕞$d1-Sekund qoldi!

☪️Ramazon Bayrami bilan!

$sana
➖➖➖➖➖➖➖➖➖➖➖➖➖

$mkm",
'show_alert'=>true,
]);   
}

if($data=="tezligini"){
$start_time = round(microtime(true) * 1000);
$send=  bot('editMessageText', [
'chat_id' => $ccid,
'message_id'=>$mmid,
 'text' =>"⏱O'lchanmoqda..",
])->result->message_id;
$end_time = round(microtime(true) * 1000);
$time_taken = $end_time - $start_time;
bot('editMessagetext',[
"chat_id" =>$ccid,
"message_id" => $send,
"text" => "✈Bot Tezligi: *" . $time_taken .  "* Ms

*$mkm*",
'parse_mode'=>'markdown',
'reply_markup'=>$qayt,
]);
}

if($data=="xabarmuhiddin"){
bot('deleteMessage',[
'chat_id'=>$ccid,
'message_id'=>$mmid,
]);
bot('sendMessage',[
'chat_id'=>$ccid,
'text'=>"♏Admin Uchun Xabaringizni Yozing!",
'reply_markup'=>$rpl, 
]);
}
if($reply=="♏Admin Uchun Xabaringizni Yozing!"){ 
bot('Sendmessage',[
      'chat_id'=>$admin,
      'text'=>"🎗️Admin Aka Xabar keldi!
      
👤Yuboruvchi: <a href='tg://user?id=$id'>$name</a>

♏UserName: <a href='tg://user?id=$id'>@$user1</a>

🆔️Raqami: <code>$cid</code>
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖
💭Xabar: <b>$text</b>",
'parse_mode'=>"html",
]);
  bot('sendMessage',[
'chat_id'=>$cid,
    'text'=>"<b>📬Xabaringiz Adminga Yuborildi!
👨‍💻Admin 24soat ichida o'qib chiqadi!</b>!",
    'parse_mode'=>'html',
'reply_markup'=>$qayt,
	]);
}

$url = 'https://daryo.uz/feed/';
$rss = simplexml_load_file($url);
foreach ($rss->channel->item as $item) {
$line = $item->title;
 $link = $item->link;
break;
}
if($data == "yangiliklar"){
bot('EditMessageText',[
   'chat_id'=>$ccid,
'message_id'=>$mmid,
'text'=>"
🎩Eng So'ngi va Qaynoq 🗞️Yangiliklar

[$line]($link)

📚To'liq O'qish Uchun Bosing!⤴️",
'parse_mode'=>'markdown',
'reply_markup'=>$qayt,
]);
}

if($data == "quron"){
bot('EditMessageText',[
   'chat_id'=>$ccid,
'message_id'=>$mmid,
'text'=>"📖Quron haqida
➖➖➖➖➖➖➖➖➖➖➖➖
Qurʼon (arab. القرآن oʻqimoq, qiroat qilmoq) — musulmonlarning asosiy muqaddas kitobi. Islom eʼtiqodiga koʻra,
Qurʼon vahiy orqali Muhammad paygʻambarga 610—632 yillar davomida nozil qilingan Allohning kalomi (Kalomulloh). Qurʼon „Kitob“ (yozuv), 
„Furqon“ (haq bilan botilning orasini ayiruvchi), 
„Zikr“ (eslatma), „Tanzil“ (nozil qilingan) kabi nomlar bilan atalib, „Nur“ (yorugʻlik), 
„Hudo“ (hidoyat), „Muborak“ (barakotli),
 „Mubin“ (ochiq-ravshan), „Bushro“ (xushxabar), 
„Aziz“ (eʼzozlanuvchi), „Majid“ (ulugʻ), 
„Bashir“ (bashorat beruvchi), 
„Nazir“ (ogohlantiruvchi) kabi soʻzlar bilan sifatlangan. 
Islom olamida Qurʼon musʼhaf nomi bilan ham mashhur. 
Islom ulamolari Qurʼonning 30 xil nom va sifatlarini sanab oʻtganlar.
➖➖➖➖➖➖➖➖➖➖➖➖
✍Quroning tuzulishi
➖➖➖➖➖➖➖➖➖➖➖➖
Qurʼonning boʻlimlari sura deyiladi,
uni shartli ravishda bob bilan taqqoslash mumkin.
Har sura oyatlarga boʻlingan. 
Qurʼon 114 sura, 6236 oyatdan iborat.
Har bir suraning oʻz nomi bor. Oyatlar esa tartib raqami bilan berilgan. 
Suralarning nomlari uning boshida kelgan soʻzdan olingan yoki zikri koʻproq kelgan narsalar,
voqealar yohud asosiy qahramon nomi bilan atalgan. 
Keyinchalik oʻqish va yodlash oson boʻlishi uchun Iroq hokimi Hajjoj ibn Yusuf (hukmronlik yillari 694—714) koʻrsatmasiga binoan Qurʼon 30 qism (arab.juz, fors. pora)ga boʻlingan.
Qurʼonda birinchi kelgan „Fotiha“ surasidan keyingi suralar katta, 
oʻrtacha va kichik suralar tartibida joylashgan. 2-Baqara surasi 286 oyatdan, eng qisqa Kavsar surasi 3 oyatdan iborat. 
Eng qisqa oyatlar „Toho“ va „Yosin“, eng uzun oyat „Baqara“ surasining 282-oyatidir. Suralar nozil boʻlish vaqti va joyiga koʻra 2 ga: hijradan oldin nozil boʻlgan suralar —
„Makka suralari“ (610—622 yillar, 90 sura) va hijradan keyin nozil boʻlgan suralar — „Madina suralari“ (622-yildan, 24 sura) ga ajratiladi.
Qurʼon matnining koʻp qismi Alloh bilan soʻzlashish, islom dushmanlari yoki undan ikkilanuvchilar bilan munozara qilish shaklida berilgan.

*$mkm*",
'parse_mode'=>'markdown',
'disable_web_page_preview' => true,
'reply_markup'=>$qayt,
]);
}

if($data=="isming"){
bot('deleteMessage',[
'chat_id'=>$ccid,
'message_id'=>$mmid,
]);
bot('sendMessage',[
'chat_id'=>$ccid,
'text'=>"📚Ismingizni yuboring!",
'parse_mode'=>'markdown',
'reply_markup'=>$rpl, 
]);
}

    if($reply=="📚Ismingizni yuboring!"){
$ism = file_get_contents("https://ismlar.com/search/$text");
  $exp = explode('<p class="text-size-5">',$ism);
  $expl = explode('<div class="col-12 col-md-4 text-md-right">',$exp[1]);
  $im = str_replace($expl[1],' ',$exp[1]);
  $ims = str_replace('</p>',' ',$im);
  $isms = str_replace('</div>',' ',$ims);
  $ismn = str_replace('<div class="col-12 col-md-4 text-md-right">',' ',$isms);
  $ismk = str_replace('&#039;','`',$ismn);
  $ismsm = trim("$ismk");
  bot('sendmessage',[
    'chat_id'=>$cid,
    'reply_to_message_id'=>$mid,
    'text'=>"📚 ISMLAR MA'NOSI 📚
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖
✍Siz Yozgan So'z: $text
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖
💠Manosi: | $ismsm! |

*$mkm*",
'parse_mode'=>'markdown',
'reply_markup'=>$qayt,
]);
} 
 
 if($data == "rozaduo"){
bot('EditMessageText',[
   'chat_id'=>$ccid,
'message_id'=>$mmid,
'text'=>"—————————————————————
🌸Рузада огиз очиш ва йопиш дуолари

Руза тутиш (огиз епиш)
дуоси. Навайту ан асума
совма шахри ромазона
миннал фажри иллал
магриби холисал
лиллоху таолло Аллоху акбар. Амин.
РУЗА (огиз очиш) дуоси.
Аллохума лака сумту ва
бика аманту валайка
тавакалту ва алла
ризика ифтору фагфирли ла гафуру ма
кадамту ва мо ахарту.
Илохим Аллохим кабул
айласин рузангизни.
Амин🤲
————————————————————

*$mkm*",
'parse_mode'=>'markdown',
'disable_web_page_preview' => true,
'reply_markup'=>$qayt,
]);
}


if($data=="restart"){
bot('editMessageText',[
'message_id'=>$mmid,
'chat_id'=>$ccid,
'text'=>"
 <b> 🕓Ma'lumotlar Yangilanmoqda </b>",
 'parse_mode'=>"HTML"
 ]);
 sleep(0.2);
bot('editMessageText',[
'message_id'=>$mmid,
'chat_id'=>$ccid,
'text'=>'⬜️'
 ]);
 sleep(0.3);
bot('editMessageText',[
'message_id'=>$mmid,
'chat_id'=>$ccid,
'text'=>'⬛️'
 ]);
 sleep(0.3);
bot('editMessageText',[
'message_id'=>$mmid,
'chat_id'=>$ccid,
'text'=>'🟪'
 ]);
 sleep(0.3);
bot('editMessageText',[
'message_id'=>$mmid,
'chat_id'=>$ccid,
'text'=>'🟦'
 ]);
 sleep(0.3);
bot('editMessageText',[
'message_id'=>$mmid,
'chat_id'=>$ccid,
'text'=>'🟩'
 ]);
 sleep(0.3);
bot('editMessageText',[
'message_id'=>$mmid,
'chat_id'=>$ccid,
'text'=>'🟨'
 ]);
 sleep(0.3);
bot('editMessageText',[
'message_id'=>$mmid,
'chat_id'=>$ccid,
'text'=>'🟧'
 ]);
 sleep(0.3);
bot('editMessageText',[
'message_id'=>$mmid,
'chat_id'=>$ccid,
'text'=>'🟫'
 ]); 
 sleep(0.3);
bot('editMessageText',[
'message_id'=>$mmid,
'chat_id'=>$ccid,
'text'=>'🟥'
]);
 sleep(0.3);
bot('editMessageText',[
'message_id'=>$mmid,
'chat_id'=>$ccid,
'text'=>'✔️'
 ]);
 sleep(0.3);
bot('editMessageText',[
'message_id'=>$mmid,
'chat_id'=>$ccid,
'text'=>'✅'
 ]); 
  bot('deletemessage',[
    'chat_id'=>$chat_id,
    'message_id'=>$mid + 1,
  ]);
 sleep(0.4);
    bot('editMessageText',[
'message_id'=>$mmid,
'chat_id'=>$ccid,
'text'=>"🚀Barcha Ma'lumotlar Yangilandi!

$mkm",
       'parse_mode'=>'html',  
       'reply_markup'=>$qayt,
]);
}


if($data=="davlatsoat"){
bot('editMessageText',[
'message_id'=>$mmid,
'chat_id'=>$ccid,
'text'=>"*🇺🇸 AQSH: $timeusa
➖➖➖➖➖➖➖➖
🇧🇷 Braziliya: $timebra
➖➖➖➖➖➖➖➖
🇵🇹 Portugaliya: $timepor
➖➖➖➖➖➖➖➖
🇸🇦 Saudiya Arabistoni: $timearb
➖➖➖➖➖➖➖➖
🇪🇸 Ispaniya: $timeisp
➖➖➖➖➖➖➖➖
🇦🇪 Dubay: $timedub
➖➖➖➖➖➖➖➖
🇯🇵 Yaponiya: $timeyap
➖➖➖➖➖➖➖➖
🇷🇺 Rossiya: $timerus
➖➖➖➖➖➖➖➖
🇩🇪 Germaniya: $timeger

$mkm*",
'parse_mode'=>'markdown',
'reply_markup'=>$qayt, 
]);
}
 


if($data=="bratan"){
bot('editMessageText',[
   'chat_id'=>$ccid,
'message_id'=>$mmid,
'text'=>"🤖Bot Dasturchisi  @$adminuser
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
🔥Sizga Xam shunday yoki Boshqa turdagi bot kerakmi?
👨‍💻Dasturchiga Murojat qiling!
👏Va Biz Sizga Botlar Yasab beramiz.
💰To'lov xam siz istagan usulda!
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
$mkm",
'parse_mode'=>'html',
  'reply_markup'=>$qayt,
]);
}

$sayt = file_get_contents('http://uzsmart.ru/namoz-vaqtlari/');
//bobdod 
$bob = explode('<td><b>Tong (sahar)</b></td> <td>',"$sayt");
$bob2 = explode('</td>',"$bob[1]");
$bobdod = str_replace("$bob[1]"," ","$bob2[0]");
//quyosh
$quy = explode('<td><b>Quyosh</b></td> <td>',"$sayt");
$quy2 = explode('</td>',"$quy[1]");
$quyosh = str_replace("$quy[1]"," ","$quy2[0]");
//peshin
$pesh= explode('<td><b>Pеshin</b></td> <td>',"$sayt");
$pesh2 = explode('</td>',"$pesh[1]");
$pеshin = str_replace("$pesh[1]"," ","$pesh2[0]");
//asr
$as= explode('<td><b>Asr</b></td> <td>',"$sayt");
$as2 = explode('</td>',"$as[1]");
$asr = str_replace("$as[1]"," ","$as2[0]");
//shom
$sho= explode('<td><b>Shom (iftor)</b></td> <td>',"$sayt");
$sho2 = explode('</td>',"$sho[1]");
$shom = str_replace("$sho[1]"," ","$sho2[0]");
//xufton
$xuf= explode('<td><b>Xufton</b></td> <td>',"$sayt");
$xuf2 = explode('</td>',"$xuf[1]");
$xufton = str_replace("$xuf[1]"," ","$xuf2[0]");
//Namoz Vaqtlari
$namoz = "🕌Namoz Vaqtlari:

🕌Bomdod: $bobdod        
🕌Peshin: $pеshin             
🕌Asr: $asr                         
🕌Shom: $shom                
🕌Xufton: $xufton";
     
if($data=="namozV"){
bot('EditMessageText',[
'chat_id'=>$ccid,
'message_id'=>$mmid,
'text'=>"$namoz

$mkm",
'parse_mode'=>'markdown',
'reply_markup'=>$qayt,
]);
}

if($data=="qrkod"){
bot('deleteMessage',[
'chat_id'=>$ccid,
'message_id'=>$mmid,
]);
bot('sendMessage',[
'chat_id'=>$ccid,
'text'=>"🔵QR Code yasash uchun matnni kiriting!
",
'parse_mode'=>'markdown',
'reply_markup'=>$rpl, 
]);
}
if($reply=="🔵QR Code yasash uchun matnni kiriting!"){
bot('sendPhoto',[
'chat_id'=>$cid,
'reply_to_message_id'=>$mid,
'photo'=>"http://qr-code.ir/api/qr-code?s=5&e=M&t=P&d=$text",
'caption'=>"$mkm",
'parse_mode'=>'html',
'reply_markup'=>$backs,
]);
}

if($data=="rasmqidiruv"){
bot('deleteMessage',[
'chat_id'=>$ccid,
'message_id'=>$mmid,
]);
bot('sendMessage',[
'chat_id'=>$ccid,
'text'=>"🕵🏻‍♂ Rasm izlash uchun so'z yozing!",
'parse_mode'=>'markdown',
'reply_markup'=>$rpl, 
]);
}
if($reply=="🕵🏻‍♂ Rasm izlash uchun so'z yozing!"){
bot('sendPhoto',[
'chat_id'=>$cid,
'photo'=>"https://yandex.uz/images/touch/search/?text=$text",
'caption'=>"
✅RASM TOPILDI✅

🌠*Rasmni $boot topib berdi!*",
'parse_mode'=>'markdown',
'reply_markup'=>$backs,
]);
}

if($data=="matem"){
bot('deleteMessage',[
'chat_id'=>$ccid,
'message_id'=>$mmid,
]);
bot('sendMessage',[
'chat_id'=>$ccid,
'text'=>"🔢Matematika Misolini Yechish Uchun Menga Misol Yuboring!",
'reply_markup'=>$rpl,
]);
} 
if($reply=="🔢Matematika Misolini Yechish Uchun Menga Misol Yuboring!"){
$calc = urlencode($text);
$rs = file_get_contents('http://api.mathjs.org/v1/?expr='.$calc);
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"👉 *$text* Ning - 🤓Javobi: *$rs*",
'parse_mode'=>'markdown',
'reply_to_message_id'=>$mid,
'reply_markup'=>json_encode([
'inline_keyboard' => [
[['text'=>"⏮Orqaga",'callback_data'=>"inline"]],
]
]),
]);
}


if($data=="tessoz"){
bot('deleteMessage',[
'chat_id'=>$ccid,
'message_id'=>$mmid,
]);
bot('sendMessage',[
'chat_id'=>$ccid,
'text'=>"💬Biror So'z yuboring!",
'parse_mode'=>'markdown',
'reply_markup'=>$rpl, 
]);
}
$str = strrev($text);
if($reply=="💬Biror So'z yuboring!"){
bot('SendMessage',[
'chat_id'=>$ccid,
 'text'=>"☄️Iltimos biroz kuting...",
 'parse_mode'=>"HTML"
 ]);
 sleep(1.1);
  bot('deletemessage',[
    'chat_id'=>$ccid,
    'message_id'=>$mmid + 1,
  ]);
 sleep(1.1);
bot('sendMessage', [
'chat_id'=>$cid,
'text'=>"😅*Siz Yozgan So'zingizni Teskarisi*⤵️

☞︎︎︎ $str ☜︎︎︎

*$mkm*",
 'parse_mode'=>'markdown',
'reply_to_message_id'=> $mmid, 
'reply_markup'=>$qayt, 
]);
}



if($data=="fonga"){
bot('editMessageText',[
   'chat_id'=>$ccid,
'message_id'=>$mmid,
'text'=>"
🥀 Bu sslilka orqali telegramingiz Fonini qulay oson o'zgartira olasiz!
⤵️ Shunchaki o'rnatmoqchi bo'lgan Fon Raqamini tanlang:

➖➖➖➖➖➖➖➖➖➖➖➖➖➖
<a href='https://t.me/bg/7HqL5bBEyUoEAAAAXYaZUZh14YE'>🌉Telegram 1️⃣ - fon		✅</a>
➖➖➖➖➖➖➖➖➖➖➖➖➖➖
<a href='https://t.me/bg/aLBLuMfyCUsEAAAA9n3N0xRCuwo'>🌉Telegram 2️⃣ - fon		✅</a>
➖➖➖➖➖➖➖➖➖➖➖➖➖➖
<a href='https://t.me/bg/FZla3e-CyEkBAAAAMwmoy6WarGY'>🌉Telegram 3️⃣ - fon		✅</a>
➖➖➖➖➖➖➖➖➖➖➖➖➖➖
<a href='https://t.me/bg/XorADb5a2EkBAAAAINKBVJtUxqo'>🌉Telegram 4️⃣ - fon		✅</a>
➖➖➖➖➖➖➖➖➖➖➖➖➖➖
<a href='https://t.me/bg/jBen_AFVwUpJAAAA3Ybd3Z-qCSQ'>🌉Telegram 5️⃣ - fon		✅</a>
➖➖➖➖➖➖➖➖➖➖➖➖➖➖
<a href='https://t.me/bg/CiwwsoTP-VEBAAAAmDYEizr71BQ'>🌉Telegram 6️⃣ - fon		✅</a>
➖➖➖➖➖➖➖➖➖➖➖➖➖➖
<a href='https://t.me/bg/Z4wGEfQLmUmYAAAARaGmMPqVJaY'>🌉Telegram 7️⃣ - fon		✅</a>
➖➖➖➖➖➖➖➖➖➖➖➖➖➖

$mkm",
    'parse_mode'=>'html',
'disable_web_page_preview' => true,
'reply_to_message_id'=> $mmid, 
 'reply_markup'=>$qayt,
	]);
}

//Telegram Tillari
if($data=="tgtil"){
bot('editMessageText',[
   'chat_id'=>$ccid,
'message_id'=>$mmid,
'text'=>"📚Telegramingiz tilini osongina o'zgartirish uchun quyidagi tillardan birini tanlang!⤵️",
'parse_mode' => 'html',
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode(
['inline_keyboard' => [
[['text'=>"🇺🇿Узбек тили",'url'=>"tg://setlanguage?lang=uzbekcyr"]],
[['text'=>"🇺🇿O'zbek tili",'url'=>"tg://setlanguage?lang=uz-beta"]],
[['text'=>"🇷🇺Руский язик",'url'=>"tg://setlanguage?lang=ru"]],
[['text'=>"🇩🇪Germaniya tili",'url'=>"tg://setlanguage?lang=de"]],
[['text'=>"🇺🇸English",'url'=>"tg://setlanguage?lang=en"]],
[['text'=>"🇸🇦Arab tili",'url'=>"tg://setlanguage?lang=ar"]],
[['text'=>"🇹🇷Turkiya tili",'url'=>"tg://setlanguage?lang=tr"]],
[['text'=>"🇫🇷 Fransuz tili",'url'=>"tg://setlanguage?lang=fr"]],
[['text'=>"$nazad",'callback_data'=>"ortinga"]],
]
]),
]);
}

$Muhiddin = $uzkmm->text;
//Nik Tayyorlash
if($data=="nikyasaw"){
	bot('deleteMessage',[
'chat_id'=>$ccid,
'message_id'=>$mmid,
]);
bot('sendMessage',[
'chat_id'=>$ccid,
'text'=>"🧙🏼‍♂Nik Tayyorlash uchun Ismingizni yoki so'z yuboring!",
  'reply_markup'=>$rpl,
    ]);
    }
    if($reply=="🧙🏼‍♂Nik Tayyorlash uchun Ismingizni yoki so'z yuboring!"){
$Muhiddin = str_replace('q', 'ϙᷭ', $Muhiddin);
   $Muhiddin = str_replace('w', 'ᴡᷱ', $Muhiddin);
   $Muhiddin = str_replace('e', 'ᴇⷷ', $Muhiddin);
   $Muhiddin = str_replace('r', 'ʀᷢ', $Muhiddin);
   $Muhiddin = str_replace('t', 'ᴛͭ', $Muhiddin);
   $Muhiddin = str_replace('y', 'ʏꙷ', $Muhiddin);
   $Muhiddin = str_replace('u', 'ᴜͧ', $Muhiddin);
   $Muhiddin = str_replace('i', 'ɪͥ', $Muhiddin);
   $Muhiddin = str_replace('o', 'ᴏⷪ', $Muhiddin);
   $Muhiddin = str_replace('p', 'ᴘᷮ', $Muhiddin);
   $Muhiddin = str_replace('a', 'ᴀⷽ', $Muhiddin);
   $Muhiddin = str_replace('s', 'sᷤ', $Muhiddin);
   $Muhiddin = str_replace('d', 'ᴅͩ', $Muhiddin);
   $Muhiddin = str_replace('f', 'ғᷫ', $Muhiddin);
   $Muhiddin = str_replace('g', 'ɢᷛ', $Muhiddin);
   $Muhiddin = str_replace('h', 'ʜⷩ', $Muhiddin);
   $Muhiddin = str_replace('j', 'ᴊᷯ', $Muhiddin);
   $Muhiddin = str_replace('k', 'ᴋⷦ', $Muhiddin);
   $Muhiddin = str_replace('l', 'ʟᷞ', $Muhiddin);
   $Muhiddin = str_replace('z', 'ᴢᷦ', $Muhiddin);
   $Muhiddin = str_replace('x', 'xͯ', $Muhiddin);
   $Muhiddin = str_replace('c', 'ᴄⷭ', $Muhiddin);
   $Muhiddin = str_replace('v', 'ᴠͮ', $Muhiddin);
   $Muhiddin = str_replace('b', 'ʙⷡ', $Muhiddin);
   $Muhiddin = str_replace('n', 'ɴᷡ', $Muhiddin);
   $Muhiddin = str_replace('m', 'ᴍᷟ', $Muhiddin);
   $Muhiddin = str_replace('Q', 'ϙᷭ', $Muhiddin);
   $Muhiddin = str_replace('W', 'ᴡᷱ', $Muhiddin);
   $Muhiddin = str_replace('E', 'ᴇⷷ', $Muhiddin);
   $Muhiddin = str_replace('R', 'ʀᷢ', $Muhiddin);
   $Muhiddin = str_replace('T', 'ᴛͭ', $Muhiddin);
   $Muhiddin = str_replace('Y', 'ʏꙷ', $Muhiddin);
   $Muhiddin = str_replace('U', 'ᴜͧ', $Muhiddin);
   $Muhiddin = str_replace('I', 'ɪͥ', $Muhiddin);
   $Muhiddin = str_replace('O', 'ᴏⷪ', $Muhiddin);
   $Muhiddin = str_replace('P', 'ᴘᷮ', $Muhiddin);
   $Muhiddin = str_replace('A', 'ᴀⷽ', $Muhiddin);
   $Muhiddin = str_replace('S', 'sᷤ', $Muhiddin);
   $Muhiddin = str_replace('D', 'ᴅͩ', $Muhiddin);
   $Muhiddin = str_replace('F', 'ғᷫ', $Muhiddin);
   $Muhiddin = str_replace('G', 'ɢᷛ', $Muhiddin);
   $Muhiddin = str_replace('H', 'ʜⷩ', $Muhiddin);
   $Muhiddin = str_replace('J', 'ᴊᷯ', $Muhiddin);
   $Muhiddin = str_replace('K', 'ᴋⷦ', $Muhiddin);
   $Muhiddin = str_replace('L', 'ʟᷞ', $Muhiddin);
   $Muhiddin = str_replace('Z', 'ᴢᷦ', $Muhiddin);
   $Muhiddin = str_replace('X', 'xͯ', $Muhiddin);
   $Muhiddin = str_replace('C', 'ᴄⷭ', $Muhiddin);
   $Muhiddin = str_replace('V', 'ᴠͮ', $Muhiddin);
   $Muhiddin = str_replace('B', 'ʙⷡ', $Muhiddin);
   $Muhiddin = str_replace('N', 'ɴᷡ', $Muhiddin);
   $Muhiddin = str_replace('M', 'ᴍᷟ', $Muhiddin);
   bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>$Muhiddin,
 
    ]);
    }
    
        $Muhiddin2 = $uzkmm->text;
   if($reply=="🧙🏼‍♂Nik Tayyorlash uchun Ismingizni yoki so'z yuboring!"){
$Muhiddin2 = str_replace(["q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m","Q","E","R","T","Y","U","I","O","P","A","S","D","F","G","H","J","K","L","Z","X","C","V","B","N","M"],["𝖖","𝖜","𝖊","𝖗","𝖙","𝛄","𝖚","𝖎","𝖔","𝖕","𝖆","𝖘","𝖉","𝖋","𝖌","𝖍","𝖏","𝖐","𝖑","𝖟","𝖝","𝖈","𝖛","𝖇","𝖓","𝖒","𝕼","𝕰","𝕽","𝕴","𝚼","𝖀","𝕿","𝕺","𝕻","𝕬","𝕾","𝕯","𝕱","𝕲","𝕳","𝕵","𝕶","𝕷","𝖅","𝖃","𝕮","𝖁","𝕭","𝕹","𝕸"], $Muhiddin2);
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>$Muhiddin2,
 
    ]);
    }
    
    $Muhiddin3 = $uzkmm->text;
   if($reply=="🧙🏼‍♂Nik Tayyorlash uchun Ismingizni yoki so'z yuboring!"){
$Muhiddin3 = str_replace(["q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m","Q","E","R","T","Y","U","I","O","P","A","S","D","F","G","H","J","K","L","Z","X","C","V","B","N","M"],["Ⓠ","Ⓦ","Ⓔ","Ⓡ","Ⓣ","Ⓨ","Ⓤ","Ⓘ","Ⓞ","Ⓟ","Ⓐ","Ⓢ","Ⓓ","Ⓕ","Ⓖ","Ⓗ","Ⓙ","Ⓚ","Ⓛ","Ⓩ","Ⓧ","Ⓒ","Ⓥ","Ⓑ","Ⓝ","Ⓜ","Ⓠ","Ⓔ","Ⓡ","Ⓣ","Ⓨ","Ⓤ","Ⓘ","Ⓞ","Ⓟ","Ⓐ","Ⓢ","Ⓓ","Ⓕ","Ⓖ","Ⓗ","Ⓙ","Ⓚ","Ⓛ","Ⓩ","Ⓧ","Ⓒ","Ⓥ","Ⓑ","Ⓝ","Ⓜ"], $Muhiddin3);
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>$Muhiddin3,
 
    ]);
    }
    
    $Muhiddin4 = $uzkmm->text;
       if($reply=="🧙🏼‍♂Nik Tayyorlash uchun Ismingizni yoki so'z yuboring!"){
$Muhiddin4 = str_replace(["q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m","Q","E","R","T","Y","U","I","O","P","A","S","D","F","G","H","J","K","L","Z","X","C","V","B","N","M"],["🅠","🅦","🅔","🅡","🅣","🅨","🅤","🅘","🅞","🅟","🅐","🅢","🅓","🅕","🅖","🅗","🅙","🅚","🅛","🅩​","🅧","🅒","🅥","🅑","🅝","🅜","🅠","🅔","🅡","🅣","🅨","🅤","🅘","🅞","🅟","🅐","🅢","🅓","🅕","🅖","🅗","🅙","🅚","🅛","🅩​","🅧","🅒","🅥","🅑","🅝","🅜"], $Muhiddin4);
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>$Muhiddin4,
 
    ]);
    }
    
    $Muhiddin5 = $uzkmm->text;
           if($reply=="🧙🏼‍♂Nik Tayyorlash uchun Ismingizni yoki so'z yuboring!"){
$Muhiddin5 = str_replace(["q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m","Q","E","R","T","Y","U","I","O","P","A","S","D","F","G","H","J","K","L","Z","X","C","V","B","N","M"],["🅀","🅆","🄴","🅁","🅃","🅈","🅄","🄸","🄾","🄿","🄰","🅂","🄳","🄵","🄶","🄷","🄹","🄺","🄻","🅉","🅇","🄲","🅅","🄱","🄽","🄼","🅀","🄴","🅁","🅃","🅈","🅄","🄸","🄾","🄿","🄰","🅂","🄳","🄵","🄶","🄷","🄹","🄺","🄻","🅉","🅇","🄲","🅅","🄱","🄽","🄼"], $Muhiddin5);
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>$Muhiddin5,
 
    ]);
    }

    $Muhiddin6 = $uzkmm->text;
    if($reply=="🧙🏼‍♂Nik Tayyorlash uchun Ismingizni yoki so'z yuboring!"){
$Muhiddin6 = str_replace(["q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m"],["𝓺","𝔀","𝓮","𝓻","𝓽","𝔂","𝓾","𝓲","𝓸","𝓹","𝓪","𝓼","𝓭","𝓯","𝓰","𝓱","𝓳","𝓴","𝓵","𝔃","𝔁","𝓬","𝓿","𝓫","𝓷","𝓶"], $Muhiddin6);
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>$Muhiddin6,
 
    ]);
    }
    
    $Muhiddin7 = $uzkmm->text;
        if($reply=="🧙🏼‍♂Nik Tayyorlash uchun Ismingizni yoki so'z yuboring!"){
$Muhiddin7 = str_replace(["q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m"],["🆀","🆆","🅴","🆁","🆃","🆈","🆄","🅸","🅾","🅿","🅰","🆂","🅳","🅵","🅶","🅷","🅹","🅺","🅻","🆉","🆇","🅲","🆅","🅱","🅽","🅼"], $Muhiddin7);
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>$Muhiddin7,
 
    ]);
    }
    
    
    //Muhiddin
    $Muhiddin8 = $uzkmm->text;
            if($reply=="🧙🏼‍♂Nik Tayyorlash uchun Ismingizni yoki so'z yuboring!"){
$Muhiddin8 = str_replace(["q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m"],["𝙦","𝙬","𝙚","𝙧","𝙩","𝙮","𝙪","𝙞","𝙤","𝙥","𝙖","𝙨","𝙙","𝙛","𝙜","𝙝","𝙟","𝙠","𝙡","𝙯","𝙭","𝙘","𝙫","𝙗","𝙣","𝙢"], $Muhiddin8);
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>$Muhiddin8,
 
    ]);
    }
    
    $Muhiddin9 = $uzkmm->text;
    if($reply=="🧙🏼‍♂Nik Tayyorlash uchun Ismingizni yoki so'z yuboring!"){
$Muhiddin9 = str_replace(["q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m","Q","E","R","T","Y","U","I","O","P","A","S","D","F","G","H","J","K","L","Z","X","C","V","B","N","M"],["𝒒","𝒘","𝒆","𝒓","𝒕","𝒚","𝒖","𝒊","𝒐","𝒑","𝒂","𝒔","𝒅","𝒇","𝒈","𝒉","𝒋","𝒌","𝒍","𝒛","𝒙","𝒄","𝒗","𝒃","𝒏","𝒎","𝑸","𝑬","𝑹","𝑻","𝒀","𝑼","𝑰","𝑶","𝑷","𝑨","𝑺","𝑫","𝑭","𝑮","𝑯","𝑱","𝑲","𝑳","𝒁","𝑿","𝑪","𝑽","𝑩","𝑵","𝑴"], $Muhiddin9);
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>$Muhiddin9,
 
    ]);
    }
    
    $Muhiddin11 = $uzkmm->text;
        if($reply=="🧙🏼‍♂Nik Tayyorlash uchun Ismingizni yoki so'z yuboring!"){
$Muhiddin11 = str_replace(["q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m","Q","E","R","T","Y","U","I","O","P","A","S","D","F","G","H","J","K","L","Z","X","C","V","B","N","M"],["𝑞","𝑤","𝑒","𝑟","𝑡","𝑦","𝑢","𝑖","𝑜","𝑝","𝑎","𝑠","𝑑","𝑓","𝑔","ℎ","𝑗","𝑘","𝑙","𝑧","𝑥","𝑐","𝑣","𝑏","𝑛","𝑚","𝑄","𝐸","𝑅","𝑇","𝑌","𝑈","𝐼","𝑂","𝑃","𝐴","𝑆","𝐷","𝐹","𝐺","𝐻","𝐽","𝐾","𝐿","𝑍","𝑋","𝐶","𝑉","𝐵","𝑁","𝑀"], $Muhiddin11);
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>$Muhiddin11,
 
    ]);
    }
    
    $Muhiddin12 = $uzkmm->text;
    if($reply=="🧙🏼‍♂Nik Tayyorlash uchun Ismingizni yoki so'z yuboring!"){
$Muhiddin12 = str_replace(["q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m","Q","E","R","T","Y","U","I","O","P","A","S","D","F","G","H","J","K","L","Z","X","C","V","B","N","M"],["🍳","👐","📧","®️","🍄","🍸","👅","🚹","⭕","🅿️","🅰️","💲","🌛","🎏","🌀","♓","🎷","🎋","💪","💤","❎","©️","✌","🅱️","🎵","〽","🍳","📧","®️","🍄","🍸","👅","🚹","⭕","🅿️","🅰️","💲","🌛","🎏","🌀","♓","🎷","🎋","💪","💤","❎","©️","✌","🅱️","🎵","〽"], $Muhiddin12);
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>$Muhiddin12,
 
    ]);
    }
    
    $Muhiddin13 = $uzkmm->text;
    if($reply=="🧙🏼‍♂Nik Tayyorlash uchun Ismingizni yoki so'z yuboring!"){
$Muhiddin13 = str_replace(["q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m","Q","E","R","T","Y","U","I","O","P","A","S","D","F","G","H","J","K","L","Z","X","C","V","B","N","M"],["𝕢","𝕨","𝕖","𝕣","𝕥","𝕪","𝕦","𝕚","𝕠","𝕡","𝕒","𝕤","𝕕","𝕗","𝕘","𝕙","𝕛","𝕜","𝕝","𝕫","𝕩","𝕔","𝕧","𝕓","𝕟","𝕞","ℚ","𝔼","ℝ","𝕋","𝕐","𝕌","𝕀","𝕆","ℙ","𝔸","𝕊","𝔻","𝔽","𝔾","ℍ","𝕁","𝕂","𝕃","ℤ","𝕏","ℂ","𝕍","𝔹","ℕ","𝕄"], $Muhiddin13);
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>$Muhiddin13,
 
    ]);
    }
    
    $Muhiddin14 = $uzkmm->text;
    if($reply=="🧙🏼‍♂Nik Tayyorlash uchun Ismingizni yoki so'z yuboring!"){
$Muhiddin14 = str_replace(["q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m","Q","E","R","T","Y","U","I","O","P","A","S","D","F","G","H","J","K","L","Z","X","C","V","B","N","M"],["ᶞ","ʷ","ᵉ","ʳ","ᵗ","ʸ","ᵘ","ᶦ","ᵒ","ᵖ","ᵃ","ˢ","ᵈ","ᶠ","ᵍ","ʰ","ʲ","ᵏ","ᶫ","ᶻ","ˣ","ᶜ","ᵛ","ᵇ","ᶰ","ᵐ","ᵟ","ᴱ","ᴿ","ᵀ","ᵞ","ᵁ","ᴵ","ᴼ","ᴾ","ᴬ","ˢ","ᴰ","ᶠ","ᴳ","ᴴ","ᴶ","ᴷ","ᴸ","ᶻ","ˣ","ᶜ","ⱽ","ᴮ","ᴺ","ᴹ"], $Muhiddin14);
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>$Muhiddin14,
 
    ]);
    }
    
    $Muhiddin15 = $uzkmm->text;
        if($reply=="🧙🏼‍♂Nik Tayyorlash uchun Ismingizni yoki so'z yuboring!"){
$Muhiddin15 = str_replace(["q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m","Q","E","R","T","Y","U","I","O","P","A","S","D","F","G","H","J","K","L","Z","X","C","V","B","N","M"],["ǫ","ᴡ","ᴇ","ʀ","ᴛ","ʏ","ᴜ","ɪ","ᴏ","ᴘ","ᴀ","s","ᴅ","ғ","ɢ","ʜ","ᴊ","ᴋ","ʟ","ᴢ","x","ᴄ","ᴠ","ʙ","ɴ","ᴍ","ǫ","ᴇ","ʀ","ᴛ","ʏ","ᴜ","ɪ","ᴏ","ᴘ","ᴀ","s","ᴅ","ғ","ɢ","ʜ","ᴊ","ᴋ","ʟ","ᴢ","x","ᴄ","ᴠ","ʙ","ɴ","ᴍ"], $Muhiddin15);
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>$Muhiddin15,
 
    ]);
    }

    if($reply=="🧙🏼‍♂Nik Tayyorlash uchun Ismingizni yoki so'z yuboring!"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"😊Nik Yoqdimi☝️

🎵Create by: $boot",
'parse_mode'=>'markdown',
'reply_markup'=>$qayt,
]);
}





?>