<?php
ob_start();
define('BEK_KODER','API_TOKEN');
$admin = "ADMIN_ID"; //admin id
$adminuser = "ADMIN_USER"; //admin user
$botname = bot('getme',['bot'])->result->username; //bot useri
$kanalim = file_get_contents("ch4.txt");
$rek_channel = "$kanalim"; //rek kanal
$kanalim1 = file_get_contents("ch5.txt");
$promokanal = "$kanalim1"; //rek kanal

echo file_get_contents("https://api.telegram.org/bot".BEK_KODER."/setwebhook?url=".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']);

function SendMessage($id,$mrk,$text){
return bot('SendMessage',[
'chat_id'=>$id,
'parse_mode'=>$mrk,
'text'=>$text,
]);
}
function DeleteMessage($ch,$m){
return bot('deletemessage',[
'chat_id'=>$ch,
'message_id'=>$m,
]);
}
function name($ch){
$c = bot('getchat',['chat_id' => "@".$ch]);
return $c->result->title;
}

function getAdmin($chat){
$url = "https://api.telegram.org/bot".BEK_KODER."/getChatAdministrators?chat_id=@".$chat;
$result = file_get_contents($url);
$result = json_decode ($result);
return $result->ok;
}

if(isset($message)){
  $gett = bot('getChatMember',[
  'chat_id'=>"@$kanalim",
  'user_id'=>$idi,
  ]);   
  $get = $gett->result->status;
  $geti = bot('getChatMember',[
  'chat_id'=>"@$kanalim1",
  'user_id'=>$idi,
  ]);   
  $geto = $geti->result->status;
  if($get != "member" and $get != "adminstrator" and $get != "creator" and $geto != "member" and $geto != "adminstrator" and $geto != "creator"){
  unlink("step/$idi.step");
  bot('sendMessage',[
  'chat_id'=>$idi,
  'text'=>"*🔐 @$kanalim kanalga obuna bo'ling va qaytadan /start bosing!*",
  'parse_mode'=>'markdown',
  'reply_to_message_id'=>$mid,
  'reply_markup'=>json_encode([
  'inline_keyboard'=>[
  [["text"=>"✅ Tasdiqlash","callback_data"=>"uz"],],
  ]]),
  ]); 
  return false;
  }
  }
  
  $salom = "*🖥 Bosh sahifaga qaytdingiz*";
  if($data=="uz"){
  $gett = bot('getChatMember',[
  'chat_id'=>"@".$pm_channel,
  'user_id'=>$from_id,
  ]);   
  $get = $gett->result->status;
  $geti = bot('getChatMember',[
  'chat_id'=>"@".$rek_channel,
  'user_id'=>$from_id,
  ]);   
  $geto = $geti->result->status;
  if(($get=="member" or $get=="adminstrator" or $get=="creator") and ($geto=="member" or $geto=="adminstrator" or $geto=="creator")){
  DeleteMessage($from_id,$mes_idi);
  bot('sendMessage',[
  'chat_id'=>$from_id,
  'parse_mode'=>'markdown',
  'text'=>$salom,
  'reply_markup'=>$key,
  ]);
  }else{
  bot('answercallbackquery',[
  'callback_query_id'=>$id,
  'text'=>"*🔐 @$kanalim kanalga obuna bo'ling !!*",
  'show_alert'=>true,
  ]);
  }
  }

function bot($method,$datas = []){
$url = "https://api.telegram.org/bot".BEK_KODER."/".$method;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
$res = curl_exec($ch);
if (curl_error($ch)) {
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}

$update = json_decode(file_get_contents('php://input'));
if(isset($update->message)){
$message = $update->message;
$mid = $message->message_id;
$re = array("[","]","(",")","*","_","`");
$name = str_replace($re, "", $message->from->first_name);
$users = $message->from->username;
$tx = $message->text;
$idi = $message->from->id;
$type = $message->chat->type;
}
if(isset($update->callback_query)){
$data = $update->callback_query->data;
$qid = $update->callback_query->id;
$cid2 = $update->callback_query->message->chat->id;
$mid2 = $update->callback_query->message->message_id;
$callfrid = $update->callback_query->from->id;
$callname = $update->callback_query->from->first_name;
$calluser = $update->callback_query->from->username;
$surname = $update->callback_query->from->last_name;
$mes_idi = $update->callback_query->message->message_id;  
$from_id = $update->callback_query->from->id;
$id = $update->callback_query->id;
}
if(!is_dir("coin") or !is_dir("step") or !is_dir("stat")){
mkdir("coin");
mkdir("step");
mkdir("soni");
mkdir("pmcoin");
mkdir("Otabek");
mkdir("Otabek/shikoyat");
mkdir("Otabek/pmshikoyati");
mkdir("Otabek/user");
mkdir("Otabek/pmuseri");
mkdir("stat");
}
$step = file_get_contents("step/$idi.step");
$fstep = file_get_contents("step/$from_id.step");
$ball = file_get_contents("coin/$idi.dat");
if(!$ball) $ball = 0;
$coin = file_get_contents("pmcoin/$idi.dat");
if(!$coin) $coin = 0;
$soni = file_get_contents("soni/$idi.soni");
if(!$soni) $soni = 0;
$from_ball = file_get_contents("coin/$from_id.dat");
if(!$from_ball) $from_ball = 0;
$lichka = file_get_contents("stat/lichka.db");

$key = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🗄 Buyurtma"],],
[['text'=>"💵 Pul Ishlash"],['text'=>"📱 Kabinet"],],
[['text'=>"💳 Promokod"],['text'=>"📚 Bot Haqida"],],
]]);

$bothaqida = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"📊 Statistika"]],
]]);

$pulishlash = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🗣 Taklifnoma"],['text'=>"🎁 Kunlik bonus"],],
[['text'=>"⬆️ Kanalga ko'rib"],],
]]);

$kabinet = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"💰 Hisobim"],['text'=>"🔄 Perevod"],],
]]);

$keyadmin = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🗄 Buyurtma"],],
[['text'=>"💵 Pul Ishlash"],['text'=>"📱 Kabinet"],],
[['text'=>"💳 Promokod"],['text'=>"📚 Bot Haqida"],],
[['text'=>"🗄 Boshqarish"],],
]]);


$botsoz = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🔗 Taklif narxi"],],
[['text'=>"📥 Minimal buyurtma"],['text'=>"🔰 Buyurtma kanali"],],
[['text'=>"🗄 Boshqarish"],],
]]); 

$orqaga = "🔙 Orqaga";
$key3 = json_encode([ 
'resize_keyboard'=>true, 
'keyboard'=>[ 
[['text'=>$orqaga]],
]]); 

if(stripos($tx,"/start")!==false){
$refid = explode(" ",$tx);
$refid = $refid[1];
if(strlen($refid)>0 and $refid>0){
if($refid==$idi){
SendMessage($idi,markdown,"*🖥 Bosh sahifaga qaytingiz*");
}else{
if(stripos($lichka,"$idi")!==false){
SendMessage($idi,markdown,"*🔎 Taklif qilgan do'stingiz botimizda avvaldan mavjud.*");
}else{
file_put_contents("soni/$refid.soni", file_get_contents("soni/$refid.soni") + 1);
$referal = file_get_contents("ch1.txt");
$usr = file_get_contents("coin/$refid.dat");
$usr = $usr + $referal;
file_put_contents("pmcoin/$refid.dat", $pm);
SendMessage($refid,markdown,"*🔗 Sizda yangi taklif bor. Hisobingizga $referal so'm qo'shildi_ 💵");
}
}
}
}

if($tx=="/panel" and $idi==$admin){
    bot('SendMessage',[
    'chat_id'=>$idi,
    'text'=>"Admin paneli xush kelibsiz!",
    'reply_markup'=>$keyadmin,
    ]);
    }

//admin bo'limi
$bekor = "⬅️ Bekor qilish";
$panel = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"📨 Xabar yuborish"],['text'=>"🖼 Forward xabar yuborish"]],
[['text'=>"➕ Ball berish"],['text'=>"➖ Ball ayirish"],],
[['text'=>"➕ Hammaga ball berish"],['text'=>"👁‍🗨 Prasmotr uchun ball qo'shish"]],
[['text'=>"⚙️ Botni Sozlash"],['text'=>"💳 Promokod Yaratish"]],
[['text'=>$orqaga],],
]]);

if($tx==$bekor){
unlink("step/$idi.step");
bot('sendMessage',[
"chat_id"=>$idi,
"text"=>"Ok",
"reply_markup"=>$panel,
]);
}

$bkey = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>$bekor]],
]]);

if($tx=="🗄 Boshqarish" and $idi==$admin){
bot('sendMessage',[
"chat_id"=>$admin,
"text"=>"Salom, Siz bot administratorisiz. Kerakli boʻlimni tanlang:",
"reply_markup"=>$panel,
]);
}

if($tx=="⚙️ Botni Sozlash" and $idi==$admin){
bot('sendMessage',[
"chat_id"=>$admin,
"text"=>"Salom Botlarni Sozlash menyusidasiz,Kerakli boʻlimni tanlang:",
"reply_markup"=>$botsoz,
]);
}

if($tx=="💳 Promokod Yaratish" and $idi==$admin){
    bot('sendmessage',[ 
  'chat_id'=>$idi, 
  'text'=>"Promo kodni kiriting!🚀 
✋🏻Bekor qilish uchun /otmena
Promo kod $promokanal kanalida e'lon qilinadi! ", 
  ]); 
file_put_contents("step/$idi.step","setcode");  
  } 
if ($step == 'setcode') { 
if ($tx != "/otmena") { 
         bot('sendmessage',[ 
         'chat_id'=>$idi, 
         'text'=>"❗️Promo kod yaratildi endi tanga sonini kirting!
✋🏻Bekor qilish uchun /otmena", 
 ]);  
file_put_contents("step/$idi.step","setcoin");  
file_put_contents("code.txt","$tx");  
} 
} 

if ($step == 'setcoin') { 
if ($tx != "/otmena") { 
file_put_contents("coin.txt","$tx");  
$code = file_get_contents("code.txt");
         bot('sendmessage',[ 
         'chat_id'=>$idi, 
         'text'=>"🎁Promo kod $promokanal ga yuborildi", 
 ]); 
          bot('sendmessage',[ 
         'chat_id'=>"$promokanal", 
         'text'=>"🚀O'yin boshlandi, Siz ham ball oling 
 
🔐 Promokod : <code>$code</code>
 
📦 Ball miqdori: $text ball 
 
 
🤖 Botga kirish👉: @$botname", 
 ]); 
file_put_contents("step/$idi.step","");  
} 
}

if($tx=="🔗 Taklif narxi" and $idi==$admin){
bot('sendMessage',[
"chat_id"=>$admin,
"text"=>"Taklif narxini quidagidek almashtiring
Namuna:
/odam-10 ushbu buyruq orqali o'zgartira olasiz!",
"reply_markup"=>$botsoz,
]);
}

if(mb_stripos($tx, "/odam-")!==false){
  $m1 = explode("-",$tx);
 $m2 = $m1[1];
 file_put_contents("ch1.txt","$m2");
 bot('sendMessage',[
'chat_id'=>$admin,
'text'=>"Taklif narxi $m2 ga o'zgardi!",
 ]);
}

if($tx=="📥 Minimal buyurtma" and $idi==$admin){
bot('sendMessage',[
"chat_id"=>$admin,
"text"=>"Minimal buyurtma va azo narxini quidagidek almashtiring!
Namuna:
/minimal-200
/azo-2",
"reply_markup"=>$botsoz,
]);
}

if(mb_stripos($tx, "/minimal-")!==false){
    $m1 = explode("-",$tx);
   $m2 = $m1[1];
   file_put_contents("ch2.txt","$m2");
   bot('sendMessage',[
  'chat_id'=>$admin,
  'text'=>"Minimal buyurtma $m2 ga o'zgardi!",
   ]);
  }

if(mb_stripos($tx, "/azo-")!==false){
    $m1 = explode("-",$tx);
   $m2 = $m1[1];
   file_put_contents("ch3.txt","$m2");
   bot('sendMessage',[
  'chat_id'=>$admin,
  'text'=>"Azo narxi $m2 ga o'zgardi!",
   ]);
  }

if($tx=="🔰 Buyurtma kanali" and $idi==$admin){
bot('sendMessage',[
"chat_id"=>$admin,
"text"=>"Kanalingizni quidagidek o'zgartiring!
/kanal-VipKons @ belgi qo'ymang!
Promokod kanalini:
/prkanal-VipKons @ belgi qo'ymang",
"reply_markup"=>$botsoz,
]);
}

if(mb_stripos($tx, "/kanal-")!==false){
    $m1 = explode("-",$tx);
   $m2 = $m1[1];
   file_put_contents("ch4.txt","$m2");
   bot('sendMessage',[
  'chat_id'=>$admin,
  'text'=>"Buyurtma kanali @$m2 ga o'zgardi!",
   ]);
  }

if(mb_stripos($tx, "/prkanal-")!==false){
    $m1 = explode("-",$tx);
   $m2 = $m1[1];
   file_put_contents("ch5.txt","$m2");
   bot('sendMessage',[
  'chat_id'=>$admin,
  'text'=>"Promokod kanali @$m2 ga o'zgardi!",
   ]);
  }

if($tx == "➕ Ball berish" and $idi == $admin){
bot('sendmessage',[
'chat_id'=>$idi,
'text'=> "<b>✅Ball berish uchun quyidagi buyruqni bajaring!
Bir qator pastga tushib id raqamni yozing, yana bir qator pastga tushib olmosni yozing!
Masalan:</b>
<code>/plus
$admin
1000</code>",
'parse_mode' => 'html',
'reply_markup'=>$keys,
]);
}elseif(mb_stripos($tx, "/plus")!==false){
if($idi == $admin){
$id = explode("n", $tx);
$id1 = $id[1]; $id2 = $id[2];
$ball = file_get_contents("coin/$idi.dat");
$miqdor = $ball+$id2;
file_put_contents("coin/$idi.dat","$miqdor");
bot('sendmessage',[
'chat_id'=>$idi,
'text'=> "<b>🛠 Hisobi to'ldirildi.
🆔 Id raqami : $id1
💳 To'ldirildi : $id2 Ball</b>",
'parse_mode' => 'html',
'reply_markup'=>$menu,
]);
bot("sendmessage",[
'chat_id'=>$id1,
'text'=> "*🛠 Hisobingiz $id2 Ball ga to'ldirildi.*",
'parse_mode'=>'Markdown',
]);
}else{
 bot("sendmessage",[
'chat_id'=>$idi,
'text'=> "*Bu bo‘limni faqat bot administratori ishlata oladi!*",
'parse_mode'=>'Markdown',
]);
}
}


if($text == "➖ Ball ayirish" and $idi == $admin){
bot('sendmessage',[
'chat_id'=>$idi,
'text'=> "<b>✅Ball ayirish uchun quyidagi buyruqni bajaring!
Bir qator pastga tushib id raqamni yozing, yana bir qator pastga tushib olmosni yozing!
Masalan:
/minus
$admin
1000</b>",
'parse_mode' => 'html',
'reply_markup'=>$keys,
]);
}elseif(mb_stripos($tx, "/minus")!==false){
if($idi == $admin){
$id = explode("n", $tx);
$id1 = $id[1]; $id2 = $id[2];
$olmos = file_get_contents("coin/$idi.dat");
$miqdor = $olmos-$id2;
file_put_contents("coin/$idi.dat","$miqdor");
bot('sendmessage',[
'chat_id'=>$idi,
'text'=> "<b>🛠 Hisobi Yechildi.
🆔 Id raqami : $id1
💳 Yechildi : $id2 Ball</b>",
'parse_mode' => 'html',
'reply_markup'=>$menu,
]);
bot("sendmessage",[
'chat_id'=>$id1,
'text'=> "*🛠 Hisobingiz $id2 Ball ga Yechildi.*",
'parse_mode'=>'Markdown',
]);
}else{
 bot("sendmessage",[
'chat_id'=>$idi,
'text'=> "*Bu bo‘limni faqat bot administratori ishlata oladi!*",
'parse_mode'=>'Markdown',
]);
}
}

if($tx=="➕ Hammaga ball berish" and $idi==$admin){
file_put_contents("step/$idi.step","scoreall");
bot('SendMessage',[
'chat_id'=>$idi,
'text'=>"Kerakli Summani Kiriting:",
'reply_markup'=>$bkey,
]);
}

if($step=="scoreall" and $idi==$admin and $tx != $bekor){
$pl = $tx;
$Member = explode("n",$lichka);
$count = substr_count($lichka,"n");
for($z = 0;$z <= $count;$z++){
$user = $Member[$z];
$dat = file_get_contents("coin/$user.dat");
$put = $dat + $pl;
file_put_contents("coin/$user.dat","$put");
$pdat = file_get_contents("pmcoin/$user.dat");
$pput = $pdat + $pl;
file_put_contents("pmcoin/$user.dat","$pput");
SendMessage($user,html,"<b>🤖 barchaga $tx so'm bonus tarqatildi</b>");
}
unlink("step/$admin.step");
SendMessage($idi,html,"Foydalanuvchilarga $tx Ball Berildi!");
}

if($tx=="🖼 Forward xabar yuborish" and $idi==$admin){
file_put_contents("step/$idi.step","send_post");
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"Forward xabar yuboring:",
"reply_markup"=>$bkey,
]);
}

if($step=="send_post" and $idi==$admin and $tx != $bekor){
file_put_contents("stat/az.txt", $lichka);
$lich = file_get_contents("stat/az.txt");
unlink("stat/lichka.db");
$im = explode("n",$lich);
$us = substr_count($lich,"n");
for($i = 0; $i < $us; $i++){
$id = $im[$i];
$yu = bot('forwardMessage',[
"chat_id"=>$id,
"from_chat_id"=>$idi,
"message_id"=>$mid,
]);
if($yu->ok){
file_put_contents("stat/lichka.db","n".$id,FILE_APPEND);
}else{
unlink("coin/$id.dat");
unlink("step/$id.step");
unlink("soni/$id.soni");
unlink("pmcoin/$id.dat");
}
}
unlink("step/$idi.step");
$ok = substr_count(file_get_contents("stat/lichka.db") ,"n");
$no = $us - $ok;
SendMessage($idi,markdown,"🆗 Xabaringiz $ok ta odamga yuborildi! $no ta odamga yuborilmadi! ♻️ Bot statistikasi yangilandi!");
}


if($tx=="👁‍🗨 Prasmotr uchun ball qo'shish" and $idi==$admin){
file_put_contents("step/$idi.step","pmbalplus");
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"Ball qo'shmoqchi bo'lgan odamingiz ID raqamini kiriting:",
"reply_markup"=>$bkey,
]);
}     
      
if($step=="pmbalplus" and $idi==$admin and $tx==$bekor){
if(strpos($lichka,"$tx") !==false){
file_put_contents("step/Admin.text","$tx");
file_put_contents("step/$idi.step","pmballi");
SendMessage($admin,html,"Qancha ball qo'shmoqchisiz:");
}else{
SendMessage($idi,html,"Botda bunday foydalanuvchi mavjud emas!");
}
}

if($step=="pmballi" and $idi==$admin and $tx==$bekor){
$ID = file_get_contents("step/Admin.text");
$bal =  file_get_contents("pmcoin/$ID.dat");
$jami = $bal + $tx;
file_put_contents("pmcoin/$ID.dat","$jami");
SendMessage($ID,html,"💰 Hisobingiz: $tx ballga to'ldirildi!
Hozirgi hisobingiz: $jami");
bot("sendMessage",[
"chat_id"=>$admin,
"parse_mode"=>'markdown',
"text"=>"[Foydalanuvchi](tg://user?id=$ID) balansi $tx ballga toʻldirildi!",
"reply_markup"=>$panel,
]);
unlink("step/$idi.step");
unlink("step/Admin.text");
}
      
if($tx=="➖dfd" and $idi==$admin){
file_put_contents("step/$idi.step","balminus");
bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"Ball ayirmoqchi bo'lgan odamingiz ID raqamini kiriting:",
"reply_markup"=>$bkey,
]);
}     

if($step=="balminus" and $idi==$admin and $tx==$bekor){
if(strpos($lichka,"$tx") !==false){
file_put_contents("step/Admin.text","$tx");
file_put_contents("step/$idi.step","balm");
SendMessage($admin,html,"Qancha ball ayirmoqchisiz:");
}else{
SendMessage($idi,html,"Botda bunday foydalanuvchi mavjud emas!");
}
}

if($step=="balm" and $idi==$admin and $tx==$bekor){
$ID = file_get_contents("step/Admin.text");
$bal =  file_get_contents("coin/$ID.dat");
$jami = $bal - $tx;
file_put_contents("coin/$ID.dat","$jami");
$ball =  file_get_contents("pmcoin/$ID.dat");
$jam = $ball - $tx;
file_put_contents("pmcoin/$ID.dat","$jam");
SendMessage($ID,html,"<b>📱 Hisobingizda $tx so'm ayrildi.</b>");
bot("sendMessage",[
"chat_id"=>$admin,
"parse_mode"=>'markdown',
"text"=>"[Foydalanuvchi](tg://use?id=$ID) balansidan $tx ball ayrildi!",
"reply_markup"=>$panel,
]);
unlink("step/$idi.step");
unlink("step/Admin.text");
}

if(strpos($tx,"/start")!==false){
bot('sendMessage',[
'chat_id'=>$idi,
'parse_mode'=>'markdown',
'text'=>$salom,
'reply_markup'=>$key,
]);
}


$ex = explode("=",$data);
$by = $ex[1];
$adm = $ex[2];
$ch = $ex[3];
if(stripos($data,"rekball=")!==false && stripos($lichka,"$from_id")!==false){
$ue = file_get_contents("Otabek/user/$mes_idi.txt");
if(stripos($ue,"$from_id") !== false){
bot('answercallbackquery', [
'callback_query_id'=>$id,
'text'=>"⚠️ Vazifani oldinroq bajargansiz.",
'show_alert'=> true,
]);
}else{
$okch = json_decode(file_get_contents("https://api.telegram.org/bot".BEK_KODER."/getChatMember?chat_id=@".$ch."&user_id=".$from_id))->result->status;
if($okch=='member' || $okch=='creator' || $okch=='administrator'){
$user = substr_count(file_get_contents("Otabek/user/$mes_idi.txt"),"n");
if($user>=5){
$rball = 5;
}else{
$rball = 3;
}
file_put_contents("Otabek/user/$mes_idi.txt","n".$from_id,FILE_APPEND);
$dat = file_get_contents("coin/$from_id.dat");
$get = $dat + $rball;
file_put_contents("coin/$from_id.dat","$get");
bot('answercallbackquery',[
'callback_query_id'=>$id,
'text'=>"✅ Sizning hisobingizga 1 so'm qo'shildi.",
'show_alert'=> true,
]);     
}else{
bot('answercallbackquery', [
'callback_query_id'=>$id,
'text'=>"‼️Kanalga obuna bo'lmadingiz",
'show_alert'=> true,
]);
}
}
$okey = substr_count(file_get_contents("Otabek/user/$mes_idi.txt"),"n");
$sh = substr_count(file_get_contents("Otabek/shikoyat/$mes_idi.txt"),"n"); 
if($okey>=$by){
DeleteMessage("@".$rek_channel,$mes_idi);     
SendMessage($adm,markdown,"*⏳ Sizning $mes_idi - soni buyurtmangiz muvaffaqiyatli bajarildi ✅*");
unlink("Otabek/user/$mes_idi.txt");
unlink("Otabek/shikoyat/$mes_idi.txt");
}
if(getAdmin($ch) != true){
DeleteMessage("@".$rek_channel,$mes_idi);     
SendMessage($adm,markdown,"*🗑 Sizning $mes_idi - sonli buyurtmangiz bekor qilindi.
📋 Sabab : Botni adminlikdan olib tashladingiz.*"); 
unlink("Otabek/user/$mes_idi.txt");
unlink("Otabek/shikoyat/$mes_idi.txt");
}   
bot('editmessagetext',[
'chat_id'=>"@".$rek_channel,
'parse_mode'=>'markdown',
'text'=>"*✅ Quyidagi kanalga obuna bo'ling:*

➡️ [@$ch]
*💵 Botga qayting va tekshirish tugmasini bosing
🤖 @$botname*",
'message_id'=>$mes_idi,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"⏩ Kanalga kirish",'url'=>"https://t.me/$ch"],],
[['text'=>"✅ Tekshirish",'callback_data'=>"rekball=$by=$adm=$ch"],],
[['text'=>"🗄 Info",'callback_data'=>"info=$by=$adm=$ch"],['text'=>"⚠ Shikoyat",'callback_data'=>"shikoyat=$by=$adm=$ch"],],
[['text'=>"➡ Botga kirish",'url'=>"https://t.me/$bot"],],
]])
]);
}




if(stripos($data,"shikoyat=")!==false && stripos($lichka,"$from_id")!==false){
$s = file_get_contents("Otabek/shikoyat/$mes_idi.txt");
if(stripos($s,"$from_id") !== false){
bot('answercallbackquery', [
'callback_query_id'=>$id,
'text'=>"❌ Ilgari shikoyat qilgansiz.",
'show_alert'=> true,
]);
}else{
file_put_contents("Otabek/shikoyat/$mes_idi.txt","n".$from_id,FILE_APPEND);
bot('answercallbackquery',[
'callback_query_id'=>$id,
'text'=>"⚠️ Shikoyat qilindi.",
'show_alert'=> true,
]);
$sh = substr_count(file_get_contents("Otabek/shikoyat/$mes_idi.txt"),"n");     
bot('sendMessage',[
'chat_id'=>$adm,
'parse_mode'=>'markdown',
'text'=>"*⚠️Sizning* [$mes_idi](https://t.me/$rek_channel/$mes_idi) *sonli buyurtmangiz shikoyat qilindi.*",
'disable_web_page_preview'=>true,
]);
}
$sh = substr_count(file_get_contents("Otabek/shikoyat/$mes_idi.txt"),"n");     
$okey = substr_count(file_get_contents("Otabek/user/$mes_idi.txt"),"n");
bot('editmessagetext',[
'chat_id'=>"@".$rek_channel,
'parse_mode'=>'markdown',
'text'=>"*✅ Quyidagi kanalga obuna bo'ling:*

➡️ [@$ch]
*💵 Botga qayting va tekshirish tugmasini bosing
🤖 @$botname*",
'message_id'=>$mes_idi,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"⏩ Kanalga kirish",'url'=>"https://t.me/$ch"],],
[['text'=>"✅ Tekshirish",'callback_data'=>"rekball=$by=$adm=$ch"],],
[['text'=>"🗄 Info",'callback_data'=>"info=$by=$adm=$ch"],['text'=>"⚠ Shikoyat",'callback_data'=>"shikoyat=$by=$adm=$ch"],],
[['text'=>"➡ Botga kirish",'url'=>"https://t.me/$bot"],],
]])
]);
if($sh>=5){
DeleteMessage("@".$rek_channel,$mes_idi); 
SendMessage($adm,markdown,"*⚠️ Shikoytlar 5 taga yetdi va buyurtma bekor qilindi 🗑
🆔 Buyurtma raqami : $mes_idi*");
unlink("Otabek/user/$mes_idi.txt");
unlink("Otabek/shikoyat/$mes_idi.txt");
}
if(getAdmin($ch) != true){                     
DeleteMessage("@".$rek_channel,$mes_idi); 
SendMessage($adm,markdown,"*🤖 Bot kanalda adminlikdan olindi va buyurtma bekor qilindi 🗑
🆔 Buyurtma raqami : $mes_idi*");        
unlink("Otabek/user/$mes_idi.txt");
unlink("Otabek/shikoyat/$mes_idi.txt");
}
}

if(stripos($data,"info=")!==false){
$idi = bot('getchat',['chat_id'=>"@".$ch,])->result->id;
$azolar = bot('getChatMembersCount',['chat_id'=>"@".$ch,])->result;
$okey = substr_count(file_get_contents("Otabek/user/$mes_idi.txt"),"n");
$sh = substr_count(file_get_contents("Otabek/shikoyat/$mes_idi.txt"),"n");
bot('answercallbackquery',[
'callback_query_id'=>$id,
'text'=>"🗄 Buyurtma haqida :

📚 Nomi : ".name($ch)."
🔗 Manzili : @$ch
🆔 Id raqami : $idi
🗣 Buyurtma : $by ta
✅ Bajarildi : $okey ta
Reklama: @VipKonsBot",
'show_alert' => true,
]);
if(getAdmin($ch) != true){                     
DeleteMessage("@".$rek_channel,$mes_idi); 
SendMessage($adm,markdown,"*🤖 Bot kanalda adminlikdan olindi va buyurtma bekor qilindi 🗑
🆔 Buyurtma raqami : $mes_idi*");        
unlink("Otabek/user/$mes_idi.txt");
unlink("Otabek/shikoyat/$mes_idi.txt");
}
}

$ex = explode("=",$data);
$fid = $ex[1];
$pm = $ex[2];
$adm = $ex[3];
if(stripos($data,"ostib=")!==false && strpos($lichka,"$from_id")!==false){
$ue = file_get_contents("Otabek/pmuseri/$mes_idi.txt");
if(strpos($ue,"$from_id") !== false){
bot('answercallbackquery', [
'callback_query_id'=>$id,
'text'=>"⚠️ Vazifani oldinroq bajargansiz.",
'show_alert'=>false,
]);
}else{
$user = substr_count(file_get_contents("Otabek/pmuseri/$mes_idi.txt"),"n");
if($user>=5){
$pball = 30;
}else{
$pball = 40;
}
file_put_contents("Otabek/pmuseri/$mes_idi.txt","n".$from_id,FILE_APPEND);
$dat = file_get_contents("pmcoin/$from_id.dat");
$get = $dat + $pball;
file_put_contents("pmcoin/$from_id.dat","$get");
bot('answercallbackquery',[
'callback_query_id'=>$id,
'text'=>"💰 Siz $pball ball oldingiz! Jami $get",
'show_alert'=>false,
]);     
}
$kk = substr_count(file_get_contents("Otabek/pmuseri/$mes_idi.txt"),"n");
$sh = substr_count(file_get_contents("Otabek/pmshikoyati/$mes_idi.txt"),"n"); 
bot('editmessagetext',[
'chat_id'=>"@".$pm_channel,
'parse_mode'=>'markdown',
'text'=>"*•Buyurtma raqami: $fid*n—————————————n•Ko'rish soni: *$pm *ta!n•Ko'rildi: *$kk* ta!n•Shikoyatlar: *$sh* ta!",
'message_id'=>$mes_idi,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Tekshirish",'callback_data'=>"ostib=$fid=$pm=$adm"],['text'=>"⚠",'callback_data'=>"mjalb=$fid=$pm=$adm"],],
]])
]);
if($kk>=$pm){
$del = $mes_idi - 1;
DeleteMessage("@".$pm_channel,$del);
DeleteMessage("@".$pm_channel,$mes_idi);
SendMessage($adm,markdown,"*🎊Sizning $fid - raqamli prasmotr buyurtmangiz muaffaqiyatli yakunlandi!n🎉Bizning botdan foydalanganingiz uchun katta rahmat!*");
unlink("Otabek/pmuseri/$mes_idi.txt");
unlink("Otabek/pmshikoyati/$mes_idi.txt");
}   
}

if(stripos($data,"mjalb=")!==false && strpos($lichka,"$from_id")!==false){
$s = file_get_contents("Otabek/pmshikoyati/$mes_idi.txt");
if(strpos($s,"$from_id") !== false){
bot('answercallbackquery', [
'callback_query_id'=>$id,
'text'=>"Siz shikoyat qilib bo'lgansiz❗️",
'show_alert'=>false
]);
}else{
file_put_contents("Otabek/pmshikoyati/$mes_idi.txt","n".$from_id,FILE_APPEND);
bot('answercallbackquery',[
'callback_query_id'=>$id,
'text'=>"☑️Shikoyatingiz qabul qilindi!",
'show_alert'=>false
]);
$sh = substr_count(file_get_contents("Otabek/pmshikoyati/$mes_idi.txt"),"n");   
$m_id = $mes_idi - 1;  
bot('sendMessage',[
'chat_id'=>$adm,
'parse_mode'=>'markdown',
'text'=>"*⭕️Sizning* [$m_id](https://t.me/$pm_channel/$m_id) *- sonli prasmotr buyurtmangiz* [foydalanuvchi](tg://user?id=$from_id) *tomonidan shikoyat qilindi! ♻️Hozirgi shikoyatlar soni: $sh ta! ✅Agar shikoyatlar soni 5 taga yetsa buyurtmangiz avtomatik o'chiriladi!*",
'disable_web_page_preview'=>true,
]);
}
$ok = substr_count(file_get_contents("Otabek/pmuseri/$mes_idi.txt"),"n");
$sh = substr_count(file_get_contents("Otabek/pmshikoyati/$mes_idi.txt"),"n");
bot('editmessagetext',[
'chat_id'=>"@".$pm_channel,
'parse_mode'=>'markdown',
'text'=>"*•Buyurtma raqami: $fid*n—————————————n•Ko'rish soni: *$pm* ta!n•Ko'rildi: *$ok* ta!n•Shikoyatlar: *$sh* ta!",
'message_id'=>$mes_idi,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Tekshirish",'callback_data'=>"postib=$fid=$pm=$adm"],['text'=>"⚠",'callback_data'=>"mjalb=$fid=$pm=$adm"],],
]])
]);
if($sh>=5){
$del = $mes_idi - 1;
DeleteMessage("@".$pm_channel,$del); 
DeleteMessage("@".$pm_channel,$mes_idi); 
SendMessage($adm,markdown,"*❌Sizning $del - sonli buyurtmangiz yakunlandi!n⭕️Sabab: Shikoyatlar soni 5 taga yetdi!*");
unlink("Otabek/pmuseri/$mes_idi.txt");
unlink("Otabek/pmshikoyati/$mes_idi.txt");
}
}  

if($tx=="📊 Statistika"){
$odam = substr_count($lichka,"n");
$rek = file_get_contents("stat/reklar.soni");
$post = file_get_contents("stat/forlar.soni");
bot('sendMessage',[ 
'chat_id'=>$idi, 
'parse_mode'=>'markdown', 
'text'=>"*📊 Statistika

- Bot a'zolari : *$odam
*- Buyurtmalar : *$rek
*- Admin : *@$adminuser",
'reply_markup'=>$key, 
]);
}  

if($tx=="📜 Qoidalar"){
bot('sendMessage',[ 
'chat_id'=>$idi, 
'parse_mode'=>'markdown', 
'text'=>"*Qoidalar topilmadi*",
'reply_markup'=>$key, 
]);
}  

if($tx=="📚 Bot Haqida"){
bot('sendMessage',[ 
'chat_id'=>$idi, 
'parse_mode'=>'markdown', 
'text'=>"*Bu bo'lim orqali bot haqida bilib olishingiz mumkin!*",
'reply_markup'=>$bothaqida, 
]);
}  

  
if($tx=="💵 Pul Ishlash"){
bot('sendmessage',[
'chat_id'=>$idi,
'text'=>"*Qay usulda Pul ishlaymiz!*",
'parse_mode'=>'markdown',
'reply_markup'=>$pulishla,
]);
}

if($tx=="🗣 Taklifnoma"){
    bot('sendmessage',[
    'chat_id'=>$idi,
    'text'=>"*🔗 Sizning taklif havolangiz :
    
    [https://t.me/$botname?start=$idi]
    
    🔗 Havola orqali kirgan har bir do'stingiz uchun $referal so'mga ega bo'ling.*",
    'parse_mode'=>'markdown',
    'reply_markup'=>$key,
    ]);
    }

if($tx=="💳 Promokod"){ 
    bot('sendmessage',[
    'chat_id'=>$idi, 
    'text'=>"Kodni kiriting...", 
    ]);  
    file_put_contents("step/$idi.step","getcoin"); 
    } 
    if($step == 'getcoin') { 
    $code = file_get_contents("code.txt");
    if($tx == $code) { 
    $coincode = file_get_contents("coin.txt");
    $ball = file_get_contents("coin/$idi.dat");
    $sum = $ball + $coincode;
    file_put_contents("coin/$idi.dat","$sum");  
    bot('sendmessage',[ 
    'chat_id'=>$idi, 
    'text'=>"🥳 Tabriklaymiz siz yuborgan promokod to'g'ri $coincode ball yutib oldingiz!", 
    ]); 
    bot('sendmessage',[ 
    'chat_id'=>"$promokanal", 
    'text'=>"💳Promokod ishlatildi!nUshbu kod endi qayta ishlatib bo'lmaydi.", 
         ]); 
        unlink("code.txt");
        unlink("coin.txt"); 
        file_put_contents("step/$idi.step","");  
    
        } else { 
         bot('sendmessage',[ 
                 'chat_id'=>$idi, 
        'text'=>"😔Afsuskiy siz promokod ishlatishga ulgurmadiz!", 
        ]); 
        } 
        }

if($tx=="📱 Kabinet"){
    bot('sendMessage',[ 
    'chat_id'=>$idi, 
    'parse_mode'=>'markdown', 
    'text'=>"*👤Shaxsiy kabinetingizga xush kelibsiz!*",
    'reply_markup'=>$kabinet, 
    ]);
    }  

if($tx=="💰 Hisobim"){
if($users){
$users = "@$users";
}else{
$users = "🚫Kiritilmagan";
}	     
bot('sendMessage',[
'chat_id'=>$idi,
'parse_mode'=>'markdown',
'text'=>"*📱 Kabinet*

*💵 Sizning hisobingiz : *$ball *so'm
🆔 Id raqamingiz : *$idi",
'reply_markup'=>$key,
]);
}

if($tx=="📚 Ma'lumot"){
bot('sendMessage',[ 
'chat_id'=>$idi,
'parse_mode'=>'markdown', 
'text'=>"_🤖 Bot orqali kanalingizga faol o'zbek obunachilar va ko'rishlar sonini ko'paytirib olishingiz mumkin ✅_",
'reply_markup'=>json_encode([
'inline_keyboard'=>[ 
[['text'=>"➡ Admin",'url'=>"https://telegram.me/$adminuser"],],
]]) 
]); 
} 

if($tx==$orqaga){
unlink("step/$idi.step");
unlink("step/Admin.text");
bot('sendMessage',[
'chat_id'=>$idi,
'parse_mode'=>'markdown',
'text'=>"*🖥 Bosh sahifaga qaytdingiz*",
'reply_markup'=>$key,
]);
}
if($data=="orqaga"){
DeleteMessage($from_id,$mes_idi);
unlink("step/$from_id.step");
bot('sendMessage',[
'chat_id'=>$from_id,
'parse_mode'=>'markdown',
'text'=>"*🖥 Bosh sahifaga qaytdingiz*",
'reply_markup'=>$key,
]);
}


if($tx=="🗄 Buyurtma"){
$buyurtma = file_get_contents("ch2.txt");
$azo = file_get_contents("ch3.txt");
if($ball>=$buyurtma){
$koder = $ball / $azo;
$otabek = floor($koder);
bot('sendmessage', [
'chat_id'=>$idi,
'text'=>"*🔢 Nechta a'zo buyurtma qilmoqchisiz ?

1 ta a'zo = $azo so'm

📱 Sizda $ball so'm mavjud

🗣 Sizda $otabek ta a'zo uchun yetarli mablag' mavjud.

🤖 Kerakli a'zolar sonini kiriting ...*",
'parse_mode'=>'markdown',
'reply_to_message_id'=>$mid,
'reply_markup'=>$key3,
]);
file_put_contents("step/$idi.step","kerakli");
}else{
bot('sendMessage',[ 
'chat_id'=>$idi, 
'parse_mode'=>'markdown', 
'text'=>"*⚠️ Buyurtma uchun eng kamida $buyurtma so'm pul bo'lishi kerak

➡️ Sizning hisobingiz : $ball so'm*",
'reply_markup'=>$key,
]);
}
}

if($step=="kerakli"){
if($tx==$orqaga or $tx=="/start"){
unlink("step/$idi.step");
}else{
$fsom = file_get_contents("coin/$idi.dat");
$a = $tx * 1;
if($fsom>=$a){
bot('sendMessage',[
'chat_id'=>$idi,
'parse_mode'=>'markdown',
'text'=>"*🔗 Endi kanalingiz manzilini yuboring :

✅ Namuna : @VipKonsBot*",
'reply_to_message_id'=>$mid,
'reply_markup'=>$key3,
]);
file_put_contents("step/$idi.step","reklama=$tx");
}else{
send($idi,html,"🗄 Ushbu buyurtmani ro'yxatdan o'tkazish uchun hisobingizda mablag' yetarli emas ⚠️");
}
}
} 

if(stripos($step,"reklama=")!==false){
if($tx==$orqaga or $tx=="/start"){ 
unlink("step/$idi.step");
}else{
$som = file_get_contents("coin/$idi.dat");
$by = str_replace("reklama=","",$step);
$a = $by * 1;
if($som>=$a){
if(stripos($tx,"@")!==false){
$get = bot('getChat',['chat_id'=>$tx]);
$types = $get->result->type;
$ch_name = $get->result->title;
$ch_user = $get->result->username;
if($types != "supergroup" and $types != "group"){
if($types=="channel"){
bot('sendMessage',[
'chat_id'=>$idi,
'parse_mode'=>'markdown',
'text'=>"🗄 Buyurtma :

- Kanal nomi : [$ch_name]
- Kanal manzili : [@$ch_user]
- Buyurtma : $by ta a'zo

Agar hammasi to'g'ri bo'lsa
« ✅ Tasdiqlash » tugmasini bosing.",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Tasdiqlash",'callback_data'=>"true=$ch_user=$by"]],
]])
]);
file_put_contents("step/$idi.step","trueresult");
}else{
SendMessage($idi,markdown,"*⚠️ Bunday kanal topilmadi.
Tekshirib ko'rib, qayta urining.*");
}
}else{
send($idi,markdown,"*⚠️ Guruh qo'shish mumkin emas.*");
}
}else{
SendMessage($idi,markdown,"*📚 Namunadagidek yuboring

✅ Namuna : @VipKons*");
}
}else{
send($idi,html,"🗄 Ushbu buyurtmani ro'yxatdan o'tkazish uchun hisobingizda mablag' yetarli emas ⚠️");
}
}
}

if($fstep=="trueresult"){
if(stripos($data,"true=")!==false){
$ex = explode("=",$data);
$ch = $ex[1];
$by = $ex[2];
if(getAdmin($ch) != true){
bot('answercallbackquery', [
'callback_query_id'=>$id,
'text'=>"*🤖 Bot kanalda admin emas.
Tog'irlab, qayta urining.*",
'show_alert'=>true,
]);
}else{
DeleteMessage($from_id,$mes_idi);
$msg_id = bot('sendmessage',[
'chat_id'=>"@".$rek_channel,
'parse_mode'=>'markdown',
'text'=>"*✅ Quyidagi kanalga obuna bo'ling:*

➡️ [@$ch]
*💵 Botga qayting va tekshirish tugmasini bosing
🤖 @$bot*",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"⏩ Kanalga kirish",'url'=>"https://t.me/$ch"],],
[['text'=>"✅ Tekshirish",'callback_data'=>"rekball=$by=$from_id=$ch"],],
[['text'=>"🗄 Info",'callback_data'=>"info=$by=$from_id=$ch"],['text'=>"⚠ Shikoyat",'callback_data'=>"shikoyat=$by=$from_id=$ch"]],
[['text'=>"➡ Botga kirish",'url'=>"https://t.me/$bot"],],
]])
])->result->message_id;
unlink("step/$from_id.step");
if($msg_id>1){
file_put_contents("stat/reklar.soni", file_get_contents("stat/reklar.soni") + 1);
$ball = file_get_contents("coin/$from_id.dat");
$put = $ball - $by; 
file_put_contents("coin/$from_id.dat","$put"); 
bot('sendMessage',[
'chat_id'=>$from_id,
'parse_mode'=>'markdown',
'text'=>"*🗄 Buyurtma muvaffaqiyatli ro'yxatdan o'tdi.

⁉️ Eslatma : botni adminlikdan olmang. Buyurtma bekor qilinadi.*", 
'reply_markup'=>$key,
]);
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"🗄 Buyurtmangizni ko'rish uchun
« ✅ Ko'rish » tugmasini bosing.", 
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Ko'rish",'url'=>"https://t.me/$rek_channel/$msg_id"]],
]])
]);
}else{
SendMessage($from_id,html,"<b>❌ Xatolik yuz berdi.</b>");
}
}
}
}

if($tx=="👁‍🗨 Prasmotr +++"){
$pmball = file_get_contents("pmcoin/$idi.dat");
if($pmball>=1){
$otabek = $pmball / 50;
$maxsudov = floor($otabek);
bot('sendMessage',[
'chat_id'=>$idi,
'text'=>"*• Qancha ko'rish buyurtma qilmoqchisiz?• Bitta ko'rish narxi 50 ball!• Sizda $pmball ball bor!• Sizda $maxsudov ta ko'rish uchun yetarli ball mavjud!• Kerakli ko'rish sonini son bilan kiriting:*",
'parse_mode'=>'markdown',
'reply_markup'=>$key3,
]);
file_put_contents("step/$idi.step","korish");
}else{
bot('sendMessage',[ 
'chat_id'=>$idi, 
'parse_mode'=>'markdown', 
'text'=>"*• Sizning hisobingiz prasmotr buyurtma uchun yetarli emas!• Eng kamida sizda 1 ball bo'lish kerak!• Sizda $pmball ball bor!*",
'reply_markup'=>$key,
]);
}
}

if($step=="korish"){
$pmball = file_get_contents("pmcoin/$idi.dat");
if($tx==$orqaga or $tx=="/start"){
unlink("step/$idi.step");
}else{
$a = $tx * 50;
if($pmball>=$a){
file_put_contents("step/$idi.step","otabek=$tx");
SendMessage($idi,markdown,"✅*Postingizni ommaviy kanaldan Forward qilib yuboring!*");
}else{
SendMessage($idi,html,"❗️Ushbu raqamni ro'yxatdan o'tkazish uchun hisobingizda yetarlicha ball mavjud emas.");
}
}
}

if(stripos($step,"otabek=")!==false){
$pm = str_replace("otabek=","",$step);
if($tx=="/start" or $tx==$orqaga){ 
unlink("step/$idi.step");
}else{
$forchat_msgid = $update->message->forward_from_message_id;
$step = file_get_contents("step/$idi.step"); 
if($forchat_msgid != null && $step != "xxxxxxxx"){
$fwd_id = bot('forwardmessage',[ 
'chat_id'=>"@".$pm_channel, 
'from_chat_id'=>$idi,
'message_id'=>$mid,
])->result->message_id;
file_put_contents("step/$idi.step","xxxxxxxx"); 
bot('sendMessage', [
'chat_id'=>"@".$pm_channel,
'parse_mode'=>'markdown',
'text'=>"‌*•Buyurtma raqami: $fwd_id*n—————————————n•Ko'rish soni: *$pm* ta!n•Ko'rildi: *0* ta!n•Shikoyatlar: *0* ta!",
'reply_to_message_id'=>$fwd_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Tekshirish",'callback_data'=>"ostib=$fwd_id=$pm=$idi"],['text'=>"⚠",'callback_data'=>"mjalb=$fwd_id=$pm=$idi"],],
]]),
]);
file_put_contents("stat/forlar.soni",file_get_contents("stat/forlar.soni") +1);
$bal = file_get_contents("pmcoin/$idi.dat");
$put = $bal - $pm;
file_put_contents("pmcoin/$idi.dat","$put"); 
bot('sendmessage',[
'chat_id'=>$idi,
'parse_mode'=>'markdown',
'text'=>"✅ Yaxshi, Postingiz bizning [@$pm_channel] kanalimizga muvaffaqiyatli joylandi!", 
'reply_to_message_id'=>$mid,
'reply_markup'=>$key,
]); 
bot('sendMessage',[
'chat_id'=>$idi,
'text'=>"Buyurtmangizni ko'rish uchun pastdagi «👁 KO'RISH» tugmasini bosing!", 
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👁 KO'RISH",'url'=>"https://t.me/$pm_channel/$fwd_id"],],
]]),
]);
}else{
SendMessage($idi,markdown,"Iltimos, xabarni *Forward* qilib yuboring❗");
}
}
unlink("step/$idi.step");
}

if($type=="private"){
$rd = explode("n",$lichka);
if(!in_array($idi,$rd)){
file_put_contents("stat/lichka.db","n".$idi,FILE_APPEND);
}
}
     
?>