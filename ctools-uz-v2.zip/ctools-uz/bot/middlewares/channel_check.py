from typing import Callable, Dict, Any, Awaitable
from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery
from aiogram.exceptions import TelegramBadRequest
import httpx
from config import settings

class ChannelCheckMiddleware(BaseMiddleware):
    async def __call__(self, handler: Callable, event: Any, data: Dict[str, Any]) -> Any:
        bot = data["bot"]
        user_id = None

        if isinstance(event, Message):
            user_id = event.from_user.id
            if event.text and event.text.startswith("/start"):
                return await handler(event, data)
        elif isinstance(event, CallbackQuery):
            user_id = event.from_user.id

        if user_id is None:
            return await handler(event, data)

        channels = await self._get_channels()
        not_joined = []

        for ch in channels:
            try:
                member = await bot.get_chat_member(ch["channel_id"], user_id)
                if member.status in ("left", "kicked", "banned"):
                    not_joined.append(ch)
            except TelegramBadRequest:
                not_joined.append(ch)

        if not_joined:
            from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
            buttons = [[InlineKeyboardButton(
                text=f"📢 {ch['title']}",
                url=f"https://t.me/{ch['username'].lstrip('@')}" if ch.get('username') else f"https://t.me/c/{str(ch['channel_id'])[4:]}"
            )] for ch in not_joined]
            buttons.append([InlineKeyboardButton(text="✅ A'zo bo'ldim", callback_data="check_joined")])
            kb = InlineKeyboardMarkup(inline_keyboard=buttons)
            text = "🔐 <b>Ilovadan foydalanish uchun quyidagi kanallarga a'zo bo'ling:</b>\n\nA'zo bo'lgach, «✅ A'zo bo'ldim» tugmasini bosing."
            if isinstance(event, Message):
                await event.answer(text, reply_markup=kb)
            elif isinstance(event, CallbackQuery):
                if event.data == "check_joined":
                    await event.answer("Iltimos, avval kanallarga a'zo bo'ling!", show_alert=True)
                else:
                    await event.message.answer(text, reply_markup=kb)
                    await event.answer()
            return
        return await handler(event, data)

    async def _get_channels(self) -> list:
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(f"{settings.API_BASE_URL}/api/channels/",
                    headers={"X-Init-Data": "internal"}, timeout=5)
                if resp.status_code == 200:
                    return resp.json()
        except:
            pass
        return []
