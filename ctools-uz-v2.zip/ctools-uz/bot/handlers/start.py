from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from config import settings

router = Router()

@router.message(CommandStart())
async def cmd_start(message: Message):
    args = message.text.split()
    deep_link = args[1] if len(args) > 1 else None
    url = settings.WEBAPP_URL
    if deep_link:
        url += f"?tgWebAppStartParam={deep_link}"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🛒 Do'konni ochish", web_app=WebAppInfo(url=url))],
        [InlineKeyboardButton(text="🔍 Mahsulot qidirish", switch_inline_query_current_chat="")],
    ])
    await message.answer(
        f"👋 Salom, <b>{message.from_user.first_name}</b>!\n\n"
        "🔐 <b>ctools.uz</b> — Kiberxavfsizlik gadjetlari do'koni\n\n"
        "⬇️ Do'konni ochish uchun quyidagi tugmani bosing:", reply_markup=kb)
