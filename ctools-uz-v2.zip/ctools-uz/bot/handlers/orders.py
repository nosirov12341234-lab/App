from aiogram import Router
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram.filters import Command
from config import settings

router = Router()

@router.message(Command("orders"))
async def my_orders(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="📦 Zakazlarim", web_app=WebAppInfo(url=f"{settings.WEBAPP_URL}/orders"))
    ]])
    await message.answer("📦 Zakazlaringizni ko'rish:", reply_markup=kb)
