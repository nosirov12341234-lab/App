from aiogram import Router
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram.filters import Command
from config import settings

router = Router()

@router.message(Command("admin"))
async def admin_panel(message: Message):
    if message.from_user.id not in settings.superadmin_list:
        await message.answer("❌ Sizda admin huquqi yo'q.")
        return
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🛠 Admin Panel", web_app=WebAppInfo(url=f"{settings.WEBAPP_URL}/admin"))
    ]])
    await message.answer("👑 <b>Admin Panelga xush kelibsiz!</b>", reply_markup=kb)
