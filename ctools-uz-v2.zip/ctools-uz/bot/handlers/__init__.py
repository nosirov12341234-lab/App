# bot/handlers/__init__.py
from . import start, catalog, orders, admin, inline
