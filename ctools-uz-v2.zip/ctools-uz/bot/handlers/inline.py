from aiogram import Router
from aiogram.types import InlineQuery, InlineQueryResultArticle, InputTextMessageContent, InlineKeyboardMarkup, InlineKeyboardButton
import httpx, hashlib
from config import settings

router = Router()

@router.inline_query()
async def inline_search(query: InlineQuery):
    search = query.query.strip()
    results = []
    try:
        async with httpx.AsyncClient() as client:
            params = {"search": search} if search else {}
            resp = await client.get(f"{settings.API_BASE_URL}/api/products/",
                params=params, headers={"X-Init-Data": "internal"}, timeout=5)
            products = resp.json() if resp.status_code == 200 else []
    except:
        products = []

    for p in products[:15]:
        url = f"{settings.WEBAPP_URL}?tgWebAppStartParam=prod_{p['id']}"
        price = f"{float(p['price']):,.0f} so'm"
        tag = "💾 Raqamli" if p["is_digital"] else "📦 Jismoniy"
        text = f"🛒 <b>{p['name']}</b>\n💰 {price}\n{tag}\n\n<a href='{url}'>Ko'rish →</a>"
        results.append(InlineQueryResultArticle(
            id=hashlib.md5(str(p["id"]).encode()).hexdigest(),
            title=p["name"], description=f"{price} • {tag}",
            input_message_content=InputTextMessageContent(message_text=text, parse_mode="HTML"),
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="🛒 Sotib olish", url=url)
            ]]),
        ))

    if not results:
        results.append(InlineQueryResultArticle(
            id="empty", title="Topilmadi 😔", description="Boshqa so'z bilan qidiring",
            input_message_content=InputTextMessageContent(message_text="❌ Mahsulot topilmadi.")
        ))
    await query.answer(results, cache_time=30, is_personal=True)
