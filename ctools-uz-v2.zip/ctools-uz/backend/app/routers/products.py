from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_
from typing import Optional
from app.database import get_db
from app.models import Product, Favorite
from app.utils.auth import get_current_user

router = APIRouter()

def product_to_dict(p, include_images=True):
    data = {
        "id": p.id, "name": p.name, "description": p.description,
        "price": float(p.price), "stock": p.stock,
        "is_digital": p.is_digital, "category_id": p.category_id,
    }
    if include_images:
        data["images"] = [{"id": i.id, "filename": i.filename, "is_main": i.is_main} for i in (p.images or [])]
    return data

@router.get("/favorites/my")
async def my_favorites(db: AsyncSession = Depends(get_db), user: dict = Depends(get_current_user)):
    result = await db.execute(select(Favorite).where(Favorite.user_id == user["id"]))
    return [{"product_id": f.product_id} for f in result.scalars().all()]

@router.get("/")
async def list_products(
    category_id: Optional[int] = None,
    search: Optional[str] = Query(None, max_length=100),
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_current_user),
):
    stmt = select(Product).where(Product.is_active == True)
    if category_id:
        stmt = stmt.where(Product.category_id == category_id)
    if search:
        stmt = stmt.where(or_(Product.name.ilike(f"%{search}%"), Product.description.ilike(f"%{search}%")))
    result = await db.execute(stmt)
    return [product_to_dict(p) for p in result.scalars().all()]

@router.get("/{product_id}")
async def get_product(product_id: int, db: AsyncSession = Depends(get_db), user: dict = Depends(get_current_user)):
    result = await db.execute(select(Product).where(Product.id == product_id, Product.is_active == True))
    p = result.scalar_one_or_none()
    if not p:
        raise HTTPException(404, "Mahsulot topilmadi")
    return product_to_dict(p)

@router.post("/{product_id}/favorite")
async def toggle_favorite(product_id: int, db: AsyncSession = Depends(get_db), user: dict = Depends(get_current_user)):
    result = await db.execute(select(Favorite).where(Favorite.user_id == user["id"], Favorite.product_id == product_id))
    existing = result.scalar_one_or_none()
    if existing:
        await db.delete(existing)
        await db.commit()
        return {"action": "removed"}
    db.add(Favorite(user_id=user["id"], product_id=product_id))
    await db.commit()
    return {"action": "added"}
