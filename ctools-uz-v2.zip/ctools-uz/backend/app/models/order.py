import enum, random, string
from sqlalchemy import Column, Integer, BigInteger, String, Text, Numeric, ForeignKey, Enum
from sqlalchemy.orm import relationship
from .base import Base

class OrderStatus(str, enum.Enum):
    PENDING    = "pending"
    VERIFIED   = "verified"
    DELIVERING = "delivering"
    COMPLETED  = "completed"
    CANCELLED  = "cancelled"

def _gen_code():
    letters = random.choices(string.ascii_uppercase, k=3)
    digits  = random.choices(string.digits, k=3)
    combo   = letters + digits
    random.shuffle(combo)
    return "".join(combo)

class Order(Base):
    __tablename__ = "orders"
    id               = Column(Integer, primary_key=True, autoincrement=True)
    user_id          = Column(BigInteger, ForeignKey("users.id"), nullable=False)
    code             = Column(String(16), unique=True, nullable=False, default=_gen_code)
    status           = Column(Enum(OrderStatus), default=OrderStatus.PENDING, nullable=False)
    delivery_address = Column(Text, nullable=True)
    admin_note       = Column(Text, nullable=True)
    verified_by      = Column(BigInteger, nullable=True)
    total_price      = Column(Numeric(12, 2), default=0)
    items            = relationship("OrderItem", back_populates="order", lazy="selectin")
    user             = relationship("User")

class OrderItem(Base):
    __tablename__ = "order_items"
    id         = Column(Integer, primary_key=True, autoincrement=True)
    order_id   = Column(Integer, ForeignKey("orders.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    quantity   = Column(Integer, default=1)
    unit_price = Column(Numeric(12, 2), nullable=False)
    order      = relationship("Order", back_populates="items")
    product    = relationship("Product", back_populates="order_items")
