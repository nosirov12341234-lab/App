from sqlalchemy import Column, Integer, String, Boolean
from sqlalchemy.orm import relationship
from .base import Base

class Category(Base):
    __tablename__ = "categories"
    id        = Column(Integer, primary_key=True, autoincrement=True)
    name      = Column(String(128), nullable=False)
    emoji     = Column(String(8), default="📦")
    is_active = Column(Boolean, default=True)
    products  = relationship("Product", back_populates="category", lazy="selectin")
