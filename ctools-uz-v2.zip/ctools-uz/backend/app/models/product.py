from sqlalchemy import Column, Integer, String, Text, Numeric, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from .base import Base

class Product(Base):
    __tablename__ = "products"
    id          = Column(Integer, primary_key=True, autoincrement=True)
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=False)
    name        = Column(String(256), nullable=False)
    description = Column(Text, nullable=True)
    price       = Column(Numeric(12, 2), nullable=False)
    stock       = Column(Integer, default=0)
    is_digital  = Column(Boolean, default=False)
    secret_note = Column(Text, nullable=True)
    is_active   = Column(Boolean, default=True)

    category    = relationship("Category", back_populates="products")
    order_items = relationship("OrderItem", back_populates="product")
    favorites   = relationship("Favorite", back_populates="product")
    images      = relationship("ProductImage", back_populates="product",
                               order_by="ProductImage.sort_order", lazy="selectin")


class ProductImage(Base):
    __tablename__ = "product_images"
    id         = Column(Integer, primary_key=True, autoincrement=True)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    filename   = Column(String(256), nullable=False)
    is_main    = Column(Boolean, default=False)
    sort_order = Column(Integer, default=0)
    product    = relationship("Product", back_populates="images")
