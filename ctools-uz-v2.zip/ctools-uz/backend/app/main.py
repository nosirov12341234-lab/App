from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import init_db
from app.routers.products import router as products_router
from app.routers.orders import router as orders_router
from app.routers.admin import router as admin_router
from app.routers.categories import cat_router, ch_router
from app.routers.upload import router as upload_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield

app = FastAPI(title="ctools.uz API", version="2.0.0", lifespan=lifespan)

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

app.include_router(products_router, prefix="/api/products",   tags=["Mahsulotlar"])
app.include_router(cat_router,      prefix="/api/categories", tags=["Kategoriyalar"])
app.include_router(ch_router,       prefix="/api/channels",   tags=["Kanallar"])
app.include_router(orders_router,   prefix="/api/orders",     tags=["Zakazlar"])
app.include_router(admin_router,    prefix="/api/admin",      tags=["Admin"])
app.include_router(upload_router,   prefix="/api/uploads",    tags=["Upload"])

@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "ctools.uz v2"}
