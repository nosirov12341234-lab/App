import { Navigate } from "react-router-dom";
import useStore from "../store/useStore";
export default function AdminGuard({children}){
  const {isAdmin}=useStore();
  if(!isAdmin) return <Navigate to="/" replace/>;
  return children;
}
