// HapticButton.jsx
import { motion } from "framer-motion";

export default function HapticButton({children,onClick,className="",variant="yellow",disabled=false}){
  const v={
    yellow:"bg-cyber-yellow text-black border-2 border-black shadow-comic hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5",
    red:"bg-cyber-red text-white border-2 border-black shadow-comicR hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5",
    cyan:"bg-cyber-cyan text-black border-2 border-black shadow-comicC hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5",
    ghost:"bg-transparent text-cyber-cyan border-2 border-cyber-cyan",
  };
  return(
    <motion.button whileTap={{scale:0.95}}
      onClick={(e)=>{window.Telegram?.WebApp?.HapticFeedback?.impactOccurred("medium");if(!disabled&&onClick)onClick(e);}}
      disabled={disabled}
      className={`font-comic tracking-wider px-4 py-2 transition-all duration-100 ${v[variant]} ${className} ${disabled?"opacity-40 cursor-not-allowed":""}`}>
      {children}
    </motion.button>
  );
}
