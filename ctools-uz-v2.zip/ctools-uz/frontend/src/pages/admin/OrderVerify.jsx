import { useState } from "react";
import { motion } from "framer-motion";
import { verifyOrder, updateOrderStatus } from "../../api/client";

const STATUS_OPTIONS=[
  {value:"verified",  label:"✅ Tasdiqlash",   variant:"cyan"},
  {value:"delivering",label:"🚴 Yetkazilmoqda",variant:"cyan"},
  {value:"completed", label:"🎉 Yakunlash",    variant:"yellow"},
  {value:"cancelled", label:"❌ Bekor qilish", variant:"red"},
];
const STATUS_LABELS={
  pending:   {text:"⏳ Kutilmoqda",    cls:"text-white opacity-60"},
  verified:  {text:"✅ Tasdiqlandi",   cls:"text-cyber-green"},
  delivering:{text:"🚴 Yetkazilmoqda", cls:"text-cyber-cyan"},
  completed: {text:"🎉 Yakunlandi",    cls:"text-cyber-yellow"},
  cancelled: {text:"❌ Bekor qilindi", cls:"text-cyber-red"},
};

export default function OrderVerify(){
  const [code,setCode]=useState("");
  const [order,setOrder]=useState(null);
  const [loading,setLoading]=useState(false);
  const [note,setNote]=useState("");
  const [updating,setUpdating]=useState(false);
  const [error,setError]=useState("");

  const handleVerify=async()=>{
    if(!code.trim())return;
    setLoading(true);setError("");setOrder(null);
    try{const data=await verifyOrder(code.trim().toUpperCase());setOrder(data);
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("success");
    }catch{setError("❌ Zakaz kodi topilmadi.");window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("error");}
    finally{setLoading(false);}
  };

  const handleStatus=async(newStatus)=>{
    if(!order)return;setUpdating(true);
    try{await updateOrderStatus(order.code,newStatus,note);setOrder({...order,status:newStatus});setNote("");
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("success");
    }catch{}finally{setUpdating(false);}
  };

  const inp="w-full bg-cyber-black border-2 border-white text-white font-body text-sm px-3 py-2 outline-none focus:border-cyber-cyan";

  return(
    <div className="min-h-screen pb-24">
      <div className="bg-cyber-red border-b-2 border-black px-4 py-3 sticky top-0 z-30">
        <div className="font-comic text-white text-2xl">🔑 ZAKAZ TEKSHIRUVI</div>
      </div>
      <div className="p-4 space-y-4">
        <div className="bg-cyber-gray border-2 border-white p-4 shadow-comic">
          <div className="font-comic text-cyber-yellow text-sm mb-3">ZAKAZ KODINI KIRITING:</div>
          <input type="text" value={code} onChange={e=>setCode(e.target.value.toUpperCase())}
            onKeyDown={e=>e.key==="Enter"&&handleVerify()} placeholder="MASALAN: A3B7X2" maxLength={8}
            className="w-full bg-cyber-black border-2 border-cyber-cyan text-cyber-cyan font-comic text-3xl tracking-[0.5em] px-4 py-3 text-center outline-none placeholder:text-base placeholder:tracking-normal placeholder:text-white placeholder:opacity-20"/>
          {error&&<div className="text-cyber-red font-body text-sm mt-2">{error}</div>}
          <button onClick={handleVerify} disabled={loading||!code.trim()}
            className="w-full mt-3 font-comic text-lg py-3 bg-cyber-cyan text-black border-2 border-black shadow-comic disabled:opacity-40">
            {loading?"IZLANMOQDA...":"🔍 QIDIRISH"}
          </button>
        </div>

        {order&&(
          <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} className="space-y-4">
            <div className="bg-cyber-gray border-2 border-cyber-yellow p-4 shadow-comicY">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <div className="font-comic text-cyber-yellow text-xl">#{order.code}</div>
                  <div className={`font-body text-sm mt-1 ${STATUS_LABELS[order.status]?.cls}`}>{STATUS_LABELS[order.status]?.text}</div>
                </div>
                <div className="text-right">
                  <div className="font-comic text-cyber-yellow text-xl">{parseFloat(order.total_price).toLocaleString()} so'm</div>
                </div>
              </div>
              <div className="border-t border-cyber-border pt-3">
                <div className="font-body text-xs text-white opacity-40">Foydalanuvchi ID:</div>
                <div className="font-comic text-white">{order.user_id}</div>
                {order.delivery_address&&(
                  <><div className="font-body text-xs text-white opacity-40 mt-2">Manzil:</div>
                  <div className="font-body text-sm text-cyber-cyan">{order.delivery_address}</div></>
                )}
              </div>
            </div>

            <div className="font-comic text-white text-sm">📋 MAHSULOTLAR:</div>
            {order.items.map((item,i)=>(
              <div key={i} className="bg-cyber-black border-2 border-white p-4 shadow-comic">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex-1 min-w-0 mr-2">
                    <div className="font-comic text-white text-base leading-tight">{item.product_name}</div>
                    <div className="font-body text-xs text-white opacity-40 mt-1">{item.quantity} × {parseFloat(item.unit_price).toLocaleString()} so'm</div>
                  </div>
                  <div className="text-xl">{item.is_digital?"💾":"📦"}</div>
                </div>
                {item.is_digital&&item.secret_note&&(
                  <div className="mt-3 border-2 border-cyber-red p-3 bg-cyber-red bg-opacity-10">
                    <div className="font-comic text-cyber-red text-xs mb-1">🔐 MAXFIY MA'LUMOT:</div>
                    <div className="font-body text-cyber-cyan text-sm break-all select-all">{item.secret_note}</div>
                  </div>
                )}
              </div>
            ))}

            <div>
              <div className="font-comic text-white text-sm mb-2">IZOH (ixtiyoriy):</div>
              <textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="Foydalanuvchiga yuboriladi..." rows={2}
                className={inp}/>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {STATUS_OPTIONS.map(opt=>(
                <button key={opt.value} onClick={()=>handleStatus(opt.value)}
                  disabled={updating||order.status===opt.value}
                  className={`font-comic text-sm py-3 border-2 border-black shadow-comic disabled:opacity-40 transition-all active:shadow-none
                    ${opt.variant==="yellow"?"bg-cyber-yellow text-black":opt.variant==="red"?"bg-cyber-red text-white":"bg-cyber-cyan text-black"}`}>
                  {opt.label}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
