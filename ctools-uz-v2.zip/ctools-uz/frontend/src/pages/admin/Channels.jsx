import { useState, useEffect } from "react";
import { getChannels, addChannel, removeChannel } from "../../api/client";

export default function Channels(){
  const [channels,setChannels]=useState([]);
  const [form,setForm]=useState({channel_id:"",title:"",username:""});
  const [saving,setSaving]=useState(false);
  const load=()=>getChannels().then(setChannels).catch(()=>{});
  useEffect(()=>{load();},[]);

  const handleAdd=async()=>{
    if(!form.channel_id||!form.title){alert("Channel ID va nom majburiy!");return;}
    setSaving(true);
    try{await addChannel({...form,channel_id:parseInt(form.channel_id)});
      setForm({channel_id:"",title:"",username:""});load();
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("success");
    }catch{alert("Xato! Channel ID ni tekshiring.");}
    finally{setSaving(false);}
  };
  const inp="w-full bg-cyber-black border-2 border-white text-white font-body text-sm px-3 py-2 outline-none focus:border-cyber-cyan";

  return(
    <div className="min-h-screen pb-24">
      <div className="bg-cyber-gray border-b-2 border-cyber-purple px-4 py-3 sticky top-0 z-30">
        <div className="font-comic text-cyber-purple text-xl">📢 KANALLAR</div>
        <div className="font-body text-xs text-white opacity-40">Majburiy a'zolik kanallarini boshqaring</div>
      </div>
      <div className="p-4 space-y-4">
        <div className="bg-cyber-gray border-2 border-cyber-purple p-4 shadow-comic">
          <div className="font-comic text-cyber-purple text-sm mb-3">➕ YANGI KANAL</div>
          <div className="space-y-3">
            <div>
              <div className="font-comic text-xs text-white opacity-40 mb-1">CHANNEL ID *</div>
              <input className={inp} type="number" value={form.channel_id}
                onChange={e=>setForm({...form,channel_id:e.target.value})} placeholder="-1001234567890"/>
              <div className="font-body text-xs text-white opacity-30 mt-1">Botni kanalga admin qiling</div>
            </div>
            <div>
              <div className="font-comic text-xs text-white opacity-40 mb-1">KANAL NOMI *</div>
              <input className={inp} value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="ctools.uz Kanal"/>
            </div>
            <div>
              <div className="font-comic text-xs text-white opacity-40 mb-1">USERNAME (ixtiyoriy)</div>
              <input className={inp} value={form.username} onChange={e=>setForm({...form,username:e.target.value})} placeholder="@ctools_uz"/>
            </div>
            <button onClick={handleAdd} disabled={saving}
              className="w-full font-comic text-sm bg-cyber-purple text-white border-2 border-black py-3 shadow-comic disabled:opacity-40">
              {saving?"QO'SHILMOQDA...":"📢 QO'SHISH"}
            </button>
          </div>
        </div>
        <div className="font-comic text-white text-sm">FAOL KANALLAR ({channels.length})</div>
        {channels.length===0?(
          <div className="text-center py-8 font-body text-white opacity-30 text-sm">Hech qanday kanal yo'q</div>
        ):(
          <div className="space-y-2">
            {channels.map(ch=>(
              <div key={ch.id} className="bg-cyber-gray border-2 border-cyber-border p-3 flex items-center gap-3 shadow-comic">
                <span className="text-2xl">📢</span>
                <div className="flex-1 min-w-0">
                  <div className="font-comic text-white text-sm truncate">{ch.title}</div>
                  {ch.username&&<div className="font-body text-xs text-cyber-cyan opacity-60">{ch.username}</div>}
                  <div className="font-body text-xs text-white opacity-30">ID: {ch.channel_id}</div>
                </div>
                <button onClick={async()=>{if(!window.confirm("O'chirilsinmi?"))return;await removeChannel(ch.id).catch(()=>{});load();}}
                  className="text-cyber-red border border-cyber-red px-2 py-1 font-comic text-xs flex-shrink-0">🗑️</button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
