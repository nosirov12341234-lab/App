import { create } from "zustand";
import { persist } from "zustand/middleware";

const useStore = create(persist((set,get)=>({
  user:null, isAdmin:false, isSuperAdmin:false,
  setUser:(u)=>set({user:u}),
  setAdminStatus:(a,s)=>set({isAdmin:a,isSuperAdmin:s}),
  cart:[],
  addToCart:(product)=>{
    const cart=get().cart;
    const ex=cart.find(i=>i.product.id===product.id);
    if(ex) set({cart:cart.map(i=>i.product.id===product.id?{...i,quantity:i.quantity+1}:i)});
    else set({cart:[...cart,{product,quantity:1}]});
    window.Telegram?.WebApp?.HapticFeedback?.impactOccurred("light");
  },
  removeFromCart:(id)=>set({cart:get().cart.filter(i=>i.product.id!==id)}),
  updateQuantity:(id,qty)=>{
    if(qty<1){get().removeFromCart(id);return;}
    set({cart:get().cart.map(i=>i.product.id===id?{...i,quantity:qty}:i)});
  },
  clearCart:()=>set({cart:[]}),
  cartTotal:()=>get().cart.reduce((s,i)=>s+parseFloat(i.product.price)*i.quantity,0),
  cartCount:()=>get().cart.reduce((s,i)=>s+i.quantity,0),
  favoriteIds:[],
  setFavoriteIds:(ids)=>set({favoriteIds:ids}),
  toggleFavoriteLocal:(id)=>{
    const favs=get().favoriteIds;
    if(favs.includes(id)) set({favoriteIds:favs.filter(f=>f!==id)});
    else{set({favoriteIds:[...favs,id]});window.Telegram?.WebApp?.HapticFeedback?.impactOccurred("medium");}
  },
}),{name:"ctools-v2",partialize:(s)=>({cart:s.cart,favoriteIds:s.favoriteIds})}));

export default useStore;
