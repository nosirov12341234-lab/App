import sqlite3
import json
from datetime import datetime, date

class Database:
    def __init__(self, db_path="bot.db"):
        self.db_path = db_path
        self.init_db()

    def get_conn(self):
        return sqlite3.connect(self.db_path)

    def init_db(self):
        with self.get_conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    referrer_id INTEGER,
                    main_stars INTEGER DEFAULT 0,
                    game_stars INTEGER DEFAULT 0,
                    referral_count INTEGER DEFAULT 0,
                    total_earned INTEGER DEFAULT 0,
                    total_withdrawn INTEGER DEFAULT 0,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT
                );

                CREATE TABLE IF NOT EXISTS withdrawals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    amount INTEGER,
                    status TEXT DEFAULT 'pending',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );
            """)
            # Default settings
            defaults = {
                'referral_bonus': '10',
                'min_withdraw': '50',
                'crash_min_bet': '5',
                'crash_house_edge': '5',
                'spin_price': '10',
                'channels': '[]',
                'groups': '[]',
                'spin_rewards': json.dumps([
                    {"label": "💥 Yutqazdingiz", "stars": 0, "chance": 40},
                    {"label": "⭐ x1.5", "stars": 15, "chance": 30},
                    {"label": "⭐ x2", "stars": 20, "chance": 20},
                    {"label": "⭐ x5", "stars": 50, "chance": 8},
                    {"label": "🎉 x10", "stars": 100, "chance": 2},
                ])
            }
            for key, value in defaults.items():
                conn.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (key, value))
            conn.commit()

    def add_user(self, user_id, username, referrer_id=None):
        with self.get_conn() as conn:
            existing = conn.execute("SELECT user_id FROM users WHERE user_id=?", (user_id,)).fetchone()
            if existing:
                conn.execute("UPDATE users SET username=? WHERE user_id=?", (username, user_id))
                return False
            conn.execute(
                "INSERT INTO users (user_id, username, referrer_id) VALUES (?, ?, ?)",
                (user_id, username, referrer_id)
            )
            if referrer_id:
                conn.execute(
                    "UPDATE users SET referral_count=referral_count+1 WHERE user_id=?",
                    (referrer_id,)
                )
            conn.commit()
            return True

    def get_user(self, user_id):
        with self.get_conn() as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
            return dict(row) if row else None

    def add_stars(self, user_id, amount, account='main'):
        col = 'main_stars' if account == 'main' else 'game_stars'
        with self.get_conn() as conn:
            conn.execute(f"UPDATE users SET {col}=MAX(0,{col}+?) WHERE user_id=?", (amount, user_id))
            if amount > 0:
                conn.execute("UPDATE users SET total_earned=total_earned+? WHERE user_id=?", (amount, user_id))
            conn.commit()

    def add_withdrawn(self, user_id, amount):
        with self.get_conn() as conn:
            conn.execute("UPDATE users SET total_withdrawn=total_withdrawn+? WHERE user_id=?", (amount, user_id))
            conn.commit()

    def get_settings(self):
        with self.get_conn() as conn:
            rows = conn.execute("SELECT key, value FROM settings").fetchall()
            result = {}
            for key, value in rows:
                try:
                    result[key] = json.loads(value)
                except:
                    try:
                        result[key] = int(value)
                    except:
                        result[key] = value
            return result

    def update_setting(self, key, value):
        with self.get_conn() as conn:
            if isinstance(value, (list, dict)):
                value = json.dumps(value)
            else:
                value = str(value)
            conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))
            conn.commit()

    def get_leaderboard(self, limit=10):
        with self.get_conn() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM users ORDER BY referral_count DESC, total_earned DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(r) for r in rows]

    def get_all_users(self):
        with self.get_conn() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute("SELECT * FROM users").fetchall()
            return [dict(r) for r in rows]

    def create_withdraw_request(self, user_id, amount):
        with self.get_conn() as conn:
            conn.execute("INSERT INTO withdrawals (user_id, amount) VALUES (?, ?)", (user_id, amount))
            conn.commit()

    def get_pending_withdrawals(self):
        with self.get_conn() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute("""
                SELECT w.*, u.username FROM withdrawals w
                JOIN users u ON w.user_id=u.user_id
                WHERE w.status='pending' ORDER BY w.created_at ASC
            """).fetchall()
            return [dict(r) for r in rows]

    def get_withdraw_request(self, req_id):
        with self.get_conn() as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute("""
                SELECT w.*, u.username FROM withdrawals w
                JOIN users u ON w.user_id=u.user_id
                WHERE w.id=?
            """, (req_id,)).fetchone()
            return dict(row) if row else None

    def complete_withdraw(self, req_id):
        with self.get_conn() as conn:
            conn.execute("UPDATE withdrawals SET status='completed' WHERE id=?", (req_id,))
            conn.commit()

    def reject_withdraw(self, req_id):
        with self.get_conn() as conn:
            conn.execute("UPDATE withdrawals SET status='rejected' WHERE id=?", (req_id,))
            conn.commit()

    def get_bot_stats(self):
        with self.get_conn() as conn:
            total_users = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            today = date.today().isoformat()
            today_users = conn.execute(
                "SELECT COUNT(*) FROM users WHERE created_at LIKE ?", (f"{today}%",)
            ).fetchone()[0]
            total_stars = conn.execute("SELECT SUM(total_earned) FROM users").fetchone()[0] or 0
            pending = conn.execute("SELECT COUNT(*) FROM withdrawals WHERE status='pending'").fetchone()[0]
            completed = conn.execute("SELECT COUNT(*) FROM withdrawals WHERE status='completed'").fetchone()[0]
            return {
                'total_users': total_users,
                'today_users': today_users,
                'total_stars': total_stars,
                'pending_withdrawals': pending,
                'completed_withdrawals': completed
            }
