import asyncio
import logging
import random
import math
from aiogram import Bot, Dispatcher, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from database import Database
from config import Config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

bot = Bot(token=Config.BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
db = Database()

class AdminStates(StatesGroup):
    set_bonus = State()
    set_channel = State()
    set_group = State()
    set_min_withdraw = State()
    set_crash_min_bet = State()
    set_spin_price = State()
    set_spin_rewards = State()
    broadcast = State()
    set_withdraw_amount = State()

class GameStates(StatesGroup):
    crash_betting = State()
    crash_playing = State()

# ==================== KEYBOARDS ====================

def main_menu_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⭐ Balansim", callback_data="balance"),
         InlineKeyboardButton(text="🔗 Referal link", callback_data="referral")],
        [InlineKeyboardButton(text="📊 Statistika", callback_data="stats"),
         InlineKeyboardButton(text="🏆 Top", callback_data="leaderboard")],
        [InlineKeyboardButton(text="🚀 Crash", callback_data="crash_menu"),
         InlineKeyboardButton(text="🎡 Baraban", callback_data="spin_menu")],
        [InlineKeyboardButton(text="💸 Yechib olish", callback_data="withdraw")],
    ])

def admin_menu_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⭐ Bonus miqdori", callback_data="admin_set_bonus"),
         InlineKeyboardButton(text="📢 Kanal qo'shish", callback_data="admin_set_channel")],
        [InlineKeyboardButton(text="👥 Guruh qo'shish", callback_data="admin_set_group"),
         InlineKeyboardButton(text="💸 Min yechib olish", callback_data="admin_set_min_withdraw")],
        [InlineKeyboardButton(text="🚀 Crash min bet", callback_data="admin_set_crash_bet"),
         InlineKeyboardButton(text="🎡 Spin narxi", callback_data="admin_set_spin_price")],
        [InlineKeyboardButton(text="🎁 Spin mukofotlari", callback_data="admin_set_spin_rewards"),
         InlineKeyboardButton(text="📊 Bot statistika", callback_data="admin_stats")],
        [InlineKeyboardButton(text="📨 Broadcast", callback_data="admin_broadcast")],
        [InlineKeyboardButton(text="💰 Yechib olish so'rovlari", callback_data="admin_withdrawals")],
    ])

def back_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 Orqaga", callback_data="main_menu")]
    ])

def crash_bet_kb(min_bet):
    bets = [min_bet, min_bet*2, min_bet*5, min_bet*10]
    rows = []
    row = []
    for bet in bets:
        row.append(InlineKeyboardButton(text=f"⭐{bet}", callback_data=f"crash_bet_{bet}"))
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([InlineKeyboardButton(text="🔙 Orqaga", callback_data="main_menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)

def crash_cashout_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💰 USHLAB QOLISH!", callback_data="crash_cashout")]
    ])

def spin_kb(price):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"🎡 Aylantirish ({price} ⭐)", callback_data="spin_play")],
        [InlineKeyboardButton(text="🔙 Orqaga", callback_data="main_menu")]
    ])

# ==================== HELPERS ====================

async def check_membership(user_id: int) -> bool:
    settings = db.get_settings()
    channels = settings.get('channels', [])
    groups = settings.get('groups', [])
    
    for chat_id in channels + groups:
        try:
            member = await bot.get_chat_member(chat_id, user_id)
            if member.status in ['left', 'kicked', 'banned']:
                return False
        except:
            pass
    return True

async def membership_required_kb():
    settings = db.get_settings()
    channels = settings.get('channels', [])
    groups = settings.get('groups', [])
    buttons = []
    
    for chat_id in channels:
        try:
            chat = await bot.get_chat(chat_id)
            invite = await bot.export_chat_invite_link(chat_id)
            buttons.append([InlineKeyboardButton(text=f"📢 {chat.title}", url=invite)])
        except:
            pass
    
    for chat_id in groups:
        try:
            chat = await bot.get_chat(chat_id)
            invite = await bot.export_chat_invite_link(chat_id)
            buttons.append([InlineKeyboardButton(text=f"👥 {chat.title}", url=invite)])
        except:
            pass
    
    buttons.append([InlineKeyboardButton(text="✅ A'zo bo'ldim", callback_data="check_membership")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def generate_crash_point():
    """Generate random crash point with house edge"""
    settings = db.get_settings()
    house_edge = settings.get('crash_house_edge', 5) / 100
    r = random.random()
    if r < house_edge:
        return 1.0
    crash = 0.99 / (1 - r)
    return round(min(crash, 1000.0), 2)

# ==================== START ====================

@dp.message(CommandStart())
async def start_handler(message: Message):
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    
    args = message.text.split()
    referrer_id = None
    if len(args) > 1 and args[1].startswith("ref"):
        try:
            referrer_id = int(args[1][3:])
        except:
            pass
    
    is_new = db.add_user(user_id, username, referrer_id)
    
    if is_new and referrer_id and referrer_id != user_id:
        settings = db.get_settings()
        bonus = settings.get('referral_bonus', 10)
        db.add_stars(referrer_id, bonus, 'main')
        try:
            await bot.send_message(
                referrer_id,
                f"🎉 Yangi referal! @{username} siz orqali qo'shildi!\n"
                f"⭐ +{bonus} Stars hisobingizga qo'shildi!"
            )
        except:
            pass
    
    if not await check_membership(user_id):
        kb = await membership_required_kb()
        await message.answer(
            "⚠️ Botdan foydalanish uchun quyidagi kanal/guruhlarga a'zo bo'ling:",
            reply_markup=kb
        )
        return
    
    await message.answer(
        f"👋 Xush kelibsiz, {username}!\n\n"
        f"⭐ Stars referral orqali ishlang va o'yinlarda baxtingizni sinab ko'ring!\n\n"
        f"📌 Asosiy hisob — referraldan\n"
        f"🎮 O'yin hisobi — o'yindan yutganlar",
        reply_markup=main_menu_kb()
    )

@dp.callback_query(F.data == "check_membership")
async def check_membership_cb(callback: CallbackQuery):
    if await check_membership(callback.from_user.id):
        await callback.message.edit_text(
            "✅ Rahmat! Endi botdan foydalanishingiz mumkin.",
            reply_markup=main_menu_kb()
        )
    else:
        await callback.answer("❌ Hali a'zo bo'lmadingiz!", show_alert=True)

@dp.callback_query(F.data == "main_menu")
async def main_menu_cb(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text(
        "🏠 Bosh menyu",
        reply_markup=main_menu_kb()
    )

# ==================== BALANCE & STATS ====================

@dp.callback_query(F.data == "balance")
async def balance_cb(callback: CallbackQuery):
    user = db.get_user(callback.from_user.id)
    await callback.message.edit_text(
        f"💰 Hisobingiz:\n\n"
        f"⭐ Asosiy hisob: {user['main_stars']} Stars\n"
        f"🎮 O'yin hisobi: {user['game_stars']} Stars\n\n"
        f"📌 Asosiy hisob — faqat o'yin uchun\n"
        f"💸 O'yin hisobi — yechib olish mumkin",
        reply_markup=back_kb()
    )

@dp.callback_query(F.data == "referral")
async def referral_cb(callback: CallbackQuery):
    user_id = callback.from_user.id
    user = db.get_user(user_id)
    settings = db.get_settings()
    bonus = settings.get('referral_bonus', 10)
    bot_info = await bot.get_me()
    link = f"https://t.me/{bot_info.username}?start=ref{user_id}"
    
    await callback.message.edit_text(
        f"🔗 Sizning referal linkingiz:\n\n"
        f"`{link}`\n\n"
        f"⭐ Har bir taklif uchun: +{bonus} Stars\n"
        f"👥 Jami taklif qilganlar: {user['referral_count']}\n"
        f"💰 Jami ishlab topgan: {user['total_earned']} Stars",
        reply_markup=back_kb(),
        parse_mode="Markdown"
    )

@dp.callback_query(F.data == "stats")
async def stats_cb(callback: CallbackQuery):
    user = db.get_user(callback.from_user.id)
    await callback.message.edit_text(
        f"📊 Sizning statistikangiz:\n\n"
        f"👥 Taklif qilganlar: {user['referral_count']}\n"
        f"⭐ Asosiy hisob: {user['main_stars']} Stars\n"
        f"🎮 O'yin hisobi: {user['game_stars']} Stars\n"
        f"💰 Jami ishlab topgan: {user['total_earned']} Stars\n"
        f"💸 Yechib olingan: {user['total_withdrawn']} Stars",
        reply_markup=back_kb()
    )

@dp.callback_query(F.data == "leaderboard")
async def leaderboard_cb(callback: CallbackQuery):
    top = db.get_leaderboard()
    text = "🏆 Top 10 referal:\n\n"
    medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
    
    for i, user in enumerate(top):
        medal = medals[i] if i < len(medals) else f"{i+1}."
        text += f"{medal} @{user['username']} — {user['referral_count']} referal ({user['total_earned']} ⭐)\n"
    
    await callback.message.edit_text(text, reply_markup=back_kb())

# ==================== WITHDRAW ====================

@dp.callback_query(F.data == "withdraw")
async def withdraw_cb(callback: CallbackQuery):
    user = db.get_user(callback.from_user.id)
    settings = db.get_settings()
    min_withdraw = settings.get('min_withdraw', 50)
    
    if user['game_stars'] < min_withdraw:
        await callback.message.edit_text(
            f"💸 Yechib olish\n\n"
            f"🎮 O'yin hisobingiz: {user['game_stars']} Stars\n"
            f"⚠️ Minimal yechib olish: {min_withdraw} Stars\n\n"
            f"❌ O'yin hisobingiz yetarli emas!\n"
            f"🎮 Ko'proq Stars ishlash uchun o'yin o'ynang.",
            reply_markup=back_kb()
        )
        return
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"💸 {user['game_stars']} Stars yechib olish", callback_data="withdraw_confirm")],
        [InlineKeyboardButton(text="🔙 Orqaga", callback_data="main_menu")]
    ])
    
    await callback.message.edit_text(
        f"💸 Yechib olish\n\n"
        f"🎮 O'yin hisobingiz: {user['game_stars']} Stars\n"
        f"📌 Minimal: {min_withdraw} Stars\n\n"
        f"So'rovingiz adminga yuboriladi va tez orada to'lov amalga oshiriladi.",
        reply_markup=kb
    )

@dp.callback_query(F.data == "withdraw_confirm")
async def withdraw_confirm_cb(callback: CallbackQuery):
    user_id = callback.from_user.id
    user = db.get_user(user_id)
    settings = db.get_settings()
    min_withdraw = settings.get('min_withdraw', 50)
    
    if user['game_stars'] < min_withdraw:
        await callback.answer("❌ Yetarli Stars yo'q!", show_alert=True)
        return
    
    amount = user['game_stars']
    db.create_withdraw_request(user_id, amount)
    db.add_stars(user_id, -amount, 'game')
    
    # Notify admin
    for admin_id in Config.ADMIN_IDS:
        try:
            await bot.send_message(
                admin_id,
                f"💸 Yangi yechib olish so'rovi!\n\n"
                f"👤 Foydalanuvchi: @{user['username']}\n"
                f"🆔 ID: {user_id}\n"
                f"⭐ Miqdor: {amount} Stars\n\n"
                f"Tasdiqlash uchun /withdrawals buyrug'ini bosing."
            )
        except:
            pass
    
    await callback.message.edit_text(
        f"✅ So'rovingiz yuborildi!\n\n"
        f"⭐ Miqdor: {amount} Stars\n"
        f"⏳ Admin tez orada to'lovni amalga oshiradi.",
        reply_markup=back_kb()
    )

# ==================== CRASH GAME ====================

@dp.callback_query(F.data == "crash_menu")
async def crash_menu_cb(callback: CallbackQuery):
    settings = db.get_settings()
    min_bet = settings.get('crash_min_bet', 5)
    user = db.get_user(callback.from_user.id)
    
    await callback.message.edit_text(
        f"🚀 CRASH O'YINI\n\n"
        f"📌 Qoida: Raketa uchadi, vaqtida ushlab qolsang yutasan!\n"
        f"⭐ Asosiy hisob: {user['main_stars']} Stars\n"
        f"🎮 O'yin hisobi: {user['game_stars']} Stars\n\n"
        f"💰 Minimal bet: {min_bet} Stars\n\n"
        f"Nechta Stars tikmoqchisiz?",
        reply_markup=crash_bet_kb(min_bet)
    )

@dp.callback_query(F.data.startswith("crash_bet_"))
async def crash_bet_cb(callback: CallbackQuery, state: FSMContext):
    bet = int(callback.data.split("_")[2])
    user_id = callback.from_user.id
    user = db.get_user(user_id)
    
    total_stars = user['main_stars'] + user['game_stars']
    if total_stars < bet:
        await callback.answer("❌ Yetarli Stars yo'q!", show_alert=True)
        return
    
    # Deduct from game stars first, then main
    if user['game_stars'] >= bet:
        db.add_stars(user_id, -bet, 'game')
        source = 'game'
    else:
        db.add_stars(user_id, -bet, 'main')
        source = 'main'
    
    crash_point = generate_crash_point()
    await state.update_data(bet=bet, crash_point=crash_point, source=source)
    await state.set_state(GameStates.crash_playing)
    
    msg = await callback.message.edit_text(
        f"🚀 RAKETA UCHMOQDA!\n\n"
        f"💰 Bet: {bet} ⭐\n\n"
        f"1.00x 🚀",
        reply_markup=crash_cashout_kb()
    )
    
    # Animate crash
    multiplier = 1.0
    step = 0.1
    crashed = False
    
    while multiplier < crash_point:
        await asyncio.sleep(0.7)
        multiplier = round(multiplier + step, 2)
        if multiplier > 2:
            step = 0.2
        if multiplier > 5:
            step = 0.5
        if multiplier > 10:
            step = 1.0
        
        if multiplier >= crash_point:
            crashed = True
            break
        
        try:
            await msg.edit_text(
                f"🚀 RAKETA UCHMOQDA!\n\n"
                f"💰 Bet: {bet} ⭐\n\n"
                f"{multiplier:.2f}x 🚀",
                reply_markup=crash_cashout_kb()
            )
        except:
            pass
    
    # Check if user already cashed out
    data = await state.get_data()
    if data.get('cashed_out'):
        return
    
    # Crashed
    await state.clear()
    await msg.edit_text(
        f"💥 PORTLADI! {crash_point:.2f}x da\n\n"
        f"😢 {bet} ⭐ yo'qotdingiz!\n\n"
        f"Yana urinib ko'ring?",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🚀 Yana o'ynash", callback_data="crash_menu")],
            [InlineKeyboardButton(text="🔙 Bosh menyu", callback_data="main_menu")]
        ])
    )

@dp.callback_query(F.data == "crash_cashout")
async def crash_cashout_cb(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    if not data or data.get('cashed_out'):
        await callback.answer("❌ O'yin tugagan!", show_alert=True)
        return
    
    bet = data.get('bet', 0)
    crash_point = data.get('crash_point', 1.0)
    
    # Current multiplier (approximate)
    current_multi = data.get('current_multi', 1.5)
    
    if current_multi >= crash_point:
        await callback.answer("💥 Kech bo'ldi! Portladi!", show_alert=True)
        await state.clear()
        return
    
    winnings = int(bet * current_multi)
    db.add_stars(callback.from_user.id, winnings, 'game')
    await state.update_data(cashed_out=True)
    await state.clear()
    
    await callback.message.edit_text(
        f"✅ USHLAB QOLDINGIZ! {current_multi:.2f}x da\n\n"
        f"💰 Bet: {bet} ⭐\n"
        f"🎉 Yutuq: {winnings} ⭐\n"
        f"📈 Foyda: +{winnings - bet} ⭐\n\n"
        f"🎮 O'yin hisobingizga qo'shildi!",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🚀 Yana o'ynash", callback_data="crash_menu")],
            [InlineKeyboardButton(text="🔙 Bosh menyu", callback_data="main_menu")]
        ])
    )

# ==================== SPIN GAME ====================

@dp.callback_query(F.data == "spin_menu")
async def spin_menu_cb(callback: CallbackQuery):
    settings = db.get_settings()
    spin_price = settings.get('spin_price', 10)
    user = db.get_user(callback.from_user.id)
    
    await callback.message.edit_text(
        f"🎡 BARABAN O'YINI\n\n"
        f"📌 Aylantir va baxtingni sinab ko'r!\n"
        f"⭐ Asosiy hisob: {user['main_stars']} Stars\n"
        f"🎮 O'yin hisobi: {user['game_stars']} Stars\n\n"
        f"💰 Narxi: {spin_price} Stars",
        reply_markup=spin_kb(spin_price)
    )

@dp.callback_query(F.data == "spin_play")
async def spin_play_cb(callback: CallbackQuery):
    user_id = callback.from_user.id
    user = db.get_user(user_id)
    settings = db.get_settings()
    spin_price = settings.get('spin_price', 10)
    
    total_stars = user['main_stars'] + user['game_stars']
    if total_stars < spin_price:
        await callback.answer(f"❌ Yetarli Stars yo'q! Kerak: {spin_price} ⭐", show_alert=True)
        return
    
    if user['game_stars'] >= spin_price:
        db.add_stars(user_id, -spin_price, 'game')
    else:
        db.add_stars(user_id, -spin_price, 'main')
    
    # Get rewards config
    rewards = settings.get('spin_rewards', [
        {"label": "💥 Yutqazdingiz", "stars": 0, "chance": 40},
        {"label": "⭐ x1.5", "stars": int(spin_price * 1.5), "chance": 30},
        {"label": "⭐ x2", "stars": spin_price * 2, "chance": 20},
        {"label": "⭐ x5", "stars": spin_price * 5, "chance": 8},
        {"label": "🎉 x10", "stars": spin_price * 10, "chance": 2},
    ])
    
    # Animate spin
    symbols = ["🍒", "🍋", "🍊", "💎", "⭐", "🎰", "7️⃣", "🍀"]
    msg = await callback.message.edit_text(
        f"🎡 AYLANMOQDA...\n\n"
        f"{'  '.join(random.choices(symbols, k=3))}"
    )
    
    for _ in range(5):
        await asyncio.sleep(0.4)
        try:
            await msg.edit_text(
                f"🎡 AYLANMOQDA...\n\n"
                f"{'  '.join(random.choices(symbols, k=3))}"
            )
        except:
            pass
    
    # Pick result
    total_chance = sum(r['chance'] for r in rewards)
    rand = random.uniform(0, total_chance)
    current = 0
    result = rewards[-1]
    for reward in rewards:
        current += reward['chance']
        if rand <= current:
            result = reward
            break
    
    won = result['stars']
    if won > 0:
        db.add_stars(user_id, won, 'game')
    
    final_symbols = random.choices(symbols, k=3)
    if won > 0:
        final_symbols[1] = "⭐"
    
    await msg.edit_text(
        f"🎡 NATIJA:\n\n"
        f"{'  '.join(final_symbols)}\n\n"
        f"{result['label']}\n"
        + (f"🎉 +{won} ⭐ O'yin hisobingizga!" if won > 0 else f"😢 Omad yo'q! Yana urinib ko'ring!"),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🎡 Yana aylantirish", callback_data="spin_menu")],
            [InlineKeyboardButton(text="🔙 Bosh menyu", callback_data="main_menu")]
        ])
    )

# ==================== ADMIN ====================

@dp.message(Command("adminpanel"))
async def admin_panel_cmd(message: Message):
    if message.from_user.id not in Config.ADMIN_IDS:
        return
    stats = db.get_bot_stats()
    await message.answer(
        f"👑 ADMIN PANEL\n\n"
        f"👥 Jami foydalanuvchilar: {stats['total_users']}\n"
        f"🆕 Bugun yangilar: {stats['today_users']}\n"
        f"⭐ Jami Stars tarqatilgan: {stats['total_stars']}\n"
        f"💸 Kutayotgan so'rovlar: {stats['pending_withdrawals']}",
        reply_markup=admin_menu_kb()
    )

@dp.callback_query(F.data == "admin_set_bonus")
async def admin_set_bonus_cb(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id not in Config.ADMIN_IDS:
        return
    await state.set_state(AdminStates.set_bonus)
    await callback.message.edit_text(
        "⭐ Referal bonus miqdorini kiriting (Stars):\n\nMisol: 10",
        reply_markup=back_kb()
    )

@dp.message(AdminStates.set_bonus)
async def set_bonus_handler(message: Message, state: FSMContext):
    if message.from_user.id not in Config.ADMIN_IDS:
        return
    try:
        bonus = int(message.text)
        db.update_setting('referral_bonus', bonus)
        await state.clear()
        await message.answer(f"✅ Referal bonus {bonus} Stars ga o'rnatildi!", reply_markup=admin_menu_kb())
    except:
        await message.answer("❌ Raqam kiriting!")

@dp.callback_query(F.data == "admin_set_channel")
async def admin_set_channel_cb(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id not in Config.ADMIN_IDS:
        return
    await state.set_state(AdminStates.set_channel)
    await callback.message.edit_text(
        "📢 Kanal ID sini kiriting:\n\nMisol: -1001234567890\n\n"
        "⚠️ Botni kanalga admin qilib qo'shing!",
        reply_markup=back_kb()
    )

@dp.message(AdminStates.set_channel)
async def set_channel_handler(message: Message, state: FSMContext):
    if message.from_user.id not in Config.ADMIN_IDS:
        return
    try:
        channel_id = int(message.text)
        settings = db.get_settings()
        channels = settings.get('channels', [])
        if channel_id not in channels:
            channels.append(channel_id)
        db.update_setting('channels', channels)
        await state.clear()
        await message.answer(f"✅ Kanal qo'shildi: {channel_id}", reply_markup=admin_menu_kb())
    except:
        await message.answer("❌ To'g'ri kanal ID kiriting!")

@dp.callback_query(F.data == "admin_set_group")
async def admin_set_group_cb(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id not in Config.ADMIN_IDS:
        return
    await state.set_state(AdminStates.set_group)
    await callback.message.edit_text(
        "👥 Guruh ID sini kiriting:\n\nMisol: -1001234567890",
        reply_markup=back_kb()
    )

@dp.message(AdminStates.set_group)
async def set_group_handler(message: Message, state: FSMContext):
    if message.from_user.id not in Config.ADMIN_IDS:
        return
    try:
        group_id = int(message.text)
        settings = db.get_settings()
        groups = settings.get('groups', [])
        if group_id not in groups:
            groups.append(group_id)
        db.update_setting('groups', groups)
        await state.clear()
        await message.answer(f"✅ Guruh qo'shildi: {group_id}", reply_markup=admin_menu_kb())
    except:
        await message.answer("❌ To'g'ri guruh ID kiriting!")

@dp.callback_query(F.data == "admin_set_min_withdraw")
async def admin_set_min_withdraw_cb(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id not in Config.ADMIN_IDS:
        return
    await state.set_state(AdminStates.set_min_withdraw)
    await callback.message.edit_text("💸 Minimal yechib olish miqdorini kiriting:", reply_markup=back_kb())

@dp.message(AdminStates.set_min_withdraw)
async def set_min_withdraw_handler(message: Message, state: FSMContext):
    if message.from_user.id not in Config.ADMIN_IDS:
        return
    try:
        amount = int(message.text)
        db.update_setting('min_withdraw', amount)
        await state.clear()
        await message.answer(f"✅ Minimal yechib olish: {amount} Stars", reply_markup=admin_menu_kb())
    except:
        await message.answer("❌ Raqam kiriting!")

@dp.callback_query(F.data == "admin_set_crash_bet")
async def admin_set_crash_bet_cb(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id not in Config.ADMIN_IDS:
        return
    await state.set_state(AdminStates.set_crash_min_bet)
    await callback.message.edit_text("🚀 Crash minimal bet miqdorini kiriting:", reply_markup=back_kb())

@dp.message(AdminStates.set_crash_min_bet)
async def set_crash_min_bet_handler(message: Message, state: FSMContext):
    if message.from_user.id not in Config.ADMIN_IDS:
        return
    try:
        amount = int(message.text)
        db.update_setting('crash_min_bet', amount)
        await state.clear()
        await message.answer(f"✅ Crash minimal bet: {amount} Stars", reply_markup=admin_menu_kb())
    except:
        await message.answer("❌ Raqam kiriting!")

@dp.callback_query(F.data == "admin_set_spin_price")
async def admin_set_spin_price_cb(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id not in Config.ADMIN_IDS:
        return
    await state.set_state(AdminStates.set_spin_price)
    await callback.message.edit_text("🎡 Spin narxini kiriting:", reply_markup=back_kb())

@dp.message(AdminStates.set_spin_price)
async def set_spin_price_handler(message: Message, state: FSMContext):
    if message.from_user.id not in Config.ADMIN_IDS:
        return
    try:
        price = int(message.text)
        db.update_setting('spin_price', price)
        await state.clear()
        await message.answer(f"✅ Spin narxi: {price} Stars", reply_markup=admin_menu_kb())
    except:
        await message.answer("❌ Raqam kiriting!")

@dp.callback_query(F.data == "admin_set_spin_rewards")
async def admin_set_spin_rewards_cb(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id not in Config.ADMIN_IDS:
        return
    settings = db.get_settings()
    rewards = settings.get('spin_rewards', [])
    text = "🎡 Spin mukofotlarini o'rnating.\n\nFormat: label|stars|chance\nHar bir qator — alohida mukofot\n\nMisol:\n💥 Yutqazdingiz|0|40\n⭐ x1.5|15|30\n⭐ x2|20|20\n⭐ x5|50|8\n🎉 x10|100|2\n\nJami chance = 100 bo'lishi kerak!"
    await state.set_state(AdminStates.set_spin_rewards)
    await callback.message.edit_text(text, reply_markup=back_kb())

@dp.message(AdminStates.set_spin_rewards)
async def set_spin_rewards_handler(message: Message, state: FSMContext):
    if message.from_user.id not in Config.ADMIN_IDS:
        return
    try:
        rewards = []
        for line in message.text.strip().split('\n'):
            parts = line.split('|')
            rewards.append({
                "label": parts[0].strip(),
                "stars": int(parts[1].strip()),
                "chance": int(parts[2].strip())
            })
        db.update_setting('spin_rewards', rewards)
        await state.clear()
        await message.answer("✅ Spin mukofotlari yangilandi!", reply_markup=admin_menu_kb())
    except:
        await message.answer("❌ Format xato! Qaytadan kiriting.")

@dp.callback_query(F.data == "admin_broadcast")
async def admin_broadcast_cb(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id not in Config.ADMIN_IDS:
        return
    await state.set_state(AdminStates.broadcast)
    await callback.message.edit_text("📨 Yubormoqchi bo'lgan xabaringizni kiriting:", reply_markup=back_kb())

@dp.message(AdminStates.broadcast)
async def broadcast_handler(message: Message, state: FSMContext):
    if message.from_user.id not in Config.ADMIN_IDS:
        return
    await state.clear()
    users = db.get_all_users()
    sent = 0
    failed = 0
    for user in users:
        try:
            await bot.send_message(user['user_id'], message.text)
            sent += 1
            await asyncio.sleep(0.05)
        except:
            failed += 1
    await message.answer(f"📨 Broadcast tugadi!\n✅ Yuborildi: {sent}\n❌ Xato: {failed}", reply_markup=admin_menu_kb())

@dp.callback_query(F.data == "admin_stats")
async def admin_stats_cb(callback: CallbackQuery):
    if callback.from_user.id not in Config.ADMIN_IDS:
        return
    stats = db.get_bot_stats()
    await callback.message.edit_text(
        f"📊 Bot statistikasi:\n\n"
        f"👥 Jami users: {stats['total_users']}\n"
        f"🆕 Bugun: {stats['today_users']}\n"
        f"⭐ Tarqatilgan Stars: {stats['total_stars']}\n"
        f"💸 Kutayotgan so'rovlar: {stats['pending_withdrawals']}\n"
        f"✅ Bajarilgan so'rovlar: {stats['completed_withdrawals']}",
        reply_markup=admin_menu_kb()
    )

@dp.callback_query(F.data == "admin_withdrawals")
async def admin_withdrawals_cb(callback: CallbackQuery):
    if callback.from_user.id not in Config.ADMIN_IDS:
        return
    pending = db.get_pending_withdrawals()
    
    if not pending:
        await callback.message.edit_text("✅ Kutayotgan so'rovlar yo'q!", reply_markup=admin_menu_kb())
        return
    
    for req in pending[:5]:
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Tasdiqlash", callback_data=f"approve_withdraw_{req['id']}"),
                InlineKeyboardButton(text="❌ Rad etish", callback_data=f"reject_withdraw_{req['id']}")
            ]
        ])
        await callback.message.answer(
            f"💸 Yechib olish so'rovi #{req['id']}\n\n"
            f"👤 @{req['username']} (ID: {req['user_id']})\n"
            f"⭐ Miqdor: {req['amount']} Stars\n"
            f"📅 Vaqt: {req['created_at']}",
            reply_markup=kb
        )
    await callback.answer()

@dp.callback_query(F.data.startswith("approve_withdraw_"))
async def approve_withdraw_cb(callback: CallbackQuery):
    if callback.from_user.id not in Config.ADMIN_IDS:
        return
    req_id = int(callback.data.split("_")[2])
    req = db.get_withdraw_request(req_id)
    
    if not req:
        await callback.answer("❌ So'rov topilmadi!", show_alert=True)
        return
    
    db.complete_withdraw(req_id)
    db.add_withdrawn(req['user_id'], req['amount'])
    
    try:
        await bot.send_message(
            req['user_id'],
            f"✅ To'lovingiz amalga oshirildi!\n\n"
            f"⭐ Miqdor: {req['amount']} Stars\n"
            f"🎉 Tabriklaymiz!"
        )
    except:
        pass
    
    await callback.message.edit_text(
        f"✅ #{req_id} so'rov tasdiqlandi! {req['amount']} Stars yuborildi.",
        reply_markup=admin_menu_kb()
    )

@dp.callback_query(F.data.startswith("reject_withdraw_"))
async def reject_withdraw_cb(callback: CallbackQuery):
    if callback.from_user.id not in Config.ADMIN_IDS:
        return
    req_id = int(callback.data.split("_")[2])
    req = db.get_withdraw_request(req_id)
    
    if not req:
        await callback.answer("❌ So'rov topilmadi!", show_alert=True)
        return
    
    db.reject_withdraw(req_id)
    db.add_stars(req['user_id'], req['amount'], 'game')
    
    try:
        await bot.send_message(
            req['user_id'],
            f"❌ Yechib olish so'rovingiz rad etildi.\n"
            f"⭐ {req['amount']} Stars qaytarildi."
        )
    except:
        pass
    
    await callback.message.edit_text(f"❌ #{req_id} so'rov rad etildi.", reply_markup=admin_menu_kb())

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
