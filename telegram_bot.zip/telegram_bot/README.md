# ⭐ Stars Referral Bot

## O'rnatish

### 1. Python o'rnatish
```bash
python3 --version  # 3.10+ bo'lishi kerak
```

### 2. Kutubxonalarni o'rnatish
```bash
pip install -r requirements.txt
```

### 3. config.py ni sozlash
```python
class Config:
    BOT_TOKEN = "1234567890:ABCdef..."  # @BotFather dan oling
    ADMIN_IDS = [123456789]             # Sizning Telegram ID ingiz
```

**Telegram ID ni bilish:** @userinfobot ga /start yuboring

### 4. Botni ishga tushirish
```bash
python bot.py
```

---

## Admin buyruqlari

| Buyruq | Tavsif |
|--------|--------|
| /adminpanel | Admin bosh panel |
| /withdrawals | Yechib olish so'rovlari |

---

## Admin panel imkoniyatlari

- ⭐ **Bonus miqdori** — har bir referal uchun nechta Stars
- 📢 **Kanal qo'shish** — a'zo bo'lish shart bo'lgan kanal
- 👥 **Guruh qo'shish** — a'zo bo'lish shart bo'lgan guruh
- 💸 **Min yechib olish** — minimal yechib olish miqdori
- 🚀 **Crash min bet** — crash o'yinida minimal tikish
- 🎡 **Spin narxi** — baraban o'yini narxi
- 🎁 **Spin mukofotlari** — baraban mukofotlari va ehtimollari
- 📊 **Bot statistika** — umumiy statistika
- 📨 **Broadcast** — barcha userlarga xabar

---

## Spin mukofotlari formati
```
💥 Yutqazdingiz|0|40
⭐ x1.5|15|30
⭐ x2|20|20
⭐ x5|50|8
🎉 x10|100|2
```
`nom|stars_miqdori|ehtimol_foizi` — jami 100% bo'lishi kerak

---

## Tizim qanday ishlaydi

```
Referal link ulashish
        ↓
Yangi odam qo'shiladi
        ↓
Asosiy hisob +Stars (admin belgilagan)
        ↓
Crash / Baraban o'ynash (asosiy yoki o'yin hisob bilan)
        ↓
Yutsa → O'yin hisobiga Stars
        ↓
Yechib olish so'rovi → Adminga bildirishnoma
        ↓
Admin tasdiqlaydi → Foydalanuvchi mukofot oladi
```

---

## Kanal/guruh qo'shish

1. Botni kanalga/guruhga **admin** sifatida qo'shing
2. Admin paneldan kanal/guruh ID sini kiriting
3. ID ni bilish: @getidsbot ga forward qiling

---

## Server da ishlatish (VPS)

```bash
# Screen yoki systemd bilan
screen -S starsbot
python bot.py
# Ctrl+A+D bilan chiqing
```

Yoki `systemd` service sifatida o'rnating.
