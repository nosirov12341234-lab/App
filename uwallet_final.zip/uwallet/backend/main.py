from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from app.core.config import settings
from app.api.v1 import router as api_router
import os

app = FastAPI(
    title="UWallet API",
    version="1.0.0",
    docs_url="/docs" if settings.DEBUG else None,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static fayllar (tonconnect-manifest.json)
static_dir = os.path.join(os.path.dirname(__file__), "static")
os.makedirs(static_dir, exist_ok=True)
app.mount("/static", StaticFiles(directory=static_dir), name="static")

app.include_router(api_router, prefix="/api/v1")


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.get("/tonconnect-manifest.json")
async def tonconnect_manifest():
    """TonConnect manifest — root URL dan ham ishlaydi"""
    from fastapi.responses import FileResponse
    manifest_path = os.path.join(static_dir, "tonconnect-manifest.json")
    return FileResponse(manifest_path)
