from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import Task, TaskCompletion, Balance, Transaction, TxType, TxStatus
import httpx, os

router = APIRouter()
BOT_TOKEN = os.getenv("BOT_TOKEN", "")


async def check_channel_subscription(user_id: int, channel: str) -> bool:
    """Telegram bot API orqali kanalga obunani tekshirish"""
    try:
        async with httpx.AsyncClient() as client:
            res = await client.get(
                f"https://api.telegram.org/bot{BOT_TOKEN}/getChatMember",
                params={"chat_id": channel, "user_id": user_id},
                timeout=5,
            )
            data = res.json()
            if data.get("ok"):
                status = data["result"]["status"]
                return status in ["member", "administrator", "creator"]
    except Exception:
        pass
    return False


@router.get("/")
async def get_tasks(
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Task).where(Task.is_active == True))
    tasks = result.scalars().all()

    comp_result = await db.execute(
        select(TaskCompletion).where(TaskCompletion.user_id == current_user.id)
    )
    completions = {c.task_id: c for c in comp_result.scalars().all()}

    # Token nomlarini olish
    from app.models.models import Token
    tok_ids = list({t.reward_token_id for t in tasks})
    tok_map = {}
    for tid in tok_ids:
        tok = await db.get(Token, tid)
        if tok:
            tok_map[tid] = tok.symbol

    return [
        {
            "id": t.id,
            "title": t.title,
            "description": t.description,
            "type": t.task_type,
            "target": t.target,
            "reward_amount": str(t.reward_amount),
            "reward_token": tok_map.get(t.reward_token_id, ""),
            "reward_token_id": t.reward_token_id,
            "completed": t.id in completions,
            "verified": completions[t.id].is_verified if t.id in completions else False,
            "reward_paid": completions[t.id].reward_paid if t.id in completions else False,
        }
        for t in tasks
    ]


@router.post("/{task_id}/complete")
async def complete_task(
    task_id: int,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    task = await db.get(Task, task_id)
    if not task or not task.is_active:
        raise HTTPException(status_code=404, detail="Task topilmadi")

    existing = await db.execute(
        select(TaskCompletion).where(
            TaskCompletion.user_id == current_user.id,
            TaskCompletion.task_id == task_id
        )
    )
    comp = existing.scalar_one_or_none()

    # Allaqachon mukofot berilgan
    if comp and comp.reward_paid:
        return {"message": "Task allaqachon bajarilgan", "already_done": True}

    verified = False

    if task.task_type == "channel":
        # Bot orqali obunani tekshirish
        is_subscribed = await check_channel_subscription(current_user.id, task.target)
        if is_subscribed:
            verified = True
        else:
            if not comp:
                db.add(TaskCompletion(
                    user_id=current_user.id,
                    task_id=task_id,
                    is_verified=False,
                    reward_paid=False,
                ))
                await db.commit()
            return {
                "message": f"Avval {task.target} kanaliga obuna bo'ling, keyin qayta bosing",
                "verified": False,
            }

    elif task.task_type == "link":
        # Birinchi marta — pending, ikkinchi marta — tasdiqlash
        if not comp:
            db.add(TaskCompletion(
                user_id=current_user.id,
                task_id=task_id,
                is_verified=False,
                reward_paid=False,
            ))
            await db.commit()
            return {
                "message": f"Havolani oching va qaytib keling",
                "url": task.target,
                "verified": False,
            }
        else:
            verified = True

    if verified:
        # Mukofot berish
        from app.models.models import Balance
        bal_r = await db.execute(
            select(Balance).where(
                Balance.user_id == current_user.id,
                Balance.token_id == task.reward_token_id
            )
        )
        bal = bal_r.scalar_one_or_none()
        if bal:
            bal.amount += task.reward_amount
        else:
            db.add(Balance(
                user_id=current_user.id,
                token_id=task.reward_token_id,
                amount=task.reward_amount,
            ))

        db.add(Transaction(
            user_id=current_user.id,
            token_id=task.reward_token_id,
            tx_type=TxType.TASK_REWARD,
            status=TxStatus.CONFIRMED,
            amount=task.reward_amount,
            note=f"Task mukofoti: {task.title}",
        ))

        if comp:
            comp.is_verified = True
            comp.reward_paid = True
        else:
            db.add(TaskCompletion(
                user_id=current_user.id,
                task_id=task_id,
                is_verified=True,
                reward_paid=True,
            ))

        await db.commit()
        return {
            "message": f"✅ Bajarildi! +{task.reward_amount} mukofot berildi",
            "verified": True,
            "reward": str(task.reward_amount),
        }
