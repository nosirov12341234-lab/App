from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import (
    Balance, Token, Transaction, TxType, TxStatus,
    WithdrawRequest, AdminSetting
)
from pydantic import BaseModel
from decimal import Decimal

router = APIRouter()


async def get_setting(db, key, default="0"):
    r = await db.execute(select(AdminSetting).where(AdminSetting.key == key))
    s = r.scalar_one_or_none()
    return s.value if s else default


@router.get("/balances")
async def get_balances(
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(
        select(Balance, Token)
        .join(Token)
        .where(Balance.user_id == current_user.id, Token.is_active == True)
        .order_by(Token.is_default.desc(), Token.symbol)
    )
    rows = result.all()
    return [
        {
            "token": {
                "id": token.id,
                "symbol": token.symbol,
                "name": token.name,
                "network": token.network,
                "icon_url": token.icon_url,
                "is_default": token.is_default,
                "deposit_fee_percent": str(token.deposit_fee_percent),
                "withdraw_fee_percent": str(token.withdraw_fee_percent),
                "withdraw_fee_flat": str(token.withdraw_fee_flat),
                "min_deposit": str(token.min_deposit),
                "min_withdraw": str(token.min_withdraw),
            },
            "amount": str(balance.amount),
            "frozen": str(balance.frozen),
            "available": str(balance.amount - balance.frozen),
        }
        for balance, token in rows
    ]


@router.get("/tokens")
async def get_tokens(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Token).where(Token.is_active == True).order_by(Token.is_default.desc())
    )
    return [
        {
            "id": t.id,
            "symbol": t.symbol,
            "name": t.name,
            "network": t.network,
            "decimals": t.decimals,
            "deposit_fee_percent": str(t.deposit_fee_percent),
            "withdraw_fee_percent": str(t.withdraw_fee_percent),
            "withdraw_fee_flat": str(t.withdraw_fee_flat),
            "min_deposit": str(t.min_deposit),
            "min_withdraw": str(t.min_withdraw),
            "icon_url": t.icon_url,
        }
        for t in result.scalars().all()
    ]


@router.get("/deposit-address")
async def get_deposit_address(
    token_id: int,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    token = await db.get(Token, token_id)
    if not token:
        raise HTTPException(status_code=404, detail="Token topilmadi")

    pool_wallet = await get_setting(db, "pool_wallet_address")
    from app.core.config import settings
    address = pool_wallet or settings.MASTER_WALLET_ADDRESS

    return {
        "address": address,
        "memo": str(current_user.id),
        "token": token.symbol,
        "network": token.network,
        "deposit_fee_percent": str(token.deposit_fee_percent),
        "note": f"Memo/Comment maydoniga {current_user.id} raqamini kiriting. Aks holda pul yo'qoladi!",
    }


class WithdrawReq(BaseModel):
    token_id: int
    amount: Decimal
    destination: str


@router.post("/withdraw")
async def create_withdraw(
    req: WithdrawReq,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    token = await db.get(Token, req.token_id)
    if not token:
        raise HTTPException(status_code=404, detail="Token topilmadi")

    if req.amount < token.min_withdraw:
        raise HTTPException(status_code=400, detail=f"Minimal chiqarish: {token.min_withdraw} {token.symbol}")

    bal = await db.execute(
        select(Balance).where(
            Balance.user_id == current_user.id,
            Balance.token_id == req.token_id
        )
    )
    balance = bal.scalar_one_or_none()
    available = (balance.amount - balance.frozen) if balance else Decimal(0)
    if available < req.amount:
        raise HTTPException(status_code=400, detail="Yetarli balans yo'q")

    # Fee hisoblash
    fee = req.amount * token.withdraw_fee_percent / 100 + token.withdraw_fee_flat
    net = req.amount - fee

    # Freeze
    balance.frozen += req.amount

    withdraw = WithdrawRequest(
        user_id=current_user.id,
        token_id=req.token_id,
        amount=req.amount,
        fee=fee,
        destination=req.destination,
        status="pending",
    )
    db.add(withdraw)
    await db.commit()

    return {
        "message": "Chiqarish so'rovi yuborildi",
        "amount": str(req.amount),
        "fee": str(fee),
        "net_amount": str(net),
        "token": token.symbol,
        "status": "pending",
    }


@router.get("/history")
async def get_history(
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    limit: int = 50,
    offset: int = 0,
):
    result = await db.execute(
        select(Transaction, Token)
        .join(Token)
        .where(Transaction.user_id == current_user.id)
        .order_by(Transaction.created_at.desc())
        .limit(limit).offset(offset)
    )
    return [
        {
            "id": tx.id,
            "type": tx.tx_type,
            "status": tx.status,
            "amount": str(tx.amount),
            "fee": str(tx.fee),
            "token": tok.symbol,
            "tx_hash": tx.tx_hash,
            "note": tx.note,
            "created_at": tx.created_at.isoformat(),
        }
        for tx, tok in result.all()
    ]
