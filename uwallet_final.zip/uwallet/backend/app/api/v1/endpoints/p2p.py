from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import (
    P2POrder, P2PTrade, Balance, Token, Transaction,
    TxType, TxStatus, AdminSetting
)
from pydantic import BaseModel
from decimal import Decimal
from typing import Optional
from datetime import datetime

router = APIRouter()


async def get_setting(db, key, default="0"):
    r = await db.execute(select(AdminSetting).where(AdminSetting.key == key))
    s = r.scalar_one_or_none()
    return s.value if s else default


# ── E'lonlar ro'yxati ─────────────────────────────────────

@router.get("/orders")
async def get_orders(
    token_id: Optional[int] = None,
    order_type: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    q = select(P2POrder, Token).join(Token).where(P2POrder.status == "open")
    if token_id:
        q = q.where(P2POrder.token_id == token_id)
    if order_type:
        q = q.where(P2POrder.order_type == order_type)
    result = await db.execute(q.order_by(P2POrder.created_at.desc()))
    rows = result.all()
    return [
        {
            "id": order.id,
            "user_id": order.user_id,
            "token": token.symbol,
            "token_id": token.id,
            "type": order.order_type,
            "amount": str(order.amount),
            "price_uzs": str(order.price_uzs),
            "total_uzs": str(order.amount * order.price_uzs),
            "payment_method": order.payment_method,
            "min_amount": str(order.min_amount) if order.min_amount else None,
            "max_amount": str(order.max_amount) if order.max_amount else None,
            "note": order.note,
            "created_at": order.created_at.isoformat(),
        }
        for order, token in rows
    ]


# ── E'lon yaratish ────────────────────────────────────────

class CreateOrderRequest(BaseModel):
    token_id: int
    order_type: str  # sell | buy
    amount: Decimal
    price_uzs: Decimal
    payment_method: str
    min_amount: Optional[Decimal] = None
    max_amount: Optional[Decimal] = None
    note: Optional[str] = None


@router.post("/orders")
async def create_order(
    req: CreateOrderRequest,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    token = await db.get(Token, req.token_id)
    if not token:
        raise HTTPException(status_code=404, detail="Token topilmadi")

    if req.order_type == "sell":
        bal = await db.execute(
            select(Balance).where(
                Balance.user_id == current_user.id,
                Balance.token_id == req.token_id
            )
        )
        balance = bal.scalar_one_or_none()
        if not balance or balance.amount - balance.frozen < req.amount:
            raise HTTPException(status_code=400, detail="Yetarli balans yo'q")
        balance.frozen += req.amount

    order = P2POrder(
        user_id=current_user.id,
        token_id=req.token_id,
        order_type=req.order_type,
        status="open",
        amount=req.amount,
        price_uzs=req.price_uzs,
        payment_method=req.payment_method,
        min_amount=req.min_amount,
        max_amount=req.max_amount,
        note=req.note,
    )
    db.add(order)
    await db.commit()
    await db.refresh(order)
    return {"message": "E'lon qo'shildi", "order_id": order.id}


# ── E'lonni bekor qilish ──────────────────────────────────

@router.post("/orders/{order_id}/cancel")
async def cancel_order(
    order_id: int,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    order = await db.get(P2POrder, order_id)
    if not order or order.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="E'lon topilmadi")
    if order.status != "open":
        raise HTTPException(status_code=400, detail="Bekor qilib bo'lmaydi")

    if order.order_type == "sell":
        bal = await db.execute(
            select(Balance).where(
                Balance.user_id == current_user.id,
                Balance.token_id == order.token_id
            )
        )
        balance = bal.scalar_one_or_none()
        if balance:
            balance.frozen -= order.amount

    order.status = "cancelled"
    await db.commit()
    return {"message": "E'lon bekor qilindi"}


# ── Trade boshlash (xaridor e'longa murojaat qiladi) ─────

class StartTradeRequest(BaseModel):
    amount: Decimal  # qancha token sotib olmoqchi


@router.post("/orders/{order_id}/trade")
async def start_trade(
    order_id: int,
    req: StartTradeRequest,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    order = await db.get(P2POrder, order_id)
    if not order or order.status != "open":
        raise HTTPException(status_code=404, detail="E'lon mavjud emas")
    if order.user_id == current_user.id:
        raise HTTPException(status_code=400, detail="O'z e'loningizga murojaat qila olmaysiz")
    if req.amount > order.amount:
        raise HTTPException(status_code=400, detail="Miqdor e'londan ko'p")
    if order.min_amount and req.amount < order.min_amount:
        raise HTTPException(status_code=400, detail=f"Minimal miqdor: {order.min_amount}")

    # P2P komissiya
    p2p_fee_pct = Decimal(await get_setting(db, "p2p_fee_percent", "0.5"))
    fee_amount = req.amount * p2p_fee_pct / 100
    total_uzs = req.amount * order.price_uzs

    # Savdo yaratish
    if order.order_type == "sell":
        buyer_id = current_user.id
        seller_id = order.user_id
    else:
        buyer_id = order.user_id
        seller_id = current_user.id

    trade = P2PTrade(
        order_id=order.id,
        buyer_id=buyer_id,
        seller_id=seller_id,
        token_id=order.token_id,
        amount=req.amount,
        price_uzs=order.price_uzs,
        total_uzs=total_uzs,
        platform_fee=fee_amount,
        status="in_progress",
    )
    db.add(trade)

    # E'lon miqdorini kamaytirish
    order.amount -= req.amount
    if order.amount <= 0:
        order.status = "in_progress"

    await db.commit()
    await db.refresh(trade)

    return {
        "trade_id": trade.id,
        "amount": str(req.amount),
        "total_uzs": str(total_uzs),
        "price_uzs": str(order.price_uzs),
        "payment_method": order.payment_method,
        "platform_fee": str(fee_amount),
        "seller_id": seller_id,
        "buyer_id": buyer_id,
        "status": "in_progress",
        "message": "Savdo boshlandi. To'lovni amalga oshiring va tasdiqlang.",
    }


# ── To'lov qilindim (xaridor tasdiqlaydi) ────────────────

@router.post("/trades/{trade_id}/payment-sent")
async def payment_sent(
    trade_id: int,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    trade = await db.get(P2PTrade, trade_id)
    if not trade or trade.status != "in_progress":
        raise HTTPException(status_code=404, detail="Savdo topilmadi")
    if trade.buyer_id != current_user.id:
        raise HTTPException(status_code=403, detail="Faqat xaridor tasdiqlaydi")

    trade.payment_confirmed_at = datetime.utcnow()
    trade.status = "payment_sent"
    await db.commit()
    return {"message": "To'lov tasdiqlandi. Sotuvchi tasdiqlashini kuting."}


# ── Sotuvchi tokenni chiqaradi (savdo yakunlanadi) ───────

@router.post("/trades/{trade_id}/release")
async def release_tokens(
    trade_id: int,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    trade = await db.get(P2PTrade, trade_id)
    if not trade or trade.status != "payment_sent":
        raise HTTPException(status_code=404, detail="Savdo topilmadi yoki to'lov tasdiqlanmagan")
    if trade.seller_id != current_user.id:
        raise HTTPException(status_code=403, detail="Faqat sotuvchi chiqaradi")

    token = await db.get(Token, trade.token_id)
    p2p_fee_pct = Decimal(await get_setting(db, "p2p_fee_percent", "0.5"))
    fee = trade.amount * p2p_fee_pct / 100
    net_amount = trade.amount - fee

    # Sotuvchi balansidan frozen kamaytirish
    seller_bal = await db.execute(
        select(Balance).where(
            Balance.user_id == trade.seller_id,
            Balance.token_id == trade.token_id
        )
    )
    seller_balance = seller_bal.scalar_one_or_none()
    if seller_balance:
        seller_balance.frozen -= trade.amount
        seller_balance.amount -= trade.amount

    # Xaridor balansiga qo'shish (fee ayirib)
    buyer_bal = await db.execute(
        select(Balance).where(
            Balance.user_id == trade.buyer_id,
            Balance.token_id == trade.token_id
        )
    )
    buyer_balance = buyer_bal.scalar_one_or_none()
    if buyer_balance:
        buyer_balance.amount += net_amount
    else:
        db.add(Balance(
            user_id=trade.buyer_id,
            token_id=trade.token_id,
            amount=net_amount
        ))

    # Tx log — sotuvchi
    db.add(Transaction(
        user_id=trade.seller_id,
        token_id=trade.token_id,
        tx_type=TxType.P2P_SELL,
        status=TxStatus.CONFIRMED,
        amount=trade.amount,
        fee=fee,
        note=f"P2P sotuv #{trade.id}",
    ))
    # Tx log — xaridor
    db.add(Transaction(
        user_id=trade.buyer_id,
        token_id=trade.token_id,
        tx_type=TxType.P2P_BUY,
        status=TxStatus.CONFIRMED,
        amount=net_amount,
        fee=fee,
        note=f"P2P xarid #{trade.id}",
    ))

    trade.status = "completed"
    trade.completed_at = datetime.utcnow()
    await db.commit()

    return {
        "message": "Savdo yakunlandi!",
        "amount_sent": str(net_amount),
        "fee": str(fee),
        "token": token.symbol,
    }


# ── Mening savdolarim ─────────────────────────────────────

@router.get("/my-trades")
async def my_trades(
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(P2PTrade, Token).join(Token, P2PTrade.token_id == Token.id).where(
            (P2PTrade.buyer_id == current_user.id) |
            (P2PTrade.seller_id == current_user.id)
        ).order_by(P2PTrade.created_at.desc())
    )
    rows = result.all()
    return [
        {
            "id": t.id,
            "role": "buyer" if t.buyer_id == current_user.id else "seller",
            "token": tok.symbol,
            "amount": str(t.amount),
            "price_uzs": str(t.price_uzs),
            "total_uzs": str(t.total_uzs),
            "fee": str(t.platform_fee),
            "status": t.status,
            "created_at": t.created_at.isoformat(),
        }
        for t, tok in rows
    ]


# ── Mening e'lonlarim ─────────────────────────────────────

@router.get("/my-orders")
async def my_orders(
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(P2POrder, Token).join(Token).where(
            P2POrder.user_id == current_user.id
        ).order_by(P2POrder.created_at.desc())
    )
    rows = result.all()
    return [
        {
            "id": o.id,
            "token": tok.symbol,
            "type": o.order_type,
            "amount": str(o.amount),
            "price_uzs": str(o.price_uzs),
            "status": o.status,
            "payment_method": o.payment_method,
            "created_at": o.created_at.isoformat(),
        }
        for o, tok in rows
    ]
