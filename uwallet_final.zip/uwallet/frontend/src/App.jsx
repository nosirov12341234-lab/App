import { useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { TonConnectUIProvider } from "@tonconnect/ui-react";
import { useAuthStore } from "./store/authStore";
import BottomNav from "./components/common/BottomNav";
import HomePage from "./pages/HomePage";
import WalletPage from "./pages/WalletPage";
import P2PPage from "./pages/P2PPage";
import DAppsPage from "./pages/DAppsPage";
import TasksPage from "./pages/TasksPage";
import ProfilePage from "./pages/ProfilePage";
import DepositPage from "./pages/DepositPage";
import UzsDepositPage from "./pages/UzsDepositPage";
import WithdrawPage from "./pages/WithdrawPage";
import TransferPage from "./pages/TransferPage";
import HistoryPage from "./pages/HistoryPage";
import AdminPage from "./pages/AdminPage";

const MANIFEST_URL = `${import.meta.env.VITE_API_URL}/tonconnect-manifest.json`;

export default function App() {
  const { login } = useAuthStore();

  useEffect(() => {
    const tg = window.Telegram?.WebApp;
    if (tg) {
      tg.ready();
      tg.expand();
      tg.setHeaderColor("#0A0E1A");
      tg.setBackgroundColor("#0A0E1A");
      tg.enableClosingConfirmation();
    }
    login();
  }, []);

  return (
    <TonConnectUIProvider manifestUrl={MANIFEST_URL}>
      <BrowserRouter>
        <div className="min-h-screen bg-bg-primary text-text-primary font-sans select-none">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/wallet" element={<WalletPage />} />
            <Route path="/deposit" element={<DepositPage />} />
            <Route path="/deposit/uzs" element={<UzsDepositPage />} />
            <Route path="/withdraw" element={<WithdrawPage />} />
            <Route path="/transfer" element={<TransferPage />} />
            <Route path="/history" element={<HistoryPage />} />
            <Route path="/p2p" element={<P2PPage />} />
            <Route path="/dapps" element={<DAppsPage />} />
            <Route path="/tasks" element={<TasksPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/admin" element={<AdminPage />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
          <BottomNav />
        </div>
      </BrowserRouter>
    </TonConnectUIProvider>
  );
}
