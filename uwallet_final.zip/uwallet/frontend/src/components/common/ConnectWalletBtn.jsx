import { TonConnectButton, useTonWallet } from "@tonconnect/ui-react";

export default function ConnectWalletBtn({ className = "" }) {
  const wallet = useTonWallet();
  return (
    <div className={className}>
      <TonConnectButton />
    </div>
  );
}
