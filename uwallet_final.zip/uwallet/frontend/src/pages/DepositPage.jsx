import { useEffect, useState } from "react";
import { useTonConnectUI, useTonWallet } from "@tonconnect/ui-react";
import { useNavigate } from "react-router-dom";
import api from "../utils/api";

export default function DepositPage() {
  const navigate = useNavigate();
  const [tonConnectUI] = useTonConnectUI();
  const wallet = useTonWallet();
  const [tokens, setTokens] = useState([]);
  const [selectedToken, setSelectedToken] = useState(null);
  const [depositInfo, setDepositInfo] = useState(null);
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);
  const [copied, setCopied] = useState("");

  useEffect(() => {
    api.get("/wallet/tokens").then(r => {
      const crypto = r.data.filter(t => t.symbol !== "UZS");
      setTokens(crypto);
      setSelectedToken(crypto[0]);
    });
  }, []);

  const getDepositInfo = async () => {
    if (!selectedToken) return;
    setLoading(true);
    const res = await api.get("/wallet/deposit-address", { params: { token_id: selectedToken.id } });
    setDepositInfo(res.data);
    setLoading(false);
    setStep(2);
  };

  const copy = (text, key) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(""), 2000);
  };

  const sendViaTonConnect = async () => {
    if (!depositInfo || !amount) return;
    if (!wallet) {
      alert("Avval wallet ulang!");
      await tonConnectUI.openModal();
      return;
    }
    setLoading(true);
    try {
      const nanoAmount = String(Math.floor(parseFloat(amount) * 1e9));
      await tonConnectUI.sendTransaction({
        validUntil: Math.floor(Date.now() / 1000) + 300,
        messages: [{
          address: depositInfo.address,
          amount: nanoAmount,
          payload: btoa(depositInfo.memo),
        }],
      });
      setStep(3);
    } catch (e) {
      if (e?.message !== "User rejected the transaction") {
        alert("Xatolik: " + e.message);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="pb-24 px-4 pt-6">
      <button onClick={() => step > 1 ? setStep(s => s - 1) : navigate(-1)} className="text-text-secondary mb-5">← Orqaga</button>
      <h1 className="text-xl font-bold mb-2">Kripto Kiritish</h1>
      <p className="text-text-muted text-sm mb-5">TON tarmog'idagi tokenlar</p>

      {step === 1 && (
        <div className="space-y-3">
          {/* UZS yo'naltirish */}
          <button onClick={() => navigate("/deposit/uzs")}
            className="w-full bg-bg-card border border-accent-green/30 rounded-2xl px-4 py-3.5 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-accent-green/20 flex items-center justify-center font-bold text-accent-green">₴</div>
            <div className="text-left flex-1">
              <p className="font-semibold text-sm">UZS (So'm) kiritish</p>
              <p className="text-xs text-text-muted">Humo karta orqali • Avtomatik • Bepul</p>
            </div>
            <span className="text-accent-green text-xs">→</span>
          </button>

          <div className="flex items-center gap-3 my-2">
            <div className="flex-1 h-px bg-border" />
            <span className="text-xs text-text-muted">Kripto tokenlar</span>
            <div className="flex-1 h-px bg-border" />
          </div>

          <div className="space-y-2">
            {tokens.map(t => (
              <button key={t.id} onClick={() => setSelectedToken(t)}
                className={`w-full bg-bg-card rounded-2xl px-4 py-3 flex items-center justify-between border transition-colors ${
                  selectedToken?.id === t.id ? "border-accent-blue" : "border-border"
                }`}>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-accent-blue/20 flex items-center justify-center text-xs font-bold text-accent-blue">
                    {t.symbol.slice(0,2)}
                  </div>
                  <div className="text-left">
                    <p className="font-semibold text-sm">{t.symbol}</p>
                    <p className="text-xs text-text-muted">{t.network}</p>
                  </div>
                </div>
                <span className="text-xs text-text-muted">Komissiya: {t.deposit_fee_percent}%</span>
              </button>
            ))}
          </div>

          <button onClick={getDepositInfo} disabled={!selectedToken || loading}
            className="w-full py-3 rounded-2xl bg-accent-blue text-white font-semibold disabled:opacity-50">
            {loading ? "Yuklanmoqda..." : "Manzilni olish"}
          </button>
        </div>
      )}

      {step === 2 && depositInfo && (
        <div className="space-y-4">
          {/* Address */}
          <div className="bg-bg-card rounded-2xl p-4 space-y-3">
            <p className="text-xs text-text-secondary uppercase tracking-wider">Pool Wallet Manzili ({depositInfo.network})</p>
            <div className="flex items-center gap-2">
              <p className="font-mono text-xs break-all flex-1 text-text-primary">{depositInfo.address}</p>
              <button onClick={() => copy(depositInfo.address, "addr")}
                className={`px-2 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  copied === "addr" ? "bg-accent-green/20 text-accent-green" : "bg-bg-elevated text-text-secondary"
                }`}>
                {copied === "addr" ? "✓" : "Nusxa"}
              </button>
            </div>

            <hr className="border-border" />

            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-text-secondary mb-1">Memo / Comment (MAJBURIY)</p>
                <p className="font-bold text-accent-yellow text-2xl tracking-wider">{depositInfo.memo}</p>
              </div>
              <button onClick={() => copy(depositInfo.memo, "memo")}
                className={`px-3 py-2 rounded-xl text-sm font-semibold transition-colors ${
                  copied === "memo" ? "bg-accent-green/20 text-accent-green" : "bg-bg-elevated text-text-secondary"
                }`}>
                {copied === "memo" ? "✓ Nusxalandi" : "Nusxalash"}
              </button>
            </div>
            <div className="bg-accent-red/10 rounded-xl p-2.5">
              <p className="text-xs text-accent-red">⚠️ Memo kiritmasangiz pul yo'qoladi! Qaytarib bo'lmaydi.</p>
            </div>
          </div>

          {/* Amount */}
          <div className="bg-bg-card rounded-2xl p-4">
            <p className="text-sm text-text-secondary mb-2">Miqdor ({selectedToken?.symbol})</p>
            <input type="number"
              className="w-full bg-bg-elevated border border-border rounded-xl px-4 py-3 text-sm outline-none focus:border-accent-blue"
              placeholder="0.00" value={amount} onChange={e => setAmount(e.target.value)} />
            {parseFloat(selectedToken?.deposit_fee_percent || 0) > 0 && amount && (
              <p className="text-xs text-text-muted mt-1.5">
                Komissiya: {(parseFloat(amount) * parseFloat(selectedToken.deposit_fee_percent) / 100).toFixed(6)} {selectedToken.symbol}
              </p>
            )}
          </div>

          {/* TonConnect button */}
          {wallet ? (
            <button onClick={sendViaTonConnect} disabled={!amount || loading}
              className="w-full py-3 rounded-2xl bg-accent-blue text-white font-semibold disabled:opacity-50">
              {loading ? "Yuborilmoqda..." : `TonConnect orqali yuborish`}
            </button>
          ) : (
            <button onClick={() => tonConnectUI.openModal()}
              className="w-full py-3 rounded-2xl bg-accent-blue/20 text-accent-blue font-semibold border border-accent-blue/30">
              🔗 Wallet ulash (TonConnect)
            </button>
          )}

          <p className="text-xs text-center text-text-muted">yoki yuqoridagi manzilga qo'lda yuboring</p>
        </div>
      )}

      {step === 3 && (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="w-20 h-20 rounded-full bg-accent-green/20 flex items-center justify-center text-4xl mb-5">✓</div>
          <h2 className="text-xl font-bold mb-2">Tranzaksiya yuborildi!</h2>
          <p className="text-text-secondary text-sm mb-2">Blockchain tasdiqlangach balans yangilanadi</p>
          <p className="text-text-muted text-xs mb-8">Odatda 1-2 daqiqa vaqt ketadi</p>
          <button onClick={() => navigate("/")} className="w-full py-3 rounded-2xl bg-accent-blue text-white font-semibold">
            Bosh sahifaga
          </button>
        </div>
      )}
    </div>
  );
}
