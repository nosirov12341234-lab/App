import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuthStore } from "../store/authStore";
import api from "../utils/api";

export default function P2PPage() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [tab, setTab] = useState("market"); // market | my-orders | my-trades
  const [orders, setOrders] = useState([]);
  const [myOrders, setMyOrders] = useState([]);
  const [myTrades, setMyTrades] = useState([]);
  const [tokens, setTokens] = useState([]);
  const [activeType, setActiveType] = useState("sell");
  const [selectedToken, setSelectedToken] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [tradeModal, setTradeModal] = useState(null);

  useEffect(() => {
    api.get("/wallet/tokens").then((r) => {
      const crypto = r.data.filter(t => t.symbol !== "UZS");
      setTokens(crypto);
      if (crypto.length) setSelectedToken(crypto[0]);
    });
  }, []);

  useEffect(() => {
    if (tab === "market" && selectedToken) {
      setLoading(true);
      api.get("/p2p/orders", { params: { token_id: selectedToken.id, order_type: activeType } })
        .then(r => { setOrders(r.data); setLoading(false); });
    } else if (tab === "my-orders") {
      api.get("/p2p/my-orders").then(r => setMyOrders(r.data));
    } else if (tab === "my-trades") {
      api.get("/p2p/my-trades").then(r => setMyTrades(r.data));
    }
  }, [tab, activeType, selectedToken]);

  const cancelOrder = async (id) => {
    await api.post(`/p2p/orders/${id}/cancel`);
    setMyOrders(o => o.filter(x => x.id !== id));
  };

  const paymentSent = async (tradeId) => {
    await api.post(`/p2p/trades/${tradeId}/payment-sent`);
    api.get("/p2p/my-trades").then(r => setMyTrades(r.data));
    alert("To'lov tasdiqlandi! Sotuvchi tasdiqlashini kuting.");
  };

  const releaseTokens = async (tradeId) => {
    const res = await api.post(`/p2p/trades/${tradeId}/release`);
    api.get("/p2p/my-trades").then(r => setMyTrades(r.data));
    alert(`✅ ${res.data.message}`);
  };

  const STATUS_COLORS = {
    open: "text-accent-green", in_progress: "text-accent-yellow",
    payment_sent: "text-accent-blue", completed: "text-accent-green",
    cancelled: "text-text-muted",
  };
  const STATUS_LABELS = {
    open: "Ochiq", in_progress: "Jarayonda", payment_sent: "To'lov kutilmoqda",
    completed: "Yakunlandi", cancelled: "Bekor qilindi",
  };

  return (
    <div className="pb-24">
      <div className="px-4 pt-6 pb-3 flex items-center justify-between">
        <h1 className="text-xl font-bold">P2P Market</h1>
        <button onClick={() => setShowCreate(true)}
          className="px-3 py-2 rounded-xl bg-accent-blue text-white text-sm font-semibold">
          + E'lon
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 px-4 mb-4 overflow-x-auto scrollbar-none">
        {[["market","Bozor"],["my-orders","E'lonlarim"],["my-trades","Savdolarim"]].map(([k,l]) => (
          <button key={k} onClick={() => setTab(k)}
            className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              tab === k ? "bg-accent-blue text-white" : "bg-bg-card text-text-secondary"
            }`}>
            {l}
          </button>
        ))}
      </div>

      {/* MARKET TAB */}
      {tab === "market" && (
        <>
          <div className="flex gap-2 px-4 mb-3">
            <button onClick={() => setActiveType("sell")}
              className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
                activeType === "sell" ? "bg-accent-green/20 text-accent-green" : "bg-bg-card text-text-muted"
              }`}>
              Sotish e'lonlari
            </button>
            <button onClick={() => setActiveType("buy")}
              className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
                activeType === "buy" ? "bg-accent-red/20 text-accent-red" : "bg-bg-card text-text-muted"
              }`}>
              Sotib olish
            </button>
          </div>

          <div className="flex gap-2 px-4 mb-4 overflow-x-auto scrollbar-none">
            {tokens.map(t => (
              <button key={t.id} onClick={() => setSelectedToken(t)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedToken?.id === t.id ? "bg-accent-blue text-white" : "bg-bg-card text-text-secondary"
                }`}>
                {t.symbol}
              </button>
            ))}
          </div>

          <div className="px-4 space-y-3">
            {loading
              ? [1,2,3].map(i => <div key={i} className="bg-bg-card rounded-2xl h-24 animate-pulse" />)
              : orders.length === 0
                ? <p className="text-center text-text-muted py-10">E'lonlar yo'q</p>
                : orders.map(order => (
                  <div key={order.id} className="bg-bg-card rounded-2xl p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <p className="text-xl font-bold">{parseFloat(order.price_uzs).toLocaleString("uz-UZ")} <span className="text-sm font-normal text-text-muted">UZS</span></p>
                        <p className="text-xs text-text-muted">1 {order.token} narxi</p>
                      </div>
                      {order.user_id !== user?.id && (
                        <button onClick={() => setTradeModal(order)}
                          className={`px-4 py-2 rounded-xl text-sm font-semibold ${
                            activeType === "sell" ? "bg-accent-green/20 text-accent-green" : "bg-accent-red/20 text-accent-red"
                          }`}>
                          {activeType === "sell" ? "Sotib ol" : "Sot"}
                        </button>
                      )}
                    </div>
                    <div className="flex gap-3 text-xs text-text-secondary flex-wrap">
                      <span>💰 {parseFloat(order.amount).toFixed(4)} {order.token}</span>
                      <span>💳 {order.payment_method}</span>
                      {order.min_amount && <span>Min: {order.min_amount} {order.token}</span>}
                    </div>
                    {order.note && <p className="text-xs text-text-muted mt-2 italic">"{order.note}"</p>}
                  </div>
                ))
            }
          </div>
        </>
      )}

      {/* MY ORDERS TAB */}
      {tab === "my-orders" && (
        <div className="px-4 space-y-3">
          {myOrders.length === 0
            ? <p className="text-center text-text-muted py-10">E'lonlar yo'q</p>
            : myOrders.map(o => (
              <div key={o.id} className="bg-bg-card rounded-2xl p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-semibold">{o.type === "sell" ? "Sotish" : "Sotib olish"} — {o.token}</p>
                    <p className="text-sm">{parseFloat(o.amount).toFixed(4)} × {parseFloat(o.price_uzs).toLocaleString()} UZS</p>
                  </div>
                  <span className={`text-xs font-semibold ${STATUS_COLORS[o.status]}`}>
                    {STATUS_LABELS[o.status]}
                  </span>
                </div>
                {o.status === "open" && (
                  <button onClick={() => cancelOrder(o.id)}
                    className="mt-2 px-3 py-1.5 rounded-lg bg-accent-red/20 text-accent-red text-xs font-semibold">
                    Bekor qilish
                  </button>
                )}
              </div>
            ))
          }
        </div>
      )}

      {/* MY TRADES TAB */}
      {tab === "my-trades" && (
        <div className="px-4 space-y-3">
          {myTrades.length === 0
            ? <p className="text-center text-text-muted py-10">Savdolar yo'q</p>
            : myTrades.map(t => (
              <div key={t.id} className="bg-bg-card rounded-2xl p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-semibold">
                      {t.role === "buyer" ? "🛒 Xarid" : "💸 Sotuv"} — {t.token}
                    </p>
                    <p className="text-sm">{parseFloat(t.amount).toFixed(4)} × {parseFloat(t.price_uzs).toLocaleString()} UZS</p>
                    <p className="text-xs text-text-muted">Jami: {parseFloat(t.total_uzs).toLocaleString()} UZS</p>
                    <p className="text-xs text-text-muted">Komissiya: {parseFloat(t.fee).toFixed(6)} {t.token}</p>
                  </div>
                  <span className={`text-xs font-semibold ${STATUS_COLORS[t.status]}`}>
                    {STATUS_LABELS[t.status]}
                  </span>
                </div>
                {/* Xaridor: to'lov qildim tugmasi */}
                {t.role === "buyer" && t.status === "in_progress" && (
                  <button onClick={() => paymentSent(t.id)}
                    className="w-full mt-2 py-2.5 rounded-xl bg-accent-blue text-white text-sm font-semibold">
                    ✅ To'lov qildim
                  </button>
                )}
                {/* Sotuvchi: tokenni chiqar */}
                {t.role === "seller" && t.status === "payment_sent" && (
                  <button onClick={() => releaseTokens(t.id)}
                    className="w-full mt-2 py-2.5 rounded-xl bg-accent-green text-white text-sm font-semibold">
                    ✅ To'lovni oldim — Tokenni chiqar
                  </button>
                )}
              </div>
            ))
          }
        </div>
      )}

      {/* Create order modal */}
      {showCreate && (
        <CreateOrderModal tokens={tokens} onClose={() => setShowCreate(false)}
          onCreated={() => { setShowCreate(false); setTab("my-orders"); api.get("/p2p/my-orders").then(r => setMyOrders(r.data)); }} />
      )}

      {/* Trade modal */}
      {tradeModal && (
        <TradeModal order={tradeModal} onClose={() => setTradeModal(null)}
          onDone={() => { setTradeModal(null); setTab("my-trades"); api.get("/p2p/my-trades").then(r => setMyTrades(r.data)); }} />
      )}
    </div>
  );
}

function TradeModal({ order, onClose, onDone }) {
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const maxAmount = parseFloat(order.amount);
  const priceUzs = parseFloat(order.price_uzs);
  const totalUzs = amount ? (parseFloat(amount) * priceUzs).toLocaleString("uz-UZ") : "0";

  const submit = async () => {
    if (!amount || parseFloat(amount) <= 0) { setError("Miqdor kiriting"); return; }
    setLoading(true);
    setError("");
    try {
      const res = await api.post(`/p2p/orders/${order.id}/trade`, { amount: parseFloat(amount) });
      alert(`✅ Savdo boshlandi!\n💳 To'lov usuli: ${order.payment_method}\n💰 To'lash kerak: ${res.data.total_uzs} UZS`);
      onDone();
    } catch (e) {
      setError(e.response?.data?.detail || "Xatolik");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-end" onClick={onClose}>
      <div className="bg-bg-card w-full rounded-t-3xl p-5 space-y-4 pb-10" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center">
          <h2 className="text-lg font-bold">Savdo</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-bg-elevated flex items-center justify-center text-text-muted">✕</button>
        </div>

        <div className="bg-bg-elevated rounded-xl p-3 space-y-1.5 text-sm">
          <div className="flex justify-between">
            <span className="text-text-secondary">Narx</span>
            <span className="font-bold">{priceUzs.toLocaleString("uz-UZ")} UZS / {order.token}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-text-secondary">Mavjud</span>
            <span>{parseFloat(order.amount).toFixed(4)} {order.token}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-text-secondary">To'lov usuli</span>
            <span>{order.payment_method}</span>
          </div>
        </div>

        <div>
          <label className="text-xs text-text-secondary mb-1 block">Miqdor ({order.token})</label>
          <div className="relative">
            <input type="number" className="w-full bg-bg-elevated border border-border rounded-xl px-4 py-3 text-sm outline-none focus:border-accent-blue"
              placeholder="0.00" value={amount} onChange={e => setAmount(e.target.value)} />
            <button onClick={() => setAmount(order.amount)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-accent-blue font-semibold">MAX</button>
          </div>
        </div>

        <div className="bg-bg-elevated rounded-xl p-3 flex justify-between text-sm">
          <span className="text-text-secondary">To'lash kerak (UZS)</span>
          <span className="font-bold text-accent-green">{totalUzs} UZS</span>
        </div>

        {error && <p className="text-accent-red text-sm text-center">{error}</p>}

        <button onClick={submit} disabled={loading || !amount}
          className="w-full py-3 rounded-2xl bg-accent-blue text-white font-semibold disabled:opacity-50">
          {loading ? "Yuklanmoqda..." : "Savdoni boshlash"}
        </button>
      </div>
    </div>
  );
}

function CreateOrderModal({ tokens, onClose, onCreated }) {
  const [form, setForm] = useState({
    token_id: tokens[0]?.id || "",
    order_type: "sell",
    amount: "",
    price_uzs: "",
    payment_method: "Uzcard",
    note: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const totalUzs = form.amount && form.price_uzs
    ? (parseFloat(form.amount) * parseFloat(form.price_uzs)).toLocaleString("uz-UZ")
    : "0";

  const submit = async () => {
    if (!form.amount || !form.price_uzs) { setError("Miqdor va narxni kiriting"); return; }
    setLoading(true);
    setError("");
    try {
      await api.post("/p2p/orders", {
        ...form,
        token_id: parseInt(form.token_id),
        amount: parseFloat(form.amount),
        price_uzs: parseFloat(form.price_uzs),
      });
      onCreated();
    } catch (e) {
      setError(e.response?.data?.detail || "Xatolik");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-end" onClick={onClose}>
      <div className="bg-bg-card w-full rounded-t-3xl p-5 space-y-3 pb-10 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center">
          <h2 className="text-lg font-bold">E'lon yaratish</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-bg-elevated flex items-center justify-center text-text-muted">✕</button>
        </div>

        <div className="flex gap-2">
          {[["sell","Sotish"],["buy","Sotib olish"]].map(([v,l]) => (
            <button key={v} onClick={() => setForm(f => ({...f, order_type: v}))}
              className={`flex-1 py-2.5 rounded-xl text-sm font-semibold ${
                form.order_type === v ? "bg-accent-blue text-white" : "bg-bg-elevated text-text-muted"
              }`}>{l}</button>
          ))}
        </div>

        <select className="w-full bg-bg-elevated border border-border rounded-xl px-4 py-3 text-sm"
          value={form.token_id} onChange={e => setForm(f => ({...f, token_id: e.target.value}))}>
          {tokens.map(t => <option key={t.id} value={t.id}>{t.symbol} — {t.name}</option>)}
        </select>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-text-muted mb-1 block">Miqdor</label>
            <input className="w-full bg-bg-elevated border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-accent-blue"
              placeholder="0.00" type="number" value={form.amount}
              onChange={e => setForm(f => ({...f, amount: e.target.value}))} />
          </div>
          <div>
            <label className="text-xs text-text-muted mb-1 block">1 token narxi (UZS)</label>
            <input className="w-full bg-bg-elevated border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-accent-blue"
              placeholder="0" type="number" value={form.price_uzs}
              onChange={e => setForm(f => ({...f, price_uzs: e.target.value}))} />
          </div>
        </div>

        {form.amount && form.price_uzs && (
          <div className="bg-bg-elevated rounded-xl p-3 flex justify-between text-sm">
            <span className="text-text-secondary">Jami</span>
            <span className="font-bold">{totalUzs} UZS</span>
          </div>
        )}

        <select className="w-full bg-bg-elevated border border-border rounded-xl px-4 py-3 text-sm"
          value={form.payment_method} onChange={e => setForm(f => ({...f, payment_method: e.target.value}))}>
          {["Uzcard","Humo","Click","Payme","Naqd"].map(m => <option key={m}>{m}</option>)}
        </select>

        <input className="w-full bg-bg-elevated border border-border rounded-xl px-4 py-3 text-sm outline-none focus:border-accent-blue"
          placeholder="Izoh (ixtiyoriy)" value={form.note}
          onChange={e => setForm(f => ({...f, note: e.target.value}))} />

        {error && <p className="text-accent-red text-sm text-center">{error}</p>}

        <button onClick={submit} disabled={loading}
          className="w-full py-3 rounded-2xl bg-accent-blue text-white font-semibold disabled:opacity-50">
          {loading ? "Yuborilmoqda..." : "E'lon qo'yish"}
        </button>
      </div>
    </div>
  );
}
