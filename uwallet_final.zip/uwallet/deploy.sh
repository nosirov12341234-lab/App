#!/bin/bash
set -e
echo "🚀 UWallet deploy boshlandi..."

if [ ! -f .env ]; then
  echo "❌ .env fayl topilmadi!"
  exit 1
fi

echo "📦 Docker image build..."
docker compose build

echo "🗄️ Database migration..."
docker compose up -d postgres redis
sleep 8
docker compose run --rm backend alembic upgrade head

echo "▶️ Barcha servislar ishga tushirilmoqda..."
docker compose up -d

echo ""
echo "✅ UWallet ishga tushdi!"
echo "   Backend:  http://localhost:8000"
echo "   Frontend: http://localhost:3000"
echo ""
echo "📋 Loglar:"
echo "   docker compose logs -f"
