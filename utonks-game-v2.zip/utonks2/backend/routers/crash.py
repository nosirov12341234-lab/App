from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect
from sqlalchemy.ext.asyncio import AsyncSession
from models.db import get_db, AsyncSessionLocal
from models.database import User, Transaction, InventoryItem
from services.auth import get_current_user
from services.crash_engine import crash_engine
import json

router = APIRouter(prefix="/crash", tags=["crash"])

@router.websocket("/ws")
async def ws(websocket: WebSocket):
    await websocket.accept()
    crash_engine.connections.append(websocket)
    crash_engine.real_online += 1
    await websocket.send_json({"type": "state", "game_state": crash_engine.state, "multiplier": crash_engine.multiplier, "history": crash_engine.history[-6:], "online": crash_engine.fake_online()})
    try:
        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)
            if msg.get("type") == "ping":
                await websocket.send_json({"type": "pong"})
    except WebSocketDisconnect:
        pass
    finally:
        if websocket in crash_engine.connections:
            crash_engine.connections.remove(websocket)
        crash_engine.real_online = max(0, crash_engine.real_online - 1)

@router.post("/bet")
async def bet(amount: float, is_gift: bool = False, inventory_item_id: int = None, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    if crash_engine.state != "betting":
        raise HTTPException(400, "Betting phase ended")
    if is_gift and inventory_item_id:
        r = await db.execute(__import__('sqlalchemy', fromlist=['select']).select(InventoryItem).where(InventoryItem.id == inventory_item_id, InventoryItem.user_id == user.id))
        item = r.scalar_one_or_none()
        if not item or item.is_locked:
            raise HTTPException(400, "Invalid gift")
        amount = item.floor_price
        await db.delete(item)
        await db.commit()
    else:
        if user.balance < amount or amount < 0.01:
            raise HTTPException(400, "Invalid amount")
        user.balance -= amount
        await db.commit()
    await crash_engine.place_bet(user.id, user.username or user.first_name, user.photo_url or "", amount, is_gift, inventory_item_id)
    return {"success": True, "amount": amount}

@router.post("/cashout")
async def cashout(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    payout = await crash_engine.cashout(user.id)
    if payout is None:
        raise HTTPException(400, "Cannot cashout")
    user.balance += payout
    db.add(Transaction(user_id=user.id, type="bet_win", amount=payout, description=f"Crash x{crash_engine.multiplier}"))
    await db.commit()
    return {"success": True, "payout": payout, "multiplier": crash_engine.multiplier}

@router.get("/history")
async def history():
    return {"history": crash_engine.history[-20:]}
