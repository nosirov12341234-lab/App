from fastapi import APIRouter, Depends, HTTPException, Header
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from models.db import get_db
from models.database import User, Case, CaseItem, GiftCollection, Transaction, WithdrawRequest, Promocode, InventoryItem
from services.auth import get_current_user
from services.settings import get_all_settings, set_setting, get_setting
from services.ton_api import sync_collections
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
import os

router = APIRouter(prefix="/admin", tags=["admin"])

async def require_admin(user: User = Depends(get_current_user)):
    if not user.is_admin:
        raise HTTPException(403, "Admin only")
    return user

async def internal_auth(x_internal_key: str = Header(...)):
    if x_internal_key != os.getenv("INTERNAL_KEY", ""):
        raise HTTPException(403, "Forbidden")

class CaseCreate(BaseModel):
    name: str
    image_url: str
    price_ton: Optional[float] = None
    price_stars: Optional[int] = None
    is_daily: bool = False
    sort_order: int = 0
    items: List[dict]

class PromoCreate(BaseModel):
    code: str
    reward_type: str
    reward_collection_id: Optional[int] = None
    reward_ton: Optional[float] = None
    max_uses: int = 1

@router.post("/auth")
async def admin_auth(password: str, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    admin_pass = await get_setting(db, "admin_password")
    if password != admin_pass:
        raise HTTPException(403, "Wrong password")
    if not user.is_admin:
        raise HTTPException(403, "Not an admin")
    return {"success": True, "token": "admin_verified"}

@router.get("/stats")
async def stats(db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    users = (await db.execute(select(func.count(User.id)))).scalar()
    deposited = (await db.execute(select(func.sum(Transaction.amount)).where(Transaction.type.in_(["deposit_ton","deposit_stars"])))).scalar() or 0
    pending = (await db.execute(select(func.count(WithdrawRequest.id)).where(WithdrawRequest.status == "pending"))).scalar()
    profit = (await db.execute(select(func.sum(Transaction.amount)).where(Transaction.type.in_(["bet_lose","sell_gift","case_open","upgrade"])))).scalar() or 0
    return {"total_users": users, "total_deposited": round(deposited, 2), "pending_withdrawals": pending, "total_profit": round(profit, 2)}

@router.get("/collections")
async def get_collections(db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(GiftCollection).where(GiftCollection.is_active == True).order_by(GiftCollection.name))
    return [{"id": c.id, "name": c.name, "slug": c.slug, "image_url": c.image_url, "floor_price": c.floor_price} for c in r.scalars().all()]

@router.post("/collections/sync")
async def sync_cols(db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    count = await sync_collections(db)
    return {"success": True, "synced": count}

@router.get("/cases")
async def get_cases(db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(Case).order_by(Case.sort_order))
    return [{"id": c.id, "name": c.name, "image_url": c.image_url, "price_ton": c.price_ton, "price_stars": c.price_stars, "is_active": c.is_active, "is_daily": c.is_daily} for c in r.scalars().all()]

@router.post("/cases")
async def create_case(data: CaseCreate, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    case = Case(name=data.name, image_url=data.image_url, price_ton=data.price_ton, price_stars=data.price_stars, is_daily=data.is_daily, sort_order=data.sort_order)
    db.add(case)
    await db.flush()
    total = sum(i["probability"] for i in data.items)
    for item in data.items:
        db.add(CaseItem(case_id=case.id, collection_id=item["collection_id"], probability=item["probability"] / total))
    await db.commit()
    return {"success": True, "id": case.id}

@router.put("/cases/{case_id}")
async def update_case(case_id: int, data: CaseCreate, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(Case).where(Case.id == case_id))
    case = r.scalar_one_or_none()
    if not case:
        raise HTTPException(404, "Not found")
    case.name = data.name; case.image_url = data.image_url
    case.price_ton = data.price_ton; case.price_stars = data.price_stars
    case.sort_order = data.sort_order
    old = await db.execute(select(CaseItem).where(CaseItem.case_id == case_id))
    for i in old.scalars().all():
        await db.delete(i)
    total = sum(i["probability"] for i in data.items)
    for item in data.items:
        db.add(CaseItem(case_id=case.id, collection_id=item["collection_id"], probability=item["probability"] / total))
    await db.commit()
    return {"success": True}

@router.delete("/cases/{case_id}")
async def delete_case(case_id: int, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(Case).where(Case.id == case_id))
    case = r.scalar_one_or_none()
    if not case:
        raise HTTPException(404, "Not found")
    case.is_active = False
    await db.commit()
    return {"success": True}

@router.get("/withdrawals")
async def get_withdrawals(db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(WithdrawRequest).where(WithdrawRequest.status == "pending").order_by(WithdrawRequest.created_at))
    return [{"id": w.id, "user_id": w.telegram_id, "username": w.username, "collection": w.collection_name, "created_at": w.created_at.isoformat()} for w in r.scalars().all()]

@router.get("/withdrawals/internal")
async def get_withdrawals_internal(db: AsyncSession = Depends(get_db), _=Depends(internal_auth)):
    r = await db.execute(select(WithdrawRequest).where(WithdrawRequest.status == "pending").order_by(WithdrawRequest.created_at))
    return [{"id": w.id, "user_id": w.telegram_id, "username": w.username, "collection": w.collection_name, "created_at": w.created_at.isoformat()} for w in r.scalars().all()]

@router.post("/withdrawals/{wid}/complete")
async def complete_withdrawal(wid: int, db: AsyncSession = Depends(get_db), _=Depends(internal_auth)):
    r = await db.execute(select(WithdrawRequest).where(WithdrawRequest.id == wid))
    w = r.scalar_one_or_none()
    if not w:
        raise HTTPException(404, "Not found")
    w.status = "completed"
    w.completed_at = datetime.utcnow()
    if w.inventory_item_id:
        ir = await db.execute(select(InventoryItem).where(InventoryItem.id == w.inventory_item_id))
        item = ir.scalar_one_or_none()
        if item:
            await db.delete(item)
    await db.commit()
    return {"success": True}

@router.post("/withdrawals/{wid}/complete_admin")
async def complete_withdrawal_admin(wid: int, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(WithdrawRequest).where(WithdrawRequest.id == wid))
    w = r.scalar_one_or_none()
    if not w:
        raise HTTPException(404, "Not found")
    w.status = "completed"
    w.completed_at = datetime.utcnow()
    if w.inventory_item_id:
        ir = await db.execute(select(InventoryItem).where(InventoryItem.id == w.inventory_item_id))
        item = ir.scalar_one_or_none()
        if item:
            await db.delete(item)
    await db.commit()
    return {"success": True}

@router.post("/promocodes")
async def create_promo(data: PromoCreate, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    db.add(Promocode(code=data.code.upper(), reward_type=data.reward_type, reward_collection_id=data.reward_collection_id, reward_ton=data.reward_ton, max_uses=data.max_uses))
    await db.commit()
    return {"success": True}

@router.get("/promocodes")
async def get_promos(db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(Promocode).order_by(Promocode.created_at.desc()))
    return [{"id": p.id, "code": p.code, "reward_type": p.reward_type, "reward_ton": p.reward_ton, "max_uses": p.max_uses, "used_count": p.used_count, "is_active": p.is_active} for p in r.scalars().all()]

@router.get("/users")
async def get_users(limit: int = 50, offset: int = 0, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(User).order_by(User.created_at.desc()).limit(limit).offset(offset))
    return [{"id": u.id, "telegram_id": u.telegram_id, "username": u.username, "first_name": u.first_name, "balance": u.balance, "is_admin": u.is_admin, "is_banned": u.is_banned, "created_at": u.created_at.isoformat()} for u in r.scalars().all()]

@router.post("/users/{uid}/ban")
async def ban_user(uid: int, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(User).where(User.id == uid))
    u = r.scalar_one_or_none()
    if not u:
        raise HTTPException(404, "Not found")
    u.is_banned = not u.is_banned
    await db.commit()
    return {"success": True, "is_banned": u.is_banned}

@router.get("/settings")
async def get_settings(db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    return await get_all_settings(db)

@router.put("/settings")
async def update_settings(settings: dict, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    for k, v in settings.items():
        await set_setting(db, k, str(v))
    return {"success": True}
