from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from models.db import get_db
from models.database import User, Transaction, InventoryItem, GiftCollection
from services.auth import get_current_user
from services.settings import get_setting
from pydantic import BaseModel
from typing import List

router = APIRouter(prefix="/upgrade", tags=["upgrade"])

class UpgradeReq(BaseModel):
    inventory_ids: List[int]
    extra_ton: float = 0.0

@router.post("/start")
async def start(data: UpgradeReq, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    total = data.extra_ton
    items = []
    for iid in data.inventory_ids:
        r = await db.execute(select(InventoryItem).where(InventoryItem.id == iid, InventoryItem.user_id == user.id))
        item = r.scalar_one_or_none()
        if not item or item.is_locked:
            raise HTTPException(400, f"Invalid item {iid}")
        total += item.floor_price
        items.append(item)

    if total < 0.1:
        raise HTTPException(400, "Minimum 0.1 TON")
    if data.extra_ton > 0 and user.balance < data.extra_ton:
        raise HTTPException(400, "Insufficient balance")

    if data.extra_ton > 0:
        user.balance -= data.extra_ton
    for item in items:
        await db.delete(item)

    commission = float(await get_setting(db, "upgrade_commission_percent")) / 100
    budget = total * (1 - commission)

    r = await db.execute(select(GiftCollection).where(GiftCollection.is_active == True, GiftCollection.floor_price > 0))
    cols = r.scalars().all()
    if not cols:
        user.balance += budget
        await db.commit()
        raise HTTPException(400, "No gifts found, refunded")

    best = min(cols, key=lambda c: abs(c.floor_price - budget))
    change = max(round(budget - best.floor_price, 6), 0)

    new_item = InventoryItem(user_id=user.id, collection_id=best.id, collection_name=best.name, collection_image=best.image_url, floor_price=best.floor_price, source="upgrade")
    db.add(new_item)
    if change > 0:
        user.balance += change
    db.add(Transaction(user_id=user.id, type="upgrade", amount=-total, description=f"Upgrade → {best.name}"))
    await db.commit()
    await db.refresh(new_item)
    return {"success": True, "gift": {"id": new_item.id, "collection_name": best.name, "collection_image": best.image_url, "floor_price": best.floor_price}, "change": change}
