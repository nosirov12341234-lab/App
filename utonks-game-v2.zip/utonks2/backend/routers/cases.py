from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from models.db import get_db
from models.database import Case, CaseItem, GiftCollection, InventoryItem, User, Transaction
from services.auth import get_current_user
from services.settings import get_setting
from datetime import datetime, timedelta
import random

router = APIRouter(prefix="/cases", tags=["cases"])

@router.get("/")
async def get_cases(db: AsyncSession = Depends(get_db)):
    r = await db.execute(select(Case).where(Case.is_active == True).order_by(Case.sort_order))
    cases = r.scalars().all()
    out = []
    for c in cases:
        items_r = await db.execute(
            select(CaseItem, GiftCollection)
            .join(GiftCollection, CaseItem.collection_id == GiftCollection.id)
            .where(CaseItem.case_id == c.id)
        )
        items = items_r.all()
        out.append({
            "id": c.id, "name": c.name, "image_url": c.image_url,
            "price_ton": c.price_ton, "price_stars": c.price_stars, "is_daily": c.is_daily,
            "items": [{"collection_id": col.id, "collection_name": col.name, "collection_image": col.image_url, "floor_price": col.floor_price, "probability": round(item.probability * 100, 1)} for item, col in items]
        })
    return out

@router.post("/{case_id}/open")
async def open_case(case_id: int, payment_method: str = "ton", db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    r = await db.execute(select(Case).where(Case.id == case_id, Case.is_active == True))
    case = r.scalar_one_or_none()
    if not case:
        raise HTTPException(404, "Case not found")

    is_locked = False
    if case.is_daily:
        if not user.daily_case_referral_done:
            raise HTTPException(400, "Need 1 referral to open daily case")
        if user.last_daily_case:
            if (datetime.utcnow() - user.last_daily_case).total_seconds() < 86400:
                raise HTTPException(400, "Daily case already opened today")
        user.last_daily_case = datetime.utcnow()
        user.daily_case_referral_done = False
        source = "daily_case"
        is_locked = True
        tx_amount = 0
    else:
        if payment_method == "ton":
            if not case.price_ton:
                raise HTTPException(400, "TON not available")
            if user.balance < case.price_ton:
                raise HTTPException(400, "Insufficient balance")
            user.balance -= case.price_ton
            tx_amount = -case.price_ton
        elif payment_method == "stars":
            if not case.price_stars:
                raise HTTPException(400, "Stars not available")
            rate = float(await get_setting(db, "stars_to_ton_rate"))
            price_ton = case.price_stars * rate
            if user.balance < price_ton:
                raise HTTPException(400, "Insufficient balance")
            user.balance -= price_ton
            tx_amount = -price_ton
        source = "case"

    items_r = await db.execute(
        select(CaseItem, GiftCollection)
        .join(GiftCollection, CaseItem.collection_id == GiftCollection.id)
        .where(CaseItem.case_id == case_id)
    )
    items = items_r.all()
    if not items:
        raise HTTPException(400, "Case has no items")

    weights = [item.probability for item, _ in items]
    selected_item, selected_col = random.choices(items, weights=weights, k=1)[0]

    inv = InventoryItem(
        user_id=user.id, collection_id=selected_col.id,
        collection_name=selected_col.name, collection_image=selected_col.image_url,
        floor_price=selected_col.floor_price, source=source, is_locked=is_locked,
        withdraw_available_at=datetime.utcnow() + timedelta(hours=1) if not is_locked else None,
    )
    db.add(inv)
    if tx_amount != 0:
        db.add(Transaction(user_id=user.id, type="case_open", amount=tx_amount, description=f"{case.name} → {selected_col.name}"))
    await db.commit()
    await db.refresh(inv)

    return {"success": True, "gift": {"id": inv.id, "collection_name": selected_col.name, "collection_image": selected_col.image_url, "floor_price": selected_col.floor_price, "is_locked": is_locked}}
