from fastapi import APIRouter, Depends, HTTPException, Header
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from models.db import get_db
from models.database import User, Transaction, Promocode, PromocodeUse, InventoryItem, GiftCollection
from services.auth import get_current_user
from services.settings import get_setting
from datetime import datetime
import os

router = APIRouter(prefix="/user", tags=["user"])
BOT_USERNAME = os.getenv("BOT_USERNAME", "utonks_bot")

@router.get("/me")
async def me(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    ref_count = (await db.execute(select(func.count(User.id)).where(User.referred_by == user.id))).scalar() or 0
    level = 1
    levels = [(500, 4), (100, 3), (25, 2), (0, 1)]
    for threshold, lvl in levels:
        if user.total_referral_deposits >= threshold:
            level = lvl
            break
    percents = {1: 10, 2: 12, 3: 14, 4: 18}
    return {
        "id": user.id, "telegram_id": user.telegram_id,
        "username": user.username, "first_name": user.first_name,
        "photo_url": user.photo_url, "balance": user.balance,
        "level": level, "is_admin": user.is_admin,
        "referral_code": user.referral_code,
        "referral_link": f"https://t.me/{BOT_USERNAME}?start={user.referral_code}",
        "referral_count": ref_count,
        "referral_earnings": user.referral_earnings,
        "referral_percent": percents.get(level, 10),
        "total_referral_deposits": user.total_referral_deposits,
    }

@router.get("/transactions")
async def transactions(limit: int = 20, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    r = await db.execute(select(Transaction).where(Transaction.user_id == user.id).order_by(Transaction.created_at.desc()).limit(limit))
    return [{"id": t.id, "type": t.type, "amount": t.amount, "description": t.description, "created_at": t.created_at.isoformat()} for t in r.scalars().all()]

@router.post("/deposit/ton")
async def deposit_ton(amount: float, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    min_dep = float(await get_setting(db, "min_deposit_ton"))
    if amount < min_dep:
        raise HTTPException(400, f"Minimum {min_dep} TON")
    wallet = await get_setting(db, "platform_ton_wallet") or os.getenv("PLATFORM_TON_WALLET", "")
    bonus = float(await get_setting(db, "deposit_bonus_ton_percent"))
    memo = f"utonks_{user.telegram_id}"
    return {"wallet": wallet, "amount": amount, "memo": memo, "bonus_percent": bonus, "bonus_amount": round(amount * bonus / 100, 6)}

@router.post("/deposit/stars")
async def deposit_stars(stars: int, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    min_stars = int(await get_setting(db, "min_deposit_stars"))
    if stars < min_stars:
        raise HTTPException(400, f"Minimum {min_stars} Stars")
    rate = float(await get_setting(db, "stars_to_ton_rate"))
    return {"stars": stars, "ton_equivalent": round(stars * rate, 6), "rate": rate}

@router.post("/deposit/confirm")
async def confirm_deposit(amount: float, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    """Called by bot webhook after payment confirmed"""
    bonus_pct = float(await get_setting(db, "deposit_bonus_ton_percent"))
    total = amount * (1 + bonus_pct / 100)
    user.balance += total
    user.total_referral_deposits  # update referral
    db.add(Transaction(user_id=user.id, type="deposit_ton", amount=total, description=f"TON deposit +{bonus_pct}% bonus"))
    await db.commit()
    return {"success": True, "credited": total}

@router.post("/promocode")
async def use_promocode(code: str, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    r = await db.execute(select(Promocode).where(Promocode.code == code.upper(), Promocode.is_active == True))
    promo = r.scalar_one_or_none()
    if not promo:
        raise HTTPException(404, "Invalid promocode")
    if promo.used_count >= promo.max_uses:
        raise HTTPException(400, "Promocode expired")
    used = await db.execute(select(PromocodeUse).where(PromocodeUse.promocode_id == promo.id, PromocodeUse.user_id == user.id))
    if used.scalar_one_or_none():
        raise HTTPException(400, "Already used")

    reward = {}
    if promo.reward_type == "gift" and promo.reward_collection_id:
        cr = await db.execute(select(GiftCollection).where(GiftCollection.id == promo.reward_collection_id))
        col = cr.scalar_one_or_none()
        if col:
            item = InventoryItem(user_id=user.id, collection_id=col.id, collection_name=col.name, collection_image=col.image_url, floor_price=col.floor_price, source="promocode", is_locked=True)
            db.add(item)
            reward = {"type": "gift", "collection": col.name, "image": col.image_url}
    elif promo.reward_type == "ton" and promo.reward_ton:
        user.balance += promo.reward_ton
        db.add(Transaction(user_id=user.id, type="promocode", amount=promo.reward_ton, description=f"Promocode: {code}"))
        reward = {"type": "ton", "amount": promo.reward_ton}

    promo.used_count += 1
    db.add(PromocodeUse(promocode_id=promo.id, user_id=user.id))
    await db.commit()
    return {"success": True, "reward": reward}
