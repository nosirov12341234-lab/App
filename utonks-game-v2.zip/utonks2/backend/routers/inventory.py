from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from models.db import get_db
from models.database import InventoryItem, User, Transaction, WithdrawRequest
from services.auth import get_current_user
from services.settings import get_setting
from datetime import datetime

router = APIRouter(prefix="/inventory", tags=["inventory"])

@router.get("/")
async def get_inventory(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    r = await db.execute(select(InventoryItem).where(InventoryItem.user_id == user.id).order_by(InventoryItem.created_at.desc()))
    now = datetime.utcnow()
    return [{"id": i.id, "collection_name": i.collection_name, "collection_image": i.collection_image, "floor_price": i.floor_price, "source": i.source, "is_locked": i.is_locked, "can_withdraw": not i.is_locked and (i.withdraw_available_at is None or i.withdraw_available_at <= now), "can_bet": not i.is_locked, "withdraw_available_at": i.withdraw_available_at.isoformat() if i.withdraw_available_at else None, "created_at": i.created_at.isoformat()} for i in r.scalars().all()]

@router.post("/{item_id}/sell")
async def sell(item_id: int, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    r = await db.execute(select(InventoryItem).where(InventoryItem.id == item_id, InventoryItem.user_id == user.id))
    item = r.scalar_one_or_none()
    if not item:
        raise HTTPException(404, "Not found")
    commission = float(await get_setting(db, "sell_commission_percent")) / 100
    price = round(item.floor_price * (1 - commission), 6)
    user.balance += price
    db.add(Transaction(user_id=user.id, type="sell_gift", amount=price, description=f"Sold: {item.collection_name}"))
    await db.delete(item)
    await db.commit()
    return {"success": True, "amount": price, "balance": user.balance}

@router.post("/{item_id}/withdraw")
async def withdraw(item_id: int, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    r = await db.execute(select(InventoryItem).where(InventoryItem.id == item_id, InventoryItem.user_id == user.id))
    item = r.scalar_one_or_none()
    if not item:
        raise HTTPException(404, "Not found")
    if item.is_locked:
        raise HTTPException(400, "Gift is locked")
    now = datetime.utcnow()
    if item.withdraw_available_at and item.withdraw_available_at > now:
        raise HTTPException(400, "Withdraw not available yet")
    req = WithdrawRequest(user_id=user.id, inventory_item_id=item.id, collection_name=item.collection_name, telegram_id=user.telegram_id, username=user.username or str(user.telegram_id))
    db.add(req)
    await db.commit()
    await db.refresh(req)
    return {"success": True, "withdraw_id": req.id, "message": "⏳ Gift yuborilmoqda..."}
