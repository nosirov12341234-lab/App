import asyncio, os, logging
from aiogram import Bot, Dispatcher, Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram.filters import CommandStart

logging.basicConfig(level=logging.INFO)
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
WEBAPP_URL = os.getenv("WEBAPP_URL", "")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()
router = Router()

@router.message(CommandStart())
async def start(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎮 Utonks Game", web_app=WebAppInfo(url=WEBAPP_URL))],
        [InlineKeyboardButton(text="📢 Channel", url="https://t.me/utonksgame")]
    ])
    await message.answer(
        "🎮 <b>Utonks Game</b>\n\n"
        "🚀 Crash · 💣 Mines · 📦 Cases · ⬆️ Upgrade\n"
        "🎁 Win Telegram Gifts!\n\n"
        "💎 Deposit with TON or ⭐ Stars",
        reply_markup=kb, parse_mode="HTML"
    )

dp.include_router(router)

async def main():
    logging.info("Bot starting...")
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
