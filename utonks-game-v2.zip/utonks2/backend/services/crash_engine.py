import asyncio, random, math, time, json
from typing import List, Dict, Optional

FAKE_BOTS = [
    {"username": "CryptoWolf", "avatar": "🐺"},
    {"username": "TON_King", "avatar": "👑"},
    {"username": "RocketMan", "avatar": "🚀"},
    {"username": "DiamondHands", "avatar": "💎"},
    {"username": "MoonShot", "avatar": "🌙"},
    {"username": "StarPlayer", "avatar": "⭐"},
    {"username": "TonWhale", "avatar": "🐋"},
    {"username": "GiftHunter", "avatar": "🎯"},
]

class CrashEngine:
    def __init__(self):
        self.state = "waiting"
        self.multiplier = 1.0
        self.crash_point = 1.0
        self.bets: Dict = {}
        self.fake_bets: Dict = {}
        self.connections: List = []
        self.real_online = 0
        self.start_time = None
        self.history: List[float] = [1.24, 5.67, 1.01, 12.4, 2.31, 1.08]

    def gen_crash_point(self, house_edge=0.04, honeymoon=False) -> float:
        if honeymoon:
            return round(random.uniform(5.0, 20.0), 2)
        r = random.random()
        if r < house_edge:
            return round(random.uniform(1.0, 1.3), 2)
        return round(min((1 - house_edge) / (1 - r), 100.0), 2)

    def fake_online(self) -> int:
        if self.real_online < 50:
            return random.randint(50, 70)
        return self.real_online

    def calc_multi(self, elapsed_ms: float) -> float:
        return round(math.pow(math.e, 0.00006 * elapsed_ms), 2)

    async def broadcast(self, msg: dict):
        dead = []
        for ws in self.connections:
            try:
                await ws.send_json(msg)
            except:
                dead.append(ws)
        for ws in dead:
            self.connections.remove(ws)

    async def run(self, db_factory, settings_getter):
        while True:
            try:
                await self._game(db_factory, settings_getter)
            except Exception as e:
                print(f"Crash error: {e}")
                await asyncio.sleep(3)

    async def _game(self, db_factory, settings_getter):
        self.state = "betting"
        self.bets = {}
        self.fake_bets = {}
        self.multiplier = 1.0
        house_edge = float(await settings_getter("crash_house_edge") or 0.04)
        self.crash_point = self.gen_crash_point(house_edge)

        await self.broadcast({
            "type": "betting",
            "duration": 5000,
            "online": self.fake_online(),
            "history": self.history[-6:],
        })
        await asyncio.sleep(5)

        # Add fake bets if no real bets
        if not any(not b.get("is_fake") for b in self.bets.values()):
            for i, bot in enumerate(random.sample(FAKE_BOTS, random.randint(2, 5))):
                amt = round(random.uniform(0.5, 25.0), 2)
                cashout_at = round(random.uniform(1.5, self.crash_point * 0.85), 2)
                self.fake_bets[f"fake_{i}"] = {
                    "username": bot["username"],
                    "avatar": bot["avatar"],
                    "amount": amt,
                    "cashout_at": cashout_at,
                    "cashed_out": False,
                    "is_fake": True,
                }

        all_bets = {**self.bets, **self.fake_bets}
        await self.broadcast({
            "type": "started",
            "bets": [{"username": b["username"], "avatar": b.get("avatar",""), "amount": b["amount"], "is_fake": b.get("is_fake", False)} for b in all_bets.values()]
        })

        self.state = "running"
        self.start_time = time.time() * 1000

        while True:
            elapsed = time.time() * 1000 - self.start_time
            self.multiplier = self.calc_multi(elapsed)

            for bet in self.fake_bets.values():
                if not bet["cashed_out"] and self.multiplier >= bet["cashout_at"]:
                    bet["cashed_out"] = True
                    await self.broadcast({
                        "type": "cashout",
                        "username": bet["username"],
                        "multiplier": self.multiplier,
                        "amount": round(bet["amount"] * self.multiplier, 3),
                        "is_fake": True,
                    })

            await self.broadcast({"type": "tick", "multiplier": self.multiplier, "online": self.fake_online()})

            if self.multiplier >= self.crash_point:
                break
            await asyncio.sleep(0.1)

        self.state = "crashed"
        self.history.append(self.crash_point)
        if len(self.history) > 10:
            self.history.pop(0)

        await self.broadcast({"type": "crashed", "crash_point": self.crash_point, "history": self.history[-6:]})

        async with db_factory() as db:
            from models.database import CrashGame, Transaction
            game = CrashGame(crash_point=self.crash_point)
            db.add(game)
            for uid, bet in self.bets.items():
                if not bet.get("cashed_out"):
                    tx = Transaction(user_id=int(uid), type="bet_lose", amount=-bet["amount"], description=f"Crash x{self.crash_point}")
                    db.add(tx)
            await db.commit()

        await asyncio.sleep(3)

    async def place_bet(self, user_id, username, avatar, amount, is_gift=False, inv_id=None) -> bool:
        if self.state != "betting":
            return False
        self.bets[str(user_id)] = {"username": username, "avatar": avatar, "amount": amount, "is_gift": is_gift, "inv_id": inv_id, "cashed_out": False, "is_fake": False}
        return True

    async def cashout(self, user_id) -> Optional[float]:
        if self.state != "running":
            return None
        bet = self.bets.get(str(user_id))
        if not bet or bet.get("cashed_out"):
            return None
        bet["cashed_out"] = True
        payout = round(bet["amount"] * self.multiplier, 6)
        await self.broadcast({"type": "cashout", "username": bet["username"], "multiplier": self.multiplier, "amount": payout, "is_fake": False})
        return payout

crash_engine = CrashEngine()
