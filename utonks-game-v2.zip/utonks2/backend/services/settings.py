from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from models.database import Settings

DEFAULTS = {
    "stars_to_ton_rate": "0.013",
    "min_deposit_stars": "50",
    "min_deposit_ton": "0.1",
    "deposit_bonus_ton_percent": "10",
    "sell_commission_percent": "15",
    "upgrade_commission_percent": "5",
    "crash_house_edge": "0.04",
    "mines_house_edge": "0.04",
    "fake_online_min": "50",
    "fake_online_max": "70",
    "referral_level1_percent": "10",
    "referral_level2_percent": "12",
    "referral_level3_percent": "14",
    "referral_level4_percent": "18",
    "referral_level2_min_ton": "25",
    "referral_level3_min_ton": "100",
    "referral_level4_min_ton": "500",
    "admin_password": "admin123",
    "platform_ton_wallet": "",
}

async def get_setting(db: AsyncSession, key: str) -> str:
    result = await db.execute(select(Settings).where(Settings.key == key))
    s = result.scalar_one_or_none()
    if s:
        return s.value
    return DEFAULTS.get(key, "")

async def set_setting(db: AsyncSession, key: str, value: str):
    result = await db.execute(select(Settings).where(Settings.key == key))
    s = result.scalar_one_or_none()
    if s:
        s.value = value
    else:
        db.add(Settings(key=key, value=value))
    await db.commit()

async def get_all_settings(db: AsyncSession) -> dict:
    result = await db.execute(select(Settings))
    data = dict(DEFAULTS)
    for s in result.scalars().all():
        data[s.key] = s.value
    return data
