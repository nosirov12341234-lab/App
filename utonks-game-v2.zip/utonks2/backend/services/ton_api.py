import httpx
import os
from typing import Optional

TON_API_KEY = os.getenv("TON_API_KEY", "")
BASE = "https://tonapi.io/v2"

async def get_all_collections() -> list:
    try:
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.get(f"{BASE}/gifts/collections", headers={"Authorization": f"Bearer {TON_API_KEY}"})
            if r.status_code == 200:
                return r.json().get("collections", [])
    except Exception as e:
        print(f"TON API error: {e}")
    return []

async def sync_collections(db) -> int:
    from sqlalchemy import select
    from models.database import GiftCollection
    from datetime import datetime

    collections = await get_all_collections()
    count = 0
    for col in collections:
        slug = col.get("slug") or col.get("name", "").lower().replace(" ", "-")
        result = await db.execute(select(GiftCollection).where(GiftCollection.slug == slug))
        existing = result.scalar_one_or_none()
        floor = col.get("floor_price", 0) / 1e9
        image = col.get("image") or col.get("cover_image") or col.get("preview_image") or ""

        if existing:
            existing.floor_price = floor
            existing.image_url = image
            existing.last_updated = datetime.utcnow()
        else:
            db.add(GiftCollection(
                name=col.get("name", slug),
                slug=slug,
                image_url=image,
                floor_price=floor,
            ))
        count += 1
    await db.commit()
    return count
