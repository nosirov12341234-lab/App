from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import asyncio, sys, os

sys.path.insert(0, os.path.dirname(__file__))

from models.db import init_db, AsyncSessionLocal
from routers import user, cases, inventory, crash, mines, upgrade, admin
from services.crash_engine import crash_engine
from services.settings import get_setting

async def _get(key):
    async with AsyncSessionLocal() as db:
        return await get_setting(db, key)

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    asyncio.create_task(crash_engine.run(AsyncSessionLocal, _get))
    yield

app = FastAPI(title="Utonks Game", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

app.include_router(user.router, prefix="/api")
app.include_router(cases.router, prefix="/api")
app.include_router(inventory.router, prefix="/api")
app.include_router(crash.router, prefix="/api")
app.include_router(mines.router, prefix="/api")
app.include_router(upgrade.router, prefix="/api")
app.include_router(admin.router, prefix="/api")

@app.get("/health")
async def health():
    return {"status": "ok"}
