import asyncio, os, httpx, logging
from telethon import TelegramClient
from telethon.sessions import StringSession

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

API_ID = int(os.getenv("TELEGRAM_API_ID", "0"))
API_HASH = os.getenv("TELEGRAM_API_HASH", "")
SESSION = os.getenv("USERBOT_SESSION", "")
BACKEND = os.getenv("BACKEND_URL", "http://backend:8000")
ADMIN_ID = int(os.getenv("ADMIN_TELEGRAM_ID", "0"))
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
INTERNAL_KEY = os.getenv("INTERNAL_KEY", "")

client = TelegramClient(StringSession(SESSION), API_ID, API_HASH)

async def notify_admin(msg: str):
    try:
        await client.send_message(ADMIN_ID, msg, parse_mode="html")
    except Exception as e:
        logger.error(f"Admin notify error: {e}")

async def notify_user(tg_id: int, msg: str):
    async with httpx.AsyncClient() as h:
        try:
            await h.post(f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
                json={"chat_id": tg_id, "text": msg, "parse_mode": "HTML"})
        except Exception as e:
            logger.error(f"User notify error: {e}")

async def get_pending():
    async with httpx.AsyncClient(timeout=10) as h:
        try:
            r = await h.get(f"{BACKEND}/api/admin/withdrawals/internal",
                headers={"x-internal-key": INTERNAL_KEY})
            if r.status_code == 200:
                return r.json()
        except Exception as e:
            logger.error(f"Fetch error: {e}")
    return []

async def complete(wid: int):
    async with httpx.AsyncClient(timeout=10) as h:
        try:
            await h.post(f"{BACKEND}/api/admin/withdrawals/{wid}/complete",
                headers={"x-internal-key": INTERNAL_KEY})
        except Exception as e:
            logger.error(f"Complete error: {e}")

async def process():
    logger.info("Withdrawal processor started")
    while True:
        try:
            withdrawals = await get_pending()
            for w in withdrawals:
                wid = w["id"]
                tg_id = w["user_id"]
                collection = w["collection"]
                username = w.get("username", "")
                logger.info(f"Processing #{wid}: {collection} → @{username}")

                # Get my gifts from Telegram
                found = False
                try:
                    async for gift in client.get_gifts():
                        gift_title = getattr(gift, 'title', '') or getattr(gift, 'name', '') or ''
                        if collection.lower() in gift_title.lower():
                            await client.send_gift(tg_id, gift)
                            await complete(wid)
                            await notify_user(tg_id,
                                f"✅ <b>Gift sent!</b>\n\n"
                                f"🎁 <b>{collection}</b>\n"
                                f"Check your Telegram gifts!")
                            logger.info(f"✅ Sent {collection} → {tg_id}")
                            found = True
                            break
                except Exception as e:
                    logger.error(f"Gift send error: {e}")

                if not found:
                    await notify_admin(
                        f"⚠️ <b>Gift needed!</b>\n\n"
                        f"🎁 Collection: <b>{collection}</b>\n"
                        f"👤 User: @{username} ({tg_id})\n"
                        f"🆔 Withdraw ID: #{wid}\n\n"
                        f"Add this gift to your account and it will be sent automatically.")
                    await notify_user(tg_id,
                        f"⏳ <b>Your gift is being prepared...</b>\n\n"
                        f"🎁 <b>{collection}</b>\n"
                        f"Will be sent within 5-10 minutes.")
        except Exception as e:
            logger.error(f"Process loop error: {e}")
        await asyncio.sleep(30)

async def main():
    logger.info("Starting Utonks userbot...")
    await client.connect()
    if not await client.is_user_authorized():
        logger.error("Session expired! Re-authorize.")
        return
    me = await client.get_me()
    logger.info(f"Logged in as @{me.username} ({me.id})")
    await notify_admin(f"🚀 Utonks userbot started!\n👤 @{me.username}")
    await process()

if __name__ == "__main__":
    asyncio.run(main())
