/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        dark: { 1: "#0A0912", 2: "#100E22", 3: "#16132E", 4: "#1E1A3A", 5: "#252147" },
        blue: { main: "#3D6EF8", light: "#5D8BFF", dark: "#2952D9" },
        ton: "#0098EA",
        green: { main: "#00E676", dark: "#00B85C" },
        red: { main: "#FF3D57", dark: "#CC2040" },
        gold: { main: "#FFB800", dark: "#CC9200" },
        purple: { main: "#7B4FE9", dark: "#5C35CC" },
      },
      fontFamily: { display: ["'Space Grotesk'", "sans-serif"] },
      animation: {
        "pulse-slow": "pulse 3s ease-in-out infinite",
        "float": "float 3s ease-in-out infinite",
        "glow": "glow 2s ease-in-out infinite",
        "spin-slow": "spin 4s linear infinite",
      },
      keyframes: {
        float: { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-8px)" } },
        glow: { "0%,100%": { boxShadow: "0 0 10px rgba(61,110,248,0.3)" }, "50%": { boxShadow: "0 0 25px rgba(61,110,248,0.7)" } },
      },
    },
  },
  plugins: [],
};
