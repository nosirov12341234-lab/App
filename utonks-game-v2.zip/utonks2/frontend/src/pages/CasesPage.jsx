import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useSearchParams } from "react-router-dom";
import api from "../utils/api";
import { useStore } from "../utils/store";
import TonIcon from "../components/ui/TonIcon";

export default function CasesPage() {
  const [cases, setCases] = useState([]);
  const [opening, setOpening] = useState(false);
  const [result, setResult] = useState(null);
  const [promoCode, setPromoCode] = useState("");
  const [promoResult, setPromoResult] = useState(null);
  const [promoLoading, setPromoLoading] = useState(false);
  const [tab, setTab] = useState("cases");
  const [params] = useSearchParams();
  const { fetchUser, fetchInventory } = useStore();

  useEffect(() => {
    api.get("/cases/").then(r => setCases(r.data));
    if (params.get("promo")) setTab("promo");
    if (params.get("daily")) setTab("daily");
  }, []);

  const openCase = async (c, method="ton") => {
    setOpening(true); setResult(null);
    try {
      const r = await api.post(`/cases/${c.id}/open?payment_method=${method}`);
      await new Promise(res => setTimeout(res, 2000));
      setResult(r.data.gift);
      await fetchUser(); await fetchInventory();
    } catch (e) { window.Telegram?.WebApp?.showAlert(e.response?.data?.detail||"Error"); }
    setOpening(false);
  };

  const usePromo = async () => {
    if (!promoCode.trim()) return;
    setPromoLoading(true);
    try {
      const r = await api.post(`/user/promocode?code=${promoCode}`);
      setPromoResult(r.data.reward);
      await fetchUser(); await fetchInventory();
    } catch (e) { window.Telegram?.WebApp?.showAlert(e.response?.data?.detail||"Invalid"); }
    setPromoLoading(false);
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <h1 className="text-2xl font-black font-display">📦 CASES</h1>

      {/* Tabs */}
      <div className="flex gap-2">
        {[["cases","🎁 Cases"],["promo","🎫 Promo"],["daily","⚡ Daily"]].map(([id,label])=>(
          <button key={id} onClick={()=>setTab(id)} className={`flex-1 py-2.5 rounded-xl text-sm font-bold border transition-all ${tab===id?"bg-blue-main border-blue-main":"bg-dark-3 border-white/8 text-white/50"}`}>{label}</button>
        ))}
      </div>

      {tab==="promo" && (
        <div className="bg-dark-3 rounded-2xl p-4 border border-white/5 space-y-3">
          <p className="text-white/60 text-sm">Enter promocode</p>
          <div className="flex gap-2">
            <input value={promoCode} onChange={e=>setPromoCode(e.target.value.toUpperCase())} placeholder="UTONKS2025"
              className="flex-1 bg-dark-4 border border-white/10 rounded-xl px-4 py-3 text-white outline-none font-mono tracking-widest uppercase"/>
            <button onClick={usePromo} disabled={promoLoading} className="px-5 py-3 bg-blue-main rounded-xl text-white font-bold disabled:opacity-50">{promoLoading?"...":"✓"}</button>
          </div>
          {promoResult && (
            <div className="bg-green-main/10 border border-green-main/30 rounded-xl p-3 text-center">
              <p className="text-green-main font-bold">🎉 Bonus received!</p>
              {promoResult.type==="ton"&&<p className="text-sm text-white/50">+{promoResult.amount} TON</p>}
              {promoResult.type==="gift"&&<p className="text-sm text-white/50">{promoResult.collection}</p>}
            </div>
          )}
        </div>
      )}

      {tab==="daily" && (
        <div className="bg-dark-3 rounded-2xl p-6 border border-white/5 text-center space-y-3">
          <span className="text-5xl">🎁</span>
          <p className="text-white font-bold text-lg">Daily Case</p>
          <p className="text-white/40 text-sm">Invite 1 friend to unlock your daily case</p>
          <button className="w-full py-4 rounded-xl bg-blue-main text-white font-bold active:scale-95 glow-blue">Open Daily Case</button>
        </div>
      )}

      {tab==="cases" && (
        <div className="space-y-4">
          {cases.length===0 && <div className="text-center py-12 text-white/30"><p className="text-4xl mb-3">📦</p><p>No cases yet</p><p className="text-sm mt-1">Admin will add cases soon</p></div>}
          {cases.map((c,i)=>(
            <motion.div key={c.id} initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{delay:i*0.08}} className="bg-dark-3 rounded-2xl p-4 border border-white/5">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-20 h-20 rounded-2xl bg-dark-4 overflow-hidden flex-shrink-0 border border-white/8">
                  {c.image_url?<img src={c.image_url} className="w-full h-full object-cover"/>:<div className="w-full h-full flex items-center justify-center text-4xl">📦</div>}
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-white text-lg font-display">{c.name}</h3>
                  <div className="flex gap-2 mt-2">
                    {c.price_ton&&<span className="flex items-center gap-1 text-xs bg-ton/20 text-ton px-2 py-1 rounded-lg font-bold"><TonIcon size={12}/>{c.price_ton}</span>}
                    {c.price_stars&&<span className="text-xs bg-gold-main/20 text-gold-main px-2 py-1 rounded-lg font-bold">⭐ {c.price_stars}</span>}
                  </div>
                </div>
              </div>

              {c.items?.length>0&&(
                <div className="mb-4">
                  <p className="text-white/30 text-xs mb-2 uppercase tracking-wider">Possible prizes</p>
                  <div className="grid grid-cols-3 gap-2">
                    {c.items.slice(0,6).map((item,j)=>(
                      <div key={j} className="bg-dark-4 rounded-xl p-2 text-center border border-white/5">
                        <div className="w-10 h-10 mx-auto rounded-lg overflow-hidden mb-1 bg-dark-5">
                          {item.collection_image?<img src={item.collection_image} className="w-full h-full object-cover"/>:<span className="text-2xl flex items-center justify-center h-full">🎁</span>}
                        </div>
                        <p className="text-white text-xs font-medium truncate">{item.collection_name}</p>
                        <p className="text-white/30 text-xs">{item.probability}%</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-2">
                {c.price_ton&&<button onClick={()=>openCase(c,"ton")} disabled={opening} className="flex-1 py-3 rounded-xl bg-blue-main text-white font-bold text-sm active:scale-95 glow-blue disabled:opacity-50">{opening?"Opening...":c.price_ton+" TON"}</button>}
                {c.price_stars&&<button onClick={()=>openCase(c,"stars")} disabled={opening} className="flex-1 py-3 rounded-xl bg-gold-main/20 border border-gold-main/40 text-gold-main font-bold text-sm active:scale-95 disabled:opacity-50">⭐ {c.price_stars}</button>}
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Opening modal */}
      <AnimatePresence>
        {(opening||result)&&(
          <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 z-50 bg-black/80 backdrop-blur flex items-center justify-center px-6">
            <motion.div initial={{scale:0.5,opacity:0}} animate={{scale:1,opacity:1}} exit={{scale:0.5,opacity:0}} className="w-full max-w-sm bg-dark-3 rounded-3xl p-8 text-center border border-white/10 space-y-5">
              {opening&&!result&&(
                <>
                  <motion.div animate={{rotateY:360}} transition={{duration:0.6,repeat:Infinity,ease:"linear"}} className="text-6xl">📦</motion.div>
                  <p className="text-white font-bold text-xl font-display">Opening...</p>
                  <div className="flex gap-1 justify-center">{[0,1,2].map(i=><motion.div key={i} className="w-2 h-2 bg-blue-main rounded-full" animate={{y:[0,-8,0]}} transition={{delay:i*0.15,repeat:Infinity,duration:0.6}}/>)}</div>
                </>
              )}
              {result&&(
                <>
                  <motion.div initial={{scale:0}} animate={{scale:[0,1.15,1]}} transition={{duration:0.5}} className="w-32 h-32 mx-auto rounded-2xl overflow-hidden border-2 border-blue-main/50 glow-blue">
                    {result.collection_image?<img src={result.collection_image} className="w-full h-full object-cover"/>:<div className="w-full h-full bg-dark-4 flex items-center justify-center text-5xl">🎁</div>}
                  </motion.div>
                  <div>
                    <p className="text-gradient-gold font-black text-2xl font-display">YOU WON!</p>
                    <p className="text-white font-bold text-xl mt-1">{result.collection_name}</p>
                    <p className="text-white/40 text-sm">{result.floor_price} TON</p>
                    {result.is_locked&&<p className="text-gold-main text-xs mt-2">🔒 Sell only (from bonus)</p>}
                  </div>
                  <button onClick={()=>setResult(null)} className="w-full py-4 rounded-2xl bg-blue-main text-white font-bold active:scale-95 glow-blue">Awesome! 🎉</button>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
