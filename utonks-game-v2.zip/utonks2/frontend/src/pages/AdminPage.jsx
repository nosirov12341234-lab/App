import { useState, useEffect } from "react";
import { Routes, Route, useNavigate, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import api from "../utils/api";
import { useStore } from "../utils/store";
import TonIcon from "../components/ui/TonIcon";

// ─── Password Gate ───────────────────────────────────────────────────────────
function AdminLogin({ onSuccess }) {
  const [pw, setPw] = useState("");
  const [err, setErr] = useState(false);
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    setLoading(true); setErr(false);
    try {
      await api.post(`/admin/auth?password=${pw}`);
      onSuccess();
    } catch { setErr(true); }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-6 bg-dark-1">
      <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm bg-dark-3 rounded-3xl p-8 border border-white/10 space-y-5">
        <div className="text-center">
          <span className="text-5xl">🛡️</span>
          <h2 className="text-2xl font-black font-display mt-3 text-gradient-gold">ADMIN PANEL</h2>
          <p className="text-white/40 text-sm mt-1">Enter admin password</p>
        </div>
        <div className={`flex items-center gap-3 bg-dark-4 rounded-2xl px-4 py-3 border ${err ? "border-red-main" : "border-white/10"}`}>
          <span className="text-xl">🔑</span>
          <input type="password" value={pw} onChange={e => setPw(e.target.value)}
            onKeyDown={e => e.key === "Enter" && submit()}
            placeholder="Password" className="flex-1 bg-transparent text-white outline-none"/>
        </div>
        {err && <p className="text-red-main text-sm text-center">❌ Wrong password</p>}
        <button onClick={submit} disabled={loading || !pw}
          className="w-full py-4 rounded-2xl bg-gold-main text-black font-bold text-lg active:scale-95 disabled:opacity-40 glow-gold">
          {loading ? "Checking..." : "Enter Admin Panel"}
        </button>
      </motion.div>
    </div>
  );
}

// ─── Main Admin ───────────────────────────────────────────────────────────────
export default function AdminPage() {
  const { adminVerified, setAdminVerified } = useStore();
  if (!adminVerified) return <AdminLogin onSuccess={() => setAdminVerified(true)} />;
  return (
    <Routes>
      <Route path="/" element={<AdminHome />} />
      <Route path="/cases" element={<AdminCases />} />
      <Route path="/collections" element={<AdminCollections />} />
      <Route path="/withdrawals" element={<AdminWithdrawals />} />
      <Route path="/users" element={<AdminUsers />} />
      <Route path="/promocodes" element={<AdminPromocodes />} />
      <Route path="/settings" element={<AdminSettings />} />
    </Routes>
  );
}

// ─── Home ─────────────────────────────────────────────────────────────────────
function AdminHome() {
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  useEffect(() => { api.get("/admin/stats").then(r => setStats(r.data)); }, []);

  const menu = [
    { label: "📦 Cases", sub: "Manage game cases", path: "/admin/cases" },
    { label: "🎁 Collections", sub: "Sync TON API gifts", path: "/admin/collections" },
    { label: "📤 Withdrawals", sub: `${stats?.pending_withdrawals || 0} pending`, path: "/admin/withdrawals", badge: stats?.pending_withdrawals },
    { label: "👥 Users", sub: `${stats?.total_users || 0} total`, path: "/admin/users" },
    { label: "🎫 Promocodes", sub: "Create promo codes", path: "/admin/promocodes" },
    { label: "⚙️ Settings", sub: "Platform settings", path: "/admin/settings" },
  ];

  return (
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-black font-display text-gradient-gold">ADMIN PANEL</h1>
        <span className="text-2xl">⚙️</span>
      </div>

      {stats && (
        <div className="grid grid-cols-2 gap-3">
          {[
            ["👥", stats.total_users, "Users"],
            ["💰", stats.total_deposited?.toFixed(1) + " TON", "Deposited"],
            ["📤", stats.pending_withdrawals, "Pending"],
            ["📈", stats.total_profit?.toFixed(1) + " TON", "Profit"],
          ].map(([icon, val, label]) => (
            <div key={label} className="bg-dark-3 rounded-2xl p-4 border border-white/5">
              <span className="text-2xl">{icon}</span>
              <p className="text-white font-bold text-xl mt-1">{val}</p>
              <p className="text-white/40 text-xs">{label}</p>
            </div>
          ))}
        </div>
      )}

      <div className="space-y-2">
        {menu.map(item => (
          <button key={item.path} onClick={() => navigate(item.path)}
            className="w-full bg-dark-3 rounded-2xl px-4 py-4 flex items-center justify-between border border-white/5 active:scale-98 transition-all">
            <div className="text-left">
              <p className="text-white font-semibold">{item.label}</p>
              <p className="text-white/40 text-xs mt-0.5">{item.sub}</p>
            </div>
            <div className="flex items-center gap-2">
              {item.badge > 0 && <span className="bg-red-main text-white text-xs font-bold px-2 py-0.5 rounded-full">{item.badge}</span>}
              <span className="text-white/30">→</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Collections ─────────────────────────────────────────────────────────────
function AdminCollections() {
  const navigate = useNavigate();
  const [cols, setCols] = useState([]);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => { api.get("/admin/collections").then(r => setCols(r.data)); }, []);

  const sync = async () => {
    setSyncing(true);
    try {
      const r = await api.post("/admin/collections/sync");
      window.Telegram?.WebApp?.showAlert(`✅ Synced ${r.data.synced} collections!`);
      api.get("/admin/collections").then(r => setCols(r.data));
    } catch { window.Telegram?.WebApp?.showAlert("Error syncing"); }
    setSyncing(false);
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate("/admin")} className="text-white/50 active:scale-90">←</button>
        <h1 className="text-xl font-black font-display">Collections</h1>
      </div>

      <button onClick={sync} disabled={syncing}
        className="w-full py-3 rounded-2xl bg-blue-main text-white font-bold active:scale-95 glow-blue disabled:opacity-50">
        {syncing ? "⏳ Syncing..." : "🔄 Sync from TON API"}
      </button>

      <p className="text-white/30 text-xs text-center">{cols.length} collections loaded</p>

      <div className="grid grid-cols-3 gap-3">
        {cols.map(c => (
          <div key={c.id} className="bg-dark-3 rounded-2xl p-3 text-center border border-white/5">
            <div className="w-12 h-12 mx-auto rounded-xl overflow-hidden bg-dark-4 mb-2">
              {c.image_url ? <img src={c.image_url} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-2xl">🎁</div>}
            </div>
            <p className="text-white text-xs font-medium truncate">{c.name}</p>
            <p className="text-white/40 text-xs">{c.floor_price?.toFixed(2)} TON</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Cases ────────────────────────────────────────────────────────────────────
function AdminCases() {
  const navigate = useNavigate();
  const [cases, setCases] = useState([]);
  const [cols, setCols] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", image_url: "", price_ton: "", price_stars: "", sort_order: 0, items: [] });

  useEffect(() => {
    api.get("/admin/cases").then(r => setCases(r.data));
    api.get("/admin/collections").then(r => setCols(r.data));
  }, []);

  const addItem = (col) => {
    if (form.items.find(i => i.collection_id === col.id)) return;
    setForm({ ...form, items: [...form.items, { collection_id: col.id, collection_name: col.name, collection_image: col.image_url, probability: 10 }] });
  };

  const save = async () => {
    try {
      await api.post("/admin/cases", {
        name: form.name, image_url: form.image_url,
        price_ton: form.price_ton ? parseFloat(form.price_ton) : null,
        price_stars: form.price_stars ? parseInt(form.price_stars) : null,
        sort_order: parseInt(form.sort_order),
        items: form.items.map(i => ({ collection_id: i.collection_id, probability: parseFloat(i.probability) })),
      });
      setShowForm(false);
      setForm({ name: "", image_url: "", price_ton: "", price_stars: "", sort_order: 0, items: [] });
      api.get("/admin/cases").then(r => setCases(r.data));
    } catch (e) { window.Telegram?.WebApp?.showAlert(e.response?.data?.detail || "Error"); }
  };

  const del = async (id) => {
    await api.delete(`/admin/cases/${id}`);
    setCases(cases.filter(c => c.id !== id));
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("/admin")} className="text-white/50">←</button>
          <h1 className="text-xl font-black font-display">Cases</h1>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="px-4 py-2 bg-blue-main rounded-xl text-white font-bold text-sm active:scale-95">+ New</button>
      </div>

      {showForm && (
        <div className="bg-dark-3 rounded-2xl p-4 border border-white/10 space-y-3">
          <input className="w-full bg-dark-4 rounded-xl px-4 py-3 text-white outline-none border border-white/8" placeholder="Case name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
          <input className="w-full bg-dark-4 rounded-xl px-4 py-3 text-white outline-none border border-white/8 text-sm" placeholder="Image URL (from TON API or direct link)" value={form.image_url} onChange={e => setForm({ ...form, image_url: e.target.value })} />
          <div className="grid grid-cols-2 gap-2">
            <input className="bg-dark-4 rounded-xl px-4 py-3 text-white outline-none border border-white/8" type="number" placeholder="Price TON" value={form.price_ton} onChange={e => setForm({ ...form, price_ton: e.target.value })} />
            <input className="bg-dark-4 rounded-xl px-4 py-3 text-white outline-none border border-white/8" type="number" placeholder="Price Stars" value={form.price_stars} onChange={e => setForm({ ...form, price_stars: e.target.value })} />
          </div>

          <p className="text-white/50 text-sm font-medium">Add gift collections:</p>
          <div className="grid grid-cols-4 gap-2 max-h-48 overflow-y-auto">
            {cols.map(c => (
              <button key={c.id} onClick={() => addItem(c)} className={`rounded-xl p-2 text-center border transition-all active:scale-95 ${form.items.find(i => i.collection_id === c.id) ? "border-blue-main bg-blue-main/20" : "border-white/8 bg-dark-4"}`}>
                <div className="w-10 h-10 mx-auto rounded-lg overflow-hidden bg-dark-5 mb-1">
                  {c.image_url ? <img src={c.image_url} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-xl">🎁</div>}
                </div>
                <p className="text-white text-xs truncate">{c.name}</p>
              </button>
            ))}
          </div>

          {form.items.length > 0 && (
            <div className="space-y-2">
              <p className="text-white/50 text-sm">Set probabilities (%):</p>
              {form.items.map((item, i) => (
                <div key={i} className="flex items-center gap-2 bg-dark-4 rounded-xl px-3 py-2 border border-white/8">
                  <div className="w-8 h-8 rounded-lg overflow-hidden flex-shrink-0">
                    {item.collection_image ? <img src={item.collection_image} className="w-full h-full object-cover" /> : <span>🎁</span>}
                  </div>
                  <p className="text-white text-sm flex-1 truncate">{item.collection_name}</p>
                  <input type="number" value={item.probability}
                    onChange={e => { const ni = [...form.items]; ni[i].probability = e.target.value; setForm({ ...form, items: ni }); }}
                    className="w-16 bg-dark-3 rounded-lg px-2 py-1 text-white text-sm outline-none text-center border border-white/10" />
                  <span className="text-white/30 text-xs">%</span>
                  <button onClick={() => setForm({ ...form, items: form.items.filter((_, j) => j !== i) })} className="text-red-main text-sm">✕</button>
                </div>
              ))}
            </div>
          )}

          <div className="flex gap-2">
            <button onClick={() => setShowForm(false)} className="flex-1 py-3 rounded-xl bg-dark-4 border border-white/10 text-white/60 font-semibold">Cancel</button>
            <button onClick={save} className="flex-1 py-3 rounded-xl bg-green-main text-black font-bold active:scale-95">Save Case</button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {cases.map(c => (
          <div key={c.id} className="bg-dark-3 rounded-2xl p-4 flex items-center gap-3 border border-white/5">
            <div className="w-14 h-14 rounded-xl overflow-hidden bg-dark-4 flex-shrink-0 border border-white/8">
              {c.image_url ? <img src={c.image_url} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-2xl">📦</div>}
            </div>
            <div className="flex-1">
              <p className="text-white font-bold">{c.name}</p>
              <div className="flex gap-2 mt-1">
                {c.price_ton && <span className="text-xs bg-ton/20 text-ton px-2 py-0.5 rounded-lg">{c.price_ton} TON</span>}
                {c.price_stars && <span className="text-xs bg-gold-main/20 text-gold-main px-2 py-0.5 rounded-lg">⭐{c.price_stars}</span>}
                {!c.is_active && <span className="text-xs bg-red-main/20 text-red-main px-2 py-0.5 rounded-lg">Hidden</span>}
              </div>
            </div>
            <button onClick={() => del(c.id)} className="px-3 py-2 bg-red-main/20 text-red-main rounded-xl text-sm active:scale-95">🗑</button>
          </div>
        ))}
        {cases.length === 0 && <p className="text-white/20 text-center py-8">No cases yet. Create one!</p>}
      </div>
    </div>
  );
}

// ─── Withdrawals ──────────────────────────────────────────────────────────────
function AdminWithdrawals() {
  const navigate = useNavigate();
  const [list, setList] = useState([]);
  useEffect(() => { api.get("/admin/withdrawals").then(r => setList(r.data)); }, []);

  const complete = async (id) => {
    await api.post(`/admin/withdrawals/${id}/complete_admin`);
    setList(list.filter(w => w.id !== id));
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate("/admin")} className="text-white/50">←</button>
        <h1 className="text-xl font-black font-display">Withdrawals</h1>
        <span className="bg-red-main/20 text-red-main text-xs font-bold px-2 py-0.5 rounded-full">{list.length}</span>
      </div>

      {list.length === 0
        ? <div className="text-center py-12 text-white/20"><p className="text-4xl mb-3">✅</p><p>No pending withdrawals</p></div>
        : <div className="space-y-3">
          {list.map(w => (
            <div key={w.id} className="bg-dark-3 rounded-2xl p-4 border border-white/5 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-white font-bold text-lg">🎁 {w.collection}</p>
                  <p className="text-white/50 text-sm">@{w.username} · ID: {w.user_id}</p>
                  <p className="text-white/30 text-xs mt-1">{new Date(w.created_at).toLocaleString()}</p>
                </div>
                <span className="text-white/30 text-sm">#{w.id}</span>
              </div>
              <div className="bg-blue-main/10 border border-blue-main/20 rounded-xl px-3 py-2 text-xs text-blue-light">
                💡 Send <b>{w.collection}</b> gift from your userbot to @{w.username} ({w.user_id}), then mark as done
              </div>
              <button onClick={() => complete(w.id)}
                className="w-full py-3 rounded-xl bg-green-main text-black font-bold active:scale-95 glow-green">
                ✅ Gift sent — Mark as Done
              </button>
            </div>
          ))}
        </div>
      }
    </div>
  );
}

// ─── Users ────────────────────────────────────────────────────────────────────
function AdminUsers() {
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  useEffect(() => { api.get("/admin/users").then(r => setUsers(r.data)); }, []);

  const toggleBan = async (u) => {
    await api.post(`/admin/users/${u.id}/ban`);
    setUsers(users.map(x => x.id === u.id ? { ...x, is_banned: !x.is_banned } : x));
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate("/admin")} className="text-white/50">←</button>
        <h1 className="text-xl font-black font-display">Users ({users.length})</h1>
      </div>
      <div className="space-y-2">
        {users.map(u => (
          <div key={u.id} className="bg-dark-3 rounded-2xl px-4 py-3 flex items-center justify-between border border-white/5">
            <div>
              <p className="text-white font-medium">{u.username ? `@${u.username}` : u.first_name || `ID:${u.telegram_id}`}</p>
              <p className="text-white/30 text-xs">{u.balance?.toFixed(2)} TON · {new Date(u.created_at).toLocaleDateString()}</p>
            </div>
            <div className="flex items-center gap-2">
              {u.is_admin && <span className="text-xs bg-gold-main/20 text-gold-main px-2 py-0.5 rounded-lg">Admin</span>}
              <button onClick={() => toggleBan(u)} className={`text-xs px-3 py-1.5 rounded-lg font-semibold active:scale-95 ${u.is_banned ? "bg-green-main/20 text-green-main" : "bg-red-main/20 text-red-main"}`}>
                {u.is_banned ? "Unban" : "Ban"}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Promocodes ───────────────────────────────────────────────────────────────
function AdminPromocodes() {
  const navigate = useNavigate();
  const [cols, setCols] = useState([]);
  const [promos, setPromos] = useState([]);
  const [form, setForm] = useState({ code: "", reward_type: "ton", reward_ton: "", reward_collection_id: "", max_uses: "1" });

  useEffect(() => {
    api.get("/admin/collections").then(r => setCols(r.data));
    api.get("/admin/promocodes").then(r => setPromos(r.data));
  }, []);

  const create = async () => {
    try {
      await api.post("/admin/promocodes", {
        code: form.code.toUpperCase(), reward_type: form.reward_type,
        reward_ton: form.reward_ton ? parseFloat(form.reward_ton) : null,
        reward_collection_id: form.reward_collection_id ? parseInt(form.reward_collection_id) : null,
        max_uses: parseInt(form.max_uses),
      });
      window.Telegram?.WebApp?.showAlert("✅ Promocode created!");
      setForm({ code: "", reward_type: "ton", reward_ton: "", reward_collection_id: "", max_uses: "1" });
      api.get("/admin/promocodes").then(r => setPromos(r.data));
    } catch (e) { window.Telegram?.WebApp?.showAlert(e.response?.data?.detail || "Error"); }
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate("/admin")} className="text-white/50">←</button>
        <h1 className="text-xl font-black font-display">Promocodes</h1>
      </div>

      <div className="bg-dark-3 rounded-2xl p-4 border border-white/10 space-y-3">
        <input className="w-full bg-dark-4 rounded-xl px-4 py-3 text-white outline-none border border-white/8 font-mono uppercase tracking-widest" placeholder="UTONKS2025" value={form.code} onChange={e => setForm({ ...form, code: e.target.value })} />
        <div className="grid grid-cols-2 gap-2">
          {[["ton", "💎 TON Reward"], ["gift", "🎁 Gift Reward"]].map(([id, label]) => (
            <button key={id} onClick={() => setForm({ ...form, reward_type: id })}
              className={`py-3 rounded-xl text-sm font-bold border transition-all ${form.reward_type === id ? "bg-blue-main border-blue-main" : "bg-dark-4 border-white/8 text-white/50"}`}>
              {label}
            </button>
          ))}
        </div>
        {form.reward_type === "ton" && (
          <input className="w-full bg-dark-4 rounded-xl px-4 py-3 text-white outline-none border border-white/8" type="number" placeholder="TON amount" value={form.reward_ton} onChange={e => setForm({ ...form, reward_ton: e.target.value })} />
        )}
        {form.reward_type === "gift" && (
          <select className="w-full bg-dark-4 rounded-xl px-4 py-3 text-white outline-none border border-white/8" value={form.reward_collection_id} onChange={e => setForm({ ...form, reward_collection_id: e.target.value })}>
            <option value="">Select collection</option>
            {cols.map(c => <option key={c.id} value={c.id}>{c.name} ({c.floor_price?.toFixed(2)} TON)</option>)}
          </select>
        )}
        <div className="flex items-center gap-2">
          <span className="text-white/50 text-sm">Max uses:</span>
          <input className="flex-1 bg-dark-4 rounded-xl px-4 py-2 text-white outline-none border border-white/8" type="number" value={form.max_uses} onChange={e => setForm({ ...form, max_uses: e.target.value })} />
        </div>
        <button onClick={create} className="w-full py-4 rounded-xl bg-blue-main text-white font-bold active:scale-95 glow-blue">Create Promocode</button>
      </div>

      <div className="space-y-2">
        {promos.map(p => (
          <div key={p.id} className="bg-dark-3 rounded-2xl px-4 py-3 border border-white/5 flex items-center justify-between">
            <div>
              <p className="text-white font-mono font-bold">{p.code}</p>
              <p className="text-white/40 text-xs">{p.reward_type === "ton" ? `+${p.reward_ton} TON` : "Gift"} · {p.used_count}/{p.max_uses} used</p>
            </div>
            <span className={`text-xs px-2 py-1 rounded-lg ${p.is_active ? "bg-green-main/20 text-green-main" : "bg-red-main/20 text-red-main"}`}>
              {p.is_active ? "Active" : "Expired"}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Settings ─────────────────────────────────────────────────────────────────
function AdminSettings() {
  const navigate = useNavigate();
  const [settings, setSettings] = useState({});
  const [loading, setLoading] = useState(false);
  useEffect(() => { api.get("/admin/settings").then(r => setSettings(r.data)); }, []);

  const save = async () => {
    setLoading(true);
    await api.put("/admin/settings", settings);
    setLoading(false);
    window.Telegram?.WebApp?.showAlert("✅ Settings saved!");
  };

  const fields = [
    ["stars_to_ton_rate", "1 Star = ? TON", "0.013"],
    ["min_deposit_stars", "Min deposit (Stars)", "50"],
    ["min_deposit_ton", "Min deposit (TON)", "0.1"],
    ["deposit_bonus_ton_percent", "TON deposit bonus %", "10"],
    ["sell_commission_percent", "Sell commission %", "15"],
    ["upgrade_commission_percent", "Upgrade commission %", "5"],
    ["crash_house_edge", "Crash house edge (0-1)", "0.04"],
    ["mines_house_edge", "Mines house edge (0-1)", "0.04"],
    ["fake_online_min", "Fake online min", "50"],
    ["fake_online_max", "Fake online max", "70"],
    ["platform_ton_wallet", "Platform TON wallet", ""],
    ["admin_password", "Admin password", "admin123"],
  ];

  return (
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate("/admin")} className="text-white/50">←</button>
        <h1 className="text-xl font-black font-display">Settings</h1>
      </div>
      <div className="space-y-3">
        {fields.map(([key, label, placeholder]) => (
          <div key={key} className="bg-dark-3 rounded-2xl p-4 border border-white/5">
            <label className="text-white/50 text-xs uppercase tracking-wider mb-2 block">{label}</label>
            <input type="text" value={settings[key] || ""} placeholder={placeholder}
              onChange={e => setSettings({ ...settings, [key]: e.target.value })}
              className="w-full bg-dark-4 rounded-xl px-4 py-2.5 text-white outline-none border border-white/8 text-sm" />
          </div>
        ))}
      </div>
      <button onClick={save} disabled={loading} className="w-full py-4 rounded-2xl bg-blue-main text-white font-bold disabled:opacity-50 active:scale-95 glow-blue">
        {loading ? "Saving..." : "💾 Save Settings"}
      </button>
    </div>
  );
}
