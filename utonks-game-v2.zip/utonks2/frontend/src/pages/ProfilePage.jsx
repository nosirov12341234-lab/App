import { useEffect, useState } from "react";
import { useTonConnectUI, useTonAddress } from "@tonconnect/ui-react";
import api from "../utils/api";
import { useStore } from "../utils/store";
import TonIcon from "../components/ui/TonIcon";
import DepositModal from "../components/ui/DepositModal";

const LEVELS = [
  { level:1, percent:10, min:0, emoji:"🍪", name:"Beginner" },
  { level:2, percent:12, min:25, emoji:"🐸", name:"Pro" },
  { level:3, percent:14, min:100, emoji:"⌚", name:"Expert" },
  { level:4, percent:18, min:500, emoji:"💎", name:"Legend" },
];

export default function ProfilePage() {
  const { user, fetchUser } = useStore();
  const [txs, setTxs] = useState([]);
  const [showLevels, setShowLevels] = useState(false);
  const [showDeposit, setShowDeposit] = useState(false);
  const [tonUI] = useTonConnectUI();
  const wallet = useTonAddress();

  useEffect(() => {
    fetchUser();
    api.get("/user/transactions").then(r=>setTxs(r.data));
  }, []);

  const copy = () => { navigator.clipboard.writeText(user?.referral_link||""); window.Telegram?.WebApp?.showAlert("Copied! ✅"); };
  const level = LEVELS.find(l=>l.level===(user?.level||1))||LEVELS[0];
  const nextLevel = LEVELS.find(l=>l.level===(user?.level||1)+1);

  const txLabel = (t) => ({ deposit_ton:"TON Deposit", deposit_stars:"Stars Deposit", deposit_gift:"Gift Deposit", withdraw_gift:"Gift Withdraw", sell_gift:"Gift Sold", bet_win:"Game Win", bet_lose:"Game Bet", referral_bonus:"Referral Bonus", case_open:"Case Opened", upgrade:"Upgrade", promocode:"Promocode" }[t]||t);

  return (
    <div className="px-4 py-4 space-y-4">
      {/* User card */}
      <div className="bg-dark-3 rounded-3xl p-5 border border-white/5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              {user?.photo_url
                ? <img src={user.photo_url} className="w-16 h-16 rounded-2xl object-cover ring-2 ring-blue-main/30"/>
                : <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-main to-purple-main flex items-center justify-center text-2xl font-bold">{user?.first_name?.[0]||"U"}</div>
              }
              <div className="absolute -bottom-1 -right-1 bg-dark-2 rounded-lg px-1.5 py-0.5 text-sm border border-white/10">{level.emoji}</div>
            </div>
            <div>
              <p className="text-white font-bold text-xl">{user?.first_name}</p>
              <p className="text-white/40 text-sm">Level {user?.level} · {level.name}</p>
            </div>
          </div>
          <button onClick={()=>tonUI.openModal()} className="bg-dark-4 rounded-xl px-3 py-2 border border-white/10 text-xs font-mono text-white/50 active:scale-95">
            {wallet?`${wallet.slice(0,6)}...${wallet.slice(-4)}`:"Connect Wallet"}
          </button>
        </div>

        <button onClick={()=>setShowDeposit(true)} className="w-full py-4 rounded-2xl bg-blue-main text-white font-bold text-lg flex items-center justify-center gap-2 active:scale-95 glow-blue">
          ↑ Deposit
        </button>
      </div>

      {/* Referrals */}
      <div className="bg-dark-3 rounded-3xl p-5 border border-white/5 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-white font-bold text-lg">Referrals</h2>
          <button onClick={()=>setShowLevels(!showLevels)} className="text-blue-light text-sm active:scale-95">Levels →</button>
        </div>

        <div className="bg-dark-4 rounded-2xl p-4 flex items-center justify-between border border-white/5">
          <div>
            <p className="text-white font-black text-2xl font-display">Level {user?.level}</p>
            <p className="text-white/40 text-sm">{level.percent}% from net income</p>
            {nextLevel&&<p className="text-white/30 text-xs mt-1">Next: Level {nextLevel.level} at {nextLevel.min} TON</p>}
          </div>
          <span className="text-5xl">{level.emoji}</span>
        </div>

        {showLevels&&(
          <div className="space-y-2">
            {LEVELS.map(l=>(
              <div key={l.level} className={`rounded-2xl p-3 flex items-center justify-between border ${l.level===(user?.level||1)?"bg-blue-main/10 border-blue-main/30":"bg-dark-4 border-white/5"}`}>
                <div>
                  <p className="text-white font-bold">Level {l.level} · {l.name}</p>
                  <p className="text-white/40 text-xs">{l.percent}% · from {l.min} TON deposits</p>
                </div>
                <span className="text-3xl">{l.emoji}</span>
              </div>
            ))}
          </div>
        )}

        <div className="grid grid-cols-3 gap-2">
          {[["👥", user?.referral_count||0, "Friends"], ["💎", (user?.total_referral_deposits||0).toFixed(1)+" TON", "Deposited"], ["💰", (user?.referral_earnings||0).toFixed(2)+" TON", "Earned"]].map(([icon,val,label])=>(
            <div key={label} className="bg-dark-4 rounded-2xl p-3 text-center border border-white/5">
              <span className="text-2xl">{icon}</span>
              <p className="text-white font-bold text-sm mt-1">{val}</p>
              <p className="text-white/30 text-xs">{label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Referral link */}
      <div className="bg-dark-3 rounded-3xl p-5 border border-white/5 space-y-3">
        <h2 className="text-white font-bold">Referral link</h2>
        <button onClick={copy} className="w-full bg-dark-4 rounded-2xl px-4 py-3 flex items-center justify-between border border-white/8 active:scale-95">
          <span className="text-white/50 text-sm font-mono truncate">{user?.referral_link||"..."}</span>
          <span className="text-white/30 ml-2 flex-shrink-0">📋</span>
        </button>
        <div className="grid grid-cols-2 gap-3">
          {[["Available",user?.referral_earnings],["Total earned",user?.referral_earnings]].map(([label,val])=>(
            <div key={label} className="bg-dark-4 rounded-2xl p-3 text-center border border-white/5">
              <p className="text-white/30 text-xs mb-1">{label}</p>
              <p className="text-white font-bold">{(val||0).toFixed(2)} TON</p>
            </div>
          ))}
        </div>
        <p className="text-white/20 text-xs text-center">Balance updates once a day</p>
      </div>

      {/* Transactions */}
      <div className="bg-dark-3 rounded-3xl p-5 border border-white/5 space-y-3">
        <h2 className="text-white font-bold">Transaction history</h2>
        {txs.length===0
          ? <p className="text-white/20 text-sm text-center py-4">No transactions yet</p>
          : <div className="space-y-2">
              {txs.map(tx=>(
                <div key={tx.id} className="flex items-center justify-between bg-dark-4 rounded-2xl px-4 py-3 border border-white/5">
                  <div>
                    <p className="text-white text-sm font-medium">{txLabel(tx.type)}</p>
                    <p className="text-white/30 text-xs">{new Date(tx.created_at).toLocaleString()}</p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className={`font-bold text-sm ${tx.amount>=0?"text-green-main":"text-red-main"}`}>{tx.amount>=0?"+":""}{tx.amount.toFixed(3)}</span>
                    <TonIcon size={14}/>
                  </div>
                </div>
              ))}
            </div>
        }
      </div>

      {showDeposit&&<DepositModal onClose={()=>setShowDeposit(false)}/>}
    </div>
  );
}
