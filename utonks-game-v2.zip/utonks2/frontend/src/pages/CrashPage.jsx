import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import api from "../utils/api";
import { useStore } from "../utils/store";
import TonIcon from "../components/ui/TonIcon";

export default function CrashPage() {
  const { user, fetchUser } = useStore();
  const [state, setState] = useState("waiting");
  const [multi, setMulti] = useState(1.0);
  const [crashPt, setCrashPt] = useState(null);
  const [history, setHistory] = useState([]);
  const [bets, setBets] = useState([]);
  const [myBet, setMyBet] = useState(null);
  const [cashed, setCashed] = useState(false);
  const [betAmt, setBetAmt] = useState("0.1");
  const [timer, setTimer] = useState(5);
  const [online, setOnline] = useState(63);
  const canvasRef = useRef(null);
  const wsRef = useRef(null);
  const startRef = useRef(null);

  const drawGraph = useCallback((m) => {
    const c = canvasRef.current; if (!c) return;
    const ctx = c.getContext("2d"); const w = c.width; const h = c.height;
    ctx.clearRect(0, 0, w, h);
    // Grid
    ctx.strokeStyle = "rgba(255,255,255,0.04)"; ctx.lineWidth = 1;
    for (let i = 1; i <= 4; i++) { ctx.beginPath(); ctx.moveTo(0, h/4*i); ctx.lineTo(w, h/4*i); ctx.stroke(); }
    if (!startRef.current) return;
    const elapsed = Date.now() - startRef.current;
    const pts = [];
    for (let t = 0; t <= elapsed; t += 80) {
      const mm = Math.pow(Math.E, 0.00006 * t);
      pts.push({ x: (t / Math.max(elapsed, 1)) * w, y: h - ((mm - 1) / Math.max(m - 1, 0.01)) * h * 0.8 });
    }
    if (pts.length < 2) return;
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, "rgba(61,110,248,0.25)"); grad.addColorStop(1, "rgba(61,110,248,0)");
    ctx.beginPath(); ctx.moveTo(pts[0].x, h);
    pts.forEach(p => ctx.lineTo(p.x, p.y));
    ctx.lineTo(pts[pts.length-1].x, h); ctx.closePath(); ctx.fillStyle = grad; ctx.fill();
    ctx.beginPath(); pts.forEach((p,i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
    ctx.strokeStyle = "#3D6EF8"; ctx.lineWidth = 3; ctx.stroke();
    const lp = pts[pts.length-1];
    ctx.font = "20px serif"; ctx.fillText("🚀", lp.x - 10, lp.y - 10);
  }, []);

  useEffect(() => {
    const proto = window.location.protocol === "https:" ? "wss:" : "ws:";
    const WS = `${proto}//${window.location.host}/api/crash/ws`;
    const connect = () => {
      const ws = new WebSocket(WS); wsRef.current = ws;
      ws.onmessage = (e) => {
        const d = JSON.parse(e.data);
        if (d.type === "state") { setState(d.game_state); setMulti(d.multiplier||1); setHistory(d.history||[]); setOnline(d.online||63); }
        if (d.type === "betting") { setState("betting"); setMulti(1); setCrashPt(null); setBets([]); setMyBet(null); setCashed(false); startRef.current=null; let t=5; setBetTimer(5); const iv=setInterval(()=>{t--;setBetTimer(t);if(t<=0)clearInterval(iv);},1000); setHistory(d.history||[]); setOnline(d.online||63); }
        if (d.type === "started") { setState("running"); setBets(d.bets||[]); startRef.current=Date.now(); }
        if (d.type === "tick") { setMulti(d.multiplier); setOnline(d.online||63); drawGraph(d.multiplier); }
        if (d.type === "cashout") { setBets(prev => prev.map(b => b.username===d.username ? {...b, cashed:true, cm:d.multiplier} : b)); }
        if (d.type === "crashed") { setState("crashed"); setCrashPt(d.crash_point); setHistory(d.history||[]); const c=canvasRef.current; if(c){const ctx=c.getContext("2d");ctx.clearRect(0,0,c.width,c.height);ctx.fillStyle="rgba(255,61,87,0.08)";ctx.fillRect(0,0,c.width,c.height);} }
      };
      ws.onclose = () => setTimeout(connect, 2000);
    };
    connect();
    return () => wsRef.current?.close();
  }, [drawGraph]);

  const [betTimer, setBetTimer] = useState(5);

  const placeBet = async () => {
    if (state !== "betting" || myBet) return;
    try { await api.post(`/crash/bet?amount=${betAmt}`); setMyBet(parseFloat(betAmt)); await fetchUser(); }
    catch (e) { window.Telegram?.WebApp?.showAlert(e.response?.data?.detail || "Error"); }
  };

  const cashout = async () => {
    if (state !== "running" || !myBet || cashed) return;
    try { const r = await api.post("/crash/cashout"); setCashed(true); await fetchUser(); }
    catch {}
  };

  const mColor = state==="crashed" ? "#FF3D57" : multi<2 ? "#fff" : multi<5 ? "#FFB800" : "#00E676";

  return (
    <div className="flex flex-col px-4 py-3 gap-4">
      {/* History pills */}
      <div className="flex gap-2 overflow-x-auto scrollbar-none pb-1">
        {[...history].reverse().map((h,i) => (
          <span key={i} className={`flex-shrink-0 text-xs font-bold px-2.5 py-1 rounded-lg ${h<2?"bg-red-main/20 text-red-main":h<5?"bg-gold-main/20 text-gold-main":"bg-green-main/20 text-green-main"}`}>x{h}</span>
        ))}
      </div>

      {/* Game canvas */}
      <div className="relative bg-dark-3 rounded-3xl overflow-hidden border border-white/5" style={{height:200}}>
        <canvas ref={canvasRef} width={400} height={200} className="w-full h-full"/>
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <motion.span key={state+multi.toFixed(1)} className="text-5xl font-black font-display" style={{color:mColor,textShadow:`0 0 30px ${mColor}50`}}>
            {state==="crashed" ? `💥 ${crashPt}x` : state==="betting" ? `${betTimer}s` : `${multi.toFixed(2)}x`}
          </motion.span>
          {state==="betting" && <p className="text-white/40 text-xs mt-1">Place your bets</p>}
        </div>
        <div className="absolute top-3 left-3 flex items-center gap-1.5 bg-dark-2/80 rounded-lg px-2 py-1">
          <div className="w-1.5 h-1.5 rounded-full bg-green-main animate-pulse"/>
          <span className="text-white/50 text-xs">{online}</span>
        </div>
      </div>

      {/* Bet controls */}
      <div className="bg-dark-3 rounded-2xl p-4 border border-white/5 space-y-3">
        <div className="flex gap-2">
          <div className="flex-1 flex items-center gap-2 bg-dark-4 rounded-xl px-3 py-2.5 border border-white/8">
            <TonIcon size={16}/>
            <input type="number" value={betAmt} onChange={e=>setBetAmt(e.target.value)} className="flex-1 bg-transparent text-white outline-none text-sm" min="0.01" step="0.1"/>
          </div>
          <button className="flex items-center gap-2 px-4 py-2.5 bg-dark-4 rounded-xl border border-white/8 text-white/40 text-sm">
            🎁 Gift
          </button>
        </div>
        <div className="flex gap-2">
          {["0.1","0.5","1","5"].map(q=>(
            <button key={q} onClick={()=>setBetAmt(q)} className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition-all ${betAmt===q?"bg-blue-main border-blue-main":"bg-dark-4 border-white/10 text-white/50"}`}>{q}</button>
          ))}
        </div>
        <button onClick={state==="running"&&myBet&&!cashed ? cashout : placeBet}
          disabled={(state==="betting"&&!!myBet)||(state==="running"&&(!myBet||cashed))||state==="crashed"}
          className={`w-full py-4 rounded-xl font-bold text-base transition-all active:scale-95 disabled:opacity-40 ${state==="running"&&myBet&&!cashed ? "bg-green-main text-black animate-pulse glow-green" : "bg-blue-main text-white glow-blue"}`}>
          {state==="running"&&myBet&&!cashed ? `Cash Out ${(parseFloat(betAmt)*multi).toFixed(3)} TON` : state==="betting"&&!myBet ? "Place Bet" : myBet ? "✓ Bet placed" : "Place Bet"}
        </button>
      </div>

      {/* Bet list */}
      <div className="space-y-2">
        {bets.slice(0,8).map((b,i)=>(
          <div key={i} className="flex items-center justify-between bg-dark-3 rounded-xl px-3 py-2.5 border border-white/5">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-dark-4 flex items-center justify-center text-sm">{b.avatar||"👤"}</div>
              <div>
                <p className="text-sm font-medium text-white">{b.username}</p>
                <p className="text-xs text-white/40">{b.amount} TON</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              {b.cashed ? <span className="text-green-main text-sm font-bold">{(b.amount*(b.cm||1)).toFixed(2)}</span> : <span className="text-white/40 text-sm">{b.amount}</span>}
              <TonIcon size={14}/>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
