import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

const GAMES = [
  { id: "crash", name: "CRASH", path: "/games/crash", from: "from-blue-600", to: "to-cyan-400", emoji: "🚀", desc: "Fly to the moon!" },
  { id: "mines", name: "MINES", path: "/games/mines", from: "from-red-600", to: "to-pink-500", emoji: "💣", desc: "Avoid the bombs!" },
  { id: "cases", name: "CASES", path: "/games/cases", from: "from-purple-600", to: "to-violet-400", emoji: "📦", desc: "Open gift cases!" },
  { id: "upgrade", name: "UPGRADE", path: "/games/upgrade", from: "from-amber-500", to: "to-orange-400", emoji: "⬆️", desc: "Upgrade your gifts!" },
];

const BONUSES = [
  { id: "promo", name: "PROMOCODE", emoji: "🎫", path: "/games/cases?promo=1" },
  { id: "daily", name: "DAILY CASE", emoji: "🎁", path: "/games/cases?daily=1" },
];

export default function GamesPage() {
  const navigate = useNavigate();
  const [online, setOnline] = useState(63);
  const [liveBets, setLiveBets] = useState([
    { col: "Plush Pepe", amount: 3.94, img: null },
    { col: "Heart", amount: 0.39, img: null },
    { col: "Star", amount: 10, img: null },
    { col: "Rose", amount: 0.19, img: null },
    { col: "Bitcoin", amount: 2.5, img: null },
  ]);

  useEffect(() => {
    const WS_URL = (window.location.protocol === "https:" ? "wss:" : "ws:") + "//" + window.location.host + "/api/crash/ws";
    const ws = new WebSocket(WS_URL);
    ws.onmessage = (e) => {
      const d = JSON.parse(e.data);
      if (d.online) setOnline(d.online);
    };
    return () => ws.close();
  }, []);

  return (
    <div className="px-4 py-4 space-y-5">
      {/* Online + live ticker */}
      <div className="flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-green-main animate-pulse"/>
        <span className="text-white/50 text-sm font-medium">{online} Online</span>
      </div>

      {/* Live bets ticker */}
      <div className="flex gap-2 overflow-x-auto scrollbar-none pb-1">
        {liveBets.map((b, i) => (
          <div key={i} className="flex-shrink-0 bg-dark-3 rounded-2xl p-3 flex flex-col items-center gap-1.5 min-w-[72px] border border-white/5">
            <div className="w-10 h-10 rounded-xl bg-dark-4 flex items-center justify-center text-xl">🎁</div>
            <span className="text-xs font-bold text-white">{b.amount}</span>
            <div className="w-full h-0.5 bg-blue-main rounded-full"/>
          </div>
        ))}
      </div>

      {/* Games */}
      <div>
        <h2 className="text-white/60 text-xs font-bold uppercase tracking-widest mb-3 flex items-center gap-2">
          <span>🔥</span> Games
        </h2>
        <div className="grid grid-cols-2 gap-3">
          {GAMES.map((g, i) => (
            <motion.button key={g.id}
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
              onClick={() => navigate(g.path)}
              className={`relative overflow-hidden rounded-2xl bg-gradient-to-br ${g.from} ${g.to} aspect-[4/3] flex flex-col justify-end p-4 active:scale-95 transition-all`}>
              <div className="absolute inset-0 flex items-center justify-center opacity-15 text-9xl select-none">{g.emoji}</div>
              <div className="relative">
                <p className="font-black text-white text-xl tracking-wider font-display">{g.name}</p>
                <p className="text-white/60 text-xs mt-0.5">{g.desc}</p>
              </div>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Bonuses */}
      <div>
        <h2 className="text-white/60 text-xs font-bold uppercase tracking-widest mb-3 flex items-center gap-2">
          <span>✨</span> Bonuses
        </h2>
        <div className="grid grid-cols-2 gap-3">
          {BONUSES.map((b, i) => (
            <motion.button key={b.id}
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 + i * 0.08 }}
              onClick={() => navigate(b.path)}
              className="relative overflow-hidden rounded-2xl bg-dark-3 border border-white/8 aspect-[4/3] flex flex-col justify-end p-4 active:scale-95 transition-all">
              <div className="absolute inset-0 flex items-center justify-center opacity-10 text-9xl select-none">{b.emoji}</div>
              <p className="relative font-black text-white text-base tracking-wider font-display">{b.name}</p>
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}
