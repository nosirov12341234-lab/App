import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import api from "../utils/api";
import { useStore } from "../utils/store";
import TonIcon from "../components/ui/TonIcon";

function Timer({ target }) {
  const [left, setLeft] = useState("");
  useEffect(() => {
    const calc = () => {
      const d = new Date(target) - new Date();
      if (d <= 0) { setLeft(""); return; }
      const h = Math.floor(d/3600000), m = Math.floor((d%3600000)/60000), s = Math.floor((d%60000)/1000);
      setLeft(`${h}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`);
    };
    calc(); const t = setInterval(calc, 1000); return () => clearInterval(t);
  }, [target]);
  if (!left) return null;
  return <p className="text-gold-main text-xs mt-1">{left}</p>;
}

export default function InventoryPage() {
  const { inventory, fetchInventory } = useStore();
  const [sel, setSel] = useState(null);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState(null);

  useEffect(() => { fetchInventory(); }, []);

  const showToast = (msg, type="success") => { setToast({msg,type}); setTimeout(()=>setToast(null),3000); };

  const sell = async (item) => {
    setLoading(true);
    try { const r = await api.post(`/inventory/${item.id}/sell`); showToast(`✅ Sold: +${r.data.amount.toFixed(3)} TON`); setSel(null); await fetchInventory(); }
    catch (e) { showToast(e.response?.data?.detail||"Error","error"); }
    setLoading(false);
  };

  const withdraw = async (item) => {
    setLoading(true);
    try { await api.post(`/inventory/${item.id}/withdraw`); showToast("⏳ Gift is being sent..."); setSel(null); await fetchInventory(); }
    catch (e) { showToast(e.response?.data?.detail||"Error","error"); }
    setLoading(false);
  };

  const sourceColor = (s) => ({ case:"bg-blue-main/20 text-blue-light", deposit:"bg-green-main/20 text-green-main", daily_case:"bg-gold-main/20 text-gold-main", promocode:"bg-purple-main/20 text-purple-main", upgrade:"bg-cyan-400/20 text-cyan-400" }[s]||"bg-white/10 text-white/40");

  return (
    <div className="px-4 py-4">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-black font-display">🎒 INVENTORY</h1>
        <span className="text-white/30 text-sm">{inventory.length} items</span>
      </div>

      {inventory.length===0
        ? <div className="text-center py-20"><p className="text-5xl mb-4">📭</p><p className="text-white/30">Inventory is empty</p><p className="text-white/20 text-sm mt-1">Open cases or deposit gifts</p></div>
        : <div className="grid grid-cols-3 gap-3">
            {inventory.map((item,i)=>(
              <motion.button key={item.id} initial={{opacity:0,scale:0.8}} animate={{opacity:1,scale:1}} transition={{delay:i*0.04}}
                onClick={()=>setSel(item)}
                className="relative bg-dark-3 rounded-2xl p-3 text-center border border-white/5 active:scale-95 transition-all">
                {item.is_locked&&<div className="absolute top-2 left-2 w-5 h-5 bg-gold-main rounded-full flex items-center justify-center text-xs">🔒</div>}
                <div className="w-16 h-16 mx-auto rounded-xl overflow-hidden mb-2 bg-dark-4 border border-white/5">
                  {item.collection_image?<img src={item.collection_image} className="w-full h-full object-cover"/>:<div className="w-full h-full flex items-center justify-center text-3xl">🎁</div>}
                </div>
                <p className="text-white text-xs font-semibold truncate">{item.collection_name}</p>
                <p className="text-white/40 text-xs">{item.floor_price} TON</p>
                {item.withdraw_available_at&&!item.can_withdraw&&<Timer target={item.withdraw_available_at}/>}
              </motion.button>
            ))}
          </div>
      }

      <AnimatePresence>
        {sel&&(
          <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 z-50 bg-black/70 backdrop-blur flex items-end justify-center" onClick={()=>setSel(null)}>
            <motion.div initial={{y:"100%"}} animate={{y:0}} exit={{y:"100%"}} transition={{type:"spring",damping:28}} className="w-full bg-dark-2 rounded-t-3xl p-6 pb-10 border-t border-white/10" onClick={e=>e.stopPropagation()}>
              <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-5"/>
              <div className="flex items-center gap-4 mb-5">
                <div className="w-20 h-20 rounded-2xl overflow-hidden bg-dark-4 border border-white/8 flex-shrink-0">
                  {sel.collection_image?<img src={sel.collection_image} className="w-full h-full object-cover"/>:<div className="w-full h-full flex items-center justify-center text-4xl">🎁</div>}
                </div>
                <div>
                  <h3 className="text-white font-bold text-xl">{sel.collection_name}</h3>
                  <p className="text-white/40">{sel.floor_price} TON</p>
                  <span className={`text-xs px-2 py-0.5 rounded-lg mt-1 inline-block font-medium ${sourceColor(sel.source)}`}>{sel.source}</span>
                  {sel.is_locked&&<p className="text-gold-main text-xs mt-1">🔒 Sell only</p>}
                </div>
              </div>
              <div className="space-y-2">
                <button onClick={()=>sell(sel)} disabled={loading} className="w-full py-4 rounded-2xl bg-blue-main text-white font-bold active:scale-95 glow-blue disabled:opacity-50">
                  💰 Sell ({(sel.floor_price*0.85).toFixed(3)} TON)
                  <span className="text-white/50 text-xs ml-2">-15% fee</span>
                </button>
                {!sel.is_locked&&sel.can_withdraw&&(
                  <button onClick={()=>withdraw(sel)} disabled={loading} className="w-full py-4 rounded-2xl bg-dark-3 border border-white/10 text-white font-bold active:scale-95 disabled:opacity-50">
                    📤 Withdraw to Telegram
                  </button>
                )}
                {!sel.is_locked&&!sel.can_withdraw&&(
                  <div className="w-full py-4 rounded-2xl bg-dark-3 border border-white/10 text-white/30 text-center text-sm">
                    ⏳ Withdraw available after timer
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {toast&&(
          <motion.div initial={{opacity:0,y:50}} animate={{opacity:1,y:0}} exit={{opacity:0,y:50}} className={`fixed bottom-24 left-4 right-4 z-50 py-3 px-4 rounded-2xl text-center font-semibold ${toast.type==="error"?"bg-red-main/90":"bg-green-main/90"} text-white`}>
            {toast.msg}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
