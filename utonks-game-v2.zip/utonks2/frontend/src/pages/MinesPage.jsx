// MinesPage
import { useState } from "react";
import { motion } from "framer-motion";
import api from "../utils/api";
import { useStore } from "../utils/store";
import TonIcon from "../components/ui/TonIcon";

export function MinesPage() {
  const { fetchUser } = useStore();
  const [cells, setCells] = useState(Array(25).fill(null));
  const [revealed, setRevealed] = useState(Array(25).fill(false));
  const [active, setActive] = useState(false);
  const [over, setOver] = useState(false);
  const [won, setWon] = useState(false);
  const [betAmt, setBetAmt] = useState("0.1");
  const [mines, setMines] = useState(3);
  const [multi, setMulti] = useState(1.0);
  const [gid, setGid] = useState(null);

  const start = async () => {
    try {
      const r = await api.post(`/mines/start?amount=${betAmt}&mines=${mines}`);
      setGid(r.data.game_id); setActive(true); setOver(false); setWon(false);
      setCells(Array(25).fill(null)); setRevealed(Array(25).fill(false)); setMulti(1.0);
      await fetchUser();
    } catch (e) { window.Telegram?.WebApp?.showAlert(e.response?.data?.detail||"Error"); }
  };

  const reveal = async (idx) => {
    if (!active||revealed[idx]||over) return;
    try {
      const r = await api.post(`/mines/reveal?game_id=${gid}&cell=${idx}`);
      const nr=[...revealed]; nr[idx]=true; setRevealed(nr);
      const nc=[...cells];
      if (r.data.is_mine) {
        nc[idx]="mine"; r.data.all_mines?.forEach(m=>{nc[m]="mine";}); setCells(nc);
        setOver(true); setActive(false); setWon(false);
      } else { nc[idx]="gem"; setCells(nc); setMulti(r.data.multiplier); }
    } catch {}
  };

  const cashout = async () => {
    try {
      await api.post(`/mines/cashout?game_id=${gid}`);
      setActive(false); setWon(true); setOver(true); await fetchUser();
    } catch {}
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-black font-display">💣 MINES</h1>
        {active && <div className="bg-green-main/20 border border-green-main/30 rounded-xl px-3 py-1"><span className="text-green-main font-bold">{multi.toFixed(2)}x</span></div>}
      </div>

      {over && (
        <div className={`rounded-2xl p-4 text-center border ${won?"bg-green-main/10 border-green-main/30":"bg-red-main/10 border-red-main/30"}`}>
          <p className="font-bold text-lg">{won?"🎉 You won!":"💥 Boom! You lost!"}</p>
          {won && <p className="text-sm text-white/50">{(parseFloat(betAmt)*multi).toFixed(3)} TON</p>}
        </div>
      )}

      {/* Grid */}
      <div className="grid grid-cols-5 gap-2">
        {Array(25).fill(null).map((_,i)=>{
          const r=revealed[i]; const t=cells[i];
          return (
            <motion.button key={i} whileTap={{scale:0.85}} onClick={()=>reveal(i)}
              className={`aspect-square rounded-xl flex items-center justify-center text-xl border transition-all ${!r?"bg-dark-3 border-white/8 active:bg-dark-4":t==="gem"?"bg-blue-main/20 border-blue-main/50":t==="mine"?"bg-red-main/20 border-red-main/50":"bg-dark-3 border-white/5"}`}>
              {r&&t==="gem"&&"💎"} {r&&t==="mine"&&"💣"}
              {!r&&over&&cells[i]==="mine"&&"💣"}
            </motion.button>
          );
        })}
      </div>

      <div className="bg-dark-3 rounded-2xl p-4 border border-white/5 space-y-3">
        {!active && (
          <>
            <div className="flex items-center gap-2 bg-dark-4 rounded-xl px-3 py-2.5 border border-white/8">
              <TonIcon size={16}/><input type="number" value={betAmt} onChange={e=>setBetAmt(e.target.value)} className="flex-1 bg-transparent text-white outline-none text-sm" min="0.01"/>
            </div>
            <div>
              <div className="flex justify-between text-xs text-white/40 mb-2"><span>Mines: {mines}</span><span>Risk: {mines>10?"High":mines>5?"Medium":"Low"}</span></div>
              <input type="range" min="1" max="20" value={mines} onChange={e=>setMines(parseInt(e.target.value))} className="w-full accent-blue-main"/>
            </div>
            <button onClick={start} className="w-full py-4 rounded-xl bg-blue-main text-white font-bold active:scale-95 glow-blue">Start Game</button>
          </>
        )}
        {active&&!over && <button onClick={cashout} className="w-full py-4 rounded-xl bg-green-main text-black font-bold active:scale-95 animate-pulse glow-green">Cash Out {(parseFloat(betAmt)*multi).toFixed(3)} TON</button>}
        {over && <button onClick={()=>{setOver(false);setActive(false);}} className="w-full py-4 rounded-xl bg-blue-main text-white font-bold active:scale-95">Play Again</button>}
      </div>
    </div>
  );
}
