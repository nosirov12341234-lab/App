import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import api from "../utils/api";
import { useStore } from "../utils/store";
import TonIcon from "../components/ui/TonIcon";

export default function UpgradePage() {
  const { inventory, fetchUser, fetchInventory } = useStore();
  const [selected, setSelected] = useState([]);
  const [extraTon, setExtraTon] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const total = selected.reduce((s,i)=>s+i.floor_price,0) + parseFloat(extraTon||0);

  const toggle = (item) => {
    if (item.is_locked) return;
    const exists = selected.find(i=>i.id===item.id);
    setSelected(exists ? selected.filter(i=>i.id!==item.id) : [...selected,item]);
  };

  const upgrade = async () => {
    if (total<0.1) return;
    setLoading(true); setResult(null);
    try {
      const r = await api.post("/upgrade/start", {inventory_ids:selected.map(i=>i.id), extra_ton:parseFloat(extraTon||0)});
      await new Promise(res=>setTimeout(res,2000));
      setResult(r.data); setSelected([]); setExtraTon("");
      await fetchUser(); await fetchInventory();
    } catch (e) { window.Telegram?.WebApp?.showAlert(e.response?.data?.detail||"Error"); }
    setLoading(false);
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <h1 className="text-2xl font-black font-display">⬆️ UPGRADE</h1>
      <p className="text-white/40 text-sm">Combine gifts + TON → get a new gift closest to total value</p>

      <div className="bg-dark-3 rounded-2xl p-4 border border-white/5 space-y-4">
        <p className="text-white/50 text-sm font-medium">Selected gifts:</p>
        {selected.length===0
          ? <p className="text-white/20 text-sm text-center py-3">Select gifts below</p>
          : <div className="flex flex-wrap gap-2">
              {selected.map(item=>(
                <motion.div key={item.id} initial={{scale:0}} animate={{scale:1}} className="relative">
                  <div className="w-16 h-16 rounded-xl overflow-hidden bg-dark-4 border border-blue-main/50">
                    {item.collection_image?<img src={item.collection_image} className="w-full h-full object-cover"/>:<div className="w-full h-full flex items-center justify-center text-2xl">🎁</div>}
                  </div>
                  <button onClick={()=>toggle(item)} className="absolute -top-1 -right-1 w-5 h-5 bg-red-main rounded-full text-xs flex items-center justify-center">✕</button>
                  <p className="text-xs text-white/40 text-center mt-1">{item.floor_price}T</p>
                </motion.div>
              ))}
            </div>
        }

        <div className="flex items-center gap-2 bg-dark-4 rounded-xl px-3 py-2.5 border border-white/8">
          <TonIcon size={16}/>
          <input type="number" value={extraTon} onChange={e=>setExtraTon(e.target.value)} placeholder="Extra TON (optional)" className="flex-1 bg-transparent text-white outline-none text-sm" min="0"/>
        </div>

        {total>0&&(
          <div className="flex items-center justify-between py-2 border-t border-white/8">
            <span className="text-white/40 text-sm">Total value:</span>
            <span className="text-white font-bold">{total.toFixed(3)} TON</span>
          </div>
        )}

        <button onClick={upgrade} disabled={total<0.1||loading} className="w-full py-4 rounded-xl bg-gradient-to-r from-purple-main to-blue-main text-white font-bold disabled:opacity-30 active:scale-95">
          {loading?"⏳ Upgrading...":total>0?`⬆️ Upgrade (${total.toFixed(2)} TON)`:"⬆️ Upgrade"}
        </button>
      </div>

      <div>
        <p className="text-white/40 text-xs uppercase tracking-widest mb-3">Your inventory</p>
        {inventory.filter(i=>!i.is_locked).length===0
          ? <p className="text-white/20 text-sm text-center py-6">No available gifts</p>
          : <div className="grid grid-cols-3 gap-3">
              {inventory.filter(i=>!i.is_locked).map(item=>{
                const sel=selected.find(i=>i.id===item.id);
                return (
                  <button key={item.id} onClick={()=>toggle(item)}
                    className={`rounded-2xl p-3 text-center border-2 transition-all active:scale-95 ${sel?"border-blue-main bg-blue-main/15":"border-transparent bg-dark-3"}`}>
                    <div className="w-12 h-12 mx-auto rounded-xl overflow-hidden mb-2 bg-dark-4">
                      {item.collection_image?<img src={item.collection_image} className="w-full h-full object-cover"/>:<div className="w-full h-full flex items-center justify-center text-2xl">🎁</div>}
                    </div>
                    <p className="text-white text-xs font-medium truncate">{item.collection_name}</p>
                    <p className="text-white/40 text-xs">{item.floor_price} TON</p>
                  </button>
                );
              })}
            </div>
        }
      </div>

      <AnimatePresence>
        {result&&(
          <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 z-50 bg-black/80 backdrop-blur flex items-center justify-center px-6">
            <motion.div initial={{scale:0.5}} animate={{scale:1}} exit={{scale:0.5}} className="w-full max-w-sm bg-dark-3 rounded-3xl p-8 text-center border border-white/10 space-y-4">
              <div className="w-32 h-32 mx-auto rounded-2xl overflow-hidden border-2 border-purple-main/50">
                {result.gift?.collection_image?<img src={result.gift.collection_image} className="w-full h-full object-cover"/>:<div className="w-full h-full bg-dark-4 flex items-center justify-center text-5xl">🎁</div>}
              </div>
              <div>
                <p className="text-gradient-gold font-black text-2xl font-display">UPGRADED!</p>
                <p className="text-white font-bold text-xl">{result.gift?.collection_name}</p>
                <p className="text-white/40 text-sm">{result.gift?.floor_price} TON</p>
                {result.change>0&&<p className="text-green-main text-sm mt-1">+{result.change.toFixed(3)} TON returned</p>}
              </div>
              <button onClick={()=>setResult(null)} className="w-full py-4 rounded-2xl bg-blue-main text-white font-bold active:scale-95">Nice! 🚀</button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
