export default function TonIcon({ size = 18, className = "" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 56 56" fill="none" className={className}>
      <circle cx="28" cy="28" r="28" fill="#0098EA"/>
      <path d="M18.1 15.2h19.8c1.4 0 2.2 1.6 1.4 2.8L28 40.8 16.7 18c-.8-1.2 0-2.8 1.4-2.8z" fill="white"/>
    </svg>
  );
}
