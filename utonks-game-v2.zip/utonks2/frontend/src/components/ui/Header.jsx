import { useState } from "react";
import { useStore } from "../../utils/store";
import TonIcon from "./TonIcon";
import DepositModal from "./DepositModal";

export default function Header() {
  const { user } = useStore();
  const [showDeposit, setShowDeposit] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-40 px-4 py-3 flex items-center justify-between glass-dark border-b border-white/5">
        <div className="flex items-center gap-3 bg-dark-3 rounded-2xl px-3 py-2 border border-white/5">
          {user?.photo_url
            ? <img src={user.photo_url} className="w-8 h-8 rounded-full object-cover ring-2 ring-blue-main/30"/>
            : <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-main to-purple-main flex items-center justify-center text-sm font-bold">{user?.first_name?.[0] || "U"}</div>
          }
          <div>
            <p className="text-sm font-semibold leading-none text-white">{user?.first_name || "Loading..."}</p>
            <p className="text-xs text-white/40 mt-0.5">Level {user?.level || 1}</p>
          </div>
        </div>

        <button onClick={() => setShowDeposit(true)}
          className="flex items-center gap-2 bg-dark-3 rounded-2xl px-3 py-2 border border-white/5 active:scale-95 transition-transform">
          <TonIcon size={18}/>
          <span className="text-sm font-bold text-white">{(user?.balance || 0).toFixed(2)}</span>
          <div className="w-6 h-6 rounded-full bg-blue-main flex items-center justify-center glow-blue">
            <span className="text-xs font-bold">+</span>
          </div>
        </button>
      </header>
      {showDeposit && <DepositModal onClose={() => setShowDeposit(false)}/>}
    </>
  );
}
