import { useLocation, useNavigate } from "react-router-dom";
import { useStore } from "../../utils/store";

const NAV = [
  { path: "/inventory", label: "Inventory", icon: "🎒" },
  { path: "/games", label: "Games", icon: "🎮" },
  { path: "/profile", label: "Profile", icon: "👤" },
];

export default function BottomNav() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { user } = useStore();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 glass-dark border-t border-white/5 pb-safe">
      <div className="flex items-center justify-around px-2 pt-2 pb-1">
        {NAV.map((item) => {
          const active = pathname.startsWith(item.path);
          return (
            <button key={item.path} onClick={() => navigate(item.path)}
              className={`flex flex-col items-center gap-1 py-2 px-6 rounded-2xl transition-all active:scale-90 ${active ? "bg-blue-main/15" : ""}`}>
              <span className="text-2xl">{item.icon}</span>
              <span className={`text-xs font-medium ${active ? "text-blue-main" : "text-white/40"}`}>{item.label}</span>
              {active && <div className="w-1 h-1 rounded-full bg-blue-main"/>}
            </button>
          );
        })}
        {user?.is_admin && (
          <button onClick={() => navigate("/admin")}
            className={`flex flex-col items-center gap-1 py-2 px-4 rounded-2xl transition-all active:scale-90 ${pathname.startsWith("/admin") ? "bg-gold-main/15" : ""}`}>
            <span className="text-2xl">⚙️</span>
            <span className={`text-xs font-medium ${pathname.startsWith("/admin") ? "text-gold-main" : "text-white/40"}`}>Admin</span>
          </button>
        )}
      </div>
    </nav>
  );
}
