import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useTonConnectUI } from "@tonconnect/ui-react";
import api from "../../utils/api";
import { useStore } from "../../utils/store";
import TonIcon from "./TonIcon";

const TABS = [
  { id: "stars", label: "Stars", icon: "⭐", badge: null },
  { id: "ton", label: "TON", icon: null, badge: "+10%" },
  { id: "gifts", label: "Gifts", icon: "🎁", badge: null },
];

export default function DepositModal({ onClose }) {
  const [tab, setTab] = useState("ton");
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const { fetchUser } = useStore();
  const [tonUI] = useTonConnectUI();

  const handleTON = async () => {
    if (!amount || parseFloat(amount) < 0.1) return;
    setLoading(true);
    try {
      const r = await api.post(`/user/deposit/ton?amount=${amount}`);
      const { wallet, amount: amt, memo } = r.data;
      await tonUI.sendTransaction({
        validUntil: Math.floor(Date.now() / 1000) + 600,
        messages: [{ address: wallet, amount: String(Math.floor(amt * 1e9)) }],
      });
      setSuccess(true);
      setTimeout(() => { fetchUser(); onClose(); }, 2000);
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  const handleStars = async () => {
    if (!amount || parseInt(amount) < 50) return;
    setLoading(true);
    try {
      const r = await api.post(`/user/deposit/stars?stars=${amount}`);
      window.Telegram?.WebApp?.openInvoice?.(r.data.invoice_url, (status) => {
        if (status === "paid") { fetchUser(); onClose(); }
      });
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  const quickAmounts = tab === "ton" ? ["0.5", "1", "2", "5", "10"] : ["50", "100", "200", "500"];

  return (
    <AnimatePresence>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm"
        onClick={onClose}>
        <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
          transition={{ type: "spring", damping: 28, stiffness: 300 }}
          className="w-full bg-dark-2 rounded-t-3xl p-6 pb-10 border-t border-white/10"
          onClick={e => e.stopPropagation()}>

          <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-6"/>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-black font-display tracking-wider">DEPOSIT</h2>
            <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/60 active:scale-90">✕</button>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 mb-6">
            {TABS.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`flex-1 relative flex flex-col items-center gap-1.5 py-3 rounded-2xl border transition-all active:scale-95 ${tab === t.id ? "bg-blue-main border-blue-main" : "bg-dark-3 border-white/10"}`}>
                {t.badge && <span className="absolute -top-2 left-1/2 -translate-x-1/2 bg-green-main text-black text-xs font-bold px-2 py-0.5 rounded-full">{t.badge}</span>}
                {t.icon ? <span className="text-xl">{t.icon}</span> : <TonIcon size={20}/>}
                <span className="text-xs font-semibold">{t.label}</span>
              </button>
            ))}
          </div>

          {success ? (
            <div className="text-center py-8">
              <div className="text-5xl mb-3">✅</div>
              <p className="text-green-main font-bold text-xl">Payment sent!</p>
              <p className="text-white/40 text-sm mt-1">Balance will update shortly</p>
            </div>
          ) : (
            <div className="space-y-4">
              {tab !== "gifts" && (
                <>
                  <div className="flex items-center gap-3 bg-dark-3 rounded-2xl px-4 py-3 border border-white/10">
                    {tab === "ton" ? <TonIcon size={22}/> : <span className="text-2xl">⭐</span>}
                    <input type="number" value={amount} onChange={e => setAmount(e.target.value)}
                      placeholder={tab === "ton" ? "0.1 TON min" : "50 Stars min"}
                      className="flex-1 bg-transparent text-white text-lg outline-none font-display"/>
                  </div>

                  <div className="flex gap-2 flex-wrap">
                    {quickAmounts.map(q => (
                      <button key={q} onClick={() => setAmount(q)}
                        className={`px-3 py-1.5 rounded-xl text-sm font-semibold border transition-all active:scale-95 ${amount === q ? "bg-blue-main border-blue-main" : "bg-dark-3 border-white/10 text-white/60"}`}>
                        {q} {tab === "ton" ? "TON" : "⭐"}
                      </button>
                    ))}
                  </div>

                  {amount && tab === "ton" && (
                    <div className="bg-green-main/10 border border-green-main/30 rounded-xl px-4 py-2.5 flex justify-between">
                      <span className="text-green-main text-sm">Bonus +10%</span>
                      <span className="text-green-main font-bold text-sm">+{(parseFloat(amount||0)*0.1).toFixed(3)} TON</span>
                    </div>
                  )}

                  <div className="flex gap-3 pt-2">
                    <button onClick={onClose} className="flex-1 py-4 rounded-2xl bg-dark-3 border border-white/10 text-white font-bold active:scale-95">Cancel</button>
                    <button onClick={tab === "ton" ? handleTON : handleStars} disabled={loading || !amount}
                      className="flex-1 py-4 rounded-2xl bg-blue-main text-white font-bold disabled:opacity-40 active:scale-95 glow-blue">
                      {loading ? "..." : "Deposit"}
                    </button>
                  </div>
                </>
              )}

              {tab === "gifts" && (
                <div className="space-y-4">
                  <div className="bg-dark-3 rounded-2xl p-5 border border-white/10 text-center">
                    <span className="text-4xl">🎁</span>
                    <p className="text-white font-semibold mt-3">Send gift to bot</p>
                    <p className="text-white/40 text-sm mt-1">TON credited at Fragment floor price</p>
                    <p className="text-blue-light text-sm font-mono mt-3">@{window.BOT_USERNAME || "utonks_bot"}</p>
                  </div>
                  <div className="bg-blue-main/10 border border-blue-main/30 rounded-xl px-4 py-3">
                    <p className="text-blue-light text-sm">💡 Gift will be auto-detected and credited to your balance</p>
                  </div>
                </div>
              )}
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
