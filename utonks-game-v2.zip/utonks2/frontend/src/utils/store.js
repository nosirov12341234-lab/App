import { create } from "zustand";
import api from "./api";

export const useStore = create((set, get) => ({
  user: null,
  inventory: [],
  loading: true,
  adminVerified: false,

  fetchUser: async () => {
    try {
      const r = await api.get("/user/me");
      set({ user: r.data });
    } catch {}
  },

  fetchInventory: async () => {
    try {
      const r = await api.get("/inventory/");
      set({ inventory: r.data });
    } catch {}
  },

  setAdminVerified: (v) => set({ adminVerified: v }),
  setLoading: (v) => set({ loading: v }),
}));
