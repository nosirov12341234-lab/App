import { useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { TonConnectUIProvider } from "@tonconnect/ui-react";
import { useStore } from "./utils/store";
import Header from "./components/ui/Header";
import BottomNav from "./components/ui/BottomNav";
import GamesPage from "./pages/GamesPage";
import CrashPage from "./pages/CrashPage";
import { MinesPage } from "./pages/MinesPage";
import CasesPage from "./pages/CasesPage";
import UpgradePage from "./pages/UpgradePage";
import InventoryPage from "./pages/InventoryPage";
import ProfilePage from "./pages/ProfilePage";
import AdminPage from "./pages/AdminPage";

const MANIFEST = "https://raw.githubusercontent.com/nosirov12341234-lab/App/main/tonconnect-manifest.json";

export default function App() {
  const { fetchUser, fetchInventory, setLoading } = useStore();

  useEffect(() => {
    const tg = window.Telegram?.WebApp;
    tg?.ready(); tg?.expand();
    tg?.setHeaderColor("#0A0912");
    tg?.setBackgroundColor("#0A0912");
    const init = async () => {
      await fetchUser();
      await fetchInventory();
      setLoading(false);
    };
    init();
  }, []);

  return (
    <TonConnectUIProvider manifestUrl={MANIFEST}>
      <BrowserRouter>
        <div className="flex flex-col min-h-screen bg-dark-1 text-white">
          <Header />
          <main className="flex-1 pb-24 overflow-y-auto">
            <Routes>
              <Route path="/" element={<Navigate to="/games" replace />} />
              <Route path="/games" element={<GamesPage />} />
              <Route path="/games/crash" element={<CrashPage />} />
              <Route path="/games/mines" element={<MinesPage />} />
              <Route path="/games/cases" element={<CasesPage />} />
              <Route path="/games/upgrade" element={<UpgradePage />} />
              <Route path="/inventory" element={<InventoryPage />} />
              <Route path="/profile" element={<ProfilePage />} />
              <Route path="/admin/*" element={<AdminPage />} />
            </Routes>
          </main>
          <BottomNav />
        </div>
      </BrowserRouter>
    </TonConnectUIProvider>
  );
}
