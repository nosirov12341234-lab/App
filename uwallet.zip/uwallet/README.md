# UWallet — Telegram Mini App

Custody-based crypto platform (TON ekotizimi) — Binance/OKX uslubida lekin Telegram ichida.

---

## Arxitektura

```
uwallet/
├── frontend/          # React + Tailwind + TonConnect (Telegram Mini App)
├── backend/           # Python FastAPI (REST API)
├── bot/               # Python aiogram 3 (Admin bot)
└── docs/              # API docs, flow diagrammalar
```

---

## Stack

| Layer | Tech |
|-------|------|
| Frontend | React 18, Vite, Tailwind CSS, TonConnect UI |
| Backend | Python 3.11, FastAPI, SQLAlchemy 2, Alembic |
| Database | PostgreSQL 15 |
| Cache/Queue | Redis |
| Blockchain | TON SDK (pytonlib), TONAPI |
| Bot | aiogram 3 |
| Deploy | Docker Compose, Nginx |

---

## Modullar

### 1. Auth
- Telegram WebApp `initData` orqali avtorizatsiya
- JWT token (access + refresh)
- Har bir foydalanuvchiga unique `uwallet_<telegram_id>` ID

### 2. Wallet (Custody)
- Har bir foydalanuvchiga platformada ichki balans
- Tokenlar: USDT, TON, USDC (default) + admin qo'shgan tokenlar
- **Deposit:** TonConnect orqali wallet ulash → platformaning master walletiga yuborish → balans +
- **Withdraw:** Token tanlash → miqdor → so'rov → admin tasdiqlaydi (UZS uchun) yoki avtomatik (kripto)
- **Ichki Transfer:** `uwallet_ID` orqali, tekin, poolda qoladi

### 3. P2P Market
- E'lon berish: token + miqdor + UZS narx + to'lov usuli
- Fast Sell: tezkor sotish (eng yaxshi narxga)
- Admin P2P komissiyasi (foizda)
- E'lonlar: ochiq, yopilgan, mening e'lonlarim

### 4. Kiritish/Chiqarish komissiyalari
- Admin panel orqali har token uchun:
  - Tarmoq komissiyasi (tashqi)
  - Platforma komissiyasi (foiz yoki flat)
- UZS chiqarish → manual (admin)

### 5. Tasks & Referral
- Kanal obuna task: bot kanalda adminligini tekshiradi
- Link task: tekshirisiz (bajargan deb qabul, keyingi safar "tasdiqlandi")
- Admin belgilaydi: token turi, miqdor, referral summa
- Referral: `uwallet_<id>` referral link

### 6. DApps
- Kategoriyalar (Admin qo'shadi)
- DApp kartochkalar (nom, icon, URL, kategoriya)
- TonKeeper-style grid

### 7. Admin Panel (Bot + Web)
- Komissiyalar sozlash
- Token qo'shish/o'chirish
- P2P komissiya belgilash
- UZS chiqarish tasdiqlash
- Task yaratish (kanal/link)
- Referral summa sozlash
- Log kanal (barcha amallar yoziladi)
- DApp + kategoriya qo'shish

---

## DB Jadvallar (asosiy)

```
users                 - foydalanuvchilar
balances              - har user har token balansi
tokens                - platform tokenlari (USDT, TON, ...)
transactions          - barcha kirim/chiqim tarixi
transfers             - ichki transferlar
p2p_orders            - P2P e'lonlar
p2p_trades            - P2P savdolar
tasks                 - tasklar
task_completions      - bajargan foydalanuvchilar
referrals             - referral munosabatlar
dapps                 - dapplar
dapp_categories       - kategoriyalar
admin_settings        - komissiyalar, sozlamalar
withdraw_requests     - chiqarish so'rovlari
deposit_requests      - kiritish so'rovlari
```

---

## Asosiy Flowlar

### Deposit Flow
```
User → Connect Wallet (TonConnect)
     → Token tanlaydi
     → Miqdor kiritadi
     → TonConnect orqali platformaning master walletiga yuboradi
     → Backend TONAPI orqali txni kuzatadi
     → Tasdiqlangach balans +
     → Log kanalga yoziladi
```

### UZS Withdraw Flow
```
User → "Chiqarish" → UZS tanlaydi
     → Miqdor + karta raqami kiritadi
     → So'rov adminga ketadi
     → Admin tasdiqlaydi → manual o'tkazadi
     → Status yangilanadi
     → Log kanalga yoziladi
```

### P2P Flow
```
Sotuvchi → E'lon qo'yadi (token + miqdor + UZS narx)
         → Token balansdan vaqtincha ushlanadi (freeze)
Xaridor  → Fast buy yoki e'londan tanlaydi
         → To'lov qiladi (bank transfer)
         → "To'ladim" bosadi
Sotuvchi → Tasdiqlaydi
         → Token xaridorga o'tadi
         → Komissiya adminga
```

### Ichki Transfer Flow
```
User → "Yuborish" → uwallet_ID kiritadi
     → Telegram profil (nick + ism) ko'rinadi
     → Miqdor + token tanlaydi
     → Tasdiqlaydi → tekin, real vaqtda
```

---

## Frontend Sahifalar

```
/ (Home)         - Balanslar (USDT, TON, USDC asosiy), qisqa amallar
/wallet          - To'liq token ro'yxati + tarixi
/deposit         - Token tanlash + TonConnect
/withdraw        - Token tanlash + forma
/transfer        - uwallet_ID qidirish + yuborish
/p2p             - E'lonlar ro'yxati + filter
/p2p/create      - E'lon yaratish
/tasks           - Tasklar ro'yxati
/dapps           - DApp katalog
/history         - Barcha tranzaksiyalar
/profile         - Profil + referral
/admin           - Admin panel (faqat admin uchun)
```

---

## Dizayn Konsepti

- **Dark theme** (TonKeeper-ga o'xshash lekin o'z branding)
- **Asosiy rang:** #0A0E1A (background), #1A2035 (card)
- **Accent:** #3B82F6 (blue) — UZS/fiat uchun, #00C896 (green) — kripto uchun
- **Font:** Inter
- **Bottom navigation:** 5 tab (Home, P2P, DApps, Tasks, Profile)

---

## Deployment

```yaml
# docker-compose.yml
services:
  frontend   # React build → Nginx
  backend    # FastAPI → uvicorn
  bot        # aiogram
  postgres   # PostgreSQL
  redis      # Redis
  nginx      # Reverse proxy + SSL
```
