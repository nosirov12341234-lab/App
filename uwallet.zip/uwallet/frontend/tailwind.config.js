/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        bg: {
          primary: "#0A0E1A",
          card: "#111827",
          elevated: "#1A2035",
        },
        accent: {
          blue: "#3B82F6",
          green: "#00C896",
          red: "#EF4444",
          yellow: "#F59E0B",
        },
        text: {
          primary: "#F9FAFB",
          secondary: "#9CA3AF",
          muted: "#4B5563",
        },
        border: "#1F2937",
      },
      fontFamily: {
        sans: ["Inter", "sans-serif"],
      },
    },
  },
  plugins: [],
};
