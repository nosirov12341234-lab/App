import { create } from "zustand";
import api from "../utils/api";

export const useAuthStore = create((set) => ({
  user: JSON.parse(localStorage.getItem("uwallet_user") || "null"),
  token: localStorage.getItem("token"),
  isAuthenticated: !!localStorage.getItem("token"),

  login: async () => {
    const tg = window.Telegram?.WebApp;
    if (!tg?.initData) return;
    try {
      const res = await api.post("/auth/login", null, {
        params: { init_data: tg.initData },
      });
      const { access_token, user } = res.data;
      localStorage.setItem("token", access_token);
      localStorage.setItem("uwallet_user", JSON.stringify(user));
      set({ token: access_token, user, isAuthenticated: true });
    } catch (e) {
      console.error("Login failed", e);
    }
  },

  logout: () => {
    localStorage.removeItem("token");
    localStorage.removeItem("uwallet_user");
    set({ user: null, token: null, isAuthenticated: false });
  },
}));
