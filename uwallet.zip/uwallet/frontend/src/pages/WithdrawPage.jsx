export { WithdrawPage as default } from "./extra-pages";
