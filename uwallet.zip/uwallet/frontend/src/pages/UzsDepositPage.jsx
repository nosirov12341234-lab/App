import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import api from "../utils/api";

export default function UzsDepositPage() {
  const navigate = useNavigate();
  const [amount, setAmount] = useState("");
  const [step, setStep] = useState(1); // 1: summa, 2: kutish, 3: tasdiqlandi
  const [depositInfo, setDepositInfo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [timeLeft, setTimeLeft] = useState(0);
  const [copied, setCopied] = useState(false);
  const pollingRef = useRef(null);
  const timerRef = useRef(null);

  const startDeposit = async () => {
    if (!amount || parseFloat(amount) < 1000) {
      setError("Minimal summa 1 000 UZS");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const res = await api.post("/uzs-deposit/create", { amount_uzs: parseFloat(amount) });
      setDepositInfo(res.data);
      setTimeLeft(res.data.timeout_minutes * 60);
      setStep(2);
      startPolling(res.data.deposit_id);
    } catch (e) {
      setError(e.response?.data?.detail || "Xatolik yuz berdi");
    } finally {
      setLoading(false);
    }
  };

  const startPolling = (depositId) => {
    pollingRef.current = setInterval(async () => {
      try {
        const res = await api.get(`/uzs-deposit/status/${depositId}`);
        if (res.data.status === "confirmed") {
          clearInterval(pollingRef.current);
          clearInterval(timerRef.current);
          setStep(3);
        } else if (res.data.status === "expired") {
          clearInterval(pollingRef.current);
          clearInterval(timerRef.current);
          setError("Vaqt tugadi. Qaytadan urinib ko'ring.");
          setStep(1);
        }
      } catch {}
    }, 5000); // 5 soniyada bir tekshirish
  };

  useEffect(() => {
    if (step !== 2) return;
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          clearInterval(timerRef.current);
          clearInterval(pollingRef.current);
          setError("Vaqt tugadi. Qaytadan urinib ko'ring.");
          setStep(1);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => {
      clearInterval(timerRef.current);
      clearInterval(pollingRef.current);
    };
  }, [step]);

  const formatTime = (s) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

  const copyCard = () => {
    navigator.clipboard.writeText(depositInfo?.card_number || "");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (step === 3) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-6 text-center">
        <div className="w-20 h-20 rounded-full bg-accent-green/20 flex items-center justify-center text-4xl mb-5">✅</div>
        <h2 className="text-2xl font-bold mb-2">To'lov tasdiqlandi!</h2>
        <p className="text-text-secondary mb-2">
          <span className="text-accent-green font-bold text-xl">{parseFloat(amount).toLocaleString()} UZS</span>
        </p>
        <p className="text-text-muted text-sm mb-8">Hisobingizga qo'shildi</p>
        <button onClick={() => navigate("/")} className="w-full py-3 rounded-2xl bg-accent-blue text-white font-semibold">
          Bosh sahifaga
        </button>
      </div>
    );
  }

  return (
    <div className="pb-24 px-4 pt-6">
      <button onClick={() => { clearInterval(pollingRef.current); clearInterval(timerRef.current); navigate(-1); }}
        className="text-text-secondary mb-6 flex items-center gap-1">
        ← Orqaga
      </button>
      <h1 className="text-xl font-bold mb-2">UZS Kiritish</h1>
      <p className="text-text-muted text-sm mb-6">Humo/Uzcard orqali avtomatik to'ldirish</p>

      {step === 1 && (
        <div className="space-y-4">
          <div className="bg-bg-card rounded-2xl p-4">
            <label className="text-xs text-text-secondary mb-2 block">Summa (UZS)</label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                className="flex-1 bg-bg-elevated border border-border rounded-xl px-4 py-3 text-lg font-bold outline-none focus:border-accent-blue transition-colors"
                placeholder="100 000"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <span className="text-text-secondary font-semibold">UZS</span>
            </div>
            {/* Quick amounts */}
            <div className="flex gap-2 mt-3 flex-wrap">
              {[50000, 100000, 200000, 500000].map((v) => (
                <button key={v} onClick={() => setAmount(String(v))}
                  className="px-3 py-1.5 rounded-lg bg-bg-elevated text-xs text-text-secondary">
                  {(v / 1000).toFixed(0)}K
                </button>
              ))}
            </div>
          </div>

          <div className="bg-bg-elevated rounded-2xl p-4 space-y-2 text-sm">
            <div className="flex justify-between text-text-secondary">
              <span>Komissiya</span>
              <span className="text-accent-green">Bepul</span>
            </div>
            <div className="flex justify-between text-text-secondary">
              <span>Minimal summa</span>
              <span>1 000 UZS</span>
            </div>
            <div className="flex justify-between text-text-secondary">
              <span>Tasdiqlash vaqti</span>
              <span>Avtomatik</span>
            </div>
          </div>

          {error && <p className="text-accent-red text-sm text-center">{error}</p>}

          <button onClick={startDeposit} disabled={loading || !amount}
            className="w-full py-3 rounded-2xl bg-accent-green text-white font-bold text-base disabled:opacity-50">
            {loading ? "Yuklanmoqda..." : "Davom etish"}
          </button>
        </div>
      )}

      {step === 2 && depositInfo && (
        <div className="space-y-4">
          {/* Countdown */}
          <div className="bg-bg-card rounded-2xl p-4 text-center">
            <p className="text-text-secondary text-sm mb-1">Qolgan vaqt</p>
            <p className={`text-4xl font-bold tabular-nums ${timeLeft < 60 ? "text-accent-red" : "text-accent-blue"}`}>
              {formatTime(timeLeft)}
            </p>
          </div>

          {/* Instruction */}
          <div className="bg-bg-card rounded-2xl p-4 space-y-4">
            <div className="flex items-start gap-3">
              <span className="text-xl">1️⃣</span>
              <div>
                <p className="text-sm font-semibold">Quyidagi kartaga o'tkazing</p>
                <p className="text-text-muted text-xs mt-0.5">Aynan shu summani yuboring</p>
              </div>
            </div>

            {/* Card number */}
            <div className="bg-bg-elevated rounded-xl p-4">
              <p className="text-xs text-text-muted mb-1">Karta raqami</p>
              <div className="flex items-center justify-between gap-3">
                <p className="font-mono text-lg font-bold tracking-widest">
                  {depositInfo.card_number}
                </p>
                <button onClick={copyCard}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    copied ? "bg-accent-green/20 text-accent-green" : "bg-bg-card text-text-secondary"
                  }`}>
                  {copied ? "Nusxalandi!" : "Nusxalash"}
                </button>
              </div>
            </div>

            {/* Amount */}
            <div className="bg-bg-elevated rounded-xl p-4">
              <p className="text-xs text-text-muted mb-1">To'lov summasi</p>
              <p className="text-2xl font-bold text-accent-green">
                {parseFloat(depositInfo.amount_uzs).toLocaleString()} UZS
              </p>
            </div>

            <div className="flex items-start gap-3">
              <span className="text-xl">2️⃣</span>
              <p className="text-sm font-semibold">To'lov o'tkazilgach avtomatik tasdiqlanadi</p>
            </div>

            <div className="flex items-start gap-3">
              <span className="text-xl">⚠️</span>
              <p className="text-xs text-text-muted">
                Aynan {parseFloat(depositInfo.amount_uzs).toLocaleString()} UZS yuboring.
                Boshqa summa yuborsangiz tizim topa olmaydi.
              </p>
            </div>
          </div>

          {/* Polling indicator */}
          <div className="bg-accent-blue/10 rounded-2xl p-3 flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-accent-blue animate-pulse" />
            <p className="text-xs text-accent-blue">To'lov kutilmoqda... (5 soniyada tekshiriladi)</p>
          </div>
        </div>
      )}
    </div>
  );
}
