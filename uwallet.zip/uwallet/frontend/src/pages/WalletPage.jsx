export { WalletPage as default } from "./extra-pages";
