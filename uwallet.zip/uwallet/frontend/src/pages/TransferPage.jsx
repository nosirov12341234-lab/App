import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import api from "../utils/api";

export default function TransferPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1); // 1: recipient, 2: amount, 3: confirm
  const [uwalletId, setUwalletId] = useState("");
  const [recipient, setRecipient] = useState(null);
  const [tokens, setTokens] = useState([]);
  const [balances, setBalances] = useState([]);
  const [selectedToken, setSelectedToken] = useState(null);
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    api.get("/wallet/balances").then((r) => setBalances(r.data));
  }, []);

  const lookupUser = async () => {
    setError("");
    setLoading(true);
    try {
      const res = await api.get(`/transfers/lookup/${uwalletId}`);
      setRecipient(res.data);
      setStep(2);
    } catch {
      setError("Foydalanuvchi topilmadi");
    } finally {
      setLoading(false);
    }
  };

  const getAvailable = () => {
    if (!selectedToken) return 0;
    const bal = balances.find((b) => b.token.id === selectedToken.id);
    return bal ? parseFloat(bal.available) : 0;
  };

  const handleSend = async () => {
    setLoading(true);
    setError("");
    try {
      await api.post("/transfers/send", {
        to_uwallet_id: uwalletId,
        token_id: selectedToken.id,
        amount: parseFloat(amount),
        note,
      });
      setSuccess(true);
    } catch (e) {
      setError(e.response?.data?.detail || "Xatolik");
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4 text-center">
        <div className="w-16 h-16 rounded-full bg-accent-green/20 flex items-center justify-center text-3xl mb-4">✓</div>
        <h2 className="text-xl font-bold mb-2">O'tkazma muvaffaqiyatli!</h2>
        <p className="text-text-secondary mb-6">{amount} {selectedToken?.symbol} yuborildi</p>
        <button onClick={() => navigate("/")} className="btn-primary">Bosh sahifaga</button>
      </div>
    );
  }

  return (
    <div className="pb-24 px-4 pt-6">
      <button onClick={() => step > 1 ? setStep(s => s - 1) : navigate(-1)} className="text-text-secondary mb-6 flex items-center gap-1">
        ← Orqaga
      </button>
      <h1 className="text-xl font-bold mb-6">Yuborish</h1>

      {step === 1 && (
        <div className="space-y-4">
          <label className="text-sm text-text-secondary">UWallet ID</label>
          <input
            className="w-full bg-bg-card border border-border rounded-2xl px-4 py-3 text-sm outline-none focus:border-accent-blue transition-colors"
            placeholder="uwallet_123456789"
            value={uwalletId}
            onChange={(e) => setUwalletId(e.target.value)}
          />
          {error && <p className="text-accent-red text-sm">{error}</p>}
          <button
            onClick={lookupUser}
            disabled={!uwalletId || loading}
            className="w-full py-3 rounded-2xl bg-accent-blue text-white font-semibold disabled:opacity-50"
          >
            {loading ? "Qidirilmoqda..." : "Qidirish"}
          </button>
        </div>
      )}

      {step === 2 && recipient && (
        <div className="space-y-4">
          <div className="bg-bg-card rounded-2xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-accent-blue/20 flex items-center justify-center font-bold text-accent-blue">
              {recipient.first_name[0]}
            </div>
            <div>
              <p className="font-semibold">{recipient.first_name} {recipient.last_name || ""}</p>
              <p className="text-xs text-text-muted">@{recipient.username || recipient.uwallet_id}</p>
            </div>
          </div>

          <label className="text-sm text-text-secondary">Token tanlang</label>
          <div className="space-y-2">
            {balances.map((b) => (
              <button
                key={b.token.id}
                onClick={() => setSelectedToken(b.token)}
                className={`w-full bg-bg-card rounded-2xl px-4 py-3 flex justify-between items-center border transition-colors ${
                  selectedToken?.id === b.token.id ? "border-accent-blue" : "border-border"
                }`}
              >
                <span className="font-semibold">{b.token.symbol}</span>
                <span className="text-text-secondary text-sm">{parseFloat(b.available).toFixed(4)}</span>
              </button>
            ))}
          </div>

          {selectedToken && (
            <>
              <label className="text-sm text-text-secondary">Miqdor</label>
              <div className="relative">
                <input
                  type="number"
                  className="w-full bg-bg-card border border-border rounded-2xl px-4 py-3 pr-20 text-sm outline-none focus:border-accent-blue"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
                <button
                  onClick={() => setAmount(getAvailable().toString())}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-accent-blue"
                >
                  MAX
                </button>
              </div>
              <p className="text-xs text-text-muted">Mavjud: {getAvailable().toFixed(4)} {selectedToken.symbol}</p>

              <label className="text-sm text-text-secondary">Izoh (ixtiyoriy)</label>
              <input
                className="w-full bg-bg-card border border-border rounded-2xl px-4 py-3 text-sm outline-none focus:border-accent-blue"
                placeholder="Izoh..."
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />

              <div className="bg-accent-green/10 rounded-2xl p-3 text-xs text-accent-green">
                ✓ Ichki transfer — tekin, real vaqtda
              </div>
            </>
          )}

          {error && <p className="text-accent-red text-sm">{error}</p>}

          <button
            onClick={handleSend}
            disabled={!selectedToken || !amount || loading}
            className="w-full py-3 rounded-2xl bg-accent-blue text-white font-semibold disabled:opacity-50"
          >
            {loading ? "Yuborilmoqda..." : `${amount || "0"} ${selectedToken?.symbol || ""} yuborish`}
          </button>
        </div>
      )}
    </div>
  );
}
