export { ProfilePage as default } from "./extra-pages";
