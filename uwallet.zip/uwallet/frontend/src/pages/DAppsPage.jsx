export { DAppsPage as default } from "./extra-pages";
