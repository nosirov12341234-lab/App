import { useEffect, useState } from "react";
import { useTonConnectUI } from "@tonconnect/ui-react";
import { useNavigate } from "react-router-dom";
import api from "../utils/api";

export default function DepositPage() {
  const navigate = useNavigate();
  const [tonConnectUI] = useTonConnectUI();
  const [tokens, setTokens] = useState([]);
  const [selectedToken, setSelectedToken] = useState(null);
  const [depositInfo, setDepositInfo] = useState(null);
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);

  useEffect(() => {
    api.get("/wallet/tokens").then((r) => {
      setTokens(r.data);
      setSelectedToken(r.data[0]);
    });
  }, []);

  const getDepositInfo = async () => {
    if (!selectedToken) return;
    setLoading(true);
    const res = await api.get("/wallet/deposit-address", { params: { token_id: selectedToken.id } });
    setDepositInfo(res.data);
    setLoading(false);
    setStep(2);
  };

  const sendViaTonConnect = async () => {
    if (!depositInfo || !amount) return;
    setLoading(true);
    try {
      await tonConnectUI.sendTransaction({
        validUntil: Math.floor(Date.now() / 1000) + 300,
        messages: [{
          address: depositInfo.address,
          amount: String(Math.floor(parseFloat(amount) * 1e9)),
          payload: btoa(depositInfo.memo),
        }],
      });
      setStep(3);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="pb-24 px-4 pt-6">
      <button onClick={() => step > 1 ? setStep(s => s - 1) : navigate(-1)} className="text-text-secondary mb-6">
        ← Orqaga
      </button>
      <h1 className="text-xl font-bold mb-2">Kiritish</h1>
      <p className="text-text-muted text-sm mb-6">Kripto yoki UZS kiritish</p>

      {step === 1 && (
        <div className="space-y-4">
          {/* UZS option */}
          <button
            onClick={() => navigate("/deposit/uzs")}
            className="w-full bg-bg-card border border-border rounded-2xl px-4 py-4 flex items-center gap-4 hover:border-accent-green transition-colors"
          >
            <div className="w-12 h-12 rounded-full bg-accent-green/20 flex items-center justify-center text-xl font-bold text-accent-green">
              ₴
            </div>
            <div className="text-left flex-1">
              <p className="font-semibold">UZS (So'm)</p>
              <p className="text-xs text-text-muted">Humo karta orqali • Avtomatik</p>
            </div>
            <span className="text-accent-green text-xs font-semibold">Bepul →</span>
          </button>

          <div className="relative">
            <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 border-t border-border" />
            <p className="relative text-center text-xs text-text-muted bg-bg-primary px-3 w-fit mx-auto">yoki kripto</p>
          </div>

          {/* Crypto tokens */}
          <div className="space-y-2">
            {tokens.map((t) => (
              <button
                key={t.id}
                onClick={() => setSelectedToken(t)}
                className={`w-full bg-bg-card rounded-2xl px-4 py-3 flex justify-between items-center border transition-colors ${
                  selectedToken?.id === t.id ? "border-accent-blue" : "border-border"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-bg-elevated flex items-center justify-center text-xs font-bold text-accent-blue">
                    {t.symbol.slice(0, 2)}
                  </div>
                  <div className="text-left">
                    <p className="font-semibold text-sm">{t.symbol}</p>
                    <p className="text-xs text-text-muted">{t.network}</p>
                  </div>
                </div>
                <div className="text-xs text-text-secondary">
                  {t.deposit_fee_percent}% komissiya
                </div>
              </button>
            ))}
          </div>

          <button
            onClick={getDepositInfo}
            disabled={!selectedToken || loading}
            className="w-full py-3 rounded-2xl bg-accent-blue text-white font-semibold disabled:opacity-50"
          >
            {loading ? "Yuklanmoqda..." : `${selectedToken?.symbol || ""} manzilini olish`}
          </button>
        </div>
      )}

      {step === 2 && depositInfo && (
        <div className="space-y-4">
          <div className="bg-bg-card rounded-2xl p-4 space-y-3">
            <p className="text-sm text-text-secondary">Master wallet manzili ({selectedToken?.network})</p>
            <div className="flex items-center gap-2">
              <p className="font-mono text-xs break-all text-text-primary flex-1">{depositInfo.address}</p>
              <button onClick={() => navigator.clipboard.writeText(depositInfo.address)}
                className="px-2 py-1 rounded-lg bg-bg-elevated text-xs text-text-secondary whitespace-nowrap">
                Nusxa
              </button>
            </div>
            <hr className="border-border" />
            <p className="text-sm text-text-secondary">Memo / Comment</p>
            <div className="flex items-center gap-2">
              <p className="font-bold text-accent-yellow text-xl">{depositInfo.memo}</p>
              <button onClick={() => navigator.clipboard.writeText(depositInfo.memo)}
                className="px-2 py-1 rounded-lg bg-bg-elevated text-xs text-text-secondary">
                Nusxa
              </button>
            </div>
            <p className="text-xs text-accent-red">⚠️ Memo kiritmasangiz pul yo'qoladi!</p>
          </div>

          <div className="bg-bg-card rounded-2xl p-4">
            <p className="text-sm text-text-secondary mb-2">Miqdor ({selectedToken?.symbol})</p>
            <input type="number"
              className="w-full bg-bg-elevated border border-border rounded-xl px-4 py-3 text-sm outline-none focus:border-accent-blue"
              placeholder="0.00" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </div>

          <button onClick={sendViaTonConnect} disabled={!amount || loading}
            className="w-full py-3 rounded-2xl bg-accent-green text-white font-semibold disabled:opacity-50">
            {loading ? "Yuborilmoqda..." : "TonConnect orqali yuborish"}
          </button>
          <p className="text-xs text-center text-text-muted">Yoki yuqoridagi manzilga qo'lda yuboring</p>
        </div>
      )}

      {step === 3 && (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="w-16 h-16 rounded-full bg-accent-green/20 flex items-center justify-center text-3xl mb-4">✓</div>
          <h2 className="text-xl font-bold mb-2">Tranzaksiya yuborildi!</h2>
          <p className="text-text-secondary text-sm mb-6">Blockchain tasdiqlangach balans yangilanadi (1-2 daqiqa)</p>
          <button onClick={() => navigate("/")} className="w-full py-3 rounded-2xl bg-accent-blue text-white font-semibold">
            Bosh sahifaga
          </button>
        </div>
      )}
    </div>
  );
}
