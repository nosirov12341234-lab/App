import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../utils/api";
import { useAuthStore } from "../store/authStore";

const DEFAULT_TOKENS = ["USDT", "TON", "USDC", "UZS"];

export default function HomePage() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [balances, setBalances] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get("/wallet/balances").then((res) => {
      setBalances(res.data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const defaultBals = balances.filter((b) => DEFAULT_TOKENS.includes(b.token.symbol));
  const otherBals = balances.filter(
    (b) => !DEFAULT_TOKENS.includes(b.token.symbol) && parseFloat(b.amount) > 0
  );

  const actions = [
    { label: "Kiritish", emoji: "↓", color: "text-accent-green", bg: "bg-accent-green/10", to: "/deposit" },
    { label: "Chiqarish", emoji: "↑", color: "text-accent-red", bg: "bg-accent-red/10", to: "/withdraw" },
    { label: "Yuborish", emoji: "→", color: "text-accent-blue", bg: "bg-accent-blue/10", to: "/transfer" },
    { label: "Tarix", emoji: "≡", color: "text-accent-yellow", bg: "bg-accent-yellow/10", to: "/history" },
  ];

  return (
    <div className="pb-24">
      {/* Header */}
      <div className="px-4 pt-8 pb-6 bg-gradient-to-b from-bg-elevated to-bg-primary">
        <p className="text-text-secondary text-sm mb-1">Salom, {user?.first_name || "Foydalanuvchi"} 👋</p>
        <p className="text-text-muted text-xs">{user?.uwallet_id}</p>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-4 gap-2 px-4 mb-6">
        {actions.map(({ label, emoji, color, bg, to }) => (
          <button key={label} onClick={() => navigate(to)}
            className="flex flex-col items-center gap-2">
            <div className={`w-14 h-14 rounded-2xl ${bg} flex items-center justify-center text-2xl ${color}`}>
              {emoji}
            </div>
            <span className="text-[11px] text-text-secondary">{label}</span>
          </button>
        ))}
      </div>

      {/* Balances */}
      <div className="px-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-text-secondary uppercase tracking-wider">Asosiy</h2>
          <button onClick={() => navigate("/wallet")} className="text-xs text-accent-blue">Barchasi →</button>
        </div>

        <div className="space-y-2">
          {loading
            ? [1,2,3].map(i => <div key={i} className="bg-bg-card rounded-2xl h-16 animate-pulse" />)
            : defaultBals.length === 0 && otherBals.length === 0
              ? (
                <div className="bg-bg-card rounded-2xl p-6 text-center">
                  <p className="text-text-muted text-sm mb-3">Hamyon bo'sh</p>
                  <button onClick={() => navigate("/deposit")}
                    className="px-4 py-2 rounded-xl bg-accent-blue text-white text-sm font-semibold">
                    Birinchi depozit
                  </button>
                </div>
              )
              : [...defaultBals, ...otherBals].map((b) => (
                <TokenRow key={b.token.id} balance={b} />
              ))
          }
        </div>

        {/* P2P shortcut */}
        <button onClick={() => navigate("/p2p")}
          className="w-full mt-4 py-3 rounded-2xl bg-bg-card border border-border flex items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-accent-green/10 flex items-center justify-center text-accent-green text-sm">⇄</div>
            <div className="text-left">
              <p className="text-sm font-semibold">P2P Market</p>
              <p className="text-xs text-text-muted">UZS ga sotish / sotib olish</p>
            </div>
          </div>
          <span className="text-text-muted text-sm">→</span>
        </button>
      </div>
    </div>
  );
}

function TokenRow({ balance }) {
  const amt = parseFloat(balance.amount);
  const frozen = parseFloat(balance.frozen);
  const isUzs = balance.token.symbol === "UZS";

  return (
    <div className="bg-bg-card rounded-2xl px-4 py-3 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold ${
          isUzs ? "bg-accent-green/20 text-accent-green" : "bg-accent-blue/20 text-accent-blue"
        }`}>
          {balance.token.symbol.slice(0, 2)}
        </div>
        <div>
          <p className="font-semibold text-sm">{balance.token.symbol}</p>
          <p className="text-xs text-text-muted">{balance.token.name}</p>
        </div>
      </div>
      <div className="text-right">
        <p className="font-semibold text-sm">
          {isUzs ? amt.toLocaleString("uz-UZ") : amt.toFixed(4)}
        </p>
        {frozen > 0 && (
          <p className="text-xs text-accent-yellow">Muzlat: {isUzs ? frozen.toLocaleString() : frozen.toFixed(4)}</p>
        )}
      </div>
    </div>
  );
}
