export { AdminPage as default } from "./extra-pages";
