export { HistoryPage as default } from "./extra-pages";
