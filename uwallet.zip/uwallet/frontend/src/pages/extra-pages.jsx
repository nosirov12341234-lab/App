import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuthStore } from "../store/authStore";
import api from "../utils/api";

// ── WalletPage ────────────────────────────────────────────

export function WalletPage() {
  const navigate = useNavigate();
  const [balances, setBalances] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get("/wallet/balances").then((r) => {
      setBalances(r.data);
      setLoading(false);
    });
  }, []);

  return (
    <div className="pb-24 px-4 pt-6">
      <div className="flex items-center justify-between mb-6">
        <button onClick={() => navigate(-1)} className="text-text-secondary">← Orqaga</button>
        <h1 className="text-xl font-bold">Hamyon</h1>
        <div className="w-16" />
      </div>
      <div className="space-y-2">
        {loading
          ? [1,2,3].map(i => <div key={i} className="bg-bg-card rounded-2xl h-16 animate-pulse" />)
          : balances.length === 0
            ? <p className="text-center text-text-muted py-12">Balans mavjud emas</p>
            : balances.map((b) => (
              <div key={b.token.id} className="bg-bg-card rounded-2xl px-4 py-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-bg-elevated flex items-center justify-center text-xs font-bold text-accent-blue">
                    {b.token.symbol.slice(0, 2)}
                  </div>
                  <div>
                    <p className="font-semibold text-sm">{b.token.symbol}</p>
                    <p className="text-xs text-text-muted">{b.token.name} • {b.token.network}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-sm">{parseFloat(b.amount).toFixed(4)}</p>
                  {parseFloat(b.frozen) > 0 && (
                    <p className="text-xs text-accent-yellow">Muzlat: {parseFloat(b.frozen).toFixed(4)}</p>
                  )}
                </div>
              </div>
            ))
        }
      </div>

      <div className="grid grid-cols-2 gap-3 mt-6">
        <button onClick={() => navigate("/deposit")}
          className="py-3 rounded-2xl bg-accent-green/20 text-accent-green font-semibold text-sm">
          ↓ Kiritish
        </button>
        <button onClick={() => navigate("/withdraw")}
          className="py-3 rounded-2xl bg-accent-red/20 text-accent-red font-semibold text-sm">
          ↑ Chiqarish
        </button>
      </div>
    </div>
  );
}

// ── WithdrawPage ──────────────────────────────────────────

export function WithdrawPage() {
  const navigate = useNavigate();
  const [balances, setBalances] = useState([]);
  const [selected, setSelected] = useState(null);
  const [amount, setAmount] = useState("");
  const [destination, setDestination] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    api.get("/wallet/balances").then((r) => {
      setBalances(r.data);
      if (r.data.length) setSelected(r.data[0]);
    });
  }, []);

  const avail = selected ? parseFloat(selected.available) : 0;

  const submit = async () => {
    setError("");
    if (!amount || parseFloat(amount) <= 0) { setError("Miqdor kiriting"); return; }
    if (parseFloat(amount) > avail) { setError("Yetarli balans yo'q"); return; }
    if (!destination.trim()) { setError("Manzil kiriting"); return; }
    setLoading(true);
    try {
      await api.post("/wallet/withdraw", {
        token_id: selected.token.id,
        amount: parseFloat(amount),
        destination,
      });
      setDone(true);
    } catch (e) {
      setError(e.response?.data?.detail || "Xatolik");
    } finally {
      setLoading(false);
    }
  };

  if (done) return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 text-center">
      <div className="w-16 h-16 rounded-full bg-accent-yellow/20 flex items-center justify-center text-3xl mb-4">⏳</div>
      <h2 className="text-xl font-bold mb-2">So'rov yuborildi</h2>
      <p className="text-text-secondary mb-6">Admin tasdiqlaydi va pul o'tkaziladi</p>
      <button onClick={() => navigate("/")} className="w-full py-3 rounded-2xl bg-accent-blue text-white font-semibold">
        Bosh sahifaga
      </button>
    </div>
  );

  return (
    <div className="pb-24 px-4 pt-6">
      <button onClick={() => navigate(-1)} className="text-text-secondary mb-6">← Orqaga</button>
      <h1 className="text-xl font-bold mb-6">Chiqarish</h1>
      <div className="space-y-4">
        {/* Token tanlash */}
        <div className="flex gap-2 overflow-x-auto scrollbar-none pb-1">
          {balances.map((b) => (
            <button key={b.token.id} onClick={() => { setSelected(b); setAmount(""); }}
              className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                selected?.token.id === b.token.id ? "bg-accent-blue text-white" : "bg-bg-card text-text-secondary"
              }`}>
              {b.token.symbol}
            </button>
          ))}
        </div>

        {/* Token info */}
        {selected && (
          <div className="bg-bg-card rounded-2xl p-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-text-secondary">Mavjud balans</span>
              <span className="font-bold">{avail.toFixed(4)} {selected.token.symbol}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-text-secondary">Komissiya</span>
              <span>{selected.token.withdraw_fee_percent}% + {selected.token.withdraw_fee_flat} {selected.token.symbol}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-text-secondary">Minimal</span>
              <span>{selected.token.min_withdraw} {selected.token.symbol}</span>
            </div>
          </div>
        )}

        {/* Miqdor */}
        <div className="relative">
          <input type="number"
            className="w-full bg-bg-card border border-border rounded-2xl px-4 py-3 pr-20 text-sm outline-none focus:border-accent-blue transition-colors"
            placeholder="Miqdor" value={amount} onChange={(e) => setAmount(e.target.value)} />
          <button onClick={() => setAmount(avail.toString())}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-accent-blue font-semibold">
            MAX
          </button>
        </div>

        {/* Manzil */}
        <input
          className="w-full bg-bg-card border border-border rounded-2xl px-4 py-3 text-sm outline-none focus:border-accent-blue transition-colors"
          placeholder={selected?.token.symbol === "UZS" ? "Karta raqami (8600...)" : "Wallet manzili"}
          value={destination} onChange={(e) => setDestination(e.target.value)} />

        {error && <p className="text-accent-red text-sm text-center">{error}</p>}

        <button onClick={submit} disabled={!amount || !destination || loading}
          className="w-full py-3 rounded-2xl bg-accent-red text-white font-semibold disabled:opacity-50">
          {loading ? "Yuborilmoqda..." : "Chiqarish so'rovi yuborish"}
        </button>
      </div>
    </div>
  );
}

// ── HistoryPage ───────────────────────────────────────────

const TX_LABELS = {
  deposit: "Kirim", withdraw: "Chiqim", transfer_in: "Qabul qilindi",
  transfer_out: "Yuborildi", p2p_buy: "P2P xarid", p2p_sell: "P2P sotuv",
  task_reward: "Task mukofoti", referral_reward: "Referal mukofoti", fee: "Komissiya",
};
const TX_IN = new Set(["deposit", "transfer_in", "task_reward", "referral_reward"]);

export function HistoryPage() {
  const navigate = useNavigate();
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get("/wallet/history").then((r) => {
      setHistory(r.data);
      setLoading(false);
    });
  }, []);

  return (
    <div className="pb-24 px-4 pt-6">
      <button onClick={() => navigate(-1)} className="text-text-secondary mb-4">← Orqaga</button>
      <h1 className="text-xl font-bold mb-6">Tranzaksiyalar tarixi</h1>
      <div className="space-y-2">
        {loading
          ? [1,2,3,4].map(i => <div key={i} className="bg-bg-card rounded-2xl h-16 animate-pulse" />)
          : history.length === 0
            ? <p className="text-center text-text-muted py-12">Tarix bo'sh</p>
            : history.map((tx) => {
              const isIn = TX_IN.has(tx.type);
              const statusColor = tx.status === "confirmed" ? "text-accent-green"
                : tx.status === "failed" ? "text-accent-red" : "text-accent-yellow";
              return (
                <div key={tx.id} className="bg-bg-card rounded-2xl px-4 py-3 flex justify-between items-center">
                  <div>
                    <p className="text-sm font-semibold">{TX_LABELS[tx.type] || tx.type}</p>
                    <p className="text-xs text-text-muted">{new Date(tx.created_at).toLocaleString("uz-UZ")}</p>
                    {tx.note && <p className="text-xs text-text-muted truncate max-w-[180px]">{tx.note}</p>}
                  </div>
                  <div className="text-right">
                    <p className={`font-bold text-sm ${isIn ? "text-accent-green" : "text-accent-red"}`}>
                      {isIn ? "+" : "-"}{tx.amount} {tx.token}
                    </p>
                    <p className={`text-xs ${statusColor}`}>{tx.status}</p>
                  </div>
                </div>
              );
            })
        }
      </div>
    </div>
  );
}

// ── TasksPage ─────────────────────────────────────────────

export function TasksPage() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadTasks = () => {
    api.get("/tasks/").then((r) => { setTasks(r.data); setLoading(false); });
  };

  useEffect(() => { loadTasks(); }, []);

  const complete = async (id) => {
    try {
      const res = await api.post(`/tasks/${id}/complete`);
      alert(res.data.message);
      loadTasks();
    } catch (e) {
      alert(e.response?.data?.detail || "Xatolik");
    }
  };

  return (
    <div className="pb-24 px-4 pt-6">
      <h1 className="text-xl font-bold mb-2">Tasklar</h1>
      <p className="text-text-muted text-sm mb-6">Vazifalarni bajaring, mukofot oling</p>
      <div className="space-y-3">
        {loading
          ? [1,2,3].map(i => <div key={i} className="bg-bg-card rounded-2xl h-20 animate-pulse" />)
          : tasks.length === 0
            ? <p className="text-center text-text-muted py-12">Tasklar yo'q</p>
            : tasks.map((t) => (
              <div key={t.id} className="bg-bg-card rounded-2xl p-4">
                <div className="flex justify-between items-start gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs px-2 py-0.5 rounded-full bg-bg-elevated text-text-muted">
                        {t.type === "channel" ? "📢 Kanal" : "🔗 Link"}
                      </span>
                    </div>
                    <p className="font-semibold text-sm">{t.title}</p>
                    {t.description && <p className="text-xs text-text-muted mt-1 line-clamp-2">{t.description}</p>}
                    <p className="text-xs text-accent-blue mt-2 font-semibold">+{t.reward_amount} mukofot</p>
                  </div>
                  <button onClick={() => complete(t.id)} disabled={t.verified}
                    className={`flex-shrink-0 px-3 py-2 rounded-xl text-xs font-semibold transition-colors ${
                      t.verified
                        ? "bg-accent-green/20 text-accent-green cursor-default"
                        : t.completed
                          ? "bg-accent-yellow/20 text-accent-yellow"
                          : "bg-accent-blue text-white"
                    }`}>
                    {t.verified ? "✓ Bajarildi" : t.completed ? "Tekshirish" : "Bajarish"}
                  </button>
                </div>
              </div>
            ))
        }
      </div>
    </div>
  );
}

// ── DAppsPage ─────────────────────────────────────────────

export function DAppsPage() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState(null);

  useEffect(() => {
    api.get("/dapps/").then((r) => {
      setCategories(r.data);
      if (r.data.length) setActiveTab(r.data[0].id);
      setLoading(false);
    });
  }, []);

  const activeCat = categories.find((c) => c.id === activeTab);

  return (
    <div className="pb-24 pt-6">
      <div className="px-4 mb-4">
        <h1 className="text-xl font-bold">DApps</h1>
      </div>

      {/* Category tabs */}
      {categories.length > 0 && (
        <div className="flex gap-2 px-4 overflow-x-auto scrollbar-none mb-4 pb-1">
          <button onClick={() => setActiveTab(null)}
            className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === null ? "bg-accent-blue text-white" : "bg-bg-card text-text-secondary"
            }`}>
            Barchasi
          </button>
          {categories.map((c) => (
            <button key={c.id} onClick={() => setActiveTab(c.id)}
              className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                activeTab === c.id ? "bg-accent-blue text-white" : "bg-bg-card text-text-secondary"
              }`}>
              {c.name}
            </button>
          ))}
        </div>
      )}

      {/* DApps grid */}
      <div className="px-4">
        {loading
          ? <div className="grid grid-cols-3 gap-3">
              {[1,2,3,4,5,6].map(i => <div key={i} className="bg-bg-card rounded-2xl h-24 animate-pulse" />)}
            </div>
          : categories.length === 0
            ? <p className="text-center text-text-muted py-12">DApps yo'q</p>
            : (activeTab === null ? categories : [activeCat]).filter(Boolean).map((cat) => (
              <div key={cat.id} className="mb-6">
                {activeTab === null && (
                  <h2 className="text-sm font-semibold text-text-secondary mb-3 uppercase tracking-wider">{cat.name}</h2>
                )}
                <div className="grid grid-cols-3 gap-3">
                  {cat.dapps.map((dapp) => (
                    <a key={dapp.id} href={dapp.url} target="_blank" rel="noopener noreferrer"
                      className="bg-bg-card rounded-2xl p-3 flex flex-col items-center gap-2 text-center hover:bg-bg-elevated transition-colors">
                      <div className="w-12 h-12 rounded-2xl bg-bg-elevated flex items-center justify-center overflow-hidden">
                        {dapp.icon_url
                          ? <img src={dapp.icon_url} alt={dapp.name} className="w-full h-full object-cover" />
                          : <span className="text-2xl">🔷</span>
                        }
                      </div>
                      <p className="text-xs font-semibold leading-tight line-clamp-2">{dapp.name}</p>
                    </a>
                  ))}
                </div>
              </div>
            ))
        }
      </div>
    </div>
  );
}

// ── ProfilePage ───────────────────────────────────────────

export function ProfilePage() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [copied, setCopied] = useState(false);

  const copy = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const BOT_USERNAME = import.meta.env.VITE_BOT_USERNAME || "UWalletBot";

  return (
    <div className="pb-24 px-4 pt-6">
      <h1 className="text-xl font-bold mb-6">Profil</h1>

      {/* User card */}
      <div className="bg-bg-card rounded-2xl p-4 mb-4">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-16 h-16 rounded-full bg-accent-blue/20 flex items-center justify-center text-2xl font-bold text-accent-blue">
            {user?.first_name?.[0]?.toUpperCase() || "U"}
          </div>
          <div>
            <p className="font-bold text-lg">{user?.first_name} {user?.last_name || ""}</p>
            {user?.username && <p className="text-sm text-text-muted">@{user.username}</p>}
          </div>
        </div>
        <button onClick={() => copy(user?.uwallet_id || "")}
          className="w-full py-2.5 rounded-xl border border-border text-sm flex items-center justify-center gap-2">
          <span className="text-text-muted">ID:</span>
          <span className="font-mono font-semibold">{user?.uwallet_id}</span>
          <span className="text-xs text-accent-blue">{copied ? "✓" : "Nusxa"}</span>
        </button>
      </div>

      {/* Referral */}
      <div className="bg-bg-card rounded-2xl p-4 mb-4 space-y-3">
        <h3 className="font-semibold">🎁 Referal dasturi</h3>
        <p className="text-xs text-text-muted">Do'stlarni taklif qiling va mukofot oling</p>
        <button
          onClick={() => copy(`https://t.me/${BOT_USERNAME}?start=${user?.uwallet_id}`)}
          className="w-full py-2.5 rounded-xl bg-accent-blue/20 text-accent-blue text-sm font-semibold">
          Referal havolani nusxalash 🔗
        </button>
        <button
          onClick={() => {
            const tg = window.Telegram?.WebApp;
            tg?.openTelegramLink(
              `https://t.me/share/url?url=https://t.me/${BOT_USERNAME}?start=${user?.uwallet_id}&text=UWallet — kripto va UZS hamyon!`
            );
          }}
          className="w-full py-2.5 rounded-xl bg-bg-elevated text-text-secondary text-sm font-semibold">
          Telegram orqali ulashish ↗
        </button>
      </div>

      {/* Navigation shortcuts */}
      <div className="bg-bg-card rounded-2xl divide-y divide-border">
        {[
          { label: "📋 Tranzaksiyalar tarixi", to: "/history" },
          { label: "💼 Hamyon", to: "/wallet" },
          { label: "📥 Kiritish", to: "/deposit" },
          { label: "📤 Chiqarish", to: "/withdraw" },
        ].map(({ label, to }) => (
          <button key={to} onClick={() => navigate(to)}
            className="w-full px-4 py-3.5 flex justify-between items-center text-sm">
            <span>{label}</span>
            <span className="text-text-muted">→</span>
          </button>
        ))}
      </div>

      {/* Admin */}
      {user?.is_admin && (
        <button onClick={() => navigate("/admin")}
          className="w-full mt-4 py-3 rounded-2xl bg-accent-yellow/20 text-accent-yellow font-semibold">
          ⚙️ Admin Panel
        </button>
      )}
    </div>
  );
}

// ── AdminPage ─────────────────────────────────────────────

const SETTING_LABELS = {
  uzs_card_number: { label: "💳 UZS karta raqami", placeholder: "9860 1234 5678 9012" },
  uzs_deposit_timeout_minutes: { label: "⏱ Deposit timeout (daqiqa)", placeholder: "15" },
  pool_wallet_address: { label: "🏦 Pool wallet (TON)", placeholder: "UQB..." },
  platform_fee_percent: { label: "📊 Platforma komissiyasi (%)", placeholder: "1.0" },
  p2p_fee_percent: { label: "🔄 P2P komissiyasi (%)", placeholder: "0.5" },
  referral_reward_uzs: { label: "🎁 Referal mukofoti (UZS)", placeholder: "10000" },
};

export function AdminPage() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [tab, setTab] = useState("settings");
  const [settings, setSettings] = useState({});
  const [withdraws, setWithdraws] = useState([]);
  const [uzsDeps, setUzsDeps] = useState([]);
  const [saving, setSaving] = useState({});
  const [editVals, setEditVals] = useState({});

  useEffect(() => {
    if (!user?.is_admin) return;
    if (tab === "settings") {
      api.get("/admin/settings").then((r) => {
        setSettings(r.data);
        const vals = {};
        Object.entries(r.data).forEach(([k, v]) => { vals[k] = v.value; });
        setEditVals(vals);
      });
    } else if (tab === "withdraws") {
      api.get("/admin/withdraws").then((r) => setWithdraws(r.data));
    } else if (tab === "uzs") {
      api.get("/admin/uzs-deposits").then((r) => setUzsDeps(r.data));
    }
  }, [tab, user]);

  const saveSetting = async (key) => {
    setSaving((s) => ({ ...s, [key]: true }));
    try {
      await api.post("/admin/settings", { key, value: editVals[key] });
    } finally {
      setSaving((s) => ({ ...s, [key]: false }));
    }
  };

  const approveWithdraw = async (id) => {
    await api.post(`/admin/withdraws/${id}/approve`);
    setWithdraws((w) => w.filter((x) => x.id !== id));
  };
  const rejectWithdraw = async (id) => {
    await api.post(`/admin/withdraws/${id}/reject`);
    setWithdraws((w) => w.filter((x) => x.id !== id));
  };

  if (!user?.is_admin) return (
    <div className="min-h-screen flex items-center justify-center text-text-muted">
      Ruxsat yo'q
    </div>
  );

  const TABS = [
    { key: "settings", label: "Sozlamalar" },
    { key: "withdraws", label: "Chiqarish" },
    { key: "uzs", label: "UZS" },
  ];

  return (
    <div className="pb-24 pt-6">
      <div className="px-4 flex items-center gap-3 mb-4">
        <button onClick={() => navigate(-1)} className="text-text-secondary">←</button>
        <h1 className="text-xl font-bold">Admin Panel</h1>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 px-4 mb-5 overflow-x-auto scrollbar-none">
        {TABS.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={`px-4 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-colors ${
              tab === t.key ? "bg-accent-blue text-white" : "bg-bg-card text-text-secondary"
            }`}>
            {t.label}
          </button>
        ))}
      </div>

      <div className="px-4 space-y-4">

        {/* Settings tab */}
        {tab === "settings" && Object.entries(SETTING_LABELS).map(([key, meta]) => (
          <div key={key} className="bg-bg-card rounded-2xl p-4">
            <p className="text-sm font-semibold mb-2">{meta.label}</p>
            <div className="flex gap-2">
              <input
                className="flex-1 bg-bg-elevated border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-accent-blue transition-colors"
                placeholder={meta.placeholder}
                value={editVals[key] || ""}
                onChange={(e) => setEditVals((v) => ({ ...v, [key]: e.target.value }))}
              />
              <button
                onClick={() => saveSetting(key)}
                disabled={saving[key]}
                className="px-4 py-2.5 rounded-xl bg-accent-blue text-white text-sm font-semibold disabled:opacity-50">
                {saving[key] ? "..." : "Saqlash"}
              </button>
            </div>
            {settings[key]?.value && (
              <p className="text-xs text-text-muted mt-1">Hozirgi: {settings[key].value}</p>
            )}
          </div>
        ))}

        {/* Withdraws tab */}
        {tab === "withdraws" && (
          withdraws.length === 0
            ? <p className="text-center text-text-muted py-12">Kutilayotgan so'rovlar yo'q</p>
            : withdraws.map((w) => (
              <div key={w.id} className="bg-bg-card rounded-2xl p-4">
                <div className="space-y-1.5 mb-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-text-secondary">User</span>
                    <span className="font-mono">{w.user_id}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-text-secondary">Miqdor</span>
                    <span className="font-bold">{w.amount}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-text-secondary">Komissiya</span>
                    <span>{w.fee}</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-text-secondary">Manzil: </span>
                    <span className="font-mono text-xs break-all">{w.destination}</span>
                  </div>
                  <p className="text-xs text-text-muted">{new Date(w.created_at).toLocaleString("uz-UZ")}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => approveWithdraw(w.id)}
                    className="flex-1 py-2.5 rounded-xl bg-accent-green/20 text-accent-green text-sm font-semibold">
                    ✅ Tasdiqlash
                  </button>
                  <button onClick={() => rejectWithdraw(w.id)}
                    className="flex-1 py-2.5 rounded-xl bg-accent-red/20 text-accent-red text-sm font-semibold">
                    ❌ Rad etish
                  </button>
                </div>
              </div>
            ))
        )}

        {/* UZS deposits tab */}
        {tab === "uzs" && (
          uzsDeps.length === 0
            ? <p className="text-center text-text-muted py-12">Kutilayotgan UZS so'rovlar yo'q</p>
            : uzsDeps.map((d) => (
              <div key={d.id} className="bg-bg-card rounded-2xl p-4 space-y-1.5">
                <div className="flex justify-between text-sm">
                  <span className="text-text-secondary">User</span>
                  <span className="font-mono">{d.user_id}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-text-secondary">Summa</span>
                  <span className="font-bold text-accent-green">{parseFloat(d.amount_uzs).toLocaleString()} UZS</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-text-secondary">Karta</span>
                  <span className="font-mono">{d.card_number}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-text-secondary">Muddati</span>
                  <span className="text-accent-yellow text-xs">{new Date(d.expires_at).toLocaleString("uz-UZ")}</span>
                </div>
                <p className="text-xs text-text-muted">{new Date(d.created_at).toLocaleString("uz-UZ")}</p>
              </div>
            ))
        )}
      </div>
    </div>
  );
}
