import { useEffect, useState } from "react";
import api from "../utils/api";

export default function P2PPage() {
  const [orders, setOrders] = useState([]);
  const [tokens, setTokens] = useState([]);
  const [activeType, setActiveType] = useState("sell");
  const [selectedToken, setSelectedToken] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);

  useEffect(() => {
    api.get("/wallet/tokens").then((r) => {
      const cryptoTokens = r.data.filter(t => t.symbol !== "UZS");
      setTokens(cryptoTokens);
      if (cryptoTokens.length) setSelectedToken(cryptoTokens[0]);
    });
  }, []);

  useEffect(() => {
    if (!selectedToken) return;
    setLoading(true);
    api.get("/p2p/orders", { params: { token_id: selectedToken.id, order_type: activeType } })
      .then((r) => { setOrders(r.data); setLoading(false); });
  }, [activeType, selectedToken]);

  return (
    <div className="pb-24">
      {/* Header */}
      <div className="px-4 pt-6 pb-4 flex items-center justify-between">
        <h1 className="text-xl font-bold">P2P Market</h1>
        <button onClick={() => setShowCreate(true)}
          className="px-4 py-2 rounded-xl bg-accent-blue text-white text-sm font-semibold">
          + E'lon
        </button>
      </div>

      {/* Type toggle */}
      <div className="flex gap-2 px-4 mb-4">
        <button onClick={() => setActiveType("sell")}
          className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
            activeType === "sell" ? "bg-accent-green/20 text-accent-green" : "bg-bg-card text-text-muted"
          }`}>
          Sotish e'lonlari
        </button>
        <button onClick={() => setActiveType("buy")}
          className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
            activeType === "buy" ? "bg-accent-red/20 text-accent-red" : "bg-bg-card text-text-muted"
          }`}>
          Sotib olish e'lonlari
        </button>
      </div>

      {/* Token filter */}
      <div className="flex gap-2 px-4 mb-4 overflow-x-auto scrollbar-none">
        {tokens.map((t) => (
          <button key={t.id} onClick={() => setSelectedToken(t)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
              selectedToken?.id === t.id ? "bg-accent-blue text-white" : "bg-bg-card text-text-secondary"
            }`}>
            {t.symbol}
          </button>
        ))}
      </div>

      {/* Orders */}
      <div className="px-4 space-y-3">
        {loading
          ? [1,2,3].map(i => <div key={i} className="bg-bg-card rounded-2xl h-24 animate-pulse" />)
          : orders.length === 0
            ? (
              <div className="text-center py-12">
                <p className="text-text-muted mb-3">E'lonlar yo'q</p>
                <button onClick={() => setShowCreate(true)}
                  className="px-4 py-2 rounded-xl bg-accent-blue/20 text-accent-blue text-sm font-semibold">
                  Birinchi e'lon qo'ying
                </button>
              </div>
            )
            : orders.map((order) => <P2POrderCard key={order.id} order={order} type={activeType} />)
        }
      </div>

      {showCreate && (
        <CreateOrderModal
          tokens={tokens}
          onClose={() => setShowCreate(false)}
          onCreated={() => { setShowCreate(false); setLoading(true); }}
        />
      )}
    </div>
  );
}

function P2POrderCard({ order, type }) {
  return (
    <div className="bg-bg-card rounded-2xl p-4">
      <div className="flex justify-between items-start mb-3">
        <div>
          <p className="text-lg font-bold">{parseFloat(order.price_uzs).toLocaleString("uz-UZ")} UZS</p>
          <p className="text-xs text-text-muted">1 {order.token} narxi</p>
        </div>
        <button className={`px-4 py-2 rounded-xl text-sm font-semibold ${
          type === "sell" ? "bg-accent-green/20 text-accent-green" : "bg-accent-red/20 text-accent-red"
        }`}>
          {type === "sell" ? "Sotib ol" : "Sot"}
        </button>
      </div>
      <div className="flex gap-4 text-xs text-text-secondary flex-wrap">
        <span>💰 {parseFloat(order.amount).toFixed(2)} {order.token}</span>
        <span>💳 {order.payment_method}</span>
        {order.min_amount && <span>Min: {order.min_amount}</span>}
        {order.max_amount && <span>Max: {order.max_amount}</span>}
      </div>
      {order.note && <p className="text-xs text-text-muted mt-2 italic">"{order.note}"</p>}
    </div>
  );
}

function CreateOrderModal({ tokens, onClose, onCreated }) {
  const [form, setForm] = useState({
    token_id: tokens[0]?.id || "",
    order_type: "sell",
    amount: "",
    price_uzs: "",
    payment_method: "Uzcard",
    note: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submit = async () => {
    if (!form.amount || !form.price_uzs) { setError("Miqdor va narxni kiriting"); return; }
    setLoading(true);
    setError("");
    try {
      await api.post("/p2p/orders", {
        ...form,
        token_id: parseInt(form.token_id),
        amount: parseFloat(form.amount),
        price_uzs: parseFloat(form.price_uzs),
      });
      onCreated();
    } catch (e) {
      setError(e.response?.data?.detail || "Xatolik");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-end" onClick={onClose}>
      <div className="bg-bg-card w-full rounded-t-3xl p-5 space-y-4 pb-10" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center">
          <h2 className="text-lg font-bold">E'lon yaratish</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-bg-elevated flex items-center justify-center text-text-muted">✕</button>
        </div>

        <div className="flex gap-2">
          {[["sell", "Sotish"], ["buy", "Sotib olish"]].map(([v, l]) => (
            <button key={v} onClick={() => setForm((f) => ({ ...f, order_type: v }))}
              className={`flex-1 py-2.5 rounded-xl text-sm font-semibold ${
                form.order_type === v ? "bg-accent-blue text-white" : "bg-bg-elevated text-text-muted"
              }`}>
              {l}
            </button>
          ))}
        </div>

        <select className="w-full bg-bg-elevated border border-border rounded-xl px-4 py-3 text-sm"
          value={form.token_id} onChange={(e) => setForm((f) => ({ ...f, token_id: e.target.value }))}>
          {tokens.map((t) => <option key={t.id} value={t.id}>{t.symbol} — {t.name}</option>)}
        </select>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-text-muted mb-1 block">Miqdor</label>
            <input className="w-full bg-bg-elevated border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-accent-blue"
              placeholder="0.00" type="number" value={form.amount}
              onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))} />
          </div>
          <div>
            <label className="text-xs text-text-muted mb-1 block">Narx (UZS)</label>
            <input className="w-full bg-bg-elevated border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-accent-blue"
              placeholder="0" type="number" value={form.price_uzs}
              onChange={(e) => setForm((f) => ({ ...f, price_uzs: e.target.value }))} />
          </div>
        </div>

        <select className="w-full bg-bg-elevated border border-border rounded-xl px-4 py-3 text-sm"
          value={form.payment_method} onChange={(e) => setForm((f) => ({ ...f, payment_method: e.target.value }))}>
          {["Uzcard", "Humo", "Click", "Payme", "Naqd"].map((m) => <option key={m}>{m}</option>)}
        </select>

        <input className="w-full bg-bg-elevated border border-border rounded-xl px-4 py-3 text-sm outline-none focus:border-accent-blue"
          placeholder="Izoh (ixtiyoriy)" value={form.note}
          onChange={(e) => setForm((f) => ({ ...f, note: e.target.value }))} />

        {error && <p className="text-accent-red text-sm text-center">{error}</p>}

        <button onClick={submit} disabled={loading}
          className="w-full py-3 rounded-2xl bg-accent-blue text-white font-semibold disabled:opacity-50">
          {loading ? "Yuborilmoqda..." : "E'lon qo'yish"}
        </button>
      </div>
    </div>
  );
}
