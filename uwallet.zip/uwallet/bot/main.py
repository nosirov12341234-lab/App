import asyncio
import re
from datetime import datetime
from aiogram import Bot, Dispatcher, Router, F
from aiogram.filters import Command
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from aiogram.fsm.storage.redis import RedisStorage
import httpx
import os

BOT_TOKEN = os.getenv("BOT_TOKEN")
API_URL = os.getenv("API_URL", "http://backend:8000/api/v1")
ADMIN_IDS = [int(i) for i in os.getenv("ADMIN_TELEGRAM_IDS", "").split(",") if i.strip()]
LOG_CHANNEL = os.getenv("LOG_CHANNEL_ID", "")
WEBAPP_URL = os.getenv("WEBAPP_URL", "")

bot = Bot(token=BOT_TOKEN)
storage = RedisStorage.from_url(os.getenv("REDIS_URL", "redis://redis:6379/0"))
dp = Dispatcher(storage=storage)
router = Router()


# ── Helpers ──────────────────────────────────────────────

async def log(text: str):
    if LOG_CHANNEL:
        try:
            await bot.send_message(LOG_CHANNEL, text, parse_mode="HTML")
        except Exception:
            pass


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


# ── /start ───────────────────────────────────────────────

@router.message(Command("start"))
async def cmd_start(message: Message):
    args = message.text.split()
    ref = args[1] if len(args) > 1 else None

    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🚀 UWallet ochish", web_app={"url": WEBAPP_URL})
    ]])
    await message.answer(
        f"👋 <b>UWallet</b> ga xush kelibsiz!\n\n"
        f"💼 TON ekotizimidagi universal hamyon\n"
        f"• Kripto saqlash va savdo\n"
        f"• UZS kiritish / chiqarish\n"
        f"• P2P bozor\n"
        f"• DApps katalog\n\n"
        f"{'🎁 Referal orqali keldingiz!' if ref else ''}",
        reply_markup=kb,
        parse_mode="HTML"
    )
    await log(f"👤 Yangi user: <code>{message.from_user.id}</code> @{message.from_user.username or '-'}")


# ── Admin /admin ──────────────────────────────────────────

@router.message(Command("admin"))
async def cmd_admin(message: Message):
    if not is_admin(message.from_user.id):
        return
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💳 Karta sozlash", callback_data="admin:card")],
        [InlineKeyboardButton(text="⏱ Timeout sozlash", callback_data="admin:timeout")],
        [InlineKeyboardButton(text="🏦 Pool wallet", callback_data="admin:pool")],
        [InlineKeyboardButton(text="📋 UZS so'rovlar", callback_data="admin:uzs_list")],
        [InlineKeyboardButton(text="💸 Chiqarish so'rovlar", callback_data="admin:withdraw_list")],
    ])
    await message.answer("⚙️ <b>Admin panel</b>", reply_markup=kb, parse_mode="HTML")


# ── Admin callbacks ───────────────────────────────────────

@router.callback_query(F.data == "admin:card")
async def cb_set_card(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return
    await call.message.answer(
        "💳 Yangi karta raqamini yuboring:\n"
        "<i>Masalan: 9860 1234 5678 9012</i>",
        parse_mode="HTML"
    )
    await call.answer()
    # FSM o'rniga oddiy state: Redis ga saqlaymiz
    import redis.asyncio as aioredis
    r = aioredis.from_url(os.getenv("REDIS_URL", "redis://redis:6379/0"))
    await r.set(f"admin_state:{call.from_user.id}", "set_card", ex=120)
    await r.aclose()


@router.callback_query(F.data == "admin:timeout")
async def cb_set_timeout(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return
    await call.message.answer(
        "⏱ Necha daqiqa ichida tasdiqlash kerak?\n"
        "<i>Masalan: 15</i>",
        parse_mode="HTML"
    )
    await call.answer()
    import redis.asyncio as aioredis
    r = aioredis.from_url(os.getenv("REDIS_URL", "redis://redis:6379/0"))
    await r.set(f"admin_state:{call.from_user.id}", "set_timeout", ex=120)
    await r.aclose()


@router.callback_query(F.data == "admin:pool")
async def cb_set_pool(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return
    await call.message.answer(
        "🏦 Pool wallet TON manzilini yuboring:\n"
        "<i>Masalan: UQB...</i>",
        parse_mode="HTML"
    )
    await call.answer()
    import redis.asyncio as aioredis
    r = aioredis.from_url(os.getenv("REDIS_URL", "redis://redis:6379/0"))
    await r.set(f"admin_state:{call.from_user.id}", "set_pool", ex=120)
    await r.aclose()


@router.callback_query(F.data == "admin:uzs_list")
async def cb_uzs_list(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return
    async with httpx.AsyncClient() as client:
        try:
            res = await client.get(
                f"{API_URL}/admin/uzs-deposits",
                headers={"X-Bot-Secret": os.getenv("BOT_SECRET", "")}
            )
            deps = res.json()
        except Exception:
            deps = []

    if not deps:
        await call.message.answer("📭 Kutilayotgan UZS so'rovlar yo'q")
    else:
        for d in deps[:10]:
            expires = d.get("expires_at", "")[:16].replace("T", " ")
            text = (
                f"📥 <b>UZS So'rov #{d['id']}</b>\n"
                f"👤 User: <code>{d['user_id']}</code>\n"
                f"💰 Summa: <b>{float(d['amount_uzs']):,.0f} UZS</b>\n"
                f"💳 Karta: <code>{d['card_number']}</code>\n"
                f"⏰ Muddati: {expires}"
            )
            await call.message.answer(text, parse_mode="HTML")
    await call.answer()


@router.callback_query(F.data == "admin:withdraw_list")
async def cb_withdraw_list(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return
    async with httpx.AsyncClient() as client:
        try:
            res = await client.get(
                f"{API_URL}/admin/withdraws",
                headers={"X-Bot-Secret": os.getenv("BOT_SECRET", "")}
            )
            reqs = res.json()
        except Exception:
            reqs = []

    if not reqs:
        await call.message.answer("📭 Kutilayotgan chiqarish so'rovlar yo'q")
    else:
        for w in reqs[:10]:
            kb = InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="✅ Tasdiqlash", callback_data=f"withdraw:approve:{w['id']}"),
                InlineKeyboardButton(text="❌ Rad etish", callback_data=f"withdraw:reject:{w['id']}"),
            ]])
            text = (
                f"💸 <b>Chiqarish #{w['id']}</b>\n"
                f"👤 User: <code>{w['user_id']}</code>\n"
                f"💰 Summa: <b>{w['amount']}</b>\n"
                f"📍 Manzil: <code>{w['destination']}</code>"
            )
            await call.message.answer(text, reply_markup=kb, parse_mode="HTML")
    await call.answer()


@router.callback_query(F.data.startswith("withdraw:"))
async def cb_withdraw_action(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return
    _, action, wid = call.data.split(":")
    async with httpx.AsyncClient() as client:
        await client.post(
            f"{API_URL}/admin/withdraws/{wid}/{action}",
            headers={"X-Bot-Secret": os.getenv("BOT_SECRET", "")}
        )
    status = "✅ Tasdiqlandi" if action == "approve" else "❌ Rad etildi"
    await call.message.edit_text(call.message.text + f"\n\n{status}", parse_mode="HTML")
    await call.answer(status)


# ── Admin text input handler ──────────────────────────────

@router.message(F.text & F.from_user.func(is_admin))
async def admin_text_input(message: Message):
    import redis.asyncio as aioredis
    r = aioredis.from_url(os.getenv("REDIS_URL", "redis://redis:6379/0"))
    state = await r.get(f"admin_state:{message.from_user.id}")
    await r.aclose()

    if not state:
        return

    state = state.decode()
    value = message.text.strip()

    setting_map = {
        "set_card": ("uzs_card_number", "💳 Karta raqami saqlandi"),
        "set_timeout": ("uzs_deposit_timeout_minutes", "⏱ Timeout saqlandi"),
        "set_pool": ("pool_wallet_address", "🏦 Pool wallet saqlandi"),
    }

    if state not in setting_map:
        return

    key, success_msg = setting_map[state]

    async with httpx.AsyncClient() as client:
        await client.post(
            f"{API_URL}/admin/settings",
            json={"key": key, "value": value},
            headers={"X-Bot-Secret": os.getenv("BOT_SECRET", "")}
        )

    # State tozalash
    import redis.asyncio as aioredis
    r = aioredis.from_url(os.getenv("REDIS_URL", "redis://redis:6379/0"))
    await r.delete(f"admin_state:{message.from_user.id}")
    await r.aclose()

    await message.answer(f"✅ {success_msg}: <code>{value}</code>", parse_mode="HTML")
    await log(f"⚙️ Admin sozlama: <b>{key}</b> = <code>{value}</code>")


# ── HUMOcardbot watcher (Telethon userbot) ───────────────

def parse_humo_message(text: str) -> dict | None:
    """
    🎉 To'ldirish
    ➕ 88.000,00 UZS
    📍 UB P2P Uzcard2Humo>T
    💳 HUMOCARD *6205
    🕓 22:45 12.06.2026
    💰 88.024,12 UZS
    """
    if "To'ldirish" not in text and "Toldirish" not in text:
        return None

    amount_match = re.search(r"➕\s*([\d\s.,]+)\s*UZS", text)
    time_match = re.search(r"🕓\s*(\d{2}:\d{2}\s+\d{2}\.\d{2}\.\d{4})", text)
    balance_match = re.search(r"💰\s*([\d\s.,]+)\s*UZS", text)
    card_match = re.search(r"💳\s*\w+\s*\*(\d+)", text)

    if not amount_match:
        return None

    raw = amount_match.group(1).replace(" ", "").replace(".", "").replace(",", ".")
    try:
        amount = float(raw)
    except ValueError:
        return None

    return {
        "amount": amount,
        "time_str": time_match.group(1) if time_match else "",
        "card_last4": card_match.group(1) if card_match else "",
    }


async def run_humo_watcher():
    """Telethon userbot — @HUMOcardbot xabarlarini kuzatadi"""
    from telethon import TelegramClient, events
    from telethon.sessions import StringSession

    api_id = int(os.getenv("TELETHON_API_ID", "0"))
    api_hash = os.getenv("TELETHON_API_HASH", "")
    session_str = os.getenv("TELETHON_SESSION", "")

    if not api_id or not api_hash or not session_str:
        print("⚠️ Telethon sozlanmagan — HUMOcardbot kuzatilmaydi")
        return

    client = TelegramClient(StringSession(session_str), api_id, api_hash)
    await client.start()
    print("✅ HUMOcardbot watcher ishga tushdi")

    @client.on(events.NewMessage(from_users="HUMOcardbot"))
    async def humo_handler(event):
        text = event.message.text or ""
        parsed = parse_humo_message(text)
        if not parsed:
            return

        amount = parsed["amount"]
        time_str = parsed["time_str"]

        print(f"💰 HUMOcardbot: {amount} UZS — {time_str}")

        # Backend ga yuborish
        async with httpx.AsyncClient() as http:
            try:
                res = await http.post(
                    f"{API_URL}/uzs-deposit/confirm-by-bot",
                    json={
                        "amount_uzs": amount,
                        "time_str": time_str,
                        "card_last4": parsed["card_last4"],
                    },
                    headers={"X-Bot-Secret": os.getenv("BOT_SECRET", "")},
                    timeout=10,
                )
                data = res.json()
                if data.get("confirmed"):
                    user_id = data.get("user_id")
                    if user_id:
                        try:
                            await bot.send_message(
                                user_id,
                                f"✅ <b>UZS depozit tasdiqlandi!</b>\n\n"
                                f"💰 <b>{amount:,.0f} UZS</b> hisobingizga qo'shildi",
                                parse_mode="HTML"
                            )
                        except Exception:
                            pass
                    await log(
                        f"✅ UZS deposit tasdiq: <b>{amount:,.0f} UZS</b> "
                        f"→ user <code>{user_id}</code>"
                    )
                else:
                    await log(
                        f"⚠️ HUMOcardbot xabar: {amount:,.0f} UZS — "
                        f"mos so'rov topilmadi ({time_str})"
                    )
            except Exception as e:
                print(f"Backend xatosi: {e}")

    await client.run_until_disconnected()


# ── Channel check (task uchun) ────────────────────────────

async def check_channel_membership(user_id: int, channel: str) -> bool:
    try:
        member = await bot.get_chat_member(channel, user_id)
        return member.status not in ["left", "kicked", "banned"]
    except Exception:
        return False


# ── Main ─────────────────────────────────────────────────

async def main():
    dp.include_router(router)
    # Ikki vazifa parallel ishlatamiz
    await asyncio.gather(
        dp.start_polling(bot),
        run_humo_watcher(),
    )


if __name__ == "__main__":
    asyncio.run(main())
