"""
Telethon session string generatsiya qilish uchun.

Bir marta ishlatiladi:
  python gen_session.py

Chiqqan session stringni .env ga TELETHON_SESSION= ga qo'yish kerak.
"""
from telethon.sync import TelegramClient
from telethon.sessions import StringSession
import os

API_ID = int(input("API ID (my.telegram.org): "))
API_HASH = input("API Hash: ")

with TelegramClient(StringSession(), API_ID, API_HASH) as client:
    session_str = client.session.save()
    print("\n✅ Session string:\n")
    print(session_str)
    print("\n.env ga qo'ying: TELETHON_SESSION=" + session_str)
