#!/bin/bash
set -e

echo "🚀 UWallet deploy boshlandi..."

# .env tekshirish
if [ ! -f .env ]; then
  echo "❌ .env fayl topilmadi! .env.example dan nusxa oling:"
  echo "   cp .env.example .env && nano .env"
  exit 1
fi

# Docker build
echo "📦 Docker image build qilinmoqda..."
docker compose build

# DB migration
echo "🗄️ Database migration..."
docker compose run --rm backend alembic upgrade head

# Start
echo "▶️ Servislar ishga tushirilmoqda..."
docker compose up -d

echo ""
echo "✅ UWallet ishga tushdi!"
echo "   Frontend:  http://localhost:3000"
echo "   Backend:   http://localhost:8000/docs"
echo ""
echo "📋 Loglarni ko'rish:"
echo "   docker compose logs -f"
