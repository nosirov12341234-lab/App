from fastapi import APIRouter
from app.api.v1.endpoints import (
    auth, wallet, p2p, tasks, dapps, transfers, admin, uzs_deposit
)

router = APIRouter()

router.include_router(auth.router, prefix="/auth", tags=["auth"])
router.include_router(wallet.router, prefix="/wallet", tags=["wallet"])
router.include_router(p2p.router, prefix="/p2p", tags=["p2p"])
router.include_router(tasks.router, prefix="/tasks", tags=["tasks"])
router.include_router(dapps.router, prefix="/dapps", tags=["dapps"])
router.include_router(transfers.router, prefix="/transfers", tags=["transfers"])
router.include_router(admin.router, prefix="/admin", tags=["admin"])
router.include_router(uzs_deposit.router, prefix="/uzs-deposit", tags=["uzs-deposit"])
