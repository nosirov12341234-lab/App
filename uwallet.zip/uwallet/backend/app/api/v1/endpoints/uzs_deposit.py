from fastapi import APIRouter, Depends, HTTPException, Header
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from datetime import datetime, timedelta
from decimal import Decimal
from pydantic import BaseModel
from typing import Optional
import os

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.uzs_deposit import UzsDepositRequest
from app.models.models import Balance, Token, AdminSetting, Transaction, TxType, TxStatus

router = APIRouter()
BOT_SECRET = os.getenv("BOT_SECRET", "")


def verify_bot(x_bot_secret: str = Header(default="")):
    if BOT_SECRET and x_bot_secret != BOT_SECRET:
        raise HTTPException(status_code=403, detail="Bot secret noto'g'ri")


async def get_setting(db: AsyncSession, key: str, default: str = "") -> str:
    result = await db.execute(select(AdminSetting).where(AdminSetting.key == key))
    s = result.scalar_one_or_none()
    return s.value if s else default


class UzsDepositCreate(BaseModel):
    amount_uzs: Decimal


@router.post("/create")
async def create_uzs_deposit(
    req: UzsDepositCreate,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """User UZS kiritish so'rovi — karta raqami va timeout qaytadi"""
    card = await get_setting(db, "uzs_card_number")
    if not card:
        raise HTTPException(status_code=400, detail="Admin karta raqami sozlanmagan")

    timeout_min = int(await get_setting(db, "uzs_deposit_timeout_minutes", "15"))
    expires_at = datetime.utcnow() + timedelta(minutes=timeout_min)

    # Eski pending so'rovlarni bekor qilish
    old = await db.execute(
        select(UzsDepositRequest).where(
            UzsDepositRequest.user_id == current_user.id,
            UzsDepositRequest.status == "pending"
        )
    )
    for old_req in old.scalars().all():
        old_req.status = "expired"

    deposit = UzsDepositRequest(
        user_id=current_user.id,
        amount_uzs=req.amount_uzs,
        card_number=card,
        expires_at=expires_at,
    )
    db.add(deposit)
    await db.commit()
    await db.refresh(deposit)

    return {
        "deposit_id": deposit.id,
        "card_number": card,
        "amount_uzs": str(req.amount_uzs),
        "expires_at": expires_at.isoformat(),
        "timeout_minutes": timeout_min,
        "instruction": (
            f"Quyidagi kartaga aynan {float(req.amount_uzs):,.0f} UZS o'tkazing. "
            f"To'lov {timeout_min} daqiqa ichida avtomatik tasdiqlanadi."
        ),
    }


@router.get("/status/{deposit_id}")
async def get_deposit_status(
    deposit_id: int,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    dep = await db.get(UzsDepositRequest, deposit_id)
    if not dep or dep.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="So'rov topilmadi")

    if dep.status == "pending" and datetime.utcnow() > dep.expires_at:
        dep.status = "expired"
        await db.commit()

    return {
        "status": dep.status,
        "amount_uzs": str(dep.amount_uzs),
        "confirmed_at": dep.confirmed_at.isoformat() if dep.confirmed_at else None,
    }


class BotConfirmRequest(BaseModel):
    amount_uzs: float
    time_str: str       # "22:45 12.06.2026"
    card_last4: str


@router.post("/confirm-by-bot")
async def confirm_by_bot(
    req: BotConfirmRequest,
    db: AsyncSession = Depends(get_db),
    _=Depends(verify_bot),
):
    """
    HUMOcardbot dan xabar kelganda bot shu endpointni chaqiradi.
    Summa va vaqt oralig'iga mos pending so'rov topiladi → tasdiqlanadi.
    """
    timeout_min = int(await get_setting(db, "uzs_deposit_timeout_minutes", "15"))
    now = datetime.utcnow()
    window_start = now - timedelta(minutes=timeout_min)

    # Summaga mos pending so'rov topish
    result = await db.execute(
        select(UzsDepositRequest).where(
            UzsDepositRequest.status == "pending",
            UzsDepositRequest.created_at >= window_start,
        ).order_by(UzsDepositRequest.created_at.asc())
    )
    candidates = result.scalars().all()

    deposit = None
    for c in candidates:
        diff = abs(float(c.amount_uzs) - req.amount_uzs)
        if diff <= 100:  # 100 UZS farq toleranslik (bank komissiyasi)
            deposit = c
            break

    if not deposit:
        return {"confirmed": False, "reason": "Mos so'rov topilmadi"}

    # UZS token
    uzs_result = await db.execute(select(Token).where(Token.symbol == "UZS"))
    uzs_token = uzs_result.scalar_one_or_none()
    if not uzs_token:
        return {"confirmed": False, "reason": "UZS token DB da yo'q"}

    # Balansga qo'shish
    bal_result = await db.execute(
        select(Balance).where(
            Balance.user_id == deposit.user_id,
            Balance.token_id == uzs_token.id
        )
    )
    balance = bal_result.scalar_one_or_none()
    if balance:
        balance.amount += Decimal(str(req.amount_uzs))
    else:
        db.add(Balance(
            user_id=deposit.user_id,
            token_id=uzs_token.id,
            amount=Decimal(str(req.amount_uzs))
        ))

    # Transaction log
    db.add(Transaction(
        user_id=deposit.user_id,
        token_id=uzs_token.id,
        tx_type=TxType.DEPOSIT,
        status=TxStatus.CONFIRMED,
        amount=Decimal(str(req.amount_uzs)),
        note=f"HUMOcard deposit — {req.time_str}",
    ))

    deposit.status = "confirmed"
    deposit.actual_amount = Decimal(str(req.amount_uzs))
    deposit.confirmed_at = now
    deposit.humo_tx_time = req.time_str

    await db.commit()
    return {"confirmed": True, "user_id": deposit.user_id, "amount_uzs": req.amount_uzs}
