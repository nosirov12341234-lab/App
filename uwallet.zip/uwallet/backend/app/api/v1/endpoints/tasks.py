from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import Task, TaskCompletion, Balance, TaskType

router = APIRouter()


@router.get("/")
async def get_tasks(
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Task).where(Task.is_active == True))
    tasks = result.scalars().all()

    comp_result = await db.execute(
        select(TaskCompletion).where(TaskCompletion.user_id == current_user.id)
    )
    completions = {c.task_id: c for c in comp_result.scalars().all()}

    return [
        {
            "id": t.id,
            "title": t.title,
            "description": t.description,
            "type": t.task_type,
            "target": t.target,
            "reward_amount": str(t.reward_amount),
            "reward_token_id": t.reward_token_id,
            "completed": t.id in completions,
            "verified": completions[t.id].is_verified if t.id in completions else False,
        }
        for t in tasks
    ]


@router.post("/{task_id}/complete")
async def complete_task(
    task_id: int,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    task = await db.get(Task, task_id)
    if not task or not task.is_active:
        raise HTTPException(status_code=404, detail="Task topilmadi")

    existing = await db.execute(
        select(TaskCompletion).where(
            TaskCompletion.user_id == current_user.id,
            TaskCompletion.task_id == task_id
        )
    )
    comp = existing.scalar_one_or_none()

    if comp and comp.is_verified:
        return {"message": "Tasdiqlandi", "already_rewarded": True}

    if comp:
        # Link task — ikkinchi urinishda tasdiqlash
        if task.task_type == TaskType.LINK:
            comp.is_verified = True
            comp.reward_paid = True
            bal = await db.execute(
                select(Balance).where(
                    Balance.user_id == current_user.id,
                    Balance.token_id == task.reward_token_id
                )
            )
            balance = bal.scalar_one_or_none()
            if balance:
                balance.amount += task.reward_amount
            else:
                db.add(Balance(
                    user_id=current_user.id,
                    token_id=task.reward_token_id,
                    amount=task.reward_amount
                ))
            await db.commit()
            return {"message": "Tasdiqlandi! Mukofot berildi", "reward": str(task.reward_amount)}
        return {"message": "Birinchi marta bajarilmadi, qayta urinib ko'ring"}

    db.add(TaskCompletion(
        user_id=current_user.id,
        task_id=task_id,
        is_verified=False,
    ))
    await db.commit()
    return {"message": "So'rov qabul qilindi"}
