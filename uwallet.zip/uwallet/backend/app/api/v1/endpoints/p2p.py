from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import P2POrder, P2PTrade, Balance, Token, P2POrderType, P2POrderStatus
from pydantic import BaseModel
from decimal import Decimal
from typing import Optional

router = APIRouter()


class CreateOrderRequest(BaseModel):
    token_id: int
    order_type: P2POrderType
    amount: Decimal
    price_uzs: Decimal
    payment_method: str
    min_amount: Optional[Decimal] = None
    max_amount: Optional[Decimal] = None
    note: Optional[str] = None


@router.get("/orders")
async def get_orders(
    token_id: Optional[int] = None,
    order_type: Optional[P2POrderType] = None,
    db: AsyncSession = Depends(get_db),
):
    q = select(P2POrder, Token).join(Token).where(P2POrder.status == P2POrderStatus.OPEN)
    if token_id:
        q = q.where(P2POrder.token_id == token_id)
    if order_type:
        q = q.where(P2POrder.order_type == order_type)
    result = await db.execute(q.order_by(P2POrder.created_at.desc()))
    rows = result.all()
    return [
        {
            "id": order.id,
            "user_id": order.user_id,
            "token": token.symbol,
            "type": order.order_type,
            "amount": str(order.amount),
            "price_uzs": str(order.price_uzs),
            "payment_method": order.payment_method,
            "min_amount": str(order.min_amount) if order.min_amount else None,
            "max_amount": str(order.max_amount) if order.max_amount else None,
            "note": order.note,
            "created_at": order.created_at.isoformat(),
        }
        for order, token in rows
    ]


@router.post("/orders")
async def create_order(
    req: CreateOrderRequest,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if req.order_type == P2POrderType.SELL:
        result = await db.execute(
            select(Balance).where(
                Balance.user_id == current_user.id,
                Balance.token_id == req.token_id
            )
        )
        balance = result.scalar_one_or_none()
        if not balance or balance.amount - balance.frozen < req.amount:
            raise HTTPException(status_code=400, detail="Yetarli balans yo'q")
        balance.frozen += req.amount

    order = P2POrder(
        user_id=current_user.id,
        token_id=req.token_id,
        order_type=req.order_type,
        amount=req.amount,
        price_uzs=req.price_uzs,
        payment_method=req.payment_method,
        min_amount=req.min_amount,
        max_amount=req.max_amount,
        note=req.note,
    )
    db.add(order)
    await db.commit()
    return {"message": "E'lon qo'shildi", "order_id": order.id}


@router.post("/orders/{order_id}/cancel")
async def cancel_order(
    order_id: int,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    order = await db.get(P2POrder, order_id)
    if not order or order.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="E'lon topilmadi")
    if order.status != P2POrderStatus.OPEN:
        raise HTTPException(status_code=400, detail="E'lon bekor qilib bo'lmaydi")

    if order.order_type == P2POrderType.SELL:
        result = await db.execute(
            select(Balance).where(
                Balance.user_id == current_user.id,
                Balance.token_id == order.token_id
            )
        )
        balance = result.scalar_one_or_none()
        if balance:
            balance.frozen -= order.amount

    order.status = P2POrderStatus.CANCELLED
    await db.commit()
    return {"message": "E'lon bekor qilindi"}
