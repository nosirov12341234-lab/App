from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import (
    Token, Task, TaskType, DApp, DAppCategory,
    WithdrawRequest, TxStatus, Balance, AdminSetting
)
from pydantic import BaseModel
from decimal import Decimal
from typing import Optional

router = APIRouter()


def require_admin(current_user=Depends(get_current_user)):
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Admin huquqi kerak")
    return current_user


# ── Tokens ──────────────────────────────────────────────

class TokenCreate(BaseModel):
    symbol: str
    name: str
    network: str
    contract_address: Optional[str] = None
    decimals: int = 9
    deposit_fee_percent: Decimal = Decimal("0")
    withdraw_fee_percent: Decimal = Decimal("1")
    withdraw_fee_flat: Decimal = Decimal("0")
    min_deposit: Decimal = Decimal("1")
    min_withdraw: Decimal = Decimal("1")
    icon_url: Optional[str] = None
    is_default: bool = False


@router.post("/tokens")
async def add_token(
    req: TokenCreate,
    admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    token = Token(**req.model_dump())
    db.add(token)
    await db.commit()
    return {"message": "Token qo'shildi"}


# ── Withdraw Requests ─────────────────────────────────

@router.get("/withdraws")
async def get_pending_withdraws(
    admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(WithdrawRequest).where(WithdrawRequest.status == TxStatus.PENDING)
        .order_by(WithdrawRequest.created_at)
    )
    reqs = result.scalars().all()
    return [
        {
            "id": r.id,
            "user_id": r.user_id,
            "token_id": r.token_id,
            "amount": str(r.amount),
            "fee": str(r.fee),
            "destination": r.destination,
            "created_at": r.created_at.isoformat(),
        }
        for r in reqs
    ]


@router.post("/withdraws/{withdraw_id}/approve")
async def approve_withdraw(
    withdraw_id: int,
    tx_hash: str = "",
    admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    req = await db.get(WithdrawRequest, withdraw_id)
    if not req or req.status != TxStatus.PENDING:
        raise HTTPException(status_code=404, detail="So'rov topilmadi")

    # Balansdan ayirish
    bal = await db.execute(
        select(Balance).where(Balance.user_id == req.user_id, Balance.token_id == req.token_id)
    )
    balance = bal.scalar_one_or_none()
    if balance:
        balance.frozen -= req.amount
        balance.amount -= req.amount

    req.status = TxStatus.CONFIRMED
    req.tx_hash = tx_hash
    await db.commit()
    return {"message": "Tasdiqlandi"}


@router.post("/withdraws/{withdraw_id}/reject")
async def reject_withdraw(
    withdraw_id: int,
    admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    req = await db.get(WithdrawRequest, withdraw_id)
    if not req or req.status != TxStatus.PENDING:
        raise HTTPException(status_code=404, detail="So'rov topilmadi")

    bal = await db.execute(
        select(Balance).where(Balance.user_id == req.user_id, Balance.token_id == req.token_id)
    )
    balance = bal.scalar_one_or_none()
    if balance:
        balance.frozen -= req.amount

    req.status = TxStatus.FAILED
    await db.commit()
    return {"message": "Rad etildi"}


# ── Tasks ────────────────────────────────────────────────

class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    task_type: TaskType
    target: str
    reward_token_id: int
    reward_amount: Decimal


@router.post("/tasks")
async def create_task(
    req: TaskCreate,
    admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    task = Task(**req.model_dump())
    db.add(task)
    await db.commit()
    return {"message": "Task yaratildi"}


# ── Settings ─────────────────────────────────────────────

class SettingUpdate(BaseModel):
    key: str
    value: str


ALLOWED_SETTINGS = {
    "uzs_card_number": "UZS qabul qilish karta raqami (Humo/Uzcard)",
    "uzs_deposit_timeout_minutes": "UZS deposit tasdiqlash vaqti (daqiqa)",
    "pool_wallet_address": "Pool wallet TON manzili",
    "platform_fee_percent": "Platforma komissiyasi (%)",
    "p2p_fee_percent": "P2P savdo komissiyasi (%)",
    "referral_reward_uzs": "Referal mukofoti (UZS)",
}


@router.get("/settings")
async def get_settings(
    admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(AdminSetting))
    settings = result.scalars().all()
    data = {s.key: s.value for s in settings}
    return {
        key: {"value": data.get(key, ""), "description": desc}
        for key, desc in ALLOWED_SETTINGS.items()
    }


@router.post("/settings")
async def update_setting(
    req: SettingUpdate,
    admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    if req.key not in ALLOWED_SETTINGS:
        raise HTTPException(status_code=400, detail="Noto'g'ri sozlama kaliti")
    setting = await db.get(AdminSetting, req.key)
    if setting:
        setting.value = req.value
    else:
        db.add(AdminSetting(key=req.key, value=req.value))
    await db.commit()
    return {"message": "Saqlandi"}


# ── UZS Deposits (pending list) ──────────────────────────

@router.get("/uzs-deposits")
async def get_pending_uzs_deposits(
    admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    from app.models.uzs_deposit import UzsDepositRequest
    result = await db.execute(
        select(UzsDepositRequest)
        .where(UzsDepositRequest.status == "pending")
        .order_by(UzsDepositRequest.created_at)
    )
    deps = result.scalars().all()
    return [
        {
            "id": d.id,
            "user_id": d.user_id,
            "amount_uzs": str(d.amount_uzs),
            "card_number": d.card_number,
            "expires_at": d.expires_at.isoformat(),
            "created_at": d.created_at.isoformat(),
        }
        for d in deps
    ]


# ── DApps ────────────────────────────────────────────────

class CategoryCreate(BaseModel):
    name: str
    icon: Optional[str] = None
    order: int = 0


class DAppCreate(BaseModel):
    category_id: int
    name: str
    description: Optional[str] = None
    url: str
    icon_url: Optional[str] = None
    is_featured: bool = False
    order: int = 0


@router.post("/dapp-categories")
async def create_category(
    req: CategoryCreate,
    admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    cat = DAppCategory(**req.model_dump())
    db.add(cat)
    await db.commit()
    return {"message": "Kategoriya qo'shildi"}


@router.post("/dapps")
async def create_dapp(
    req: DAppCreate,
    admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    dapp = DApp(**req.model_dump())
    db.add(dapp)
    await db.commit()
    return {"message": "DApp qo'shildi"}
