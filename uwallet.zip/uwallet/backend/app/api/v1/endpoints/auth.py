import hashlib
import hmac
import json
from urllib.parse import unquote
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.config import settings
from app.core.database import get_db
from app.models.models import User
from app.core.security import create_access_token
from sqlalchemy import select
import secrets

router = APIRouter()


def verify_telegram_webapp(init_data: str) -> dict:
    """Telegram WebApp initData ni tekshirish"""
    vals = dict(item.split("=", 1) for item in init_data.split("&"))
    hash_val = vals.pop("hash", "")
    data_check = "\n".join(f"{k}={unquote(v)}" for k, v in sorted(vals.items()))
    secret = hmac.new(b"WebAppData", settings.BOT_TOKEN.encode(), hashlib.sha256).digest()
    computed = hmac.new(secret, data_check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(computed, hash_val):
        raise HTTPException(status_code=401, detail="Invalid Telegram data")
    user_data = json.loads(unquote(vals.get("user", "{}")))
    return user_data


@router.post("/login")
async def login(init_data: str, db: AsyncSession = Depends(get_db)):
    user_data = verify_telegram_webapp(init_data)
    telegram_id = user_data["id"]

    result = await db.execute(select(User).where(User.id == telegram_id))
    user = result.scalar_one_or_none()

    if not user:
        user = User(
            id=telegram_id,
            username=user_data.get("username"),
            first_name=user_data.get("first_name", ""),
            last_name=user_data.get("last_name"),
            uwallet_id=f"uwallet_{telegram_id}",
            referral_code=secrets.token_urlsafe(8),
            is_admin=telegram_id in settings.admin_ids,
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)

    token = create_access_token({"sub": str(telegram_id)})
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "uwallet_id": user.uwallet_id,
            "username": user.username,
            "first_name": user.first_name,
            "is_admin": user.is_admin,
        }
    }
