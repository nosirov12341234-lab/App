# transfers.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import Transfer, Balance, User
from pydantic import BaseModel
from decimal import Decimal

router = APIRouter()


class TransferRequest(BaseModel):
    to_uwallet_id: str
    token_id: int
    amount: Decimal
    note: str = ""


@router.get("/lookup/{uwallet_id}")
async def lookup_user(uwallet_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.uwallet_id == uwallet_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Foydalanuvchi topilmadi")
    return {
        "uwallet_id": user.uwallet_id,
        "first_name": user.first_name,
        "last_name": user.last_name,
        "username": user.username,
    }


@router.post("/send")
async def send_transfer(
    req: TransferRequest,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if req.to_uwallet_id == current_user.uwallet_id:
        raise HTTPException(status_code=400, detail="O'zingizga yubora olmaysiz")

    result = await db.execute(select(User).where(User.uwallet_id == req.to_uwallet_id))
    to_user = result.scalar_one_or_none()
    if not to_user:
        raise HTTPException(status_code=404, detail="Qabul qiluvchi topilmadi")

    from_bal = await db.execute(
        select(Balance).where(Balance.user_id == current_user.id, Balance.token_id == req.token_id)
    )
    from_balance = from_bal.scalar_one_or_none()
    if not from_balance or from_balance.amount - from_balance.frozen < req.amount:
        raise HTTPException(status_code=400, detail="Yetarli balans yo'q")

    to_bal = await db.execute(
        select(Balance).where(Balance.user_id == to_user.id, Balance.token_id == req.token_id)
    )
    to_balance = to_bal.scalar_one_or_none()

    from_balance.amount -= req.amount
    if to_balance:
        to_balance.amount += req.amount
    else:
        db.add(Balance(user_id=to_user.id, token_id=req.token_id, amount=req.amount))

    transfer = Transfer(
        from_user_id=current_user.id,
        to_user_id=to_user.id,
        token_id=req.token_id,
        amount=req.amount,
        note=req.note,
    )
    db.add(transfer)
    await db.commit()
    return {"message": "O'tkazma muvaffaqiyatli amalga oshirildi"}
