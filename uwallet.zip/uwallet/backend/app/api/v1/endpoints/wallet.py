from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import Balance, Token, Transaction, TxType, TxStatus, WithdrawRequest
from pydantic import BaseModel
from decimal import Decimal

router = APIRouter()


@router.get("/balances")
async def get_balances(
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(
        select(Balance, Token)
        .join(Token)
        .where(Balance.user_id == current_user.id, Token.is_active == True)
    )
    rows = result.all()
    return [
        {
            "token": {
                "id": token.id,
                "symbol": token.symbol,
                "name": token.name,
                "network": token.network,
                "icon_url": token.icon_url,
                "is_default": token.is_default,
            },
            "amount": str(balance.amount),
            "frozen": str(balance.frozen),
            "available": str(balance.amount - balance.frozen),
        }
        for balance, token in rows
    ]


@router.get("/tokens")
async def get_tokens(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Token).where(Token.is_active == True).order_by(Token.is_default.desc())
    )
    tokens = result.scalars().all()
    return [
        {
            "id": t.id,
            "symbol": t.symbol,
            "name": t.name,
            "network": t.network,
            "decimals": t.decimals,
            "deposit_fee_percent": str(t.deposit_fee_percent),
            "withdraw_fee_percent": str(t.withdraw_fee_percent),
            "withdraw_fee_flat": str(t.withdraw_fee_flat),
            "min_deposit": str(t.min_deposit),
            "min_withdraw": str(t.min_withdraw),
            "icon_url": t.icon_url,
        }
        for t in tokens
    ]


@router.get("/deposit-address")
async def get_deposit_address(
    token_id: int,
    current_user=Depends(get_current_user),
):
    """Master wallet manzili + memo (user_id)"""
    from app.core.config import settings
    return {
        "address": settings.MASTER_WALLET_ADDRESS,
        "memo": str(current_user.id),
        "note": "Depozit paytida memo/comment maydoniga Telegram ID ni kiriting"
    }


class WithdrawRequest_(BaseModel):
    token_id: int
    amount: Decimal
    destination: str  # wallet address yoki karta raqami


@router.post("/withdraw")
async def create_withdraw(
    req: WithdrawRequest_,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    # Balance tekshirish
    result = await db.execute(
        select(Balance).where(
            Balance.user_id == current_user.id,
            Balance.token_id == req.token_id
        )
    )
    balance = result.scalar_one_or_none()
    if not balance or balance.amount - balance.frozen < req.amount:
        raise HTTPException(status_code=400, detail="Yetarli balans yo'q")

    # Token info
    token = await db.get(Token, req.token_id)
    if not token:
        raise HTTPException(status_code=404, detail="Token topilmadi")

    # Fee hisoblash
    fee = req.amount * token.withdraw_fee_percent / 100 + token.withdraw_fee_flat

    # Balansdан ushlab qo'yish
    balance.frozen += req.amount
    withdraw = WithdrawRequest(
        user_id=current_user.id,
        token_id=req.token_id,
        amount=req.amount,
        fee=fee,
        destination=req.destination,
    )
    db.add(withdraw)
    await db.commit()
    return {"message": "So'rov yuborildi, admin tasdiqlaydi", "fee": str(fee)}


@router.get("/history")
async def get_history(
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    limit: int = 50,
    offset: int = 0,
):
    result = await db.execute(
        select(Transaction, Token)
        .join(Token)
        .where(Transaction.user_id == current_user.id)
        .order_by(Transaction.created_at.desc())
        .limit(limit).offset(offset)
    )
    rows = result.all()
    return [
        {
            "id": tx.id,
            "type": tx.tx_type,
            "status": tx.status,
            "amount": str(tx.amount),
            "fee": str(tx.fee),
            "token": tx_token.symbol,
            "tx_hash": tx.tx_hash,
            "note": tx.note,
            "created_at": tx.created_at.isoformat(),
        }
        for tx, tx_token in rows
    ]
