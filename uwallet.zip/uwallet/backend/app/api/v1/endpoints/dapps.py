from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.models.models import DApp, DAppCategory

router = APIRouter()


@router.get("/")
async def get_dapps(db: AsyncSession = Depends(get_db)):
    cats = await db.execute(
        select(DAppCategory).where(DAppCategory.is_active == True).order_by(DAppCategory.order)
    )
    categories = cats.scalars().all()

    result = []
    for cat in categories:
        apps = await db.execute(
            select(DApp).where(DApp.category_id == cat.id, DApp.is_active == True).order_by(DApp.order)
        )
        dapps = apps.scalars().all()
        result.append({
            "id": cat.id,
            "name": cat.name,
            "icon": cat.icon,
            "dapps": [
                {
                    "id": d.id,
                    "name": d.name,
                    "description": d.description,
                    "url": d.url,
                    "icon_url": d.icon_url,
                    "is_featured": d.is_featured,
                }
                for d in dapps
            ]
        })
    return result
