# models/uzs_deposit.py — UZS deposit so'rovlari uchun jadval
from datetime import datetime
from sqlalchemy import BigInteger, Column, DateTime, Integer, Numeric, String, Boolean
from app.models.models import Base


class UzsDepositRequest(Base):
    __tablename__ = "uzs_deposit_requests"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger)                    # telegram_id
    amount_uzs = Column(Numeric(18, 2))             # user kiritgan summa
    actual_amount = Column(Numeric(18, 2), nullable=True)  # HUMOcardbot dan kelgan summa
    status = Column(String(20), default="pending")  # pending, confirmed, expired, failed
    card_number = Column(String(20))                # admin kartasi (snapshot)
    expires_at = Column(DateTime)                   # timeout vaqti
    confirmed_at = Column(DateTime, nullable=True)
    humo_tx_time = Column(String(32), nullable=True)  # "22:45 12.06.2026"
    created_at = Column(DateTime, default=datetime.utcnow)
