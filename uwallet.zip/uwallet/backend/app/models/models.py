from datetime import datetime
from decimal import Decimal
from sqlalchemy import (
    BigInteger, Boolean, Column, DateTime, ForeignKey,
    Integer, Numeric, String, Text, Enum as SAEnum
)
from sqlalchemy.orm import DeclarativeBase, relationship
import enum


class Base(DeclarativeBase):
    pass


class TxType(str, enum.Enum):
    DEPOSIT = "deposit"
    WITHDRAW = "withdraw"
    TRANSFER_IN = "transfer_in"
    TRANSFER_OUT = "transfer_out"
    P2P_BUY = "p2p_buy"
    P2P_SELL = "p2p_sell"
    TASK_REWARD = "task_reward"
    REFERRAL_REWARD = "referral_reward"
    FEE = "fee"


class TxStatus(str, enum.Enum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class P2POrderType(str, enum.Enum):
    BUY = "buy"
    SELL = "sell"


class P2POrderStatus(str, enum.Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    DISPUTED = "disputed"


class TaskType(str, enum.Enum):
    CHANNEL = "channel"
    LINK = "link"


class User(Base):
    __tablename__ = "users"

    id = Column(BigInteger, primary_key=True)  # telegram_id
    username = Column(String(64), nullable=True)
    first_name = Column(String(128))
    last_name = Column(String(128), nullable=True)
    uwallet_id = Column(String(64), unique=True)  # uwallet_<telegram_id>
    is_admin = Column(Boolean, default=False)
    is_banned = Column(Boolean, default=False)
    referral_code = Column(String(32), unique=True)
    referred_by_id = Column(BigInteger, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    balances = relationship("Balance", back_populates="user")
    transactions = relationship("Transaction", back_populates="user")
    p2p_orders = relationship("P2POrder", back_populates="user")
    task_completions = relationship("TaskCompletion", back_populates="user")


class Token(Base):
    __tablename__ = "tokens"

    id = Column(Integer, primary_key=True, autoincrement=True)
    symbol = Column(String(16), unique=True)  # USDT, TON, USDC
    name = Column(String(64))
    network = Column(String(32))  # TON, TRC20, ERC20
    contract_address = Column(String(128), nullable=True)
    decimals = Column(Integer, default=9)
    is_active = Column(Boolean, default=True)
    is_default = Column(Boolean, default=False)  # USDT, TON, USDC
    deposit_fee_percent = Column(Numeric(5, 2), default=0)
    withdraw_fee_percent = Column(Numeric(5, 2), default=1)
    withdraw_fee_flat = Column(Numeric(18, 6), default=0)
    min_deposit = Column(Numeric(18, 6), default=1)
    min_withdraw = Column(Numeric(18, 6), default=1)
    icon_url = Column(String(256), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Balance(Base):
    __tablename__ = "balances"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, ForeignKey("users.id"))
    token_id = Column(Integer, ForeignKey("tokens.id"))
    amount = Column(Numeric(18, 6), default=0)
    frozen = Column(Numeric(18, 6), default=0)  # P2P uchun

    user = relationship("User", back_populates="balances")
    token = relationship("Token")


class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, ForeignKey("users.id"))
    token_id = Column(Integer, ForeignKey("tokens.id"))
    tx_type = Column(SAEnum(TxType))
    status = Column(SAEnum(TxStatus), default=TxStatus.PENDING)
    amount = Column(Numeric(18, 6))
    fee = Column(Numeric(18, 6), default=0)
    tx_hash = Column(String(128), nullable=True)  # blockchain tx
    note = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="transactions")
    token = relationship("Token")


class WithdrawRequest(Base):
    __tablename__ = "withdraw_requests"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, ForeignKey("users.id"))
    token_id = Column(Integer, ForeignKey("tokens.id"))
    amount = Column(Numeric(18, 6))
    fee = Column(Numeric(18, 6), default=0)
    destination = Column(String(256))  # wallet address yoki karta raqami
    status = Column(SAEnum(TxStatus), default=TxStatus.PENDING)
    admin_note = Column(Text, nullable=True)
    tx_hash = Column(String(128), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Transfer(Base):
    __tablename__ = "transfers"

    id = Column(Integer, primary_key=True, autoincrement=True)
    from_user_id = Column(BigInteger, ForeignKey("users.id"))
    to_user_id = Column(BigInteger, ForeignKey("users.id"))
    token_id = Column(Integer, ForeignKey("tokens.id"))
    amount = Column(Numeric(18, 6))
    note = Column(String(256), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class P2POrder(Base):
    __tablename__ = "p2p_orders"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, ForeignKey("users.id"))
    token_id = Column(Integer, ForeignKey("tokens.id"))
    order_type = Column(SAEnum(P2POrderType))  # BUY or SELL
    status = Column(SAEnum(P2POrderStatus), default=P2POrderStatus.OPEN)
    amount = Column(Numeric(18, 6))      # token miqdori
    price_uzs = Column(Numeric(18, 2))   # 1 token = ? UZS
    min_amount = Column(Numeric(18, 6), nullable=True)
    max_amount = Column(Numeric(18, 6), nullable=True)
    payment_method = Column(String(128))  # Uzcard, Humo, Click, ...
    note = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="p2p_orders")
    token = relationship("Token")


class P2PTrade(Base):
    __tablename__ = "p2p_trades"

    id = Column(Integer, primary_key=True, autoincrement=True)
    order_id = Column(Integer, ForeignKey("p2p_orders.id"))
    buyer_id = Column(BigInteger, ForeignKey("users.id"))
    seller_id = Column(BigInteger, ForeignKey("users.id"))
    token_id = Column(Integer, ForeignKey("tokens.id"))
    amount = Column(Numeric(18, 6))
    price_uzs = Column(Numeric(18, 2))
    total_uzs = Column(Numeric(18, 2))
    platform_fee = Column(Numeric(18, 6), default=0)
    status = Column(SAEnum(P2POrderStatus), default=P2POrderStatus.IN_PROGRESS)
    payment_confirmed_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Task(Base):
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String(256))
    description = Column(Text, nullable=True)
    task_type = Column(SAEnum(TaskType))
    target = Column(String(256))  # kanal username yoki URL
    reward_token_id = Column(Integer, ForeignKey("tokens.id"))
    reward_amount = Column(Numeric(18, 6))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class TaskCompletion(Base):
    __tablename__ = "task_completions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, ForeignKey("users.id"))
    task_id = Column(Integer, ForeignKey("tasks.id"))
    is_verified = Column(Boolean, default=False)
    reward_paid = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="task_completions")


class DAppCategory(Base):
    __tablename__ = "dapp_categories"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(64))
    icon = Column(String(256), nullable=True)
    order = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)

    dapps = relationship("DApp", back_populates="category")


class DApp(Base):
    __tablename__ = "dapps"

    id = Column(Integer, primary_key=True, autoincrement=True)
    category_id = Column(Integer, ForeignKey("dapp_categories.id"))
    name = Column(String(128))
    description = Column(Text, nullable=True)
    url = Column(String(512))
    icon_url = Column(String(512), nullable=True)
    is_active = Column(Boolean, default=True)
    is_featured = Column(Boolean, default=False)
    order = Column(Integer, default=0)

    category = relationship("DAppCategory", back_populates="dapps")


class AdminSetting(Base):
    __tablename__ = "admin_settings"

    key = Column(String(64), primary_key=True)
    value = Column(Text)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
