from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    DEBUG: bool = False
    DATABASE_URL: str
    REDIS_URL: str = "redis://redis:6379/0"
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    REFRESH_TOKEN_EXPIRE_DAYS: int = 30
    BOT_TOKEN: str
    WEBAPP_URL: str
    MASTER_WALLET_ADDRESS: str
    MASTER_WALLET_MNEMONIC: str
    TONAPI_KEY: str
    TON_NETWORK: str = "mainnet"
    ADMIN_TELEGRAM_IDS: str = ""
    LOG_CHANNEL_ID: str = ""
    PLATFORM_NAME: str = "UWallet"
    PLATFORM_FEE_PERCENT: float = 1.0
    P2P_FEE_PERCENT: float = 0.5

    @property
    def admin_ids(self) -> list[int]:
        return [int(i) for i in self.ADMIN_TELEGRAM_IDS.split(",") if i.strip()]

    class Config:
        env_file = ".env"


settings = Settings()
