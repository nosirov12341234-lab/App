"""initial

Revision ID: 001
Revises: 
Create Date: 2026-01-01
"""
from alembic import op
import sqlalchemy as sa

revision = '001'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('users',
        sa.Column('id', sa.BigInteger(), primary_key=True),
        sa.Column('username', sa.String(64), nullable=True),
        sa.Column('first_name', sa.String(128), nullable=False),
        sa.Column('last_name', sa.String(128), nullable=True),
        sa.Column('uwallet_id', sa.String(64), unique=True),
        sa.Column('is_admin', sa.Boolean(), default=False),
        sa.Column('is_banned', sa.Boolean(), default=False),
        sa.Column('referral_code', sa.String(32), unique=True),
        sa.Column('referred_by_id', sa.BigInteger(), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('created_at', sa.DateTime()),
    )
    op.create_table('tokens',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('symbol', sa.String(16), unique=True),
        sa.Column('name', sa.String(64)),
        sa.Column('network', sa.String(32)),
        sa.Column('contract_address', sa.String(128), nullable=True),
        sa.Column('decimals', sa.Integer(), default=9),
        sa.Column('is_active', sa.Boolean(), default=True),
        sa.Column('is_default', sa.Boolean(), default=False),
        sa.Column('deposit_fee_percent', sa.Numeric(5, 2), default=0),
        sa.Column('withdraw_fee_percent', sa.Numeric(5, 2), default=1),
        sa.Column('withdraw_fee_flat', sa.Numeric(18, 6), default=0),
        sa.Column('min_deposit', sa.Numeric(18, 6), default=1),
        sa.Column('min_withdraw', sa.Numeric(18, 6), default=1),
        sa.Column('icon_url', sa.String(256), nullable=True),
        sa.Column('created_at', sa.DateTime()),
    )
    op.create_table('balances',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('user_id', sa.BigInteger(), sa.ForeignKey('users.id')),
        sa.Column('token_id', sa.Integer(), sa.ForeignKey('tokens.id')),
        sa.Column('amount', sa.Numeric(18, 6), default=0),
        sa.Column('frozen', sa.Numeric(18, 6), default=0),
    )
    op.create_table('transactions',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('user_id', sa.BigInteger(), sa.ForeignKey('users.id')),
        sa.Column('token_id', sa.Integer(), sa.ForeignKey('tokens.id')),
        sa.Column('tx_type', sa.String(32)),
        sa.Column('status', sa.String(20), default='pending'),
        sa.Column('amount', sa.Numeric(18, 6)),
        sa.Column('fee', sa.Numeric(18, 6), default=0),
        sa.Column('tx_hash', sa.String(128), nullable=True),
        sa.Column('note', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime()),
        sa.Column('updated_at', sa.DateTime()),
    )
    op.create_table('withdraw_requests',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('user_id', sa.BigInteger(), sa.ForeignKey('users.id')),
        sa.Column('token_id', sa.Integer(), sa.ForeignKey('tokens.id')),
        sa.Column('amount', sa.Numeric(18, 6)),
        sa.Column('fee', sa.Numeric(18, 6), default=0),
        sa.Column('destination', sa.String(256)),
        sa.Column('status', sa.String(20), default='pending'),
        sa.Column('admin_note', sa.Text(), nullable=True),
        sa.Column('tx_hash', sa.String(128), nullable=True),
        sa.Column('created_at', sa.DateTime()),
        sa.Column('updated_at', sa.DateTime()),
    )
    op.create_table('transfers',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('from_user_id', sa.BigInteger(), sa.ForeignKey('users.id')),
        sa.Column('to_user_id', sa.BigInteger(), sa.ForeignKey('users.id')),
        sa.Column('token_id', sa.Integer(), sa.ForeignKey('tokens.id')),
        sa.Column('amount', sa.Numeric(18, 6)),
        sa.Column('note', sa.String(256), nullable=True),
        sa.Column('created_at', sa.DateTime()),
    )
    op.create_table('p2p_orders',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('user_id', sa.BigInteger(), sa.ForeignKey('users.id')),
        sa.Column('token_id', sa.Integer(), sa.ForeignKey('tokens.id')),
        sa.Column('order_type', sa.String(10)),
        sa.Column('status', sa.String(20), default='open'),
        sa.Column('amount', sa.Numeric(18, 6)),
        sa.Column('price_uzs', sa.Numeric(18, 2)),
        sa.Column('min_amount', sa.Numeric(18, 6), nullable=True),
        sa.Column('max_amount', sa.Numeric(18, 6), nullable=True),
        sa.Column('payment_method', sa.String(128)),
        sa.Column('note', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime()),
    )
    op.create_table('p2p_trades',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('order_id', sa.Integer(), sa.ForeignKey('p2p_orders.id')),
        sa.Column('buyer_id', sa.BigInteger(), sa.ForeignKey('users.id')),
        sa.Column('seller_id', sa.BigInteger(), sa.ForeignKey('users.id')),
        sa.Column('token_id', sa.Integer(), sa.ForeignKey('tokens.id')),
        sa.Column('amount', sa.Numeric(18, 6)),
        sa.Column('price_uzs', sa.Numeric(18, 2)),
        sa.Column('total_uzs', sa.Numeric(18, 2)),
        sa.Column('platform_fee', sa.Numeric(18, 6), default=0),
        sa.Column('status', sa.String(20), default='in_progress'),
        sa.Column('payment_confirmed_at', sa.DateTime(), nullable=True),
        sa.Column('completed_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime()),
    )
    op.create_table('tasks',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('title', sa.String(256)),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('task_type', sa.String(20)),
        sa.Column('target', sa.String(256)),
        sa.Column('reward_token_id', sa.Integer(), sa.ForeignKey('tokens.id')),
        sa.Column('reward_amount', sa.Numeric(18, 6)),
        sa.Column('is_active', sa.Boolean(), default=True),
        sa.Column('created_at', sa.DateTime()),
    )
    op.create_table('task_completions',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('user_id', sa.BigInteger(), sa.ForeignKey('users.id')),
        sa.Column('task_id', sa.Integer(), sa.ForeignKey('tasks.id')),
        sa.Column('is_verified', sa.Boolean(), default=False),
        sa.Column('reward_paid', sa.Boolean(), default=False),
        sa.Column('created_at', sa.DateTime()),
    )
    op.create_table('dapp_categories',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('name', sa.String(64)),
        sa.Column('icon', sa.String(256), nullable=True),
        sa.Column('order', sa.Integer(), default=0),
        sa.Column('is_active', sa.Boolean(), default=True),
    )
    op.create_table('dapps',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('category_id', sa.Integer(), sa.ForeignKey('dapp_categories.id')),
        sa.Column('name', sa.String(128)),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('url', sa.String(512)),
        sa.Column('icon_url', sa.String(512), nullable=True),
        sa.Column('is_active', sa.Boolean(), default=True),
        sa.Column('is_featured', sa.Boolean(), default=False),
        sa.Column('order', sa.Integer(), default=0),
    )
    op.create_table('admin_settings',
        sa.Column('key', sa.String(64), primary_key=True),
        sa.Column('value', sa.Text()),
        sa.Column('updated_at', sa.DateTime()),
    )
    op.create_table('uzs_deposit_requests',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('user_id', sa.BigInteger()),
        sa.Column('amount_uzs', sa.Numeric(18, 2)),
        sa.Column('actual_amount', sa.Numeric(18, 2), nullable=True),
        sa.Column('status', sa.String(20), default='pending'),
        sa.Column('card_number', sa.String(20)),
        sa.Column('expires_at', sa.DateTime()),
        sa.Column('confirmed_at', sa.DateTime(), nullable=True),
        sa.Column('humo_tx_time', sa.String(32), nullable=True),
        sa.Column('created_at', sa.DateTime()),
    )

    # Default tokens
    op.execute("""
        INSERT INTO tokens (symbol, name, network, decimals, is_active, is_default,
            deposit_fee_percent, withdraw_fee_percent, withdraw_fee_flat, min_deposit, min_withdraw, created_at)
        VALUES
            ('USDT', 'Tether USD', 'TON', 6, true, true, 0, 1.0, 0, 1, 1, NOW()),
            ('TON',  'Toncoin',    'TON', 9, true, true, 0, 0.5, 0.01, 0.1, 0.1, NOW()),
            ('USDC', 'USD Coin',   'TON', 6, true, true, 0, 1.0, 0, 1, 1, NOW()),
            ('UZS',  'O''zbek So''mi', 'FIAT', 0, true, true, 0, 0, 0, 1000, 10000, NOW())
    """)


def downgrade():
    for tbl in ['uzs_deposit_requests','admin_settings','dapps','dapp_categories',
                'task_completions','tasks','p2p_trades','p2p_orders','transfers',
                'withdraw_requests','transactions','balances','tokens','users']:
        op.drop_table(tbl)
