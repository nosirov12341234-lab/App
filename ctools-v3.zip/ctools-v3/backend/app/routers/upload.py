from fastapi import APIRouter, UploadFile, File, HTTPException, Depends
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import os, uuid, shutil

from app.database import get_db
from app.models import ProductImage

router = APIRouter()
UPLOAD_DIR = "/app/uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

def save_file(file: UploadFile) -> str:
    ext = (file.filename or "img.jpg").split(".")[-1].lower()
    if ext not in ["jpg","jpeg","png","webp","gif","bmp"]:
        ext = "jpg"
    filename = f"{uuid.uuid4().hex}.{ext}"
    path = os.path.join(UPLOAD_DIR, filename)
    with open(path, "wb") as f:
        shutil.copyfileobj(file.file, f)
    return filename

@router.post("/product/{product_id}")
async def add_product_image(
    product_id: int,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
):
    """Rasm yuklash — auth tekshiruvsiz (admin paneldan ishlatiladi)"""
    filename = save_file(file)
    result = await db.execute(
        select(ProductImage).where(ProductImage.product_id == product_id)
    )
    existing = result.scalars().all()
    img = ProductImage(
        product_id=product_id,
        filename=filename,
        is_main=len(existing) == 0,
        sort_order=len(existing),
    )
    db.add(img)
    await db.commit()
    await db.refresh(img)
    return {"id": img.id, "filename": filename, "is_main": img.is_main}

@router.get("/product/{product_id}")
async def get_product_images(product_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(ProductImage)
        .where(ProductImage.product_id == product_id)
        .order_by(ProductImage.sort_order)
    )
    imgs = result.scalars().all()
    return [{"id": i.id, "filename": i.filename, "is_main": i.is_main} for i in imgs]

@router.delete("/image/{image_id}")
async def delete_image(image_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(ProductImage).where(ProductImage.id == image_id))
    img = result.scalar_one_or_none()
    if not img:
        raise HTTPException(404, "Topilmadi")
    try:
        os.remove(os.path.join(UPLOAD_DIR, img.filename))
    except Exception:
        pass
    await db.delete(img)
    await db.commit()
    return {"success": True}

@router.get("/{filename}")
async def serve_image(filename: str):
    path = os.path.join(UPLOAD_DIR, filename)
    if not os.path.exists(path):
        raise HTTPException(404, "Topilmadi")
    return FileResponse(path, headers={"Cache-Control": "public, max-age=86400"})
