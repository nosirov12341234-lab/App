from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from app.database import get_db
from app.models import Category, Channel
from app.utils.auth import get_current_user, get_admin_user

cat_router = APIRouter()
ch_router  = APIRouter()

class CategoryBody(BaseModel):
    name: str
    emoji: str = "📦"

class ChannelBody(BaseModel):
    channel_id: int
    title: str
    username: str = ""

@cat_router.get("/")
async def list_categories(db: AsyncSession = Depends(get_db),
                          user: dict = Depends(get_current_user)):
    result = await db.execute(select(Category).where(Category.is_active == True))
    return [{"id": c.id, "name": c.name, "emoji": c.emoji} for c in result.scalars().all()]

@cat_router.post("/")
async def create_category(body: CategoryBody, db: AsyncSession = Depends(get_db),
                          user: dict = Depends(get_admin_user)):
    cat = Category(name=body.name, emoji=body.emoji)
    db.add(cat); await db.commit(); await db.refresh(cat)
    return {"id": cat.id, "name": cat.name}

@cat_router.put("/{cat_id}")
async def update_category(cat_id: int, body: CategoryBody,
                          db: AsyncSession = Depends(get_db),
                          user: dict = Depends(get_admin_user)):
    result = await db.execute(select(Category).where(Category.id == cat_id))
    cat = result.scalar_one_or_none()
    if not cat: raise HTTPException(404, "Topilmadi")
    cat.name = body.name; cat.emoji = body.emoji
    await db.commit(); return {"success": True}

@cat_router.delete("/{cat_id}")
async def delete_category(cat_id: int, db: AsyncSession = Depends(get_db),
                          user: dict = Depends(get_admin_user)):
    result = await db.execute(select(Category).where(Category.id == cat_id))
    cat = result.scalar_one_or_none()
    if not cat: raise HTTPException(404, "Topilmadi")
    cat.is_active = False; await db.commit(); return {"success": True}

@ch_router.get("/")
async def list_channels(db: AsyncSession = Depends(get_db),
                        user: dict = Depends(get_current_user)):
    result = await db.execute(select(Channel).where(Channel.is_active == True))
    return [{"id": c.id, "channel_id": c.channel_id, "title": c.title, "username": c.username}
            for c in result.scalars().all()]

@ch_router.post("/")
async def add_channel(body: ChannelBody, db: AsyncSession = Depends(get_db),
                      user: dict = Depends(get_admin_user)):
    ch = Channel(channel_id=body.channel_id, title=body.title, username=body.username)
    db.add(ch); await db.commit(); await db.refresh(ch)
    return {"id": ch.id}

@ch_router.delete("/{ch_id}")
async def remove_channel(ch_id: int, db: AsyncSession = Depends(get_db),
                         user: dict = Depends(get_admin_user)):
    result = await db.execute(select(Channel).where(Channel.id == ch_id))
    ch = result.scalar_one_or_none()
    if not ch: raise HTTPException(404, "Topilmadi")
    ch.is_active = False; await db.commit(); return {"success": True}
