from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import List
import httpx

from app.database import get_db
from app.models import Order, OrderItem, Product, User, OrderStatus
from app.utils.auth import get_current_user, get_admin_user
from app.config import settings

router = APIRouter()

class CartItem(BaseModel):
    product_id: int
    quantity: int

class CreateOrderRequest(BaseModel):
    items: List[CartItem]
    delivery_address: str = ""

@router.post("/create")
async def create_order(body: CreateOrderRequest,
                       db: AsyncSession = Depends(get_db),
                       user: dict = Depends(get_current_user)):
    if not body.items:
        raise HTTPException(400, "Savatcha bo'sh")

    result = await db.execute(select(User).where(User.id == user["id"]))
    db_user = result.scalar_one_or_none()
    if not db_user:
        db_user = User(
            id=user["id"],
            username=user.get("username"),
            full_name=(user.get("first_name","") + " " + user.get("last_name","")).strip()
        )
        db.add(db_user)

    order = Order(user_id=user["id"], delivery_address=body.delivery_address)
    db.add(order)
    await db.flush()

    total = 0
    items_info = []
    for item in body.items:
        result = await db.execute(
            select(Product).where(Product.id == item.product_id, Product.is_active == True)
        )
        product = result.scalar_one_or_none()
        if not product:
            raise HTTPException(404, f"Mahsulot #{item.product_id} topilmadi")
        db.add(OrderItem(
            order_id=order.id, product_id=product.id,
            quantity=item.quantity, unit_price=product.price
        ))
        total += float(product.price) * item.quantity
        items_info.append(f"• {product.name} × {item.quantity}")

    order.total_price = total
    await db.commit()
    await db.refresh(order)

    await _notify_admins(order, user, db, items_info)
    return {
        "order_id": order.id,
        "order_code": order.code,
        "total_price": float(order.total_price),
        "status": order.status
    }

@router.get("/my")
async def my_orders(db: AsyncSession = Depends(get_db),
                    user: dict = Depends(get_current_user)):
    result = await db.execute(
        select(Order).where(Order.user_id == user["id"]).order_by(Order.created_at.desc())
    )
    orders = result.scalars().all()
    return [{
        "id": o.id, "code": o.code, "status": o.status,
        "total_price": float(o.total_price),
        "created_at": o.created_at.isoformat() if o.created_at else None
    } for o in orders]

@router.get("/verify/{code}")
async def verify_order(code: str, db: AsyncSession = Depends(get_db),
                       user: dict = Depends(get_admin_user)):
    result = await db.execute(select(Order).where(Order.code == code.upper()))
    order = result.scalar_one_or_none()
    if not order:
        raise HTTPException(404, "Zakaz kodi topilmadi")
    items_data = []
    for item in order.items:
        items_data.append({
            "product_id": item.product_id,
            "product_name": item.product.name,
            "quantity": item.quantity,
            "unit_price": float(item.unit_price),
            "is_digital": item.product.is_digital,
            "secret_note": item.product.secret_note,
        })
    return {
        "order_id": order.id, "code": order.code, "status": order.status,
        "user_id": order.user_id, "delivery_address": order.delivery_address,
        "total_price": float(order.total_price), "items": items_data,
        "created_at": order.created_at.isoformat() if order.created_at else None
    }

@router.patch("/verify/{code}/status")
async def update_order_status(code: str, status: str, admin_note: str = "",
                               db: AsyncSession = Depends(get_db),
                               user: dict = Depends(get_admin_user)):
    valid = [s.value for s in OrderStatus]
    if status not in valid:
        raise HTTPException(400, "Noto'g'ri holat")
    result = await db.execute(select(Order).where(Order.code == code.upper()))
    order = result.scalar_one_or_none()
    if not order:
        raise HTTPException(404, "Topilmadi")
    order.status = status
    order.admin_note = admin_note
    order.verified_by = user.get("id")
    await db.commit()
    await _notify_user(order)
    return {"success": True, "new_status": status}

async def _notify_admins(order, user, db, items_info):
    result = await db.execute(
        select(User).where((User.is_admin == True) | (User.is_superadmin == True))
    )
    admins = result.scalars().all()
    name = user.get("first_name", "Foydalanuvchi")
    uname = user.get("username", "")
    mention = f"@{uname}" if uname else f"<a href='tg://user?id={user['id']}'>{name}</a>"
    items_text = "\n".join(items_info)
    text = (
        f"🛒 <b>YANGI ZAKAZ!</b>\n\n"
        f"👤 Xaridor: {mention}\n"
        f"🔑 <b>Kod: <code>{order.code}</code></b>\n"
        f"💰 Jami: {float(order.total_price):,.0f} so'm\n\n"
        f"📦 Mahsulotlar:\n{items_text}\n\n"
        f"Admin panelda tasdiqlang."
    )
    bot_url = f"https://api.telegram.org/bot{settings.BOT_TOKEN}/sendMessage"
    async with httpx.AsyncClient() as client:
        for admin in admins:
            try:
                await client.post(bot_url, json={
                    "chat_id": admin.id, "text": text, "parse_mode": "HTML"
                })
            except Exception:
                pass
        # SuperAdminlarga ham yuborish
        for sid in settings.superadmin_list:
            try:
                await client.post(bot_url, json={
                    "chat_id": sid, "text": text, "parse_mode": "HTML"
                })
            except Exception:
                pass

async def _notify_user(order):
    labels = {
        "pending": "⏳ Kutilmoqda", "verified": "✅ Tasdiqlandi",
        "delivering": "🚴 Yetkazilmoqda", "completed": "🎉 Yetkazildi!",
        "cancelled": "❌ Bekor qilindi"
    }
    text = f"📦 <b>Zakaz #{order.code}</b>\n\nHolat: {labels.get(order.status, order.status)}"
    if order.admin_note:
        text += f"\n\nAdmin izohi: {order.admin_note}"
    bot_url = f"https://api.telegram.org/bot{settings.BOT_TOKEN}/sendMessage"
    async with httpx.AsyncClient() as client:
        try:
            await client.post(bot_url, json={
                "chat_id": order.user_id, "text": text, "parse_mode": "HTML"
            })
        except Exception:
            pass
