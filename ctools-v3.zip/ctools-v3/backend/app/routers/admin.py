from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import Optional
from app.database import get_db
from app.models import User, Product
from app.utils.auth import get_current_user, get_admin_user
from app.config import settings

router = APIRouter()

class ProductCreate(BaseModel):
    name: str
    description: str = ""
    price: float
    stock: int = 0
    category_id: int
    is_digital: bool = False
    secret_note: str = ""
    video_url: Optional[str] = None

@router.get("/check")
async def check_admin(user: dict = Depends(get_current_user),
                      db: AsyncSession = Depends(get_db)):
    user_id = user.get("id", 0)
    if user_id in settings.superadmin_list:
        return {"is_admin": True, "is_superadmin": True}
    result = await db.execute(select(User).where(User.id == user_id))
    db_user = result.scalar_one_or_none()
    if db_user and (db_user.is_admin or db_user.is_superadmin):
        return {"is_admin": True, "is_superadmin": db_user.is_superadmin}
    return {"is_admin": False, "is_superadmin": False}

@router.get("/users")
async def list_admins(db: AsyncSession = Depends(get_db),
                      user: dict = Depends(get_admin_user)):
    result = await db.execute(
        select(User).where((User.is_admin == True) | (User.is_superadmin == True))
    )
    return [{"id": u.id, "full_name": u.full_name, "username": u.username,
             "is_admin": u.is_admin, "is_superadmin": u.is_superadmin}
            for u in result.scalars().all()]

@router.post("/users/{user_id}/promote")
async def promote_admin(user_id: int, db: AsyncSession = Depends(get_db),
                        current_user: dict = Depends(get_admin_user)):
    if current_user.get("id") not in settings.superadmin_list:
        raise HTTPException(403, "Faqat SuperAdmin")
    result = await db.execute(select(User).where(User.id == user_id))
    target = result.scalar_one_or_none()
    if not target:
        raise HTTPException(404, "Topilmadi")
    target.is_admin = True
    await db.commit()
    return {"success": True}

@router.delete("/users/{user_id}/demote")
async def demote_admin(user_id: int, db: AsyncSession = Depends(get_db),
                       current_user: dict = Depends(get_admin_user)):
    if current_user.get("id") not in settings.superadmin_list:
        raise HTTPException(403, "Faqat SuperAdmin")
    result = await db.execute(select(User).where(User.id == user_id))
    target = result.scalar_one_or_none()
    if not target:
        raise HTTPException(404, "Topilmadi")
    target.is_admin = False
    await db.commit()
    return {"success": True}

@router.post("/products")
async def admin_create_product(body: ProductCreate,
                                db: AsyncSession = Depends(get_db),
                                user: dict = Depends(get_admin_user)):
    product = Product(**body.model_dump())
    db.add(product)
    await db.commit()
    await db.refresh(product)
    return {"id": product.id, "name": product.name}

@router.put("/products/{product_id}")
async def admin_update_product(product_id: int, body: ProductCreate,
                                db: AsyncSession = Depends(get_db),
                                user: dict = Depends(get_admin_user)):
    result = await db.execute(select(Product).where(Product.id == product_id))
    product = result.scalar_one_or_none()
    if not product:
        raise HTTPException(404, "Topilmadi")
    for k, v in body.model_dump().items():
        setattr(product, k, v)
    await db.commit()
    return {"success": True}

@router.delete("/products/{product_id}")
async def admin_delete_product(product_id: int,
                                db: AsyncSession = Depends(get_db),
                                user: dict = Depends(get_admin_user)):
    result = await db.execute(select(Product).where(Product.id == product_id))
    product = result.scalar_one_or_none()
    if not product:
        raise HTTPException(404, "Topilmadi")
    product.is_active = False
    await db.commit()
    return {"success": True}
