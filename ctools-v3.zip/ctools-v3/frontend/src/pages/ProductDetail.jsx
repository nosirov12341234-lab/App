import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { getProduct } from "../api/client";
import ImageSlider from "../components/ImageSlider";
import useStore from "../store/useStore";

export default function ProductDetail(){
  const {id}=useParams();
  const navigate=useNavigate();
  const {addToCart,favoriteIds,toggleFavoriteLocal}=useStore();
  const [product,setProduct]=useState(null);
  const [loading,setLoading]=useState(true);
  const [added,setAdded]=useState(false);
  const isFav=product?favoriteIds.includes(product.id):false;

  useEffect(()=>{
    getProduct(id).then(setProduct).catch(()=>navigate("/catalog")).finally(()=>setLoading(false));
  },[id]);

  const handleAdd=()=>{
    if(!product)return;
    addToCart(product);
    setAdded(true);
    setTimeout(()=>setAdded(false),1500);
  };

  const handleShare=()=>{
    const bot=import.meta.env.VITE_BOT_USERNAME||"CTools_robot";
    const url=`https://t.me/${bot}?start=prod_${product.id}`;
    if(window.Telegram?.WebApp?.openTelegramLink){
      window.Telegram.WebApp.openTelegramLink(url);
    } else {
      navigator.clipboard?.writeText(url);
      alert("Havola nusxalandi!");
    }
    window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("success");
  };

  const handleVideo=()=>{
    if(!product?.video_url)return;
    if(window.Telegram?.WebApp?.openLink){
      window.Telegram.WebApp.openLink(product.video_url);
    } else {
      window.open(product.video_url,"_blank");
    }
  };

  if(loading) return(
    <div className="min-h-screen">
      <div className="w-full aspect-square skeleton"/>
      <div className="p-4 space-y-4">
        <div className="h-6 skeleton w-3/4"/>
        <div className="h-4 skeleton w-1/2"/>
        <div className="h-20 skeleton"/>
      </div>
    </div>
  );
  if(!product)return null;

  return(
    <div className="min-h-screen pb-36">
      {/* Header */}
      <div className="sticky top-0 z-40 flex items-center justify-between px-3 py-2 bg-cyber-black bg-opacity-90 border-b border-cyber-border">
        <button onClick={()=>navigate(-1)} className="font-comic text-white text-xl px-1">‹ ORQAGA</button>
        <div className="flex items-center gap-3">
          <button onClick={()=>toggleFavoriteLocal(product.id)} className="text-xl">{isFav?"❤️":"🤍"}</button>
          <button onClick={handleShare} className="text-xl" title="Ulashish">🔗</button>
        </div>
      </div>

      {/* Rasm slider */}
      <ImageSlider images={product.images||[]} className="w-full aspect-square"
        placeholder={product.is_digital?"💾":"📦"}/>

      {/* Badge */}
      <div className="px-4 pt-3">
        <span className={`font-comic text-xs px-2 py-1 border border-white ${product.is_digital?"bg-cyber-purple text-white":"bg-cyber-gray text-white"}`}>
          {product.is_digital?"💾 RAQAMLI":"📦 JISMONIY"}
        </span>
      </div>

      <div className="px-4 pt-3 space-y-4">
        {/* Nom va narx */}
        <div>
          <h1 className="font-comic text-white text-xl leading-tight mb-2">{product.name}</h1>
          <span className="font-comic text-cyber-yellow text-3xl">{parseFloat(product.price).toLocaleString()} so'm</span>
        </div>

        <div className="border-t-2 border-cyber-border"/>

        {/* Stock */}
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${product.stock>0||product.is_digital?"bg-cyber-green":"bg-cyber-red"}`}/>
          <span className="font-body text-sm text-white opacity-60">
            {product.is_digital?"Cheksiz mavjud":product.stock>0?`${product.stock} dona qoldi`:"Tugagan"}
          </span>
        </div>

        {/* Video tugma */}
        {product.video_url&&(
          <button onClick={handleVideo}
            className="w-full flex items-center justify-center gap-2 bg-cyber-purple text-white font-comic text-sm py-3 border-2 border-white shadow-comic active:shadow-none active:translate-x-0.5 active:translate-y-0.5 transition-all">
            🎬 REKLAMA VIDEOSINI KO'RISH
          </button>
        )}

        {/* Tavsif */}
        {product.description&&(
          <div>
            <div className="font-comic text-white text-sm mb-2 opacity-60">TAVSIF</div>
            <div className="bg-cyber-gray border-2 border-cyber-border p-3">
              <p className="font-body text-sm text-white leading-relaxed opacity-80">{product.description}</p>
            </div>
          </div>
        )}

        {product.is_digital&&(
          <div className="bg-cyber-purple bg-opacity-20 border-2 border-cyber-purple p-3">
            <div className="font-comic text-cyber-purple text-xs mb-1">💾 RAQAMLI MAHSULOT</div>
            <p className="font-body text-xs text-white opacity-60 leading-relaxed">
              Zakaz tasdiqlangandan so'ng admin kalit yoki havolani yuboradi.
            </p>
          </div>
        )}

        {!product.is_digital&&(
          <div className="bg-cyan-900 bg-opacity-30 border-2 border-cyber-cyan p-3">
            <div className="font-comic text-cyber-cyan text-xs mb-1">🚴 YETKAZIB BERISH</div>
            <p className="font-body text-xs text-white opacity-60 leading-relaxed">
              Zakaz qilib manzil qoldirsangiz — admin eng yaqin joyga olib boradi.
            </p>
          </div>
        )}
      </div>

      {/* Bottom bar — 3 ta tugma */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-cyber-black border-t-2 border-cyber-yellow px-4 py-3 flex gap-2">
        <motion.button whileTap={{scale:0.95}} onClick={handleAdd}
          disabled={product.stock===0&&!product.is_digital}
          className={`flex-1 font-comic text-sm py-3 border-2 border-black shadow-comic transition-all active:shadow-none
            ${added?"bg-cyber-green text-white border-cyber-green":"bg-cyber-yellow text-black"}
            ${product.stock===0&&!product.is_digital?"opacity-30":""}`}>
          {added?"✅ QO'SHILDI!":"🛒 SAVATGA"}
        </motion.button>

        <motion.button whileTap={{scale:0.95}}
          onClick={()=>{addToCart(product);navigate("/cart");}}
          disabled={product.stock===0&&!product.is_digital}
          className="flex-1 font-comic text-sm py-3 border-2 border-cyber-red text-cyber-red shadow-comicR transition-all active:shadow-none">
          ⚡ ZAKAZ
        </motion.button>

        <motion.button whileTap={{scale:0.95}} onClick={handleShare}
          className="w-12 font-comic text-sm py-3 border-2 border-cyber-cyan text-cyber-cyan transition-all active:opacity-70 flex items-center justify-center">
          🔗
        </motion.button>
      </div>
    </div>
  );
}
