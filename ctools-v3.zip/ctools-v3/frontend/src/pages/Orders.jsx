import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { getMyOrders } from "../api/client";

const STATUS={
  pending:   {label:"⏳ Kutilmoqda",    cls:"text-white opacity-50", bg:"border-cyber-border"},
  verified:  {label:"✅ Tasdiqlandi",   cls:"text-cyber-green",      bg:"border-cyber-green"},
  delivering:{label:"🚴 Yetkazilmoqda", cls:"text-cyber-cyan",       bg:"border-cyber-cyan"},
  completed: {label:"🎉 Yakunlandi",    cls:"text-cyber-yellow",     bg:"border-cyber-yellow"},
  cancelled: {label:"❌ Bekor qilindi", cls:"text-cyber-red",        bg:"border-cyber-red"},
};

export default function Orders(){
  const [orders,setOrders]=useState([]);
  const [loading,setLoading]=useState(true);

  useEffect(()=>{
    getMyOrders().then(setOrders).catch(()=>{}).finally(()=>setLoading(false));
  },[]);

  if(loading) return(
    <div className="p-4 space-y-3">
      {[...Array(3)].map((_,i)=><div key={i} className="bg-cyber-gray border-2 border-cyber-border h-24 skeleton"/>)}
    </div>
  );

  if(orders.length===0) return(
    <div className="min-h-screen flex flex-col items-center justify-center gap-4">
      <span className="text-6xl opacity-20">📦</span>
      <span className="font-comic text-white opacity-30 text-xl">ZAKAZLAR YO'Q</span>
    </div>
  );

  return(
    <div className="min-h-screen pb-24">
      <div className="bg-cyber-gray border-b-2 border-cyber-yellow px-4 py-3 sticky top-0 z-30">
        <div className="font-comic text-cyber-yellow text-2xl">ZAKAZLARIM</div>
      </div>
      <div className="p-4 space-y-3">
        {orders.map((order,i)=>{
          const st=STATUS[order.status]||STATUS.pending;
          return(
            <motion.div key={order.id} initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} transition={{delay:i*0.06}}
              className={`bg-cyber-gray border-2 ${st.bg} p-4 shadow-comic`}>
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="font-comic text-white text-base">ZAKAZ #{order.id}</div>
                  <div className={`font-body text-xs mt-0.5 ${st.cls}`}>{st.label}</div>
                </div>
                <div className="text-right">
                  <div className="font-comic text-cyber-yellow text-base">
                    {parseFloat(order.total_price).toLocaleString()} so'm
                  </div>
                  <div className="font-body text-xs text-white opacity-30 mt-0.5">
                    {order.created_at?new Date(order.created_at).toLocaleDateString("uz-UZ"):""}
                  </div>
                </div>
              </div>
              <div className="bg-cyber-black border border-cyber-border px-3 py-2 flex items-center justify-between">
                <span className="font-body text-xs text-white opacity-40">Zakaz kodi:</span>
                <span className="font-comic text-cyber-cyan text-lg tracking-widest select-all">{order.code}</span>
              </div>
              {order.status==="pending"&&(
                <div className="mt-2 font-body text-xs text-white opacity-40 text-center">
                  Kodni adminga yuboring → tasdiq kutilmoqda
                </div>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
