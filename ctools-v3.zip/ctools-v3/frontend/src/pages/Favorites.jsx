import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { getProducts } from "../api/client";
import ImageSlider from "../components/ImageSlider";
import useStore from "../store/useStore";

export default function Favorites(){
  const {favoriteIds,addToCart,toggleFavoriteLocal}=useStore();
  const [products,setProducts]=useState([]);
  const [loading,setLoading]=useState(true);
  const navigate=useNavigate();

  useEffect(()=>{
    if(favoriteIds.length===0){setLoading(false);return;}
    getProducts().then(all=>setProducts(all.filter(p=>favoriteIds.includes(p.id)))).catch(()=>{}).finally(()=>setLoading(false));
  },[]);

  if(loading) return(
    <div className="p-4 grid grid-cols-2 gap-3">
      {[...Array(4)].map((_,i)=><div key={i} className="bg-cyber-gray border-2 border-cyber-border aspect-square skeleton"/>)}
    </div>
  );

  if(products.length===0) return(
    <div className="min-h-screen flex flex-col items-center justify-center gap-4">
      <span className="text-6xl">🤍</span>
      <span className="font-comic text-white text-xl opacity-30">SEVIMLILAR BO'SH</span>
      <button onClick={()=>navigate("/catalog")}
        className="font-comic text-sm bg-cyber-yellow text-black border-2 border-black px-4 py-2 shadow-comic">
        KATALOGGA O'TISH
      </button>
    </div>
  );

  return(
    <div className="min-h-screen pb-24">
      <div className="bg-cyber-gray border-b-2 border-cyber-red px-4 py-3 sticky top-0 z-30">
        <div className="font-comic text-cyber-red text-2xl">❤️ SEVIMLILAR</div>
        <div className="font-body text-xs text-white opacity-40">{products.length} ta mahsulot</div>
      </div>
      <div className="p-4 grid grid-cols-2 gap-3">
        {products.map(p=>(
          <div key={p.id} onClick={()=>navigate(`/product/${p.id}`)}
            className="bg-cyber-gray border-2 border-cyber-border flex flex-col cursor-pointer">
            <div className="relative">
              <ImageSlider images={p.images||[]} className="w-full aspect-square"
                placeholder={p.is_digital?"💾":"📦"}/>
              <button onClick={e=>{e.stopPropagation();toggleFavoriteLocal(p.id);}}
                className="absolute top-1.5 right-1.5 w-7 h-7 bg-black bg-opacity-50 flex items-center justify-center text-base border border-cyber-border">❤️</button>
            </div>
            <div className="p-2 flex flex-col flex-1">
              <p className="font-body text-xs text-white line-clamp-2 flex-1 mb-1.5">{p.name}</p>
              <div className="font-comic text-cyber-yellow text-sm mb-2">{parseFloat(p.price).toLocaleString()} so'm</div>
              <button onClick={e=>{e.stopPropagation();addToCart(p);}}
                className="w-full bg-cyber-yellow text-black font-comic text-xs py-1.5 border-2 border-black shadow-comic active:shadow-none active:translate-x-0.5 active:translate-y-0.5 transition-all">
                + SAVATGA
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
