import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import useStore from "../../store/useStore";

const links=[
  {path:"/admin/verify",    icon:"🔑",title:"Zakaz Tekshiruvi", desc:"Kodni kiritib tasdiqlash",  color:"border-cyber-red"},
  {path:"/admin/products",  icon:"📦",title:"Mahsulotlar",      desc:"Qo'shish / Tahrirlash",     color:"border-cyber-yellow"},
  {path:"/admin/categories",icon:"📂",title:"Kategoriyalar",    desc:"Tur boshqaruvi",            color:"border-cyber-cyan"},
  {path:"/admin/channels",  icon:"📢",title:"Kanallar",         desc:"Majburiy a'zolik",          color:"border-cyber-purple"},
];

export default function Dashboard(){
  const navigate=useNavigate();
  const {user,isSuperAdmin}=useStore();
  return(
    <div className="min-h-screen pb-24">
      <div className="bg-cyber-red border-b-4 border-black px-4 py-4">
        <div className="font-comic text-white text-3xl animate-glitch">ADMIN PANEL</div>
        <div className="font-body text-white opacity-60 text-xs mt-1">
          {isSuperAdmin?"👑 SuperAdmin":"🛡 Admin"} • {user?.first_name}
        </div>
      </div>
      <div className="p-4 grid grid-cols-1 gap-3">
        {links.map((link,i)=>(
          <motion.div key={link.path}
            initial={{x:-40,opacity:0}} animate={{x:0,opacity:1}} transition={{delay:i*0.08}}
            onClick={()=>navigate(link.path)}
            className={`bg-cyber-gray border-2 ${link.color} p-4 shadow-comic cursor-pointer flex items-center gap-4 active:shadow-none active:translate-x-0.5 active:translate-y-0.5 transition-all`}>
            <div className="text-4xl">{link.icon}</div>
            <div>
              <div className="font-comic text-white text-xl">{link.title}</div>
              <div className="font-body text-xs text-white opacity-40">{link.desc}</div>
            </div>
            <div className="ml-auto font-comic text-white opacity-30 text-2xl">›</div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
