import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  getProducts, getCategories,
  adminCreateProduct, adminUpdateProduct, adminDeleteProduct,
  getProductImages, uploadProductImage, deleteProductImage,
} from "../../api/client";

const BASE=(import.meta.env.VITE_API_URL||"/api").replace("/api","");
const EMPTY={name:"",description:"",price:"",stock:0,category_id:"",is_digital:false,secret_note:"",video_url:""};

export default function AdminProducts(){
  const [products,setProducts]=useState([]);
  const [categories,setCategories]=useState([]);
  const [showForm,setShowForm]=useState(false);
  const [form,setForm]=useState(EMPTY);
  const [editId,setEditId]=useState(null);
  const [saving,setSaving]=useState(false);
  const [images,setImages]=useState([]);
  const [imgLoading,setImgLoading]=useState(false);
  const fileRef=useRef();

  const load=()=>{
    getProducts().then(setProducts).catch(()=>{});
    getCategories().then(setCategories).catch(()=>{});
  };
  useEffect(()=>{load();},[]);

  const openCreate=()=>{setForm(EMPTY);setEditId(null);setImages([]);setShowForm(true);};
  const openEdit=async(p)=>{
    setForm({
      name:p.name, description:p.description||"",
      price:p.price, stock:p.stock, category_id:p.category_id,
      is_digital:p.is_digital, secret_note:"", video_url:p.video_url||"",
    });
    setEditId(p.id); setImages([]); setShowForm(true);
    getProductImages(p.id).then(setImages).catch(()=>{});
  };

  const handleSave=async()=>{
    if(!form.name||!form.price||!form.category_id){alert("Ism, narx va kategoriya majburiy!");return;}
    setSaving(true);
    try{
      const payload={
        ...form,
        price:parseFloat(form.price),
        stock:parseInt(form.stock),
        video_url:form.video_url||null,
      };
      if(editId){
        await adminUpdateProduct(editId,payload);
        alert("✅ Yangilandi!");
      } else {
        const res=await adminCreateProduct(payload);
        setEditId(res.id);
        alert("✅ Saqlandi! Endi rasm qo'shing.");
      }
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("success");
      load();
    }catch{alert("Xato!");}
    finally{setSaving(false);}
  };

  const handleImages=async(e)=>{
    const files=Array.from(e.target.files);
    if(!files.length)return;

    let pid=editId;
    if(!pid){
      if(!form.name||!form.price||!form.category_id){
        alert("Avval mahsulot ma'lumotlarini to'ldiring va saqlang!");return;
      }
      setSaving(true);
      try{
        const res=await adminCreateProduct({
          ...form,price:parseFloat(form.price),
          stock:parseInt(form.stock),video_url:form.video_url||null,
        });
        pid=res.id; setEditId(pid);
      }catch{alert("Xato!");setSaving(false);return;}
      setSaving(false);
    }

    setImgLoading(true);
    for(const file of files){
      try{
        const data=await uploadProductImage(pid,file);
        setImages(prev=>[...prev,data]);
        window.Telegram?.WebApp?.HapticFeedback?.impactOccurred("light");
      }catch{alert(`${file.name} yuklanmadi!`);}
    }
    setImgLoading(false);
    e.target.value="";
  };

  const handleDeleteImg=async(imgId)=>{
    await deleteProductImage(imgId).catch(()=>{});
    setImages(prev=>prev.filter(i=>i.id!==imgId));
  };

  const handleDelete=async(id)=>{
    if(!window.confirm("O'chirishni tasdiqlaysizmi?"))return;
    await adminDeleteProduct(id).catch(()=>{});
    load();
  };

  const inp="w-full bg-cyber-black border-2 border-white text-white font-body text-sm px-3 py-2 outline-none focus:border-cyber-cyan";

  return(
    <div className="min-h-screen">
      <div className="bg-cyber-gray border-b-2 border-cyber-yellow px-4 py-3 sticky top-0 z-30 flex justify-between items-center">
        <div className="font-comic text-cyber-yellow text-xl">📦 MAHSULOTLAR</div>
        <button onClick={openCreate}
          className="font-comic text-sm bg-cyber-yellow text-black border-2 border-black px-3 py-1.5 shadow-comic active:shadow-none">
          + QO'SHISH
        </button>
      </div>

      <AnimatePresence>
        {showForm&&(
          <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}
            className="fixed inset-0 z-50 bg-black bg-opacity-80 flex flex-col justify-end">
            <motion.div initial={{y:"100%"}} animate={{y:0}} exit={{y:"100%"}}
              transition={{type:"spring",damping:25}}
              className="bg-cyber-black border-t-4 border-cyber-yellow max-h-[92vh] overflow-y-auto">

              <div className="sticky top-0 bg-cyber-black border-b-2 border-cyber-border px-4 py-3 flex justify-between z-10">
                <div className="font-comic text-cyber-yellow text-lg">{editId?"✏️ TAHRIRLASH":"➕ YANGI"}</div>
                <button onClick={()=>setShowForm(false)} className="text-white text-2xl">✕</button>
              </div>

              <div className="p-4 space-y-4">

                {/* RASMLAR */}
                <div>
                  <div className="font-comic text-xs text-white opacity-50 mb-2">
                    📸 RASMLAR ({images.length} ta)
                  </div>
                  {images.length>0&&(
                    <div className="flex gap-2 flex-wrap mb-3">
                      {images.map(img=>(
                        <div key={img.id} className="relative w-20 h-20 border-2 border-cyber-border">
                          <img src={`${BASE}/api/uploads/${img.filename}`}
                            className="w-full h-full object-cover"
                            onError={e=>e.target.style.display="none"}/>
                          {img.is_main&&(
                            <div className="absolute bottom-0 left-0 right-0 bg-cyber-yellow text-black text-[8px] font-comic text-center">ASOSIY</div>
                          )}
                          <button onClick={()=>handleDeleteImg(img.id)}
                            className="absolute -top-1.5 -right-1.5 bg-cyber-red text-white text-xs w-5 h-5 rounded-full flex items-center justify-center border border-white">✕</button>
                        </div>
                      ))}
                    </div>
                  )}
                  <button type="button" onClick={()=>fileRef.current?.click()} disabled={imgLoading}
                    className="w-full border-2 border-dashed border-cyber-cyan bg-cyber-black py-5 flex flex-col items-center gap-1 active:opacity-70">
                    <span className="text-3xl">{imgLoading?"⏳":"📸"}</span>
                    <span className="font-comic text-cyber-cyan text-xs">
                      {imgLoading?"YUKLANMOQDA...":"GALLEREYADAN RASM QO'SHISH"}
                    </span>
                    <span className="font-body text-white opacity-30 text-[10px]">Ko'p rasm tanlash mumkin</span>
                  </button>
                  <input ref={fileRef} type="file" accept="image/*" multiple onChange={handleImages} className="hidden"/>
                </div>

                <div className="border-t border-cyber-border"/>

                {/* Nom */}
                <div>
                  <div className="font-comic text-xs text-white opacity-50 mb-1">MAHSULOT NOMI *</div>
                  <input className={inp} value={form.name}
                    onChange={e=>setForm({...form,name:e.target.value})}
                    placeholder="Rubber Ducky USB..."/>
                </div>

                {/* Tavsif */}
                <div>
                  <div className="font-comic text-xs text-white opacity-50 mb-1">TAVSIF</div>
                  <textarea className={inp} rows={3} value={form.description}
                    onChange={e=>setForm({...form,description:e.target.value})}
                    placeholder="Mahsulot haqida..."/>
                </div>

                {/* Narx & Soni */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="font-comic text-xs text-white opacity-50 mb-1">NARX (so'm) *</div>
                    <input className={inp} type="number" value={form.price}
                      onChange={e=>setForm({...form,price:e.target.value})} placeholder="150000"/>
                  </div>
                  <div>
                    <div className="font-comic text-xs text-white opacity-50 mb-1">SONI</div>
                    <input className={inp} type="number" value={form.stock}
                      onChange={e=>setForm({...form,stock:e.target.value})}/>
                  </div>
                </div>

                {/* Kategoriya */}
                <div>
                  <div className="font-comic text-xs text-white opacity-50 mb-1">KATEGORIYA *</div>
                  <select className={inp} value={form.category_id}
                    onChange={e=>setForm({...form,category_id:parseInt(e.target.value)})}>
                    <option value="">— tanlang —</option>
                    {categories.map(c=><option key={c.id} value={c.id}>{c.emoji} {c.name}</option>)}
                  </select>
                </div>

                {/* Video URL */}
                <div>
                  <div className="font-comic text-xs text-cyber-purple mb-1">🎬 REKLAMA VIDEO LINKI (ixtiyoriy)</div>
                  <input className={`${inp} border-cyber-purple focus:border-cyber-purple`}
                    value={form.video_url}
                    onChange={e=>setForm({...form,video_url:e.target.value})}
                    placeholder="https://youtube.com/watch?v=..."/>
                  <div className="font-body text-xs text-white opacity-30 mt-1">
                    YouTube, TikTok yoki boshqa video havola
                  </div>
                </div>

                {/* Digital toggle */}
                <div className="flex items-center justify-between bg-cyber-gray border-2 border-cyber-border p-3">
                  <div>
                    <div className="font-comic text-white text-sm">💾 RAQAMLI MAHSULOT</div>
                    <div className="font-body text-xs text-white opacity-40">Kalit/link yuboriladi</div>
                  </div>
                  <button onClick={()=>setForm({...form,is_digital:!form.is_digital})}
                    className={`w-12 h-6 border-2 border-white transition-colors relative ${form.is_digital?"bg-cyber-cyan":"bg-cyber-black"}`}>
                    <span className={`absolute top-0.5 w-4 h-4 bg-white transition-all ${form.is_digital?"right-0.5":"left-0.5"}`}/>
                  </button>
                </div>

                {/* Secret note */}
                {form.is_digital&&(
                  <div>
                    <div className="font-comic text-xs text-cyber-red mb-1">🔐 MAXFIY KALIT / HAVOLA</div>
                    <textarea className={`${inp} border-cyber-red`} rows={3}
                      value={form.secret_note}
                      onChange={e=>setForm({...form,secret_note:e.target.value})}
                      placeholder="Litsenziya kaliti yoki yuklab olish havolasi..."/>
                    <div className="text-xs text-cyber-red mt-1">⚠️ Faqat admin ko'radi</div>
                  </div>
                )}

                {/* Tugmalar */}
                <div className="flex gap-3 pb-6">
                  <button onClick={()=>setShowForm(false)}
                    className="flex-1 font-comic text-sm border-2 border-cyber-cyan text-cyber-cyan py-3">
                    BEKOR
                  </button>
                  <button onClick={handleSave} disabled={saving}
                    className="flex-1 font-comic text-sm bg-cyber-yellow text-black border-2 border-black py-3 shadow-comic disabled:opacity-40">
                    {saving?"SAQLANMOQDA...":"💾 SAQLASH"}
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Ro'yxat */}
      <div className="p-4 space-y-3">
        {products.length===0?(
          <div className="text-center py-16 text-white opacity-30 font-comic text-xl">MAHSULOT YO'Q</div>
        ):(
          products.map(p=>(
            <div key={p.id} className="bg-cyber-gray border-2 border-white p-3 shadow-comic flex gap-3">
              {p.images&&p.images[0]?(
                <img src={`${BASE}/api/uploads/${p.images[0].filename}`}
                  className="w-14 h-14 object-cover border border-cyber-border flex-shrink-0"
                  onError={e=>e.target.style.display="none"}/>
              ):(
                <div className="w-14 h-14 bg-cyber-black flex items-center justify-center text-2xl flex-shrink-0 border border-cyber-border">
                  {p.is_digital?"💾":"📦"}
                </div>
              )}
              <div className="flex-1 min-w-0">
                <div className="font-comic text-white text-sm leading-tight">{p.name}</div>
                <div className="text-cyber-yellow font-comic text-sm">{parseFloat(p.price).toLocaleString()} so'm</div>
                <div className="text-xs text-white opacity-40 font-body">
                  {p.images?.length||0} rasm • {p.is_digital?"Raqamli":"Jismoniy"}{p.video_url?" • 🎬":""}
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <button onClick={()=>openEdit(p)}
                  className="text-cyber-cyan border border-cyber-cyan px-2 py-1 font-comic text-xs">✏️</button>
                <button onClick={()=>handleDelete(p.id)}
                  className="text-cyber-red border border-cyber-red px-2 py-1 font-comic text-xs">🗑️</button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
