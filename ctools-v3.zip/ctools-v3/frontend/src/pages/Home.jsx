import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { getProducts, getCategories } from "../api/client";
import ImageSlider from "../components/ImageSlider";
import useStore from "../store/useStore";

function ProductCard({ product }){
  const navigate=useNavigate();
  const {addToCart,favoriteIds,toggleFavoriteLocal}=useStore();
  const isFav=favoriteIds.includes(product.id);
  return(
    <div onClick={()=>navigate(`/product/${product.id}`)}
      className="bg-cyber-gray border-2 border-cyber-border flex flex-col cursor-pointer active:opacity-75">
      <div className="relative">
        <ImageSlider images={product.images||[]} className="w-full aspect-square"
          placeholder={product.is_digital?"💾":"📦"}/>
        <div className="absolute top-1.5 left-1.5 flex flex-col gap-1">
          {product.is_digital&&<span className="bg-cyber-purple text-white text-[9px] font-comic px-1.5 py-0.5 border border-white">RAQAMLI</span>}
          {product.stock===0&&!product.is_digital&&<span className="bg-cyber-red text-white text-[9px] font-comic px-1.5 py-0.5 border border-white">TUGADI</span>}
        </div>
        <button onClick={e=>{e.stopPropagation();toggleFavoriteLocal(product.id);}}
          className="absolute top-1.5 right-1.5 w-7 h-7 bg-black bg-opacity-50 border border-cyber-border flex items-center justify-center text-sm">
          {isFav?"❤️":"🤍"}
        </button>
      </div>
      <div className="p-2 flex flex-col flex-1">
        <p className="font-body text-xs text-white leading-tight line-clamp-2 flex-1 mb-2">{product.name}</p>
        <div className="font-comic text-cyber-yellow text-base mb-2">{parseFloat(product.price).toLocaleString()} so'm</div>
        <button onClick={e=>{e.stopPropagation();addToCart(product);}}
          disabled={product.stock===0&&!product.is_digital}
          className="w-full bg-cyber-yellow disabled:opacity-30 text-black font-comic text-xs py-1.5 border-2 border-black shadow-comic active:shadow-none active:translate-x-0.5 active:translate-y-0.5 transition-all">
          {product.stock===0&&!product.is_digital?"TUGADI":"+ SAVATGA"}
        </button>
      </div>
    </div>
  );
}

const BANNERS=[
  {bg:"from-purple-900 to-cyber-black",icon:"💾",title:"RAQAMLI MAHSULOTLAR",sub:"Litsenziyalar & kalitlar"},
  {bg:"from-red-900 to-cyber-black",   icon:"🔌",title:"HACKING GADJETLAR",  sub:"USB, Wi-Fi, Bluetooth"},
  {bg:"from-cyan-900 to-cyber-black",  icon:"🛡️",title:"XAVFSIZLIK VOSITALARI",sub:"Pen-test qurilmalari"},
];

export default function Home(){
  const navigate=useNavigate();
  const {user,isAdmin}=useStore();
  const [cats,setCats]=useState([]);
  const [featured,setFeatured]=useState([]);
  const [bannerIdx,setBannerIdx]=useState(0);
  const timerRef=useRef(null);

  useEffect(()=>{
    getCategories().then(setCats).catch(()=>{});
    getProducts().then(all=>setFeatured(all.slice(0,6))).catch(()=>{});
    timerRef.current=setInterval(()=>setBannerIdx(i=>(i+1)%BANNERS.length),3500);
    return()=>clearInterval(timerRef.current);
  },[]);

  const banner=BANNERS[bannerIdx];
  return(
    <div className="min-h-screen pb-24">
      <div className="sticky top-0 z-40 bg-cyber-black border-b-2 border-cyber-yellow px-4 py-2 flex items-center justify-between">
        <span className="font-comic text-cyber-yellow text-2xl">CTOOLS.UZ</span>
        <div className="flex items-center gap-2">
          {isAdmin&&<button onClick={()=>navigate("/admin")} className="font-comic text-xs text-cyber-red border border-cyber-red px-2 py-1">ADMIN</button>}
          {user&&<span className="font-body text-xs text-white opacity-40 truncate max-w-[80px]">{user.first_name}</span>}
        </div>
      </div>

      <div className="px-4 pt-3 pb-2">
        <button onClick={()=>navigate("/catalog")}
          className="w-full bg-cyber-gray border-2 border-cyber-border text-left px-3 py-2.5 flex items-center gap-2">
          <span className="text-white opacity-30">🔍</span>
          <span className="font-body text-sm text-white opacity-30">Mahsulot qidirish...</span>
        </button>
      </div>

      <div className="px-4 mb-4">
        <motion.div key={bannerIdx} initial={{opacity:0,x:30}} animate={{opacity:1,x:0}} transition={{duration:0.3}}
          onClick={()=>navigate("/catalog")}
          className={`relative bg-gradient-to-r ${banner.bg} border-2 border-cyber-yellow shadow-comicY p-5 cursor-pointer overflow-hidden`}>
          <div className="halftone absolute inset-0"/>
          <div className="relative z-10">
            <div className="text-5xl mb-2 animate-float">{banner.icon}</div>
            <div className="font-comic text-cyber-yellow text-xl">{banner.title}</div>
            <div className="font-body text-white text-xs opacity-60 mt-1">{banner.sub}</div>
            <div className="mt-3 inline-block font-comic text-xs bg-cyber-yellow text-black px-3 py-1 border border-black">KO'RISH →</div>
          </div>
          <div className="absolute top-0 right-0 text-[80px] leading-none opacity-10 select-none">{banner.icon}</div>
        </motion.div>
        <div className="flex justify-center gap-1.5 mt-2">
          {BANNERS.map((_,i)=>(
            <button key={i} onClick={()=>setBannerIdx(i)}
              className={`h-1.5 transition-all border border-cyber-yellow ${i===bannerIdx?"w-6 bg-cyber-yellow":"w-1.5"}`}/>
          ))}
        </div>
      </div>

      {cats.length>0&&(
        <div className="mb-4">
          <div className="px-4 flex items-center justify-between mb-3">
            <span className="font-comic text-white text-base">KATEGORIYALAR</span>
            <button onClick={()=>navigate("/catalog")} className="font-body text-xs text-cyber-cyan">Barchasi →</button>
          </div>
          <div className="flex gap-4 px-4 overflow-x-auto no-scrollbar pb-1">
            <button onClick={()=>navigate("/catalog")} className="flex flex-col items-center gap-1 min-w-[64px]">
              <div className="w-14 h-14 bg-cyber-gray border-2 border-cyber-border flex items-center justify-center text-2xl">🛒</div>
              <span className="font-comic text-[10px] text-white">Barchasi</span>
            </button>
            {cats.map(c=>(
              <button key={c.id} onClick={()=>navigate(`/catalog?cat=${c.id}`)} className="flex flex-col items-center gap-1 min-w-[64px]">
                <div className="w-14 h-14 bg-cyber-gray border-2 border-cyber-border flex items-center justify-center text-2xl">{c.emoji}</div>
                <span className="font-comic text-[10px] text-white text-center line-clamp-2 max-w-[60px]">{c.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="mx-4 border-t-2 border-cyber-yellow mb-4"/>

      <div className="px-4">
        <div className="flex items-center justify-between mb-3">
          <span className="font-comic text-white text-base">🔥 TAVSIYA ETILADI</span>
          <button onClick={()=>navigate("/catalog")} className="font-body text-xs text-cyber-cyan">Hammasi →</button>
        </div>
        {featured.length===0?(
          <div className="grid grid-cols-2 gap-3">
            {[...Array(4)].map((_,i)=><div key={i} className="bg-cyber-gray border-2 border-cyber-border aspect-square skeleton"/>)}
          </div>
        ):(
          <div className="grid grid-cols-2 gap-3">
            {featured.map(p=><ProductCard key={p.id} product={p}/>)}
          </div>
        )}
      </div>
      <div className="mx-4 mt-6 bg-cyber-yellow border-2 border-black p-3 shadow-comic">
        <div className="font-comic text-black text-xs text-center">⚡ SIFAT KAFOLATI • TEZKOR YETKAZIB BERISH • 24/7 SUPPORT ⚡</div>
      </div>
    </div>
  );
}
