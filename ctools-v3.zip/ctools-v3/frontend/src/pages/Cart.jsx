import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import useStore from "../store/useStore";
import { createOrder } from "../api/client";

export default function Cart(){
  const {cart,removeFromCart,updateQuantity,cartTotal,clearCart}=useStore();
  const [address,setAddress]=useState("");
  const [loading,setLoading]=useState(false);
  const [orderResult,setOrderResult]=useState(null);
  const navigate=useNavigate();
  const total=cartTotal();
  const hasPhysical=cart.some(i=>!i.product.is_digital);

  const handleOrder=async()=>{
    if(hasPhysical&&!address.trim()){
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("error");
      alert("Jismoniy mahsulotlar uchun manzil kiriting!");return;
    }
    setLoading(true);
    try{
      const result=await createOrder({
        items:cart.map(i=>({product_id:i.product.id,quantity:i.quantity})),
        delivery_address:address,
      });
      setOrderResult(result);
      clearCart();
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("success");
    }catch{
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("error");
      alert("Xato yuz berdi. Qaytadan urining.");
    }finally{setLoading(false);}
  };

  const handleSendToAdmin=()=>{
    if(!orderResult)return;
    // Admin ID orqali to'g'ridan chat ochiladi (username o'zgarsа ham ishlaydi)
    const adminId=import.meta.env.VITE_ADMIN_ID||"";
    const text=`Salom! Zakaz kodim: ${orderResult.order_code}\nJami: ${orderResult.total_price?.toLocaleString?.()} so'm`;
    let url;
    if(adminId){
      // tg://user?id=123456789 — to'g'ridan admin profiliga
      url=`tg://user?id=${adminId}`;
      // Xabarni clipboard ga saqlaymiz
      navigator.clipboard?.writeText(text).catch(()=>{});
    } else {
      const bot=import.meta.env.VITE_BOT_USERNAME||"CTools_robot";
      url=`https://t.me/${bot}?text=${encodeURIComponent(text)}`;
    }
    if(window.Telegram?.WebApp?.openTelegramLink){
      window.Telegram.WebApp.openTelegramLink(url);
    } else {
      window.open(url,"_blank");
    }
    window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("success");
  };

  // Zakaz muvaffaqiyatli
  if(orderResult) return(
    <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center">
      <motion.div initial={{scale:0}} animate={{scale:1}} className="text-7xl mb-6 animate-float">🎉</motion.div>
      <div className="font-comic text-cyber-yellow text-3xl mb-3">ZAKAZ QABUL QILINDI!</div>

      {/* Zakaz kodi */}
      <div className="bg-cyber-gray border-2 border-cyber-yellow p-5 shadow-comicY w-full max-w-sm mb-4">
        <div className="text-xs text-white opacity-50 mb-1">ZAKAZ KODINGIZ:</div>
        <div className="font-comic text-cyber-cyan text-5xl tracking-widest select-all mb-1">{orderResult.order_code}</div>
        <div className="text-xs text-white opacity-40">Kodni adminga yuboring</div>
      </div>

      {/* Adminga yuborish tugmasi — asosiy tugma */}
      <button onClick={handleSendToAdmin}
        className="w-full max-w-sm font-comic text-lg py-4 bg-cyber-yellow text-black border-2 border-black shadow-comicY active:shadow-none active:translate-x-0.5 active:translate-y-0.5 transition-all mb-3">
        📨 ADMINGA YUBORISH
      </button>

      <div className="relative bg-white text-black p-4 border-2 border-black shadow-comic font-comic text-xs mb-4 text-left w-full max-w-sm">
        <div className="text-cyber-red text-sm mb-2">📋 KEYINGI QADAM:</div>
        <ol className="list-decimal list-inside space-y-1 font-body text-xs">
          <li>"Adminga yuborish" tugmasini bosing</li>
          <li>Admin zakaz kodingizni ko'radi</li>
          <li>Admin siz bilan bog'lanadi</li>
          <li>To'lovni amalga oshiring</li>
        </ol>
      </div>

      <button onClick={()=>navigate("/orders")}
        className="font-comic text-sm border-2 border-cyber-cyan text-cyber-cyan px-6 py-3">
        📦 ZAKAZLARIMNI KO'RISH
      </button>
    </div>
  );

  if(cart.length===0) return(
    <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center">
      <div className="text-6xl mb-4 opacity-30">🛍️</div>
      <div className="font-comic text-white text-xl opacity-40">SAVATCHA BO'SH</div>
      <button onClick={()=>navigate("/catalog")}
        className="mt-6 font-comic text-sm bg-cyber-yellow text-black border-2 border-black px-6 py-3 shadow-comic">
        KATALOGGA O'TISH
      </button>
    </div>
  );

  return(
    <div className="min-h-screen pb-32">
      <div className="bg-cyber-gray border-b-2 border-cyber-yellow px-4 py-3 sticky top-0 z-30">
        <div className="font-comic text-cyber-yellow text-2xl">SAVAT</div>
      </div>
      <div className="p-4 space-y-3">
        <AnimatePresence>
          {cart.map(({product,quantity})=>(
            <motion.div key={product.id} exit={{x:-100,opacity:0}}
              className="bg-cyber-gray border-2 border-white p-3 flex gap-3 shadow-comic">
              {/* Mini rasm */}
              <div className="w-14 h-14 flex-shrink-0 bg-cyber-black border border-cyber-border overflow-hidden">
                {product.images&&product.images[0]?(
                  <img src={`${(import.meta.env.VITE_API_URL||"/api").replace("/api","")}/api/uploads/${product.images[0].filename}`}
                    className="w-full h-full object-cover"/>
                ):(
                  <div className="w-full h-full flex items-center justify-center text-2xl">
                    {product.is_digital?"💾":"📦"}
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-comic text-white text-sm leading-tight line-clamp-2">{product.name}</div>
                <div className="text-cyber-yellow font-comic text-sm mt-1">
                  {(parseFloat(product.price)*quantity).toLocaleString()} so'm
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <button onClick={()=>updateQuantity(product.id,quantity-1)}
                    className="w-7 h-7 bg-cyber-black border border-white text-white font-comic flex items-center justify-center">-</button>
                  <span className="font-comic text-white w-5 text-center">{quantity}</span>
                  <button onClick={()=>updateQuantity(product.id,quantity+1)}
                    className="w-7 h-7 bg-cyber-black border border-white text-white font-comic flex items-center justify-center">+</button>
                </div>
              </div>
              <button onClick={()=>removeFromCart(product.id)} className="text-cyber-red text-xl self-start">✕</button>
            </motion.div>
          ))}
        </AnimatePresence>

        {hasPhysical&&(
          <div className="bg-cyber-gray border-2 border-cyber-cyan p-4">
            <div className="font-comic text-cyber-cyan text-sm mb-2">📍 YETKAZIB BERISH MANZILI</div>
            <textarea value={address} onChange={e=>setAddress(e.target.value)}
              placeholder="Shahar, ko'cha, uy raqami..." rows={3}
              className="w-full bg-cyber-black border border-white text-white font-body text-sm p-2 outline-none focus:border-cyber-cyan resize-none"/>
          </div>
        )}

        <div className="bg-cyber-yellow border-2 border-black p-4 shadow-comic">
          <div className="flex justify-between items-center">
            <span className="font-comic text-black text-lg">JAMI:</span>
            <span className="font-comic text-black text-2xl">{total.toLocaleString()} so'm</span>
          </div>
        </div>

        <button onClick={handleOrder} disabled={loading}
          className="w-full font-comic text-xl py-4 bg-cyber-red text-white border-2 border-black shadow-comicR active:shadow-none active:translate-x-0.5 active:translate-y-0.5 transition-all disabled:opacity-40">
          {loading?"YUKLANMOQDA...":"✅ ZAKAZ QILISH"}
        </button>
      </div>
    </div>
  );
}
