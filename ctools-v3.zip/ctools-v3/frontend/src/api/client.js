import axios from "axios";

const BASE_URL = import.meta.env.VITE_API_URL || "/api";
const client = axios.create({ baseURL: BASE_URL });

client.interceptors.request.use((config) => {
  const tg = window.Telegram?.WebApp;
  if (tg?.initData) config.headers["X-Init-Data"] = tg.initData;
  return config;
});

export const getProducts        = (p={})   => client.get("/products/",{params:p}).then(r=>r.data);
export const getProduct         = (id)     => client.get(`/products/${id}`).then(r=>r.data);
export const toggleFavorite     = (id)     => client.post(`/products/${id}/favorite`).then(r=>r.data);
export const getMyFavorites     = ()       => client.get("/products/favorites/my").then(r=>r.data);
export const getCategories      = ()       => client.get("/categories/").then(r=>r.data);
export const createCategory     = (d)      => client.post("/categories/",d).then(r=>r.data);
export const updateCategory     = (id,d)   => client.put(`/categories/${id}`,d).then(r=>r.data);
export const deleteCategory     = (id)     => client.delete(`/categories/${id}`).then(r=>r.data);
export const createOrder        = (d)      => client.post("/orders/create",d).then(r=>r.data);
export const getMyOrders        = ()       => client.get("/orders/my").then(r=>r.data);
export const verifyOrder        = (code)   => client.get(`/orders/verify/${code}`).then(r=>r.data);
export const updateOrderStatus  = (c,s,n="") => client.patch(`/orders/verify/${c}/status`,null,{params:{status:s,admin_note:n}}).then(r=>r.data);
export const checkAdmin         = ()       => client.get("/admin/check").then(r=>r.data);
export const adminCreateProduct = (d)      => client.post("/admin/products",d).then(r=>r.data);
export const adminUpdateProduct = (id,d)   => client.put(`/admin/products/${id}`,d).then(r=>r.data);
export const adminDeleteProduct = (id)     => client.delete(`/admin/products/${id}`).then(r=>r.data);
export const getChannels        = ()       => client.get("/channels/").then(r=>r.data);
export const addChannel         = (d)      => client.post("/channels/",d).then(r=>r.data);
export const removeChannel      = (id)     => client.delete(`/channels/${id}`).then(r=>r.data);
export const getProductImages   = (id)     => client.get(`/uploads/product/${id}`).then(r=>r.data);
export const deleteProductImage = (id)     => client.delete(`/uploads/image/${id}`).then(r=>r.data);

export const uploadProductImage = async (productId, file) => {
  const fd = new FormData();
  fd.append("file", file);
  const BASE = (import.meta.env.VITE_API_URL || "/api").replace("/api","");
  const resp = await fetch(`${BASE}/api/uploads/product/${productId}`, {
    method: "POST",
    body: fd,
  });
  if (!resp.ok) throw new Error("Yuklanmadi");
  return resp.json();
};

export default client;
