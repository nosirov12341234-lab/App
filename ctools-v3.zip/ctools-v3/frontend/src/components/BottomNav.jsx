import { useNavigate, useLocation } from "react-router-dom";
import useStore from "../store/useStore";

const navItems=[
  {path:"/",         icon:"🏠",label:"Bosh"},
  {path:"/catalog",  icon:"🛒",label:"Katalog"},
  {path:"/favorites",icon:"❤️", label:"Sevimli"},
  {path:"/orders",   icon:"📦",label:"Zakazlar"},
];

export default function BottomNav(){
  const navigate=useNavigate();
  const {pathname}=useLocation();
  const {cartCount}=useStore();
  const count=cartCount();

  return(
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-cyber-black border-t-2 border-cyber-yellow">
      <div className="flex">
        {navItems.map(item=>{
          const active=pathname===item.path;
          return(
            <button key={item.path}
              onClick={()=>{window.Telegram?.WebApp?.HapticFeedback?.selectionChanged();navigate(item.path);}}
              className={`flex-1 flex flex-col items-center py-3 gap-0.5 font-comic text-xs transition-colors ${active?"text-cyber-yellow bg-cyber-gray":"text-white opacity-60"}`}>
              <span className="text-xl">{item.icon}</span>
              <span>{item.label}</span>
            </button>
          );
        })}
        <button onClick={()=>navigate("/cart")}
          className={`flex-1 flex flex-col items-center py-3 gap-0.5 font-comic text-xs relative ${pathname==="/cart"?"text-cyber-yellow bg-cyber-gray":"text-white opacity-60"}`}>
          <span className="text-xl">🛍️</span>
          {count>0&&<span className="absolute top-1.5 right-[18%] bg-cyber-red text-white text-[10px] font-comic px-1 border border-black min-w-[18px] text-center">{count}</span>}
          <span>Savat</span>
        </button>
      </div>
    </nav>
  );
}
