// HapticButton.jsx
import { motion } from "framer-motion";

export default function HapticButton({children,onClick,className="",variant="yellow",disabled=false}){
  const v={
    yellow:"bg-cyber-yellow text-black border-2 border-black shadow-comic",
    red:"bg-cyber-red text-white border-2 border-black shadow-comicR",
    cyan:"bg-cyber-cyan text-black border-2 border-black shadow-comicC",
    ghost:"bg-transparent text-cyber-cyan border-2 border-cyber-cyan",
  };
  return(
    <motion.button whileTap={{scale:0.95}}
      onClick={e=>{window.Telegram?.WebApp?.HapticFeedback?.impactOccurred("medium");if(!disabled&&onClick)onClick(e);}}
      disabled={disabled}
      className={`font-comic tracking-wider px-4 py-2 transition-all ${v[variant]} ${className} ${disabled?"opacity-40 cursor-not-allowed":""}`}>
      {children}
    </motion.button>
  );
}
