import { useState } from "react";

const BASE = (import.meta.env.VITE_API_URL || "/api").replace("/api","");

export default function ImageSlider({ images=[], className="", placeholder="📦" }){
  const [idx,setIdx]=useState(0);

  if(!images||images.length===0){
    return(
      <div className={`flex items-center justify-center bg-cyber-black ${className}`}>
        <span className="text-6xl opacity-20">{placeholder}</span>
      </div>
    );
  }

  return(
    <div className={`relative overflow-hidden bg-cyber-black ${className}`}>
      <img
        src={`${BASE}/api/uploads/${images[idx].filename}`}
        alt=""
        className="w-full h-full object-cover"
        onError={e=>{e.target.style.display="none";}}
      />
      {images.length>1&&(
        <>
          <button onClick={e=>{e.stopPropagation();setIdx(i=>(i-1+images.length)%images.length);}}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-black bg-opacity-60 text-white font-comic border border-white flex items-center justify-center text-lg">‹</button>
          <button onClick={e=>{e.stopPropagation();setIdx(i=>(i+1)%images.length);}}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-black bg-opacity-60 text-white font-comic border border-white flex items-center justify-center text-lg">›</button>
          <div className="absolute bottom-2 left-0 right-0 flex justify-center gap-1.5">
            {images.map((_,i)=>(
              <button key={i} onClick={e=>{e.stopPropagation();setIdx(i);}}
                className={`h-1.5 border border-white transition-all ${i===idx?"w-5 bg-white":"w-1.5"}`}/>
            ))}
          </div>
          <div className="absolute top-2 right-2 bg-black bg-opacity-60 text-white font-comic text-xs px-2 py-0.5 border border-white">
            {idx+1}/{images.length}
          </div>
        </>
      )}
    </div>
  );
}
