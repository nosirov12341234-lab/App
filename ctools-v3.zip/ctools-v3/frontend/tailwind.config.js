export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        cyber: {
          black:"#0a0a0a", yellow:"#FFE500", red:"#FF2D55",
          cyan:"#00F5FF", purple:"#BF5AF2", green:"#30D158",
          gray:"#1C1C1E", border:"#2C2C2E",
        },
      },
      fontFamily: {
        comic:["'Bangers'","cursive"],
        body:["'Share Tech Mono'","monospace"],
      },
      boxShadow: {
        comic:"4px 4px 0px #000",
        comicY:"4px 4px 0px #FFE500",
        comicR:"4px 4px 0px #FF2D55",
        comicC:"4px 4px 0px #00F5FF",
      },
      animation: {
        glitch:"glitch 1s infinite",
        float:"float 3s ease-in-out infinite",
      },
      keyframes: {
        glitch:{"0%,100%":{transform:"translate(0)"},"20%":{transform:"translate(-2px,2px)"},"40%":{transform:"translate(2px,-2px)"},"60%":{transform:"translate(-1px,1px)"},"80%":{transform:"translate(1px,-1px)"}},
        float:{"0%,100%":{transform:"translateY(0)"},"50%":{transform:"translateY(-8px)"}},
      },
    },
  },
  plugins: [],
};
