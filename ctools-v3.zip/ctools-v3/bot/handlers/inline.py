from aiogram import Router
from aiogram.types import (
    InlineQuery, InlineQueryResultArticle,
    InputTextMessageContent, InlineKeyboardMarkup, InlineKeyboardButton
)
import httpx, hashlib
from config import settings

router = Router()

@router.inline_query()
async def inline_search(query: InlineQuery):
    search = query.query.strip()
    results = []

    try:
        async with httpx.AsyncClient() as client:
            params = {"search": search} if search else {}
            resp = await client.get(
                f"{settings.API_BASE_URL}/api/products/",
                params=params,
                headers={"X-Init-Data": "internal"},
                timeout=8,
            )
            products = resp.json() if resp.status_code == 200 else []
    except Exception:
        products = []

    for p in products[:15]:
        url = f"{settings.WEBAPP_URL}?tgWebAppStartParam=prod_{p['id']}"
        price = f"{float(p['price']):,.0f} so'm"
        tag = "💾 Raqamli" if p["is_digital"] else "📦 Jismoniy"

        # Tugmalar
        buttons = [[InlineKeyboardButton(text="🛒 Mini ilovada ko'rish", url=url)]]
        if p.get("video_url"):
            buttons.append([InlineKeyboardButton(text="🎬 Reklama videosi", url=p["video_url"])])

        text = (
            f"🛒 <b>{p['name']}</b>\n"
            f"💰 {price}  •  {tag}\n\n"
            f"{p.get('description','') or ''}\n\n"
            f"<a href='{url}'>Mini ilovada ko'rish →</a>"
        )

        results.append(
            InlineQueryResultArticle(
                id=hashlib.md5(str(p["id"]).encode()).hexdigest(),
                title=p["name"],
                description=f"{price} • {tag}",
                input_message_content=InputTextMessageContent(
                    message_text=text,
                    parse_mode="HTML",
                ),
                reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
                thumbnail_url=None,
            )
        )

    if not results:
        results.append(InlineQueryResultArticle(
            id="empty",
            title="Mahsulot topilmadi 😔",
            description="Boshqa so'z bilan qidiring",
            input_message_content=InputTextMessageContent(
                message_text="❌ Hech qanday mahsulot topilmadi. Boshqa so'z bilan qidiring."
            ),
        ))

    await query.answer(results, cache_time=10, is_personal=True)
