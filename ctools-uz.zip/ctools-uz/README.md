# ctools.uz — To'liq Deploy Qo'llanmasi

## Talablar
- VPS (Ubuntu 20.04+, 2GB RAM)
- Docker + Docker Compose
- Cloudflare hisob (bepul)

---

## 1-QADAM: Loyihani yuklab olish

```bash
cd ~
git clone https://github.com/nosirov12341234-lab/App.git
# zip ichidan chiqarish
unzip App/ctools-uz.zip
cd ctools-uz
```

---

## 2-QADAM: Cloudflare Tunnel sozlash

```bash
# cloudflared o'rnatish
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o cloudflared
chmod +x cloudflared && sudo mv cloudflared /usr/local/bin/

# Login (havola chiqadi - telefondan oching)
cloudflared tunnel login

# Tunnel yaratish
cloudflared tunnel create ctools

# Subdomen olish
cloudflared tunnel route dns ctools ctools-app

# Config yozish (TUNNEL_ID ni o'zgartiring)
mkdir -p ~/.cloudflared
nano ~/.cloudflared/config.yml
```

`config.yml` ichiga:
```yaml
tunnel: SIZNING_TUNNEL_ID
credentials-file: /home/nonroot/.cloudflared/SIZNING_TUNNEL_ID.json
ingress:
  - hostname: ctools-app.cfargotunnel.com
    service: http://nginx:80
  - service: http_status:404
```

---

## 3-QADAM: .env fayli

```bash
cp .env.example .env
nano .env
```

To'ldirish:
```
BOT_TOKEN=...
SUPERADMIN_IDS=SIZNING_TELEGRAM_ID
POSTGRES_PASSWORD=KUCHLI_PAROL
DATABASE_URL=postgresql+asyncpg://ctools:KUCHLI_PAROL@db:5432/ctoolsdb
VITE_API_URL=https://ctools-app.cfargotunnel.com/api
WEBAPP_URL=https://ctools-app.cfargotunnel.com
VITE_BOT_USERNAME=sizning_bot_username
SECRET_KEY=kamida32belgilikalit123456789012
```

---

## 4-QADAM: Ishga tushirish

```bash
docker compose up -d --build
```

Tekshirish:
```bash
docker compose ps
docker compose logs -f bot
```

---

## 5-QADAM: BotFather sozlash

```
/setmenubutton  →  https://ctools-app.cfargotunnel.com
/setdomain      →  ctools-app.cfargotunnel.com
/setinline      →  (bo'sh qoldiring)
```

---

## Foydali buyruqlar

```bash
# Loglar
docker compose logs -f

# Qayta build
docker compose up -d --build

# To'xtatish
docker compose down

# Tunnel holati
docker compose logs cloudflared
```
