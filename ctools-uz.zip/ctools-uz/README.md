# ctools.uz — To'liq O'rnatish Qo'llanmasi

## 1. Boshlash

```bash
git clone https://github.com/SIZNING_USERNAME/ctools-uz.git
cd ctools-uz
cp .env.example .env
```

## 2. `.env` faylini to'ldiring

```
BOT_TOKEN=7xxxxxxxxxx:AAxxxxxxxxxx
SUPERADMIN_IDS=123456789
POSTGRES_USER=ctools
POSTGRES_PASSWORD=KUCHLI_PAROL
POSTGRES_DB=ctoolsdb
DATABASE_URL=postgresql+asyncpg://ctools:KUCHLI_PAROL@db:5432/ctoolsdb
SECRET_KEY=kamida_32_ta_belgi_bu_yerda
VITE_API_URL=http://SIZNING_VPS_IP/api
VITE_BOT_USERNAME=ctools_bot
API_BASE_URL=http://backend:8000
WEBAPP_URL=http://SIZNING_VPS_IP
```

## 3. Botni sozlash (BotFather)

```
/setinline — @ctools_bot
/setinlinefeedback — on
/setmenubutton — URL: http://SIZNING_VPS_IP
```

## 4. Deploy

```bash
docker compose up -d --build
```

## 5. Tekshirish

```bash
docker compose ps          # Barcha xizmatlar running bo'lishi kerak
docker compose logs bot    # Bot logi
docker compose logs backend # API logi
```

## 6. Admin sifatida kirish

Telegram da `/admin` yuboring → Admin Panel tugmasi chiqadi.

## 7. Kanal qo'shish (majburiy a'zolik)

1. Botni kanalga admin qiling
2. Admin Panel → Kanallar → Channel ID va nom kiriting

## Foydali buyruqlar

```bash
# Loglarni ko'rish
docker compose logs -f

# Qayta ishga tushirish
docker compose restart

# To'xtatish
docker compose down

# Ma'lumotlar bazasini tozalash (ehtiyot bo'ling!)
docker compose down -v
```

## Loyiha tuzilmasi

```
ctools-uz/
├── backend/     FastAPI + SQLAlchemy
├── bot/         Aiogram 3.x
├── frontend/    React + Vite + Tailwind
├── nginx/       Reverse proxy
└── docker-compose.yml
```
