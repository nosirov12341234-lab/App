# bot/handlers/start.py
from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message, WebAppInfo
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from config import settings

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message):
    args = message.text.split()
    deep_link = args[1] if len(args) > 1 else None

    webapp_url = settings.WEBAPP_URL
    if deep_link:
        webapp_url += f"?tgWebAppStartParam={deep_link}"

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="🛒 Do'konni ochish",
            web_app=WebAppInfo(url=webapp_url),
        )],
        [InlineKeyboardButton(
            text="🔍 Mahsulot qidirish",
            switch_inline_query_current_chat="",
        )],
    ])

    await message.answer(
        f"👋 Salom, <b>{message.from_user.first_name}</b>!\n\n"
        "🔐 <b>ctools.uz</b> — Kiberxavfsizlik gadjetlari do'koniga xush kelibsiz!\n\n"
        "💡 Eng so'nggi qurilmalar, raqamli kalitlar va ekskluziv mahsulotlar.\n\n"
        "⬇️ Do'konni ochish uchun quyidagi tugmani bosing:",
        reply_markup=kb,
    )
