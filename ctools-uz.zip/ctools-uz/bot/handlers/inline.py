# bot/handlers/inline.py
from aiogram import Router
from aiogram.types import (
    InlineQuery, InlineQueryResultArticle,
    InputTextMessageContent, InlineKeyboardMarkup, InlineKeyboardButton
)
import httpx
import hashlib

from config import settings

router = Router()


@router.inline_query()
async def inline_search(query: InlineQuery):
    search = query.query.strip()
    results = []

    try:
        async with httpx.AsyncClient() as client:
            params = {"search": search} if search else {}
            resp = await client.get(
                f"{settings.API_BASE_URL}/api/products/",
                params=params,
                headers={"X-Init-Data": "internal"},
                timeout=5,
            )
            products = resp.json() if resp.status_code == 200 else []
    except Exception:
        products = []

    for p in products[:15]:   # Inline max 50, biz 15 ta ko'rsatamiz
        product_url = f"{settings.WEBAPP_URL}?tgWebAppStartParam=prod_{p['id']}"
        price_str = f"{float(p['price']):,.0f} so'm"
        digital_tag = "💾 Raqamli" if p["is_digital"] else "📦 Jismoniy"

        text = (
            f"🛒 <b>{p['name']}</b>\n"
            f"💰 {price_str}\n"
            f"{digital_tag}\n\n"
            f"<a href='{product_url}'>Do'konda ko'rish →</a>"
        )

        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="🛒 Sotib olish", url=product_url)
        ]])

        results.append(
            InlineQueryResultArticle(
                id=hashlib.md5(str(p["id"]).encode()).hexdigest(),
                title=p["name"],
                description=f"{price_str} • {digital_tag}",
                input_message_content=InputTextMessageContent(
                    message_text=text,
                    parse_mode="HTML",
                ),
                reply_markup=kb,
                thumbnail_url=None,
            )
        )

    if not results:
        results.append(
            InlineQueryResultArticle(
                id="empty",
                title="Mahsulot topilmadi 😔",
                description="Boshqa so'z bilan qidiring",
                input_message_content=InputTextMessageContent(
                    message_text="❌ Hech qanday mahsulot topilmadi."
                ),
            )
        )

    await query.answer(results, cache_time=30, is_personal=True)


# bot/handlers/catalog.py
from aiogram import Router as _Router
_cat_router = _Router()

# bot/handlers/orders.py
from aiogram import Router as _ORouter
_ord_router = _ORouter()

# bot/handlers/admin.py  
from aiogram import Router as _ARouter, F
from aiogram.types import Message
from aiogram.filters import Command

_adm_router = _ARouter()


@_adm_router.message(Command("admin"))
async def admin_panel(message: Message):
    from config import settings as _s
    if message.from_user.id not in _s.superadmin_list:
        await message.answer("❌ Ruxsat yo'q.")
        return

    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="🛠 Admin Panel",
            web_app=WebAppInfo(url=f"{_s.WEBAPP_URL}/admin"),
        )
    ]])
    await message.answer("👑 <b>Admin Panelga xush kelibsiz!</b>", reply_markup=kb)


# Eksport
catalog = type("M", (), {"router": _cat_router})
orders = type("M", (), {"router": _ord_router})
admin = type("M", (), {"router": _adm_router})
