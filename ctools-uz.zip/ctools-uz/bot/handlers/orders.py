# bot/handlers/orders.py
from aiogram import Router
from aiogram.types import Message
from aiogram.filters import Command

router = Router()

# Asosiy order logikasi WebApp orqali ishlaydi.
# Bu handler faqat to'g'ridan-to'g'ri /orders komandasi uchun.
@router.message(Command("orders"))
async def my_orders(message: Message):
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
    from config import settings
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="📦 Zakazlarim",
            web_app=WebAppInfo(url=f"{settings.WEBAPP_URL}/orders"),
        )
    ]])
    await message.answer("📦 Zakazlaringizni ko'rish:", reply_markup=kb)


# bot/handlers/catalog.py
from aiogram import Router as _R2
from aiogram.types import Message as _M2
from aiogram.filters import Command as _C2

router = _R2()

@router.message(_C2("catalog"))
async def show_catalog(message: _M2):
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
    from config import settings
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="🛒 Katalogni ochish",
            web_app=WebAppInfo(url=f"{settings.WEBAPP_URL}/catalog"),
        )
    ]])
    await message.answer("🛒 Do'kon katalogi:", reply_markup=kb)
