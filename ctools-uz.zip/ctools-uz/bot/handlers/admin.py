# bot/handlers/admin.py
from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo

from config import settings

router = Router()


@router.message(Command("admin"))
async def admin_panel(message: Message):
    if message.from_user.id not in settings.superadmin_list:
        await message.answer("❌ Sizda admin huquqi yo'q.")
        return

    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="🛠 Admin Panelni ochish",
            web_app=WebAppInfo(url=f"{settings.WEBAPP_URL}/admin"),
        )
    ]])
    await message.answer(
        "👑 <b>Admin Panelga xush kelibsiz!</b>\n\n"
        "Quyidagi tugma orqali boshqaruv panelini oching.",
        reply_markup=kb,
    )
