# bot/handlers/catalog.py
from aiogram import Router
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram.filters import Command
from config import settings

router = Router()

@router.message(Command("catalog"))
async def show_catalog(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="🛒 Katalogni ochish",
            web_app=WebAppInfo(url=f"{settings.WEBAPP_URL}/catalog"),
        )
    ]])
    await message.answer("🛒 Do'kon katalogi:", reply_markup=kb)
