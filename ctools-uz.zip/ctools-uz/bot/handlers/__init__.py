# bot/handlers/__init__.py
from . import start, inline

# catalog, orders, admin — inline.py da aniqlandi (oddiylashtirish uchun)
# Katta loyihada ularni alohida faylga chiqaring
