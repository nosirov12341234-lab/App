// frontend/src/store/useStore.js
import { create } from "zustand";
import { persist } from "zustand/middleware";

const useStore = create(
  persist(
    (set, get) => ({
      // ---- Foydalanuvchi ----
      user: null,
      isAdmin: false,
      isSuperAdmin: false,
      setUser: (user) => set({ user }),
      setAdminStatus: (isAdmin, isSuperAdmin) =>
        set({ isAdmin, isSuperAdmin }),

      // ---- Savatcha ----
      cart: [],   // [{ product, quantity }]

      addToCart: (product) => {
        const cart = get().cart;
        const existing = cart.find((i) => i.product.id === product.id);
        if (existing) {
          set({
            cart: cart.map((i) =>
              i.product.id === product.id
                ? { ...i, quantity: i.quantity + 1 }
                : i
            ),
          });
        } else {
          set({ cart: [...cart, { product, quantity: 1 }] });
        }
        // Haptic feedback
        window.Telegram?.WebApp?.HapticFeedback?.impactOccurred("light");
      },

      removeFromCart: (productId) =>
        set({ cart: get().cart.filter((i) => i.product.id !== productId) }),

      updateQuantity: (productId, quantity) => {
        if (quantity < 1) {
          get().removeFromCart(productId);
          return;
        }
        set({
          cart: get().cart.map((i) =>
            i.product.id === productId ? { ...i, quantity } : i
          ),
        });
      },

      clearCart: () => set({ cart: [] }),

      cartTotal: () =>
        get().cart.reduce(
          (sum, i) => sum + parseFloat(i.product.price) * i.quantity,
          0
        ),

      cartCount: () =>
        get().cart.reduce((sum, i) => sum + i.quantity, 0),

      // ---- Sevimlilar ----
      favoriteIds: [],
      setFavoriteIds: (ids) => set({ favoriteIds: ids }),
      toggleFavoriteLocal: (productId) => {
        const favs = get().favoriteIds;
        if (favs.includes(productId)) {
          set({ favoriteIds: favs.filter((id) => id !== productId) });
        } else {
          set({ favoriteIds: [...favs, productId] });
          window.Telegram?.WebApp?.HapticFeedback?.impactOccurred("medium");
        }
      },
    }),
    {
      name: "ctools-storage",
      partialize: (state) => ({
        cart: state.cart,
        favoriteIds: state.favoriteIds,
      }),
    }
  )
);

export default useStore;
