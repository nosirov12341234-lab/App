// frontend/src/components/TelegramImage.jsx
/**
 * Telegram CDN rasmlarini ko'rsatish.
 * file_id backend orqali real URL ga aylantiriladi.
 * Agar rasm yo'q bo'lsa — placeholder ko'rsatiladi.
 */
import { useState } from "react";

export default function TelegramImage({
  fileId,
  alt = "",
  className = "",
  placeholder = "📦",
  placeholderClass = "",
}) {
  const [loaded, setLoaded] = useState(false);
  const [error, setError]   = useState(false);

  // Backend orqali rasm URL si
  const src = fileId
    ? `${import.meta.env.VITE_API_URL || "/api"}/media/photo/${fileId}`
    : null;

  if (!src || error) {
    return (
      <div className={`flex items-center justify-center bg-cyber-black ${className} ${placeholderClass}`}>
        <span className="text-5xl opacity-30">{placeholder}</span>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden ${className}`}>
      {!loaded && (
        <div className="absolute inset-0 skeleton" />
      )}
      <img
        src={src}
        alt={alt}
        onLoad={() => setLoaded(true)}
        onError={() => setError(true)}
        className={`w-full h-full object-cover transition-opacity duration-300 ${loaded ? "opacity-100" : "opacity-0"}`}
      />
    </div>
  );
}
