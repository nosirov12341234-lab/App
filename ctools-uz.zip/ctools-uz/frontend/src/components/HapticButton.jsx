// frontend/src/components/HapticButton.jsx
import { motion } from "framer-motion";

export default function HapticButton({
  children, onClick, className = "", variant = "yellow", disabled = false,
}) {
  const variants = {
    yellow: "bg-cyber-yellow text-black border-2 border-black shadow-comic hover:shadow-none hover:translate-x-1 hover:translate-y-1",
    red:    "bg-cyber-red    text-white border-2 border-black shadow-comicR hover:shadow-none hover:translate-x-1 hover:translate-y-1",
    cyan:   "bg-cyber-cyan   text-black border-2 border-black shadow-comicC hover:shadow-none hover:translate-x-1 hover:translate-y-1",
    ghost:  "bg-transparent  text-cyber-cyan border-2 border-cyber-cyan hover:bg-cyber-cyan hover:text-black",
  };

  const handleClick = (e) => {
    window.Telegram?.WebApp?.HapticFeedback?.impactOccurred("medium");
    if (!disabled && onClick) onClick(e);
  };

  return (
    <motion.button
      whileTap={{ scale: 0.95 }}
      onClick={handleClick}
      disabled={disabled}
      className={`
        font-comic tracking-wider px-4 py-2 transition-all duration-100
        ${variants[variant]} ${className}
        ${disabled ? "opacity-40 cursor-not-allowed" : "cursor-pointer"}
      `}
    >
      {children}
    </motion.button>
  );
}
