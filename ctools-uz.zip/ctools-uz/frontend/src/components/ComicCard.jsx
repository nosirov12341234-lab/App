// frontend/src/components/ComicCard.jsx
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import HapticButton from "./HapticButton";
import useStore from "../store/useStore";
import { toggleFavorite } from "../api/client";

export default function ComicCard({ product }) {
  const navigate = useNavigate();
  const { addToCart, favoriteIds, toggleFavoriteLocal } = useStore();
  const isFav = favoriteIds.includes(product.id);

  const handleFav = async (e) => {
    e.stopPropagation();
    toggleFavoriteLocal(product.id);
    await toggleFavorite(product.id).catch(() => {});
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      onClick={() => navigate(`/product/${product.id}`)}
      className="
        bg-cyber-gray border-2 border-white
        shadow-comic cursor-pointer
        relative overflow-hidden
        active:shadow-none active:translate-x-1 active:translate-y-1
        transition-all duration-100
      "
    >
      {/* Rasm */}
      <div className="relative h-40 bg-cyber-black border-b-2 border-white overflow-hidden">
        {product.tg_photo_id ? (
          <div className="w-full h-full flex items-center justify-center text-4xl">
            📦
          </div>
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <span className="text-6xl opacity-30">
              {product.is_digital ? "💾" : "📦"}
            </span>
          </div>
        )}

        {/* Digital badge */}
        {product.is_digital && (
          <div className="absolute top-2 left-2 bg-cyber-purple text-white text-xs font-comic px-2 py-1 border border-white shadow-comic">
            💾 RAQAMLI
          </div>
        )}

        {/* Sevimli tugma */}
        <button
          onClick={handleFav}
          className="absolute top-2 right-2 text-xl w-8 h-8 flex items-center justify-center"
        >
          {isFav ? "❤️" : "🤍"}
        </button>
      </div>

      {/* Ma'lumot */}
      <div className="p-3">
        <h3 className="font-comic text-cyber-yellow text-lg leading-tight mb-1 line-clamp-2">
          {product.name}
        </h3>
        <p className="text-cyber-cyan font-comic text-xl">
          {parseFloat(product.price).toLocaleString()} so'm
        </p>

        {/* Savatchaga */}
        <HapticButton
          variant="yellow"
          className="w-full mt-3 text-sm"
          onClick={(e) => {
            e.stopPropagation();
            addToCart(product);
          }}
        >
          + SAVATGA
        </HapticButton>
      </div>

      {/* Comic halftone corner */}
      <div className="absolute bottom-0 right-0 w-8 h-8 bg-cyber-yellow opacity-20"
        style={{ clipPath: "polygon(100% 0, 100% 100%, 0 100%)" }}
      />
    </motion.div>
  );
}
