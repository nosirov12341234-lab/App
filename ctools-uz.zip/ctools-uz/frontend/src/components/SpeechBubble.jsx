// frontend/src/components/SpeechBubble.jsx
export default function SpeechBubble({ children, direction = "bottom", className = "" }) {
  const tails = {
    bottom: "after:content-[''] after:absolute after:bottom-[-12px] after:left-6 after:border-l-8 after:border-r-0 after:border-t-[12px] after:border-l-transparent after:border-t-white",
    top:    "after:content-[''] after:absolute after:top-[-12px] after:left-6 after:border-l-8 after:border-r-0 after:border-b-[12px] after:border-l-transparent after:border-b-white",
  };
  return (
    <div className={`relative bg-white text-black border-2 border-black p-3 shadow-comic font-comic ${tails[direction]} ${className}`}>
      {children}
    </div>
  );
}
