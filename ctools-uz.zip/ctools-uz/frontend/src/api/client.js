// frontend/src/api/client.js
import axios from "axios";

const BASE_URL = import.meta.env.VITE_API_URL || "/api";

const client = axios.create({ baseURL: BASE_URL });

// Har so'rovga Telegram initData qo'shamiz
client.interceptors.request.use((config) => {
  const tg = window.Telegram?.WebApp;
  if (tg?.initData) {
    config.headers["X-Init-Data"] = tg.initData;
  }
  return config;
});

// ---- API metodlari ----

// Mahsulotlar
export const getProducts = (params = {}) =>
  client.get("/products/", { params }).then((r) => r.data);

export const getProduct = (id) =>
  client.get(`/products/${id}`).then((r) => r.data);

export const toggleFavorite = (productId) =>
  client.post(`/products/${productId}/favorite`).then((r) => r.data);

export const getMyFavorites = () =>
  client.get("/products/favorites/my").then((r) => r.data);

// Kategoriyalar
export const getCategories = () =>
  client.get("/categories/").then((r) => r.data);

export const createCategory = (data) =>
  client.post("/categories/", data).then((r) => r.data);

export const updateCategory = (id, data) =>
  client.put(`/categories/${id}`, data).then((r) => r.data);

export const deleteCategory = (id) =>
  client.delete(`/categories/${id}`).then((r) => r.data);

// Zakazlar
export const createOrder = (data) =>
  client.post("/orders/create", data).then((r) => r.data);

export const getMyOrders = () =>
  client.get("/orders/my").then((r) => r.data);

export const verifyOrder = (code) =>
  client.get(`/orders/verify/${code}`).then((r) => r.data);

export const updateOrderStatus = (code, status, adminNote = "") =>
  client
    .patch(`/orders/verify/${code}/status`, null, {
      params: { status, admin_note: adminNote },
    })
    .then((r) => r.data);

// Admin
export const checkAdmin = () =>
  client.get("/admin/check").then((r) => r.data);

export const adminCreateProduct = (data) =>
  client.post("/admin/products", data).then((r) => r.data);

export const adminUpdateProduct = (id, data) =>
  client.put(`/admin/products/${id}`, data).then((r) => r.data);

export const adminDeleteProduct = (id) =>
  client.delete(`/admin/products/${id}`).then((r) => r.data);

// Kanallar
export const getChannels = () =>
  client.get("/channels/").then((r) => r.data);

export const addChannel = (data) =>
  client.post("/channels/", data).then((r) => r.data);

export const removeChannel = (id) =>
  client.delete(`/channels/${id}`).then((r) => r.data);

export default client;
