// frontend/src/App.jsx
import { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import useStore from "./store/useStore";
import { checkAdmin, getMyFavorites } from "./api/client";

import Home        from "./pages/Home";
import Catalog     from "./pages/Catalog";
import ProductDetail from "./pages/ProductDetail";
import Cart        from "./pages/Cart";
import Orders      from "./pages/Orders";
import Favorites   from "./pages/Favorites";
import AdminGuard  from "./components/AdminGuard";
import Dashboard   from "./pages/admin/Dashboard";
import AdminProducts from "./pages/admin/Products";
import AdminCategories from "./pages/admin/Categories";
import OrderVerify from "./pages/admin/OrderVerify";
import Channels    from "./pages/admin/Channels";
import BottomNav   from "./components/BottomNav";

export default function App() {
  const { setUser, setAdminStatus, setFavoriteIds } = useStore();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const tg = window.Telegram?.WebApp;
    if (tg) {
      tg.ready();
      tg.expand();
      tg.setHeaderColor("#0a0a0a");
      tg.setBackgroundColor("#0a0a0a");
      const user = tg.initDataUnsafe?.user;
      if (user) setUser(user);
    }

    // Admin tekshiruvi
    checkAdmin()
      .then(({ is_admin, is_superadmin }) => {
        setAdminStatus(is_admin, is_superadmin);
      })
      .catch(() => {});

    // Sevimlilar
    getMyFavorites()
      .then((favs) => setFavoriteIds(favs.map((f) => f.product_id)))
      .catch(() => {});

    setReady(true);
  }, []);

  if (!ready) {
    return (
      <div className="flex items-center justify-center h-screen bg-cyber-black">
        <div className="font-comic text-cyber-yellow text-4xl animate-pulse">
          YUKLANMOQDA...
        </div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <div className="bg-cyber-black min-h-screen font-body text-white pb-20">
        <Routes>
          <Route path="/"               element={<Home />} />
          <Route path="/catalog"        element={<Catalog />} />
          <Route path="/product/:id"    element={<ProductDetail />} />
          <Route path="/cart"           element={<Cart />} />
          <Route path="/orders"         element={<Orders />} />
          <Route path="/favorites"      element={<Favorites />} />

          {/* Admin Routes */}
          <Route path="/admin" element={<AdminGuard><Dashboard /></AdminGuard>} />
          <Route path="/admin/products" element={<AdminGuard><AdminProducts /></AdminGuard>} />
          <Route path="/admin/categories" element={<AdminGuard><AdminCategories /></AdminGuard>} />
          <Route path="/admin/verify"   element={<AdminGuard><OrderVerify /></AdminGuard>} />
          <Route path="/admin/channels" element={<AdminGuard><Channels /></AdminGuard>} />
        </Routes>

        <BottomNav />
      </div>
    </BrowserRouter>
  );
}
