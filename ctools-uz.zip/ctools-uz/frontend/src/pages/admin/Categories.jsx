// frontend/src/pages/admin/Categories.jsx
import { useState, useEffect } from "react";
import { getCategories, createCategory, updateCategory, deleteCategory } from "../../api/client";
import HapticButton from "../../components/HapticButton";

export default function AdminCategories() {
  const [cats, setCats]       = useState([]);
  const [name, setName]       = useState("");
  const [emoji, setEmoji]     = useState("📦");
  const [editId, setEditId]   = useState(null);
  const [saving, setSaving]   = useState(false);

  const load = () => getCategories().then(setCats).catch(() => {});
  useEffect(() => { load(); }, []);

  const handleSave = async () => {
    if (!name.trim()) return;
    setSaving(true);
    try {
      if (editId) {
        await updateCategory(editId, { name, emoji });
      } else {
        await createCategory({ name, emoji });
      }
      setName(""); setEmoji("📦"); setEditId(null);
      load();
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("success");
    } catch {
      alert("Xato!");
    } finally {
      setSaving(false);
    }
  };

  const startEdit = (c) => { setEditId(c.id); setName(c.name); setEmoji(c.emoji); };
  const cancelEdit = () => { setEditId(null); setName(""); setEmoji("📦"); };

  const handleDelete = async (id) => {
    if (!window.confirm("O'chirishni tasdiqlaysizmi?")) return;
    await deleteCategory(id).catch(() => {});
    load();
  };

  const EMOJIS = ["📦","💾","🔌","📡","🔑","🛡️","⚡","🖥️","📱","🔧","🎮","🧰"];

  return (
    <div className="min-h-screen">
      <div className="bg-cyber-gray border-b-2 border-cyber-cyan px-4 py-3 sticky top-0 z-30">
        <div className="font-comic text-cyber-cyan text-xl">📂 KATEGORIYALAR</div>
      </div>

      <div className="p-4 space-y-4">
        {/* Form */}
        <div className="bg-cyber-gray border-2 border-cyber-cyan p-4 shadow-comicC">
          <div className="font-comic text-cyber-cyan text-sm mb-3">
            {editId ? "✏️ TAHRIRLASH" : "➕ YANGI KATEGORIYA"}
          </div>

          {/* Emoji tanlash */}
          <div className="flex flex-wrap gap-2 mb-3">
            {EMOJIS.map((e) => (
              <button key={e} onClick={() => setEmoji(e)}
                className={`text-2xl p-1.5 border-2 transition-all ${emoji === e ? "border-cyber-yellow bg-cyber-black shadow-comicY" : "border-cyber-border"}`}>
                {e}
              </button>
            ))}
          </div>

          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSave()}
            placeholder="Kategoriya nomi..."
            className="w-full bg-cyber-black border-2 border-white text-white font-body text-sm px-3 py-2 outline-none focus:border-cyber-cyan mb-3"
          />

          <div className="flex gap-2">
            {editId && (
              <HapticButton variant="ghost" onClick={cancelEdit} className="flex-1 text-sm">
                BEKOR
              </HapticButton>
            )}
            <HapticButton variant="cyan" onClick={handleSave} disabled={saving || !name.trim()} className="flex-1 text-sm">
              {saving ? "..." : editId ? "💾 YANGILASH" : "➕ QO'SHISH"}
            </HapticButton>
          </div>
        </div>

        {/* List */}
        <div className="space-y-2">
          {cats.map((c) => (
            <div key={c.id} className="bg-cyber-gray border-2 border-white p-3 flex items-center gap-3 shadow-comic">
              <span className="text-3xl">{c.emoji}</span>
              <span className="font-comic text-white flex-1">{c.name}</span>
              <button onClick={() => startEdit(c)} className="text-cyber-cyan border border-cyber-cyan px-2 py-1 font-comic text-xs">✏️</button>
              <button onClick={() => handleDelete(c.id)} className="text-cyber-red border border-cyber-red px-2 py-1 font-comic text-xs">🗑️</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
