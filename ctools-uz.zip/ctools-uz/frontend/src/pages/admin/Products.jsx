// frontend/src/pages/admin/Products.jsx
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  getProducts, getCategories,
  adminCreateProduct, adminUpdateProduct, adminDeleteProduct,
} from "../../api/client";
import HapticButton from "../../components/HapticButton";

const EMPTY_FORM = {
  name: "", description: "", price: "", stock: 0,
  category_id: "", is_digital: false, secret_note: "",
  tg_photo_id: "", tg_file_id: "",
};

export default function AdminProducts() {
  const [products, setProducts]     = useState([]);
  const [categories, setCategories] = useState([]);
  const [showForm, setShowForm]     = useState(false);
  const [form, setForm]             = useState(EMPTY_FORM);
  const [editId, setEditId]         = useState(null);
  const [saving, setSaving]         = useState(false);

  const load = () => {
    getProducts().then(setProducts).catch(() => {});
    getCategories().then(setCategories).catch(() => {});
  };

  useEffect(() => { load(); }, []);

  const openCreate = () => { setForm(EMPTY_FORM); setEditId(null); setShowForm(true); };
  const openEdit   = (p) => {
    setForm({
      name: p.name, description: p.description || "",
      price: p.price, stock: p.stock, category_id: p.category_id,
      is_digital: p.is_digital, secret_note: "",
      tg_photo_id: p.tg_photo_id || "", tg_file_id: "",
    });
    setEditId(p.id);
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.name || !form.price || !form.category_id) {
      alert("Ism, narx va kategoriya majburiy!");
      return;
    }
    setSaving(true);
    try {
      const payload = { ...form, price: parseFloat(form.price), stock: parseInt(form.stock) };
      if (editId) {
        await adminUpdateProduct(editId, payload);
      } else {
        await adminCreateProduct(payload);
      }
      setShowForm(false);
      load();
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("success");
    } catch {
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("error");
      alert("Xato yuz berdi!");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Mahsulotni o'chirishni tasdiqlaysizmi?")) return;
    await adminDeleteProduct(id).catch(() => {});
    load();
    window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("warning");
  };

  const Field = ({ label, children }) => (
    <div>
      <div className="font-comic text-xs text-white opacity-50 mb-1">{label}</div>
      {children}
    </div>
  );

  const inputCls = "w-full bg-cyber-black border-2 border-white text-white font-body text-sm px-3 py-2 outline-none focus:border-cyber-cyan";

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-cyber-gray border-b-2 border-cyber-yellow px-4 py-3 sticky top-0 z-30 flex justify-between items-center">
        <div className="font-comic text-cyber-yellow text-xl">📦 MAHSULOTLAR</div>
        <HapticButton variant="yellow" onClick={openCreate} className="text-sm px-3 py-1.5">
          + QO'SHISH
        </HapticButton>
      </div>

      {/* Form Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black bg-opacity-80 flex flex-col justify-end"
          >
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25 }}
              className="bg-cyber-black border-t-4 border-cyber-yellow max-h-[90vh] overflow-y-auto"
            >
              <div className="sticky top-0 bg-cyber-black border-b-2 border-cyber-border px-4 py-3 flex justify-between items-center z-10">
                <div className="font-comic text-cyber-yellow text-lg">
                  {editId ? "✏️ TAHRIRLASH" : "➕ YANGI MAHSULOT"}
                </div>
                <button onClick={() => setShowForm(false)} className="text-white text-2xl font-comic">✕</button>
              </div>

              <div className="p-4 space-y-4">
                <Field label="MAHSULOT NOMI *">
                  <input className={inputCls} value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="Rubber Ducky USB..." />
                </Field>

                <Field label="TAVSIF">
                  <textarea className={inputCls} rows={3} value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    placeholder="Mahsulot haqida..." />
                </Field>

                <div className="grid grid-cols-2 gap-3">
                  <Field label="NARX (so'm) *">
                    <input className={inputCls} type="number" value={form.price}
                      onChange={(e) => setForm({ ...form, price: e.target.value })}
                      placeholder="150000" />
                  </Field>
                  <Field label="SONI">
                    <input className={inputCls} type="number" value={form.stock}
                      onChange={(e) => setForm({ ...form, stock: e.target.value })} />
                  </Field>
                </div>

                <Field label="KATEGORIYA *">
                  <select className={inputCls} value={form.category_id}
                    onChange={(e) => setForm({ ...form, category_id: parseInt(e.target.value) })}>
                    <option value="">— tanlang —</option>
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>{c.emoji} {c.name}</option>
                    ))}
                  </select>
                </Field>

                {/* Digital toggle */}
                <div className="flex items-center justify-between bg-cyber-gray border-2 border-cyber-border p-3">
                  <div>
                    <div className="font-comic text-white text-sm">💾 RAQAMLI MAHSULOT</div>
                    <div className="font-body text-xs text-white opacity-40">Kalit/link yuboriladi</div>
                  </div>
                  <button
                    onClick={() => setForm({ ...form, is_digital: !form.is_digital })}
                    className={`w-12 h-6 border-2 border-white transition-colors relative ${form.is_digital ? "bg-cyber-cyan" : "bg-cyber-black"}`}
                  >
                    <span className={`absolute top-0.5 w-4 h-4 bg-white transition-all ${form.is_digital ? "right-0.5" : "left-0.5"}`} />
                  </button>
                </div>

                {/* Secret Note — faqat raqamli uchun */}
                {form.is_digital && (
                  <Field label="🔐 MAXFIY KALIT / HAVOLA">
                    <textarea className={`${inputCls} border-cyber-red focus:border-cyber-red`}
                      rows={3} value={form.secret_note}
                      onChange={(e) => setForm({ ...form, secret_note: e.target.value })}
                      placeholder="Litsenziya kaliti yoki yuklab olish havolasi..." />
                    <div className="text-xs text-cyber-red mt-1 font-body">
                      ⚠️ Faqat admin ko'radi. Foydalanuvchiga ko'rinmaydi.
                    </div>
                  </Field>
                )}

                <Field label="TELEGRAM FOTO ID (ixtiyoriy)">
                  <input className={inputCls} value={form.tg_photo_id}
                    onChange={(e) => setForm({ ...form, tg_photo_id: e.target.value })}
                    placeholder="AgACAgIAAxkBAAI..." />
                </Field>

                <div className="flex gap-3 pb-4">
                  <HapticButton variant="ghost" className="flex-1" onClick={() => setShowForm(false)}>
                    BEKOR
                  </HapticButton>
                  <HapticButton variant="yellow" className="flex-1" onClick={handleSave} disabled={saving}>
                    {saving ? "SAQLANMOQDA..." : "💾 SAQLASH"}
                  </HapticButton>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Products List */}
      <div className="p-4 space-y-3">
        {products.length === 0 ? (
          <div className="text-center py-16 text-white opacity-30 font-comic text-xl">
            MAHSULOT YO'Q
          </div>
        ) : (
          products.map((p) => (
            <div key={p.id} className="bg-cyber-gray border-2 border-white p-3 shadow-comic flex gap-3">
              <div className="text-3xl">{p.is_digital ? "💾" : "📦"}</div>
              <div className="flex-1 min-w-0">
                <div className="font-comic text-white text-sm leading-tight">{p.name}</div>
                <div className="text-cyber-yellow font-comic text-sm mt-1">
                  {parseFloat(p.price).toLocaleString()} so'm
                </div>
                <div className="text-xs text-white opacity-40 font-body mt-0.5">
                  Soni: {p.stock} • {p.is_digital ? "Raqamli" : "Jismoniy"}
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <button onClick={() => openEdit(p)}
                  className="text-cyber-cyan font-comic text-xs border border-cyber-cyan px-2 py-1">
                  ✏️
                </button>
                <button onClick={() => handleDelete(p.id)}
                  className="text-cyber-red font-comic text-xs border border-cyber-red px-2 py-1">
                  🗑️
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
