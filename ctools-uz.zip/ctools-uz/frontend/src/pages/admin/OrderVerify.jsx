// frontend/src/pages/admin/OrderVerify.jsx
import { useState } from "react";
import { motion } from "framer-motion";
import { verifyOrder, updateOrderStatus } from "../../api/client";
import HapticButton from "../../components/HapticButton";

const STATUS_OPTIONS = [
  { value: "verified",   label: "✅ Tasdiqlash",       color: "green" },
  { value: "delivering", label: "🚴 Yetkazilmoqda",    color: "cyan" },
  { value: "completed",  label: "🎉 Yakunlash",        color: "yellow" },
  { value: "cancelled",  label: "❌ Bekor qilish",     color: "red" },
];

const STATUS_LABELS = {
  pending:    { text: "⏳ Kutilmoqda",    cls: "text-white opacity-60" },
  verified:   { text: "✅ Tasdiqlandi",   cls: "text-cyber-green" },
  delivering: { text: "🚴 Yetkazilmoqda", cls: "text-cyber-cyan" },
  completed:  { text: "🎉 Yakunlandi",    cls: "text-cyber-yellow" },
  cancelled:  { text: "❌ Bekor qilindi", cls: "text-cyber-red" },
};

export default function OrderVerify() {
  const [code, setCode]         = useState("");
  const [order, setOrder]       = useState(null);
  const [loading, setLoading]   = useState(false);
  const [note, setNote]         = useState("");
  const [updating, setUpdating] = useState(false);
  const [error, setError]       = useState("");

  const handleVerify = async () => {
    if (!code.trim()) return;
    setLoading(true);
    setError("");
    setOrder(null);
    try {
      const data = await verifyOrder(code.trim().toUpperCase());
      setOrder(data);
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("success");
    } catch (e) {
      setError("❌ Zakaz kodi topilmadi. Qaytadan tekshiring.");
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("error");
    } finally {
      setLoading(false);
    }
  };

  const handleStatus = async (newStatus) => {
    if (!order) return;
    setUpdating(true);
    try {
      await updateOrderStatus(order.code, newStatus, note);
      setOrder({ ...order, status: newStatus });
      setNote("");
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("success");
    } catch {
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred("error");
    } finally {
      setUpdating(false);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-cyber-red border-b-2 border-black px-4 py-3 sticky top-0 z-30">
        <div className="font-comic text-white text-2xl">🔑 ZAKAZ TEKSHIRUVI</div>
        <div className="font-body text-white text-xs opacity-60">Admin Dashboard</div>
      </div>

      <div className="p-4 space-y-4">
        {/* Kod kiritish */}
        <div className="bg-cyber-gray border-2 border-white p-4 shadow-comic">
          <div className="font-comic text-cyber-yellow text-sm mb-3">
            ZAKAZ KODINI KIRITING:
          </div>
          <input
            type="text"
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            onKeyDown={(e) => e.key === "Enter" && handleVerify()}
            placeholder="MASALAN: A3B7X2"
            maxLength={8}
            className="
              w-full bg-cyber-black border-2 border-cyber-cyan text-cyber-cyan
              font-comic text-3xl tracking-[0.5em] px-4 py-3 text-center
              outline-none placeholder-white placeholder-opacity-20
              placeholder:text-base placeholder:tracking-normal
            "
          />
          {error && (
            <div className="text-cyber-red font-body text-sm mt-2">{error}</div>
          )}
          <HapticButton
            variant="cyan"
            className="w-full mt-3 text-lg py-3"
            onClick={handleVerify}
            disabled={loading || !code.trim()}
          >
            {loading ? "IZLANMOQDA..." : "🔍 QIDIRISH"}
          </HapticButton>
        </div>

        {/* Zakaz ma'lumoti */}
        {order && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            {/* Holat */}
            <div className="bg-cyber-gray border-2 border-cyber-yellow p-4 shadow-comicY">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <div className="font-comic text-cyber-yellow text-xl">
                    #{order.code}
                  </div>
                  <div className={`font-body text-sm mt-1 ${STATUS_LABELS[order.status]?.cls}`}>
                    {STATUS_LABELS[order.status]?.text}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-body text-xs text-white opacity-40">Jami to'lov</div>
                  <div className="font-comic text-cyber-yellow text-xl">
                    {parseFloat(order.total_price).toLocaleString()} so'm
                  </div>
                </div>
              </div>

              <div className="border-t border-cyber-border pt-3">
                <div className="font-body text-xs text-white opacity-40">Foydalanuvchi ID:</div>
                <div className="font-comic text-white">{order.user_id}</div>
                {order.delivery_address && (
                  <>
                    <div className="font-body text-xs text-white opacity-40 mt-2">Manzil:</div>
                    <div className="font-body text-sm text-cyber-cyan">{order.delivery_address}</div>
                  </>
                )}
              </div>
            </div>

            {/* Mahsulotlar (secret_note bilan) */}
            <div className="font-comic text-white text-sm mb-2">
              📋 MAHSULOTLAR:
            </div>
            {order.items.map((item, i) => (
              <div
                key={i}
                className="bg-cyber-black border-2 border-white p-4 shadow-comic"
              >
                <div className="flex justify-between items-start mb-2">
                  <div className="flex-1 min-w-0 mr-2">
                    <div className="font-comic text-white text-base leading-tight">
                      {item.product_name}
                    </div>
                    <div className="font-body text-xs text-white opacity-40 mt-1">
                      {item.quantity} × {parseFloat(item.unit_price).toLocaleString()} so'm
                    </div>
                  </div>
                  <div className="text-xl flex-shrink-0">
                    {item.is_digital ? "💾" : "📦"}
                  </div>
                </div>

                {/* SECRET NOTE — faqat admin ko'radi */}
                {item.is_digital && item.secret_note && (
                  <div className="mt-3 border-2 border-cyber-red p-3 bg-cyber-red bg-opacity-10">
                    <div className="font-comic text-cyber-red text-xs mb-1">
                      🔐 MAXFIY MA'LUMOT (FAQAT ADMIN):
                    </div>
                    <div className="font-body text-cyber-cyan text-sm break-all select-all">
                      {item.secret_note}
                    </div>
                  </div>
                )}
              </div>
            ))}

            {/* Admin izohi */}
            <div>
              <div className="font-comic text-white text-sm mb-2">IZOH (ixtiyoriy):</div>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Foydalanuvchiga yuboriladi..."
                rows={2}
                className="
                  w-full bg-cyber-gray border-2 border-white text-white
                  font-body text-sm p-3 outline-none focus:border-cyber-cyan resize-none
                "
              />
            </div>

            {/* Holat tugmalari */}
            <div className="grid grid-cols-2 gap-3">
              {STATUS_OPTIONS.map((opt) => (
                <HapticButton
                  key={opt.value}
                  variant={opt.color === "green" ? "cyan" : opt.color}
                  className="text-sm py-3"
                  onClick={() => handleStatus(opt.value)}
                  disabled={updating || order.status === opt.value}
                >
                  {opt.label}
                </HapticButton>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
