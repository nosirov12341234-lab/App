// frontend/src/pages/Catalog.jsx
import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { getProducts, getCategories } from "../api/client";
import TelegramImage from "../components/TelegramImage";
import useStore from "../store/useStore";

function ProductCard({ product }) {
  const navigate = useNavigate();
  const { addToCart, favoriteIds, toggleFavoriteLocal } = useStore();
  const isFav = favoriteIds.includes(product.id);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      onClick={() => navigate(`/product/${product.id}`)}
      className="bg-cyber-gray border-2 border-cyber-border flex flex-col cursor-pointer active:opacity-75 transition-opacity"
    >
      <div className="relative">
        <TelegramImage
          fileId={product.tg_photo_id}
          alt={product.name}
          className="w-full aspect-square"
          placeholder={product.is_digital ? "💾" : "📦"}
        />
        <div className="absolute top-1.5 left-1.5 flex flex-col gap-1">
          {product.is_digital && (
            <span className="bg-cyber-purple text-white text-[9px] font-comic px-1.5 py-0.5 border border-white">RAQAMLI</span>
          )}
          {product.stock === 0 && !product.is_digital && (
            <span className="bg-cyber-red text-white text-[9px] font-comic px-1.5 py-0.5 border border-white">TUGADI</span>
          )}
        </div>
        <button
          onClick={(e) => { e.stopPropagation(); toggleFavoriteLocal(product.id); }}
          className="absolute top-1.5 right-1.5 w-7 h-7 bg-black bg-opacity-50 border border-cyber-border flex items-center justify-center text-sm"
        >
          {isFav ? "❤️" : "🤍"}
        </button>
      </div>
      <div className="p-2 flex flex-col flex-1">
        <p className="font-body text-xs text-white leading-snug line-clamp-2 flex-1 mb-1.5">{product.name}</p>
        <div className="font-comic text-cyber-yellow text-sm mb-2">
          {parseFloat(product.price).toLocaleString()} so'm
        </div>
        <button
          onClick={(e) => { e.stopPropagation(); addToCart(product); }}
          disabled={product.stock === 0 && !product.is_digital}
          className="w-full bg-cyber-yellow disabled:opacity-30 text-black font-comic text-xs py-1.5 border-2 border-black shadow-comic active:shadow-none active:translate-x-0.5 active:translate-y-0.5 transition-all"
        >
          {product.stock === 0 && !product.is_digital ? "TUGADI" : "+ SAVATGA"}
        </button>
      </div>
    </motion.div>
  );
}

export default function Catalog() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initCat = searchParams.get("cat") ? parseInt(searchParams.get("cat")) : null;

  const [products, setProducts]       = useState([]);
  const [categories, setCategories]   = useState([]);
  const [selectedCat, setSelectedCat] = useState(initCat);
  const [search, setSearch]           = useState("");
  const [loading, setLoading]         = useState(true);
  const [sort, setSort]               = useState("default"); // default | price_asc | price_desc

  useEffect(() => { getCategories().then(setCategories).catch(() => {}); }, []);

  useEffect(() => {
    setLoading(true);
    const params = {};
    if (selectedCat) params.category_id = selectedCat;
    if (search.trim()) params.search = search.trim();
    getProducts(params)
      .then((data) => {
        let sorted = [...data];
        if (sort === "price_asc")  sorted.sort((a, b) => a.price - b.price);
        if (sort === "price_desc") sorted.sort((a, b) => b.price - a.price);
        setProducts(sorted);
      })
      .catch(() => setProducts([]))
      .finally(() => setLoading(false));
  }, [selectedCat, search, sort]);

  return (
    <div className="min-h-screen pb-24">
      {/* Sticky header */}
      <div className="sticky top-0 z-40 bg-cyber-black border-b-2 border-cyber-border">
        {/* Qidiruv */}
        <div className="px-3 pt-2 pb-2 flex gap-2">
          <button onClick={() => navigate(-1)} className="text-white text-xl px-1">‹</button>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="🔍 Mahsulot qidirish..."
            className="flex-1 bg-cyber-gray border-2 border-cyber-border text-white font-body text-sm px-3 py-2 outline-none focus:border-cyber-cyan"
          />
        </div>

        {/* Kategoriyalar */}
        <div className="flex gap-2 px-3 pb-2 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setSelectedCat(null)}
            className={`font-comic text-xs px-3 py-1.5 border-2 whitespace-nowrap transition-all flex-shrink-0
              ${!selectedCat ? "bg-cyber-yellow text-black border-black" : "border-cyber-border text-white opacity-50"}`}
          >
            Barchasi
          </button>
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCat(selectedCat === c.id ? null : c.id)}
              className={`font-comic text-xs px-3 py-1.5 border-2 whitespace-nowrap transition-all flex-shrink-0
                ${selectedCat === c.id ? "bg-cyber-cyan text-black border-black" : "border-cyber-border text-white opacity-50"}`}
            >
              {c.emoji} {c.name}
            </button>
          ))}
        </div>

        {/* Sort + Count */}
        <div className="flex items-center justify-between px-3 pb-2">
          <span className="font-body text-xs text-white opacity-40">
            {loading ? "..." : `${products.length} ta mahsulot`}
          </span>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="bg-cyber-gray border border-cyber-border text-white font-body text-xs px-2 py-1 outline-none"
          >
            <option value="default">Standart</option>
            <option value="price_asc">Narx: past → yuqori</option>
            <option value="price_desc">Narx: yuqori → past</option>
          </select>
        </div>
      </div>

      {/* Grid */}
      <div className="p-3">
        {loading ? (
          <div className="grid grid-cols-2 gap-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-cyber-gray border-2 border-cyber-border">
                <div className="aspect-square skeleton" />
                <div className="p-2 space-y-2">
                  <div className="h-3 skeleton" />
                  <div className="h-3 skeleton w-2/3" />
                  <div className="h-7 skeleton" />
                </div>
              </div>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 gap-3">
            <span className="text-5xl opacity-20">🔍</span>
            <span className="font-comic text-white opacity-30 text-xl">TOPILMADI</span>
            {search && (
              <button onClick={() => setSearch("")} className="font-body text-xs text-cyber-cyan border border-cyber-cyan px-3 py-1">
                Tozalash
              </button>
            )}
          </div>
        ) : (
          <AnimatePresence>
            <div className="grid grid-cols-2 gap-3">
              {products.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}
