# backend/app/main.py
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import init_db
from app.routers import products, orders, admin, categories, channels, media


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield


app = FastAPI(
    title="ctools.uz API",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],    # Cloudflare orqali cheklash mumkin
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(products.router,   prefix="/api/products",   tags=["Mahsulotlar"])
app.include_router(categories.router, prefix="/api/categories", tags=["Kategoriyalar"])
app.include_router(orders.router,     prefix="/api/orders",     tags=["Zakazlar"])
app.include_router(channels.router,   prefix="/api/channels",   tags=["Kanallar"])
app.include_router(admin.router,      prefix="/api/admin",      tags=["Admin"])
app.include_router(media.router,      prefix="/api/media",      tags=["Media"])


@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "ctools.uz"}
