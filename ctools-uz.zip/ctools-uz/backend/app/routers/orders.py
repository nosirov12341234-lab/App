# backend/app/routers/orders.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import List
import httpx

from app.database import get_db
from app.models import Order, OrderItem, Product, User, OrderStatus
from app.utils.auth import get_current_user, get_admin_user
from app.config import settings

router = APIRouter()


class CartItem(BaseModel):
    product_id: int
    quantity: int


class CreateOrderRequest(BaseModel):
    items: List[CartItem]
    delivery_address: str = ""


@router.post("/create")
async def create_order(
    body: CreateOrderRequest,
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_current_user),
):
    """Savatchadan zakaz yaratish + adminlarga xabar yuborish"""
    if not body.items:
        raise HTTPException(status_code=400, detail="Savatcha bo'sh")

    # Foydalanuvchini DB ga saqlash (agar yangi bo'lsa)
    result = await db.execute(select(User).where(User.id == user["id"]))
    db_user = result.scalar_one_or_none()
    if not db_user:
        db_user = User(
            id=user["id"],
            username=user.get("username"),
            full_name=user.get("first_name", "") + " " + user.get("last_name", ""),
        )
        db.add(db_user)

    # Zakaz yaratish
    order = Order(
        user_id=user["id"],
        delivery_address=body.delivery_address,
    )
    db.add(order)
    await db.flush()   # ID olish uchun

    total = 0
    for item in body.items:
        result = await db.execute(
            select(Product).where(Product.id == item.product_id, Product.is_active == True)
        )
        product = result.scalar_one_or_none()
        if not product:
            raise HTTPException(status_code=404, detail=f"Mahsulot #{item.product_id} topilmadi")

        order_item = OrderItem(
            order_id=order.id,
            product_id=product.id,
            quantity=item.quantity,
            unit_price=product.price,
        )
        db.add(order_item)
        total += float(product.price) * item.quantity

    order.total_price = total
    await db.commit()
    await db.refresh(order)

    # Adminlarga Telegram orqali xabar yuborish
    await _notify_admins(order, user, db)

    return {
        "order_id": order.id,
        "order_code": order.code,
        "total_price": float(order.total_price),
        "status": order.status,
    }


@router.get("/my")
async def my_orders(
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_current_user),
):
    result = await db.execute(
        select(Order).where(Order.user_id == user["id"]).order_by(Order.created_at.desc())
    )
    orders = result.scalars().all()
    return [
        {
            "id": o.id,
            "code": o.code,
            "status": o.status,
            "total_price": float(o.total_price),
            "created_at": o.created_at.isoformat() if o.created_at else None,
        }
        for o in orders
    ]


@router.get("/verify/{code}")
async def verify_order(
    code: str,
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_admin_user),
):
    """Admin zakaz kodini kiritib mahsulotlarni ko'radi (secret_note bilan)"""
    result = await db.execute(
        select(Order).where(Order.code == code.upper())
    )
    order = result.scalar_one_or_none()
    if not order:
        raise HTTPException(status_code=404, detail="Zakaz kodi topilmadi")

    items_data = []
    for item in order.items:
        items_data.append({
            "product_id": item.product_id,
            "product_name": item.product.name,
            "quantity": item.quantity,
            "unit_price": float(item.unit_price),
            "is_digital": item.product.is_digital,
            "secret_note": item.product.secret_note,   # 🔐 Faqat admin ko'radi
        })

    return {
        "order_id": order.id,
        "code": order.code,
        "status": order.status,
        "user_id": order.user_id,
        "delivery_address": order.delivery_address,
        "total_price": float(order.total_price),
        "items": items_data,
        "created_at": order.created_at.isoformat() if order.created_at else None,
    }


@router.patch("/verify/{code}/status")
async def update_order_status(
    code: str,
    status: str,
    admin_note: str = "",
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_admin_user),
):
    """Admin zakaz holatini yangilaydi"""
    valid_statuses = [s.value for s in OrderStatus]
    if status not in valid_statuses:
        raise HTTPException(status_code=400, detail=f"Noto'g'ri holat: {status}")

    result = await db.execute(select(Order).where(Order.code == code.upper()))
    order = result.scalar_one_or_none()
    if not order:
        raise HTTPException(status_code=404, detail="Zakaz topilmadi")

    order.status = status
    order.admin_note = admin_note
    order.verified_by = user["id"]
    await db.commit()

    # Foydalanuvchiga Telegram xabari
    await _notify_user(order)

    return {"success": True, "new_status": status}


async def _notify_admins(order: Order, user: dict, db: AsyncSession):
    """Barcha adminlarga zakaz haqida xabar yuborish"""
    result = await db.execute(
        select(User).where(
            (User.is_admin == True) | (User.is_superadmin == True)
        )
    )
    admins = result.scalars().all()

    user_name = user.get("first_name", "Foydalanuvchi")
    username = user.get("username", "")
    mention = f"@{username}" if username else f"ID: {user['id']}"

    text = (
        f"🛒 <b>Yangi Zakaz!</b>\n\n"
        f"👤 Xaridor: {user_name} ({mention})\n"
        f"🔑 <b>Zakaz Kodi: <code>{order.code}</code></b>\n"
        f"💰 Jami: {float(order.total_price):,.0f} so'm\n\n"
        f"Kodni tekshirish uchun Admin Panelni oching."
    )

    bot_url = f"https://api.telegram.org/bot{settings.BOT_TOKEN}/sendMessage"
    async with httpx.AsyncClient() as client:
        for admin in admins:
            try:
                await client.post(bot_url, json={
                    "chat_id": admin.id,
                    "text": text,
                    "parse_mode": "HTML",
                })
            except Exception:
                pass


async def _notify_user(order: Order):
    """Foydalanuvchiga holat o'zgarganda xabar"""
    status_labels = {
        "pending": "⏳ Kutilmoqda",
        "verified": "✅ Tasdiqlandi",
        "delivering": "🚴 Yetkazilmoqda",
        "completed": "🎉 Yetkazildi!",
        "cancelled": "❌ Bekor qilindi",
    }
    label = status_labels.get(order.status, order.status)
    text = (
        f"📦 <b>Zakaz #{order.code}</b>\n\n"
        f"Holat: {label}\n"
    )
    if order.admin_note:
        text += f"\nAdmin izohi: {order.admin_note}"

    bot_url = f"https://api.telegram.org/bot{settings.BOT_TOKEN}/sendMessage"
    async with httpx.AsyncClient() as client:
        try:
            await client.post(bot_url, json={
                "chat_id": order.user_id,
                "text": text,
                "parse_mode": "HTML",
            })
        except Exception:
            pass
