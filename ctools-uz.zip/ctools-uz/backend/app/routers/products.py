# backend/app/routers/products.py
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_
from typing import Optional

from app.database import get_db
from app.models import Product, Category, Favorite
from app.utils.auth import get_current_user

router = APIRouter()


@router.get("/")
async def list_products(
    category_id: Optional[int] = None,
    search: Optional[str] = Query(None, max_length=100),
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_current_user),
):
    stmt = select(Product).where(Product.is_active == True)
    if category_id:
        stmt = stmt.where(Product.category_id == category_id)
    if search:
        stmt = stmt.where(
            or_(
                Product.name.ilike(f"%{search}%"),
                Product.description.ilike(f"%{search}%"),
            )
        )
    result = await db.execute(stmt)
    products = result.scalars().all()

    return [
        {
            "id": p.id,
            "name": p.name,
            "description": p.description,
            "price": float(p.price),
            "stock": p.stock,
            "tg_photo_id": p.tg_photo_id,
            "is_digital": p.is_digital,
            "category_id": p.category_id,
        }
        for p in products
    ]


@router.get("/{product_id}")
async def get_product(
    product_id: int,
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_current_user),
):
    result = await db.execute(
        select(Product).where(Product.id == product_id, Product.is_active == True)
    )
    product = result.scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Mahsulot topilmadi")

    return {
        "id": product.id,
        "name": product.name,
        "description": product.description,
        "price": float(product.price),
        "stock": product.stock,
        "tg_photo_id": product.tg_photo_id,
        "is_digital": product.is_digital,
        "category_id": product.category_id,
    }


@router.post("/{product_id}/favorite")
async def toggle_favorite(
    product_id: int,
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_current_user),
):
    user_id = user["id"]
    result = await db.execute(
        select(Favorite).where(
            Favorite.user_id == user_id,
            Favorite.product_id == product_id,
        )
    )
    existing = result.scalar_one_or_none()
    if existing:
        await db.delete(existing)
        await db.commit()
        return {"action": "removed"}
    else:
        fav = Favorite(user_id=user_id, product_id=product_id)
        db.add(fav)
        await db.commit()
        return {"action": "added"}


@router.get("/favorites/my")
async def my_favorites(
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_current_user),
):
    result = await db.execute(
        select(Favorite).where(Favorite.user_id == user["id"])
    )
    favs = result.scalars().all()
    return [{"product_id": f.product_id} for f in favs]
