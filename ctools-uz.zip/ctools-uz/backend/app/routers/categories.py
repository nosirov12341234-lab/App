# backend/app/routers/categories.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel

from app.database import get_db
from app.models import Category
from app.utils.auth import get_current_user, get_admin_user

router = APIRouter()


class CategoryBody(BaseModel):
    name: str
    emoji: str = "📦"


@router.get("/")
async def list_categories(
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_current_user),
):
    result = await db.execute(select(Category).where(Category.is_active == True))
    cats = result.scalars().all()
    return [{"id": c.id, "name": c.name, "emoji": c.emoji} for c in cats]


@router.post("/")
async def create_category(
    body: CategoryBody,
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_admin_user),
):
    cat = Category(name=body.name, emoji=body.emoji)
    db.add(cat)
    await db.commit()
    await db.refresh(cat)
    return {"id": cat.id, "name": cat.name}


@router.put("/{cat_id}")
async def update_category(
    cat_id: int,
    body: CategoryBody,
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_admin_user),
):
    result = await db.execute(select(Category).where(Category.id == cat_id))
    cat = result.scalar_one_or_none()
    if not cat:
        raise HTTPException(status_code=404, detail="Topilmadi")
    cat.name = body.name
    cat.emoji = body.emoji
    await db.commit()
    return {"success": True}


@router.delete("/{cat_id}")
async def delete_category(
    cat_id: int,
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_admin_user),
):
    result = await db.execute(select(Category).where(Category.id == cat_id))
    cat = result.scalar_one_or_none()
    if not cat:
        raise HTTPException(status_code=404, detail="Topilmadi")
    cat.is_active = False
    await db.commit()
    return {"success": True}
