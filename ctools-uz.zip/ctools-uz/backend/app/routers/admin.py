# backend/app/routers/admin.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel

from app.database import get_db
from app.models import User, Product, Category
from app.utils.auth import get_current_user, get_admin_user
from app.config import settings

router = APIRouter()


class ProductCreate(BaseModel):
    name: str
    description: str = ""
    price: float
    stock: int = 0
    category_id: int
    is_digital: bool = False
    secret_note: str = ""
    tg_photo_id: str = ""
    tg_file_id: str = ""


@router.get("/check")
async def check_admin(user: dict = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    """Frontend admin ekanligini tekshiradi"""
    user_id = user["id"]

    # SuperAdmin tekshiruvi
    if user_id in settings.superadmin_list:
        return {"is_admin": True, "is_superadmin": True}

    # DB dan tekshirish
    result = await db.execute(select(User).where(User.id == user_id))
    db_user = result.scalar_one_or_none()
    if db_user and (db_user.is_admin or db_user.is_superadmin):
        return {"is_admin": True, "is_superadmin": db_user.is_superadmin}

    return {"is_admin": False, "is_superadmin": False}


@router.get("/users")
async def list_admins(db: AsyncSession = Depends(get_db), user: dict = Depends(get_admin_user)):
    result = await db.execute(
        select(User).where((User.is_admin == True) | (User.is_superadmin == True))
    )
    return [
        {"id": u.id, "full_name": u.full_name, "username": u.username,
         "is_admin": u.is_admin, "is_superadmin": u.is_superadmin}
        for u in result.scalars().all()
    ]


@router.post("/users/{user_id}/promote")
async def promote_admin(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    """SuperAdmin faqat yangi admin qo'sha oladi"""
    if current_user["id"] not in settings.superadmin_list:
        raise HTTPException(status_code=403, detail="Faqat SuperAdmin uchun")

    result = await db.execute(select(User).where(User.id == user_id))
    target = result.scalar_one_or_none()
    if not target:
        raise HTTPException(status_code=404, detail="Foydalanuvchi topilmadi")

    target.is_admin = True
    await db.commit()
    return {"success": True}


@router.delete("/users/{user_id}/demote")
async def demote_admin(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    if current_user["id"] not in settings.superadmin_list:
        raise HTTPException(status_code=403, detail="Faqat SuperAdmin uchun")

    result = await db.execute(select(User).where(User.id == user_id))
    target = result.scalar_one_or_none()
    if not target:
        raise HTTPException(status_code=404, detail="Topilmadi")

    target.is_admin = False
    await db.commit()
    return {"success": True}


# Admin mahsulot CRUD
@router.post("/products")
async def admin_create_product(
    body: ProductCreate,
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_admin_user),
):
    product = Product(**body.model_dump())
    db.add(product)
    await db.commit()
    await db.refresh(product)
    return {"id": product.id, "name": product.name}


@router.put("/products/{product_id}")
async def admin_update_product(
    product_id: int,
    body: ProductCreate,
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_admin_user),
):
    result = await db.execute(select(Product).where(Product.id == product_id))
    product = result.scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Topilmadi")

    for key, value in body.model_dump().items():
        setattr(product, key, value)

    await db.commit()
    return {"success": True}


@router.delete("/products/{product_id}")
async def admin_delete_product(
    product_id: int,
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_admin_user),
):
    result = await db.execute(select(Product).where(Product.id == product_id))
    product = result.scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Topilmadi")
    product.is_active = False   # Soft delete
    await db.commit()
    return {"success": True}
