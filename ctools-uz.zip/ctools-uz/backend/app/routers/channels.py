# backend/app/routers/channels.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel

from app.database import get_db
from app.models import Channel
from app.utils.auth import get_current_user, get_admin_user

router = APIRouter()


class ChannelBody(BaseModel):
    channel_id: int
    title: str
    username: str = ""


@router.get("/")
async def list_channels(
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_current_user),
):
    result = await db.execute(select(Channel).where(Channel.is_active == True))
    channels = result.scalars().all()
    return [
        {"id": c.id, "channel_id": c.channel_id,
         "title": c.title, "username": c.username}
        for c in channels
    ]


@router.post("/")
async def add_channel(
    body: ChannelBody,
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_admin_user),
):
    ch = Channel(
        channel_id=body.channel_id,
        title=body.title,
        username=body.username,
    )
    db.add(ch)
    await db.commit()
    await db.refresh(ch)
    return {"id": ch.id}


@router.delete("/{ch_id}")
async def remove_channel(
    ch_id: int,
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_admin_user),
):
    result = await db.execute(select(Channel).where(Channel.id == ch_id))
    ch = result.scalar_one_or_none()
    if not ch:
        raise HTTPException(status_code=404, detail="Topilmadi")
    ch.is_active = False
    await db.commit()
    return {"success": True}
