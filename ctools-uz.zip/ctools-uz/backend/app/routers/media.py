# backend/app/routers/media.py
"""
Telegram CDN proxy — file_id orqali rasm qaytaradi.
Frontend to'g'ridan-to'g'ri Telegram API ga murojaat qilmaydi,
hamma narsa backend orqali o'tadi.
"""
import httpx
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from app.config import settings

router = APIRouter()


@router.get("/photo/{file_id}")
async def get_photo(file_id: str):
    """
    1. Telegram API dan file path oladi
    2. CDN URL yaratadi
    3. Rasmni stream qilib qaytaradi
    """
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            # 1. file_path olish
            resp = await client.get(
                f"https://api.telegram.org/bot{settings.BOT_TOKEN}/getFile",
                params={"file_id": file_id},
            )
            data = resp.json()
            if not data.get("ok"):
                raise HTTPException(status_code=404, detail="Rasm topilmadi")

            file_path = data["result"]["file_path"]

            # 2. Haqiqiy URL
            photo_url = f"https://api.telegram.org/file/bot{settings.BOT_TOKEN}/{file_path}"

            # 3. Stream
            photo_resp = await client.get(photo_url)
            content_type = photo_resp.headers.get("content-type", "image/jpeg")

            return StreamingResponse(
                content=iter([photo_resp.content]),
                media_type=content_type,
                headers={"Cache-Control": "public, max-age=86400"},  # 1 kun cache
            )

    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=500, detail="Rasm yuklanmadi")
