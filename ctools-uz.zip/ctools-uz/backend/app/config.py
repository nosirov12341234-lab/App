# backend/app/config.py
from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    BOT_TOKEN: str
    SUPERADMIN_IDS: str = ""          # "123,456" formatida
    DATABASE_URL: str
    SECRET_KEY: str
    API_BASE_URL: str = "http://backend:8000"

    @property
    def superadmin_list(self) -> List[int]:
        if not self.SUPERADMIN_IDS:
            return []
        return [int(x.strip()) for x in self.SUPERADMIN_IDS.split(",") if x.strip()]

    class Config:
        env_file = ".env"


settings = Settings()
