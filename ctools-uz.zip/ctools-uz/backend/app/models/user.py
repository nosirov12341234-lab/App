# backend/app/models/user.py
from sqlalchemy import Column, BigInteger, String, Boolean
from .base import Base


class User(Base):
    __tablename__ = "users"

    id = Column(BigInteger, primary_key=True)          # Telegram user_id
    username = Column(String(64), nullable=True)
    full_name = Column(String(128))
    is_admin = Column(Boolean, default=False)
    is_superadmin = Column(Boolean, default=False)
    is_blocked = Column(Boolean, default=False)
