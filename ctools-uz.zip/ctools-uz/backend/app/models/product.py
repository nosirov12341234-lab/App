# backend/app/models/product.py
from sqlalchemy import (
    Column, Integer, String, Text,
    Numeric, Boolean, ForeignKey
)
from sqlalchemy.orm import relationship
from .base import Base


class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, autoincrement=True)
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=False)

    name = Column(String(256), nullable=False)
    description = Column(Text, nullable=True)
    price = Column(Numeric(12, 2), nullable=False)
    stock = Column(Integer, default=0)          # -1 = cheksiz (raqamli)

    # Media — Telegram CDN orqali saqlanadi
    tg_photo_id = Column(String(256), nullable=True)   # file_id
    tg_file_id = Column(String(256), nullable=True)    # hujjat/zip uchun

    # Mahsulot turi
    is_digital = Column(Boolean, default=False)
    # Faqat adminlar ko'radi — raqamli kalit/havola
    secret_note = Column(Text, nullable=True)

    is_active = Column(Boolean, default=True)

    category = relationship("Category", back_populates="products")
    order_items = relationship("OrderItem", back_populates="product")
    favorites = relationship("Favorite", back_populates="product")
