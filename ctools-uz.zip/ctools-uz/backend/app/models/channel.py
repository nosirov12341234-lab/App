# backend/app/models/channel.py
from sqlalchemy import Column, Integer, BigInteger, String, Boolean
from .base import Base


class Channel(Base):
    __tablename__ = "channels"

    id = Column(Integer, primary_key=True, autoincrement=True)
    # Telegram channel_id (manfiy son: -100xxxxxxxxxx)
    channel_id = Column(BigInteger, unique=True, nullable=False)
    title = Column(String(256), nullable=False)
    username = Column(String(128), nullable=True)   # @ctools_channel
    is_active = Column(Boolean, default=True)


# backend/app/models/favorite.py  (shu faylda birlashtiramiz)
from sqlalchemy import UniqueConstraint
from sqlalchemy.orm import relationship
from .base import Base
from sqlalchemy import Column, Integer, BigInteger, ForeignKey


class Favorite(Base):
    __tablename__ = "favorites"
    __table_args__ = (
        UniqueConstraint("user_id", "product_id", name="uq_user_product"),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, ForeignKey("users.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)

    product = relationship("Product", back_populates="favorites")
