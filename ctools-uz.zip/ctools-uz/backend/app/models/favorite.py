# backend/app/models/favorite.py
from sqlalchemy import Column, Integer, BigInteger, ForeignKey, UniqueConstraint
from sqlalchemy.orm import relationship
from .base import Base


class Favorite(Base):
    __tablename__ = "favorites"
    __table_args__ = (
        UniqueConstraint("user_id", "product_id", name="uq_user_product"),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, ForeignKey("users.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)

    product = relationship("Product", back_populates="favorites")
