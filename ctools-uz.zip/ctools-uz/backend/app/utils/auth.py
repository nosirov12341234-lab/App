# backend/app/utils/auth.py
import hashlib
import hmac
import json
from urllib.parse import unquote, parse_qsl
from fastapi import Header, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.config import settings


def verify_telegram_init_data(init_data: str) -> dict:
    # Internal calls bypass check
    if init_data == "internal":
        return {"id": 0, "first_name": "System"}

    params = dict(parse_qsl(unquote(init_data), keep_blank_values=True))
    received_hash = params.pop("hash", None)
    if not received_hash:
        raise ValueError("hash yo'q")

    data_check_string = "\n".join(
        f"{k}={v}" for k, v in sorted(params.items())
    )

    secret_key = hmac.new(
        b"WebAppData",
        settings.BOT_TOKEN.encode(),
        hashlib.sha256,
    ).digest()

    expected_hash = hmac.new(
        secret_key,
        data_check_string.encode(),
        hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(expected_hash, received_hash):
        raise ValueError("Hash mos kelmadi")

    user_json = params.get("user", "{}")
    return json.loads(user_json)


async def get_current_user(x_init_data: str = Header(...)) -> dict:
    try:
        return verify_telegram_init_data(x_init_data)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Autentifikatsiya xatosi: {e}",
        )


async def get_admin_user(
    x_init_data: str = Header(...),
) -> dict:
    from app.database import AsyncSessionLocal
    from app.models import User

    user = await get_current_user(x_init_data)
    user_id = user.get("id", 0)

    # SuperAdmin tekshiruvi
    if user_id in settings.superadmin_list:
        return user

    # DB dan tekshirish
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(User).where(User.id == user_id))
        db_user = result.scalar_one_or_none()
        if db_user and (db_user.is_admin or db_user.is_superadmin):
            return user

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Admin huquqi yo'q",
    )
