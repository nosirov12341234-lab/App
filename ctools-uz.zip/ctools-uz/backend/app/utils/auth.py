# backend/app/utils/auth.py
"""
Telegram WebApp initData tekshiruvi.
Hujjat: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
"""
import hashlib
import hmac
import json
from urllib.parse import unquote, parse_qsl
from fastapi import Header, HTTPException, status
from app.config import settings


def verify_telegram_init_data(init_data: str) -> dict:
    """
    initData string'ini tekshirib, foydalanuvchi ma'lumotlarini qaytaradi.
    Noto'g'ri bo'lsa — ValueError chiqaradi.
    """
    params = dict(parse_qsl(unquote(init_data), keep_blank_values=True))
    received_hash = params.pop("hash", None)
    if not received_hash:
        raise ValueError("hash yo'q")

    data_check_string = "\n".join(
        f"{k}={v}" for k, v in sorted(params.items())
    )

    secret_key = hmac.new(
        b"WebAppData",
        settings.BOT_TOKEN.encode(),
        hashlib.sha256,
    ).digest()

    expected_hash = hmac.new(
        secret_key,
        data_check_string.encode(),
        hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(expected_hash, received_hash):
        raise ValueError("Hash mos kelmadi")

    user_json = params.get("user", "{}")
    return json.loads(user_json)


async def get_current_user(x_init_data: str = Header(...)) -> dict:
    """FastAPI dependency — har so'rovda foydalanuvchini tekshiradi"""
    try:
        user = verify_telegram_init_data(x_init_data)
        return user
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Telegram autentifikatsiya xatosi: {e}",
        )


async def get_admin_user(x_init_data: str = Header(...)) -> dict:
    """Faqat adminlar uchun dependency"""
    user = await get_current_user(x_init_data)
    user_id = user.get("id")
    if user_id not in settings.superadmin_list:
        # DB dan tekshiramiz (dinamik adminlar uchun)
        # Bu yerda DB check ham qo'shilgan (routers/admin.py da)
        pass
    return user
