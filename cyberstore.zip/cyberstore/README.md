# ⚡ CyberStore — Telegram Mini App

> Kiberxavfsizlik do'koni | Comic Cyberpunk UI | Uzbek tilida

---

## 🗂 Loyiha tuzilmasi

```
cyberstore/
├── backend/
│   ├── database.py       # SQLAlchemy modellari (User, Product, Order, ...)
│   ├── api.py            # FastAPI REST API + SPA xizmat
│   ├── bot.py            # Aiogram 3.x bot (Force Join, Inline, DeepLink)
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── App.jsx           # Routing + Telegram SDK init
│   │   ├── Store.jsx         # Comic do'kon sahifasi
│   │   ├── ProductDetail.jsx # Mahsulot detali + Cart + Favorites + ForceSubscribe
│   │   ├── AdminPanel.jsx    # To'liq admin boshqaruvi
│   │   ├── main.jsx
│   │   └── styles.css        # Comic Cyberpunk dizayn
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
└── .env.example
```

---

## 🚀 O'rnatish

### 1. Backend
```bash
cd backend
pip install -r requirements.txt
cp ../.env.example .env
# .env faylida BOT_TOKEN va SUPERADMIN_ID ni to'ldiring
```

### 2. Frontend
```bash
cd frontend
npm install
cp ../.env.example .env
# VITE_API_URL ni to'g'rilang
npm run build
```

### 3. Ishga tushirish
```bash
# Terminal 1 — FastAPI server
cd backend
uvicorn api:app --host 0.0.0.0 --port 8000 --reload

# Terminal 2 — Bot
cd backend
python bot.py
```

---

## ⚙️ Sozlash

`.env` faylini to'ldiring:
```env
BOT_TOKEN=7xxxxxxxxx:AAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
SUPERADMIN_ID=123456789          # Sizning Telegram ID'ingiz
API_BASE=http://localhost:8000   # Yoki ishlab chiqarish URL'i
MINI_APP_URL=https://yourdomain.com
VITE_API_URL=https://yourdomain.com
```

**@BotFather** da Mini App ulang:
1. `/newapp` → botni tanlang
2. URL: `https://yourdomain.com`
3. Inline Mode: `/setinline` → yoqing

---

## 🔑 Asosiy xususiyatlar

### Force Subscribe
- Bot `/start` da kanallarni tekshiradi
- A'zo bo'lmagan kanallar ko'rsatiladi
- "✅ Tekshirish" tugmasi bilan qayta tekshiradi
- Admin panel orqali kanallar qo'shiladi/o'chiriladi

### Multi-Admin Tizimi
- **SuperAdmin** (SUPERADMIN_ID): barcha huquqlar + admin boshqarish
- **Admin**: mahsulot, kategoriya, kanal boshqarish, buyurtma tasdiqlash
- Header: `X-Telegram-Id` orqali autentifikatsiya

### Digital Mahsulotlar
- `secret_key` maydoni — faqat admin ko'radi
- Buyurtma detalida kalit ko'rsatiladi
- Premium qo'lda yetkazish xizmati

### Inline Mode
- `@YourBot mahsulot_nomi` — istalgan chatda qidirish
- Comic stil kartalar
- "Ko'rish" tugmasi Mini App'ni ochadi
- "Ulashish" — deep link yaratadi

### Deep Linking
- `t.me/YourBot?start=prod123` → Mini App'da mahsulot sahifasi
- Inline va "Ulashish" tugmalarida ishlatiladi

### Buyurtma tizimi
- Noyob kod: `#CB-XXXX`
- Admin Telegram'ga yo'naltiradi
- Admin status yangilaydi: Kutilmoqda → Tasdiqlangan → Yetkazildi

---

## 🗄 Ma'lumotlar bazasi

| Model      | Asosiy maydonlar                               |
|------------|-----------------------------------------------|
| User       | telegram_id, username, first_name             |
| Admin      | telegram_id, is_superadmin                    |
| Channel    | channel_id, channel_link, title               |
| Category   | name, emoji, description                      |
| Product    | name, price, product_type, secret_key, stock  |
| Order      | order_code, status, total_price               |
| OrderItem  | order_id, product_id, quantity                |
| Favorite   | user_id, product_id                           |

---

## 🎨 UI/UX

- **Shrift**: Bangers (sarlavhalar) + Rajdhani (matn) + Share Tech Mono (kodlar)
- **Rang palitrasi**: #0d1117 bg · #00ff88 neon yashil · #ff006e rozoviy · #7b2fff binafsha · #00d4ff ko'k
- **Comic elementlar**: Qattiq chegaralar · Soya effekti · Nutq pufakchalari · Neon glow
- **Agent**: 🕶️ Cyber-Agent xush kelibsiz xabari bilan

---

## 📋 API yo'nalishlari

### Ommaviy
| Metod | Yo'l | Tavsif |
|-------|------|--------|
| GET | `/api/categories` | Barcha kategoriyalar |
| GET | `/api/products` | Mahsulotlar (filtrlash mumkin) |
| GET | `/api/products/{id}` | Bitta mahsulot |
| POST | `/api/register` | Foydalanuvchini ro'yxatdan o'tkazish |
| POST | `/api/orders` | Yangi buyurtma |
| GET/POST | `/api/favorites/{tid}/{pid}` | Sevimlilar |

### Admin (X-Telegram-Id header kerak)
| Metod | Yo'l | Tavsif |
|-------|------|--------|
| GET/POST/DELETE | `/api/admin/products` | CRUD |
| GET/POST/DELETE | `/api/admin/categories` | CRUD |
| GET/POST/DELETE | `/api/admin/channels` | CRUD |
| GET | `/api/admin/orders` | Buyurtmalar + secret key |
| PATCH | `/api/admin/orders/{code}/status` | Status yangilash |
| GET/POST/DELETE | `/api/admin/admins` | SuperAdmin only |

---

*Ishlab chiqildi: CyberStore Team · Comic Cyberpunk · Uzbek 🇺🇿*
