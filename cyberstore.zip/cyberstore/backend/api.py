"""
CyberStore – FastAPI Backend
Serves the React build + exposes REST API for bot and frontend.
"""
import os, random, string
from datetime import datetime
from typing import List, Optional
from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database import (
    get_db, init_db,
    User, Admin, Channel, Category, Product, Order, OrderItem, Favorite,
    ProductType, OrderStatus,
)

# ─── Config ───────────────────────────────────────────────────────────────────
SUPERADMIN_ID = int(os.getenv("SUPERADMIN_ID", "123456789"))
BOT_TOKEN     = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN")

app = FastAPI(title="CyberStore API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def startup():
    init_db()

# ─── Auth helpers ─────────────────────────────────────────────────────────────

def require_admin(x_telegram_id: Optional[str] = Header(None), db: Session = Depends(get_db)):
    if not x_telegram_id:
        raise HTTPException(403, "X-Telegram-Id header required")
    tid = int(x_telegram_id)
    if tid == SUPERADMIN_ID:
        return tid
    admin = db.query(Admin).filter(Admin.telegram_id == tid).first()
    if not admin:
        raise HTTPException(403, "Admin huquqi yo'q")
    return tid

def require_superadmin(x_telegram_id: Optional[str] = Header(None)):
    if not x_telegram_id or int(x_telegram_id) != SUPERADMIN_ID:
        raise HTTPException(403, "Faqat SuperAdmin")
    return int(x_telegram_id)

# ─── Pydantic schemas ─────────────────────────────────────────────────────────

class CategoryIn(BaseModel):
    name: str
    emoji: Optional[str] = "🔒"
    description: Optional[str] = None

class ProductIn(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    image_url: Optional[str] = None
    product_type: ProductType = ProductType.PHYSICAL
    secret_key: Optional[str] = None
    stock: int = 0
    category_id: Optional[int] = None

class ChannelIn(BaseModel):
    channel_id: str
    channel_link: str
    title: Optional[str] = None

class AdminIn(BaseModel):
    telegram_id: int
    username: Optional[str] = None

class OrderIn(BaseModel):
    telegram_id: int
    items: List[dict]   # [{product_id, quantity}]
    note: Optional[str] = None

class OrderStatusIn(BaseModel):
    status: OrderStatus

# ─── Helper ───────────────────────────────────────────────────────────────────

def gen_order_code():
    suffix = ''.join(random.choices(string.digits, k=4))
    return f"#CB-{suffix}"

# ═══════════════════════════════════════════════════════════════════════════════
# PUBLIC ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/api/channels")
def list_channels(db: Session = Depends(get_db)):
    return db.query(Channel).filter(Channel.is_active == True).all()

@app.get("/api/check-subscriptions/{telegram_id}")
def check_subscriptions(telegram_id: int, db: Session = Depends(get_db)):
    """Returns list of channels user has NOT joined (bot checks via Telegram API)."""
    channels = db.query(Channel).filter(Channel.is_active == True).all()
    return {"channels": [{"id": c.channel_id, "link": c.channel_link, "title": c.title} for c in channels]}

@app.get("/api/categories")
def list_categories(db: Session = Depends(get_db)):
    cats = db.query(Category).all()
    return cats

@app.get("/api/products")
def list_products(
    category_id: Optional[int] = None,
    q: Optional[str] = None,
    db: Session = Depends(get_db)
):
    qry = db.query(Product).filter(Product.is_active == True)
    if category_id:
        qry = qry.filter(Product.category_id == category_id)
    if q:
        qry = qry.filter(Product.name.ilike(f"%{q}%"))
    products = qry.all()
    result = []
    for p in products:
        result.append({
            "id": p.id, "name": p.name, "description": p.description,
            "price": p.price, "image_url": p.image_url,
            "product_type": p.product_type, "stock": p.stock,
            "category_id": p.category_id,
            "category": {"id": p.category.id, "name": p.category.name, "emoji": p.category.emoji} if p.category else None,
        })
    return result

@app.get("/api/products/{product_id}")
def get_product(product_id: int, db: Session = Depends(get_db)):
    p = db.query(Product).filter(Product.id == product_id, Product.is_active == True).first()
    if not p:
        raise HTTPException(404, "Mahsulot topilmadi")
    return {
        "id": p.id, "name": p.name, "description": p.description,
        "price": p.price, "image_url": p.image_url,
        "product_type": p.product_type, "stock": p.stock,
        "category_id": p.category_id,
        "category": {"id": p.category.id, "name": p.category.name, "emoji": p.category.emoji} if p.category else None,
    }

@app.post("/api/register")
def register_user(data: dict, db: Session = Depends(get_db)):
    tid = data.get("telegram_id")
    user = db.query(User).filter(User.telegram_id == tid).first()
    if not user:
        user = User(telegram_id=tid, username=data.get("username"), first_name=data.get("first_name"))
        db.add(user)
        db.commit()
    return {"ok": True}

@app.post("/api/orders")
def create_order(data: OrderIn, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.telegram_id == data.telegram_id).first()
    if not user:
        raise HTTPException(404, "Foydalanuvchi topilmadi")
    total = 0
    items_data = []
    for item in data.items:
        p = db.query(Product).filter(Product.id == item["product_id"]).first()
        if not p:
            raise HTTPException(404, f"Mahsulot {item['product_id']} topilmadi")
        qty = item.get("quantity", 1)
        total += p.price * qty
        items_data.append((p, qty))

    code = gen_order_code()
    while db.query(Order).filter(Order.order_code == code).first():
        code = gen_order_code()

    order = Order(order_code=code, user_id=user.id, total_price=total, note=data.note)
    db.add(order)
    db.flush()
    for p, qty in items_data:
        db.add(OrderItem(order_id=order.id, product_id=p.id, quantity=qty, price_at_purchase=p.price))
    db.commit()
    return {"order_code": code, "total": total}

@app.get("/api/orders/{order_code}")
def get_order(order_code: str, db: Session = Depends(get_db)):
    o = db.query(Order).filter(Order.order_code == order_code).first()
    if not o:
        raise HTTPException(404, "Buyurtma topilmadi")
    items = []
    for oi in o.items:
        items.append({
            "product_id": oi.product_id,
            "product_name": oi.product.name,
            "quantity": oi.quantity,
            "price": oi.price_at_purchase,
            "product_type": oi.product.product_type,
        })
    return {"order_code": o.order_code, "status": o.status, "total": o.total_price, "items": items, "created_at": o.created_at}

# ─── Favorites ────────────────────────────────────────────────────────────────

@app.get("/api/favorites/{telegram_id}")
def get_favorites(telegram_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.telegram_id == telegram_id).first()
    if not user:
        return []
    favs = db.query(Favorite).filter(Favorite.user_id == user.id).all()
    return [{"product_id": f.product_id, "product": {
        "id": f.product.id, "name": f.product.name, "price": f.product.price, "image_url": f.product.image_url
    }} for f in favs]

@app.post("/api/favorites/{telegram_id}/{product_id}")
def toggle_favorite(telegram_id: int, product_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.telegram_id == telegram_id).first()
    if not user:
        raise HTTPException(404)
    fav = db.query(Favorite).filter(Favorite.user_id == user.id, Favorite.product_id == product_id).first()
    if fav:
        db.delete(fav)
        db.commit()
        return {"action": "removed"}
    db.add(Favorite(user_id=user.id, product_id=product_id))
    db.commit()
    return {"action": "added"}

# ═══════════════════════════════════════════════════════════════════════════════
# ADMIN ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

# ─── Admin management (SuperAdmin only) ───────────────────────────────────────

@app.get("/api/admin/admins")
def list_admins(tid=Depends(require_superadmin), db: Session = Depends(get_db)):
    return db.query(Admin).all()

@app.post("/api/admin/admins")
def add_admin(data: AdminIn, tid=Depends(require_superadmin), db: Session = Depends(get_db)):
    if db.query(Admin).filter(Admin.telegram_id == data.telegram_id).first():
        raise HTTPException(400, "Admin allaqachon mavjud")
    admin = Admin(telegram_id=data.telegram_id, username=data.username)
    db.add(admin); db.commit()
    return {"ok": True}

@app.delete("/api/admin/admins/{admin_telegram_id}")
def remove_admin(admin_telegram_id: int, tid=Depends(require_superadmin), db: Session = Depends(get_db)):
    admin = db.query(Admin).filter(Admin.telegram_id == admin_telegram_id).first()
    if not admin:
        raise HTTPException(404)
    db.delete(admin); db.commit()
    return {"ok": True}

# ─── Channel management ───────────────────────────────────────────────────────

@app.get("/api/admin/channels")
def admin_list_channels(tid=Depends(require_admin), db: Session = Depends(get_db)):
    return db.query(Channel).all()

@app.post("/api/admin/channels")
def add_channel(data: ChannelIn, tid=Depends(require_admin), db: Session = Depends(get_db)):
    ch = Channel(channel_id=data.channel_id, channel_link=data.channel_link, title=data.title)
    db.add(ch); db.commit()
    return {"ok": True}

@app.delete("/api/admin/channels/{ch_id}")
def remove_channel(ch_id: int, tid=Depends(require_admin), db: Session = Depends(get_db)):
    ch = db.query(Channel).filter(Channel.id == ch_id).first()
    if not ch:
        raise HTTPException(404)
    db.delete(ch); db.commit()
    return {"ok": True}

# ─── Category management ──────────────────────────────────────────────────────

@app.post("/api/admin/categories")
def create_category(data: CategoryIn, tid=Depends(require_admin), db: Session = Depends(get_db)):
    cat = Category(**data.dict())
    db.add(cat); db.commit()
    return cat

@app.put("/api/admin/categories/{cat_id}")
def update_category(cat_id: int, data: CategoryIn, tid=Depends(require_admin), db: Session = Depends(get_db)):
    cat = db.query(Category).filter(Category.id == cat_id).first()
    if not cat:
        raise HTTPException(404)
    for k, v in data.dict().items():
        setattr(cat, k, v)
    db.commit()
    return cat

@app.delete("/api/admin/categories/{cat_id}")
def delete_category(cat_id: int, tid=Depends(require_admin), db: Session = Depends(get_db)):
    cat = db.query(Category).filter(Category.id == cat_id).first()
    if not cat:
        raise HTTPException(404)
    db.delete(cat); db.commit()
    return {"ok": True}

# ─── Product management ───────────────────────────────────────────────────────

@app.get("/api/admin/products")
def admin_list_products(tid=Depends(require_admin), db: Session = Depends(get_db)):
    products = db.query(Product).all()
    result = []
    for p in products:
        d = {
            "id": p.id, "name": p.name, "description": p.description,
            "price": p.price, "image_url": p.image_url,
            "product_type": p.product_type, "stock": p.stock,
            "is_active": p.is_active, "category_id": p.category_id,
            "secret_key": p.secret_key,   # admin sees this
        }
        result.append(d)
    return result

@app.post("/api/admin/products")
def create_product(data: ProductIn, tid=Depends(require_admin), db: Session = Depends(get_db)):
    p = Product(**data.dict())
    db.add(p); db.commit(); db.refresh(p)
    return {"id": p.id}

@app.put("/api/admin/products/{prod_id}")
def update_product(prod_id: int, data: ProductIn, tid=Depends(require_admin), db: Session = Depends(get_db)):
    p = db.query(Product).filter(Product.id == prod_id).first()
    if not p:
        raise HTTPException(404)
    for k, v in data.dict().items():
        setattr(p, k, v)
    db.commit()
    return {"ok": True}

@app.delete("/api/admin/products/{prod_id}")
def delete_product(prod_id: int, tid=Depends(require_admin), db: Session = Depends(get_db)):
    p = db.query(Product).filter(Product.id == prod_id).first()
    if not p:
        raise HTTPException(404)
    p.is_active = False
    db.commit()
    return {"ok": True}

# ─── Order management ─────────────────────────────────────────────────────────

@app.get("/api/admin/orders")
def admin_list_orders(tid=Depends(require_admin), db: Session = Depends(get_db)):
    orders = db.query(Order).order_by(Order.created_at.desc()).all()
    result = []
    for o in orders:
        items = []
        for oi in o.items:
            items.append({
                "product_name": oi.product.name,
                "product_type": oi.product.product_type,
                "secret_key": oi.product.secret_key,
                "quantity": oi.quantity,
                "price": oi.price_at_purchase,
            })
        result.append({
            "order_code": o.order_code,
            "status": o.status,
            "total": o.total_price,
            "user": {"telegram_id": o.user.telegram_id, "first_name": o.user.first_name},
            "items": items,
            "created_at": o.created_at,
            "note": o.note,
        })
    return result

@app.patch("/api/admin/orders/{order_code}/status")
def update_order_status(order_code: str, data: OrderStatusIn, tid=Depends(require_admin), db: Session = Depends(get_db)):
    o = db.query(Order).filter(Order.order_code == order_code).first()
    if not o:
        raise HTTPException(404)
    o.status = data.status
    db.commit()
    return {"ok": True}

# ─── Static files (React build) ───────────────────────────────────────────────

FRONTEND_BUILD = os.path.join(os.path.dirname(__file__), "..", "frontend", "dist")
if os.path.exists(FRONTEND_BUILD):
    app.mount("/assets", StaticFiles(directory=os.path.join(FRONTEND_BUILD, "assets")), name="assets")

    @app.get("/{full_path:path}")
    def serve_spa(full_path: str):
        return FileResponse(os.path.join(FRONTEND_BUILD, "index.html"))
