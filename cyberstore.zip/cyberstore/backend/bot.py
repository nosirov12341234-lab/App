"""
CyberStore – Aiogram 3.x Bot
Features: Force Subscribe, Inline Mode, Deep Linking
"""
import os, asyncio, aiohttp
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import CommandStart, Command
from aiogram.types import (
    InlineKeyboardMarkup, InlineKeyboardButton,
    InlineQueryResultArticle, InputTextMessageContent,
    WebAppInfo,
)
from aiogram.enums import ChatMemberStatus
from aiogram.utils.deep_linking import decode_payload
import hashlib

BOT_TOKEN      = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN")
API_BASE       = os.getenv("API_BASE", "http://localhost:8000")
MINI_APP_URL   = os.getenv("MINI_APP_URL", "https://yourdomain.com")
SUPERADMIN_ID  = int(os.getenv("SUPERADMIN_ID", "123456789"))

bot = Bot(token=BOT_TOKEN)
dp  = Dispatcher()


# ─── Helpers ──────────────────────────────────────────────────────────────────

async def fetch_channels() -> list[dict]:
    async with aiohttp.ClientSession() as s:
        async with s.get(f"{API_BASE}/api/channels") as r:
            return await r.json()

async def check_user_subscriptions(user_id: int) -> list[dict]:
    """Returns list of channels the user has NOT joined."""
    channels = await fetch_channels()
    not_joined = []
    for ch in channels:
        try:
            member = await bot.get_chat_member(ch["id"], user_id)
            if member.status in (ChatMemberStatus.LEFT, ChatMemberStatus.KICKED, ChatMemberStatus.RESTRICTED):
                not_joined.append(ch)
        except Exception:
            not_joined.append(ch)
    return not_joined

def build_subscribe_keyboard(channels: list[dict]) -> InlineKeyboardMarkup:
    buttons = []
    for ch in channels:
        buttons.append([InlineKeyboardButton(text=f"📢 {ch.get('title', 'Kanal')}", url=ch["link"])])
    buttons.append([InlineKeyboardButton(text="✅ Tekshirish", callback_data="check_sub")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def build_main_keyboard(deep_link_product: str | None = None) -> InlineKeyboardMarkup:
    url = MINI_APP_URL
    if deep_link_product:
        url = f"{MINI_APP_URL}?product={deep_link_product}"
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="🛒 Do'konga kirish",
            web_app=WebAppInfo(url=url)
        )
    ]])

async def register_user(user: types.User):
    async with aiohttp.ClientSession() as s:
        await s.post(f"{API_BASE}/api/register", json={
            "telegram_id": user.id,
            "username": user.username,
            "first_name": user.first_name,
        })


# ─── /start handler ───────────────────────────────────────────────────────────

@dp.message(CommandStart())
async def cmd_start(message: types.Message):
    await register_user(message.from_user)
    args = message.text.split(maxsplit=1)[1] if len(message.text.split()) > 1 else None
    deep_link_product = None

    if args and args.startswith("prod"):
        deep_link_product = args.replace("prod", "")

    not_joined = await check_user_subscriptions(message.from_user.id)
    if not_joined:
        await message.answer(
            "⚠️ <b>AGENT, MISSIYA BLOKLANDI!</b>\n\n"
            "Do'konimizga kirish uchun quyidagi kanallarga a'zo bo'ling:\n\n"
            "Barcha kanallarga qo'shilgach <b>✅ Tekshirish</b> tugmasini bosing.",
            parse_mode="HTML",
            reply_markup=build_subscribe_keyboard(not_joined),
        )
        return

    name = message.from_user.first_name or "Agent"
    text = (
        f"🎯 <b>Xush kelibsiz, {name}!</b>\n\n"
        f"🕶️ <i>CyberStore – Kiberxavfsizlik do'koni</i>\n\n"
        "Missiya: Savatni to'ldirish!\n"
        "Qurollaringizni tanlang, Agent. 💻🔐"
    )
    await message.answer(text, parse_mode="HTML", reply_markup=build_main_keyboard(deep_link_product))


# ─── Subscription check callback ──────────────────────────────────────────────

@dp.callback_query(F.data == "check_sub")
async def check_sub_callback(call: types.CallbackQuery):
    not_joined = await check_user_subscriptions(call.from_user.id)
    if not_joined:
        await call.answer("❌ Hali ham a'zo emassiz!", show_alert=True)
        await call.message.edit_reply_markup(reply_markup=build_subscribe_keyboard(not_joined))
        return

    await call.answer("✅ Zo'r! Endi do'konga kiring!", show_alert=True)
    name = call.from_user.first_name or "Agent"
    await call.message.edit_text(
        f"🎯 <b>Xush kelibsiz, {name}!</b>\n\n"
        "Missiya: Savatni to'ldirish! 🛒",
        parse_mode="HTML",
        reply_markup=build_main_keyboard(),
    )


# ─── Admin /panel command ─────────────────────────────────────────────────────

@dp.message(Command("panel"))
async def admin_panel(message: types.Message):
    async with aiohttp.ClientSession() as s:
        async with s.get(f"{API_BASE}/api/admin/admins",
                         headers={"x-telegram-id": str(message.from_user.id)}) as r:
            if r.status != 200:
                await message.answer("❌ Admin huquqi yo'q.")
                return

    panel_url = f"{MINI_APP_URL}?admin=1"
    await message.answer(
        "🔐 <b>Admin Paneli</b>\n\nCyberStore boshqaruv markazi:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="⚙️ Admin Paneliga kirish", web_app=WebAppInfo(url=panel_url))
        ]])
    )


# ─── Inline Mode ──────────────────────────────────────────────────────────────

@dp.inline_query()
async def inline_query_handler(query: types.InlineQuery):
    search_term = query.query.strip()
    results = []

    async with aiohttp.ClientSession() as s:
        url = f"{API_BASE}/api/products"
        if search_term:
            url += f"?q={search_term}"
        async with s.get(url) as r:
            if r.status != 200:
                await query.answer([], cache_time=1)
                return
            products = await r.json()

    for p in products[:15]:
        product_url = f"{MINI_APP_URL}?product={p['id']}"
        price_str = f"{p['price']:,.0f} so'm"
        type_badge = "💾 Digital" if p["product_type"] == "digital" else "📦 Jismoniy"
        cat_name = p["category"]["name"] if p.get("category") else "Umumiy"

        desc = (p.get("description") or "")[:100]

        results.append(
            InlineQueryResultArticle(
                id=str(p["id"]),
                title=f"{'🔐' if p['product_type']=='digital' else '📦'} {p['name']}",
                description=f"{price_str} | {cat_name} | {type_badge}",
                thumb_url=p.get("image_url") or "https://via.placeholder.com/100x100/0d1117/00ff88?text=CB",
                input_message_content=InputTextMessageContent(
                    message_text=(
                        f"🎯 <b>{p['name']}</b>\n"
                        f"{'─'*25}\n"
                        f"💰 Narx: <b>{price_str}</b>\n"
                        f"🏷️ Tur: <b>{type_badge}</b>\n"
                        f"📂 Kategoriya: <b>{cat_name}</b>\n\n"
                        f"📝 {desc}{'...' if len(desc)==100 else ''}\n\n"
                        f"<i>CyberStore – Kiberxavfsizlik do'koni 🔒</i>"
                    ),
                    parse_mode="HTML",
                ),
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                    InlineKeyboardButton(text="🛒 Ko'rish", url=product_url),
                    InlineKeyboardButton(text="🔗 Ulashish", url=f"https://t.me/share/url?url=https://t.me/YourBot?start=prod{p['id']}&text={p['name']}")
                ]])
            )
        )

    if not results:
        results = [InlineQueryResultArticle(
            id="empty",
            title="🔍 Mahsulot topilmadi",
            description="Boshqa so'z bilan qidiring",
            input_message_content=InputTextMessageContent(
                message_text="❌ Mahsulot topilmadi. CyberStore'ni ko'ring: @YourBot"
            )
        )]

    await query.answer(results, cache_time=30, is_personal=True)


# ─── Main ─────────────────────────────────────────────────────────────────────

async def main():
    print("🤖 CyberStore Bot ishga tushdi...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
