import { useEffect, useState } from "react";

const API = import.meta.env.VITE_API_URL || "";
const tg = window.Telegram?.WebApp;
const ADMIN_ID = tg?.initDataUnsafe?.user?.id || 123456789;
const HEADERS = { "Content-Type": "application/json", "x-telegram-id": String(ADMIN_ID) };

export default function AdminPanel({ ctx }) {
  const [tab, setTab] = useState("products");

  return (
    <div className="admin-root">
      <div className="admin-header">
        <div className="admin-logo">⚙️ <span>ADMIN PANEL</span></div>
        <div className="admin-sub">CyberStore Boshqaruvi</div>
      </div>

      <div className="admin-tabs">
        {[
          { id: "products", label: "📦 Mahsulotlar" },
          { id: "categories", label: "📂 Kategoriyalar" },
          { id: "orders", label: "🧾 Buyurtmalar" },
          { id: "channels", label: "📢 Kanallar" },
          { id: "admins", label: "👤 Adminlar" },
        ].map((t) => (
          <button
            key={t.id}
            className={`admin-tab ${tab === t.id ? "active" : ""}`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="admin-content">
        {tab === "products" && <ProductsManager />}
        {tab === "categories" && <CategoriesManager />}
        {tab === "orders" && <OrdersManager />}
        {tab === "channels" && <ChannelsManager />}
        {tab === "admins" && <AdminsManager />}
      </div>
    </div>
  );
}

// ─── Products ─────────────────────────────────────────────────────────────────
function ProductsManager() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState(null); // null = list, object = edit/new
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchAll(); }, []);

  async function fetchAll() {
    setLoading(true);
    const [pr, cr] = await Promise.all([
      fetch(`${API}/api/admin/products`, { headers: HEADERS }),
      fetch(`${API}/api/categories`, { headers: HEADERS }),
    ]);
    setProducts(await pr.json());
    setCategories(await cr.json());
    setLoading(false);
  }

  async function save(data) {
    const url = data.id ? `${API}/api/admin/products/${data.id}` : `${API}/api/admin/products`;
    const method = data.id ? "PUT" : "POST";
    const { id, ...body } = data;
    await fetch(url, { method, headers: HEADERS, body: JSON.stringify(body) });
    setForm(null);
    fetchAll();
  }

  async function del(id) {
    if (!confirm("O'chirishni tasdiqlaysizmi?")) return;
    await fetch(`${API}/api/admin/products/${id}`, { method: "DELETE", headers: HEADERS });
    fetchAll();
  }

  if (form !== null) {
    return <ProductForm form={form} categories={categories} onSave={save} onCancel={() => setForm(null)} />;
  }

  return (
    <div className="manager">
      <div className="manager-top">
        <h2 className="manager-title">📦 Mahsulotlar</h2>
        <button className="comic-btn green" onClick={() => setForm({ name: "", price: 0, product_type: "physical", stock: 0 })}>
          + Qo'shish
        </button>
      </div>
      {loading ? <div className="loading-txt">Yuklanmoqda...</div> : (
        <div className="admin-list">
          {products.map((p) => (
            <div key={p.id} className="admin-card">
              <div className="admin-card-info">
                <div className="admin-card-name">
                  {p.product_type === "digital" ? "💾" : "📦"} {p.name}
                </div>
                <div className="admin-card-meta">
                  {p.price.toLocaleString()} so'm | Stok: {p.stock}
                  {p.product_type === "digital" && p.secret_key && (
                    <span className="secret-badge"> 🔑 Kalit mavjud</span>
                  )}
                </div>
              </div>
              <div className="admin-card-btns">
                <button className="comic-btn blue sm" onClick={() => setForm(p)}>✏️</button>
                <button className="comic-btn red sm" onClick={() => del(p.id)}>🗑️</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ProductForm({ form, categories, onSave, onCancel }) {
  const [data, setData] = useState(form);
  const set = (k, v) => setData((d) => ({ ...d, [k]: v }));

  return (
    <div className="form-panel">
      <h3 className="form-title">{data.id ? "✏️ Tahrirlash" : "➕ Yangi mahsulot"}</h3>
      <label className="field-label">Nomi</label>
      <input className="field-input" value={data.name} onChange={(e) => set("name", e.target.value)} />

      <label className="field-label">Tavsif</label>
      <textarea className="field-textarea" value={data.description || ""} onChange={(e) => set("description", e.target.value)} />

      <label className="field-label">Narx (so'm)</label>
      <input className="field-input" type="number" value={data.price} onChange={(e) => set("price", +e.target.value)} />

      <label className="field-label">Rasm URL</label>
      <input className="field-input" value={data.image_url || ""} onChange={(e) => set("image_url", e.target.value)} />

      <label className="field-label">Tur</label>
      <select className="field-select" value={data.product_type} onChange={(e) => set("product_type", e.target.value)}>
        <option value="physical">📦 Jismoniy</option>
        <option value="digital">💾 Digital</option>
      </select>

      {data.product_type === "digital" && (
        <>
          <label className="field-label">🔑 Maxfiy kalit / Nota (Faqat admin)</label>
          <textarea className="field-textarea secret" placeholder="Litsenziya kaliti, aktivatsiya kodi..." value={data.secret_key || ""} onChange={(e) => set("secret_key", e.target.value)} />
        </>
      )}

      <label className="field-label">Stok</label>
      <input className="field-input" type="number" value={data.stock} onChange={(e) => set("stock", +e.target.value)} />

      <label className="field-label">Kategoriya</label>
      <select className="field-select" value={data.category_id || ""} onChange={(e) => set("category_id", e.target.value ? +e.target.value : null)}>
        <option value="">— Tanlang —</option>
        {categories.map((c) => <option key={c.id} value={c.id}>{c.emoji} {c.name}</option>)}
      </select>

      <div className="form-actions">
        <button className="comic-btn green" onClick={() => onSave(data)}>💾 Saqlash</button>
        <button className="comic-btn gray" onClick={onCancel}>Bekor</button>
      </div>
    </div>
  );
}

// ─── Categories ───────────────────────────────────────────────────────────────
function CategoriesManager() {
  const [cats, setCats] = useState([]);
  const [form, setForm] = useState(null);
  useEffect(() => { fetch(`${API}/api/categories`).then(r => r.json()).then(setCats); }, []);

  async function save(data) {
    const url = data.id ? `${API}/api/admin/categories/${data.id}` : `${API}/api/admin/categories`;
    await fetch(url, { method: data.id ? "PUT" : "POST", headers: HEADERS, body: JSON.stringify(data) });
    setForm(null);
    fetch(`${API}/api/categories`).then(r => r.json()).then(setCats);
  }
  async function del(id) {
    if (!confirm("O'chirishni tasdiqlaysizmi?")) return;
    await fetch(`${API}/api/admin/categories/${id}`, { method: "DELETE", headers: HEADERS });
    fetch(`${API}/api/categories`).then(r => r.json()).then(setCats);
  }

  return (
    <div className="manager">
      <div className="manager-top">
        <h2 className="manager-title">📂 Kategoriyalar</h2>
        <button className="comic-btn green" onClick={() => setForm({ name: "", emoji: "🔒" })}>+ Qo'shish</button>
      </div>
      {form && (
        <div className="form-panel">
          <input className="field-input" placeholder="Nomi" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
          <input className="field-input" placeholder="Emoji" value={form.emoji} onChange={e => setForm(f => ({ ...f, emoji: e.target.value }))} />
          <textarea className="field-textarea" placeholder="Tavsif" value={form.description || ""} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
          <div className="form-actions">
            <button className="comic-btn green" onClick={() => save(form)}>💾 Saqlash</button>
            <button className="comic-btn gray" onClick={() => setForm(null)}>Bekor</button>
          </div>
        </div>
      )}
      <div className="admin-list">
        {cats.map(c => (
          <div key={c.id} className="admin-card">
            <div className="admin-card-info">
              <div className="admin-card-name">{c.emoji} {c.name}</div>
              <div className="admin-card-meta">{c.description || "Tavsif yo'q"}</div>
            </div>
            <div className="admin-card-btns">
              <button className="comic-btn blue sm" onClick={() => setForm(c)}>✏️</button>
              <button className="comic-btn red sm" onClick={() => del(c.id)}>🗑️</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Orders ───────────────────────────────────────────────────────────────────
function OrdersManager() {
  const [orders, setOrders] = useState([]);
  const [expanded, setExpanded] = useState(null);
  useEffect(() => {
    fetch(`${API}/api/admin/orders`, { headers: HEADERS }).then(r => r.json()).then(setOrders);
  }, []);

  const STATUS_COLORS = { pending: "orange", verified: "blue", delivered: "green", cancelled: "red" };
  const STATUS_LABELS = { pending: "Kutilmoqda", verified: "Tasdiqlangan", delivered: "Yetkazildi", cancelled: "Bekor" };

  async function updateStatus(code, status) {
    await fetch(`${API}/api/admin/orders/${code}/status`, {
      method: "PATCH", headers: HEADERS, body: JSON.stringify({ status }),
    });
    setOrders(prev => prev.map(o => o.order_code === code ? { ...o, status } : o));
  }

  return (
    <div className="manager">
      <h2 className="manager-title">🧾 Buyurtmalar</h2>
      <div className="admin-list">
        {orders.map(o => (
          <div key={o.order_code} className="admin-card order-card">
            <div className="order-header" onClick={() => setExpanded(expanded === o.order_code ? null : o.order_code)}>
              <div>
                <span className="order-code">{o.order_code}</span>
                <span className={`status-badge ${STATUS_COLORS[o.status]}`}>{STATUS_LABELS[o.status]}</span>
              </div>
              <div className="order-meta">
                {o.user?.first_name} | {o.total.toLocaleString()} so'm
              </div>
            </div>
            {expanded === o.order_code && (
              <div className="order-detail">
                <div className="order-items">
                  {o.items.map((item, i) => (
                    <div key={i} className="order-item">
                      <span>{item.product_type === "digital" ? "💾" : "📦"} {item.product_name} ×{item.quantity}</span>
                      {item.product_type === "digital" && item.secret_key && (
                        <div className="secret-key-box">🔑 <b>Kalit:</b> {item.secret_key}</div>
                      )}
                    </div>
                  ))}
                </div>
                {o.note && <div className="order-note">📝 {o.note}</div>}
                <div className="status-actions">
                  {["pending","verified","delivered","cancelled"].map(s => (
                    <button key={s} className={`comic-btn sm ${s === o.status ? "active-status" : "gray"}`}
                      onClick={() => updateStatus(o.order_code, s)}>
                      {STATUS_LABELS[s]}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Channels ─────────────────────────────────────────────────────────────────
function ChannelsManager() {
  const [channels, setChannels] = useState([]);
  const [form, setForm] = useState({ channel_id: "", channel_link: "", title: "" });
  useEffect(() => { fetch(`${API}/api/admin/channels`, { headers: HEADERS }).then(r => r.json()).then(setChannels); }, []);

  async function add() {
    await fetch(`${API}/api/admin/channels`, { method: "POST", headers: HEADERS, body: JSON.stringify(form) });
    setForm({ channel_id: "", channel_link: "", title: "" });
    fetch(`${API}/api/admin/channels`, { headers: HEADERS }).then(r => r.json()).then(setChannels);
  }
  async function del(id) {
    await fetch(`${API}/api/admin/channels/${id}`, { method: "DELETE", headers: HEADERS });
    setChannels(prev => prev.filter(c => c.id !== id));
  }

  return (
    <div className="manager">
      <h2 className="manager-title">📢 Force Subscribe Kanallar</h2>
      <div className="form-panel">
        <input className="field-input" placeholder="Kanal ID (@username yoki -100xxx)" value={form.channel_id} onChange={e => setForm(f => ({ ...f, channel_id: e.target.value }))} />
        <input className="field-input" placeholder="Kanal havolasi (t.me/...)" value={form.channel_link} onChange={e => setForm(f => ({ ...f, channel_link: e.target.value }))} />
        <input className="field-input" placeholder="Kanal nomi" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} />
        <button className="comic-btn green" onClick={add}>+ Qo'shish</button>
      </div>
      <div className="admin-list">
        {channels.map(c => (
          <div key={c.id} className="admin-card">
            <div className="admin-card-info">
              <div className="admin-card-name">📢 {c.title || c.channel_id}</div>
              <div className="admin-card-meta">{c.channel_link}</div>
            </div>
            <button className="comic-btn red sm" onClick={() => del(c.id)}>🗑️</button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Admins ───────────────────────────────────────────────────────────────────
function AdminsManager() {
  const [admins, setAdmins] = useState([]);
  const [form, setForm] = useState({ telegram_id: "", username: "" });
  useEffect(() => { fetch(`${API}/api/admin/admins`, { headers: HEADERS }).then(r => r.json()).then(setAdmins).catch(() => {}); }, []);

  async function add() {
    await fetch(`${API}/api/admin/admins`, {
      method: "POST", headers: HEADERS,
      body: JSON.stringify({ telegram_id: +form.telegram_id, username: form.username }),
    });
    setForm({ telegram_id: "", username: "" });
    fetch(`${API}/api/admin/admins`, { headers: HEADERS }).then(r => r.json()).then(setAdmins);
  }
  async function del(tid) {
    await fetch(`${API}/api/admin/admins/${tid}`, { method: "DELETE", headers: HEADERS });
    setAdmins(prev => prev.filter(a => a.telegram_id !== tid));
  }

  return (
    <div className="manager">
      <h2 className="manager-title">👤 Adminlar (SuperAdmin)</h2>
      <div className="form-panel">
        <input className="field-input" placeholder="Telegram ID" type="number" value={form.telegram_id} onChange={e => setForm(f => ({ ...f, telegram_id: e.target.value }))} />
        <input className="field-input" placeholder="Username (@...)" value={form.username} onChange={e => setForm(f => ({ ...f, username: e.target.value }))} />
        <button className="comic-btn green" onClick={add}>+ Admin qo'shish</button>
      </div>
      <div className="admin-list">
        {admins.map(a => (
          <div key={a.id} className="admin-card">
            <div className="admin-card-info">
              <div className="admin-card-name">👤 {a.username || `ID: ${a.telegram_id}`}</div>
              <div className="admin-card-meta">Telegram ID: {a.telegram_id}</div>
            </div>
            <button className="comic-btn red sm" onClick={() => del(a.telegram_id)}>🗑️</button>
          </div>
        ))}
      </div>
    </div>
  );
}
