import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const API = import.meta.env.VITE_API_URL || "";

export default function Store({ ctx }) {
  const { user, cart, favorites, addToCart, toggleFavorite, tg } = ctx;
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [activeCategory, setActiveCategory] = useState(null);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCategories();
    fetchProducts();
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [activeCategory, search]);

  async function fetchCategories() {
    const res = await fetch(`${API}/api/categories`);
    const data = await res.json();
    setCategories(data);
  }

  async function fetchProducts() {
    setLoading(true);
    let url = `${API}/api/products?`;
    if (activeCategory) url += `category_id=${activeCategory}&`;
    if (search) url += `q=${encodeURIComponent(search)}&`;
    const res = await fetch(url);
    const data = await res.json();
    setProducts(data);
    setLoading(false);
  }

  function handleShare(product) {
    const shareUrl = `https://t.me/YourBot?start=prod${product.id}`;
    if (tg?.shareToContact) {
      tg.shareToContact({ text: `${product.name}\n${shareUrl}` });
    } else {
      navigator.share?.({ title: product.name, url: shareUrl });
    }
  }

  const cartCount = cart.reduce((acc, i) => acc + i.qty, 0);

  return (
    <div className="store">
      {/* Header */}
      <header className="store-header">
        <div className="header-top">
          <div className="logo-zone">
            <span className="logo-icon">⚡</span>
            <span className="logo-text">CYBER<span className="logo-accent">STORE</span></span>
          </div>
          <div className="header-actions">
            <button className="icon-btn" onClick={() => navigate("/favorites")}>
              <span>❤️</span>
              {favorites.length > 0 && <span className="badge">{favorites.length}</span>}
            </button>
            <button className="icon-btn" onClick={() => navigate("/cart")}>
              <span>🛒</span>
              {cartCount > 0 && <span className="badge">{cartCount}</span>}
            </button>
          </div>
        </div>

        {/* Agent greeting */}
        <div className="agent-bubble">
          <div className="agent-avatar">🕶️</div>
          <div className="bubble">
            <span className="bubble-text">
              Xush kelibsiz, <b>{user?.first_name || "Agent"}!</b>
              <br />Missiya: Savatni to'ldirish 🎯
            </span>
          </div>
        </div>

        {/* Search */}
        <div className="search-wrap">
          <span className="search-icon">🔍</span>
          <input
            className="search-input"
            placeholder="Mahsulot qidirish..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </header>

      {/* Categories */}
      <div className="categories-scroll">
        <button
          className={`cat-chip ${!activeCategory ? "active" : ""}`}
          onClick={() => setActiveCategory(null)}
        >
          ⚡ Barchasi
        </button>
        {categories.map((cat) => (
          <button
            key={cat.id}
            className={`cat-chip ${activeCategory === cat.id ? "active" : ""}`}
            onClick={() => setActiveCategory(activeCategory === cat.id ? null : cat.id)}
          >
            {cat.emoji} {cat.name}
          </button>
        ))}
      </div>

      {/* Products Grid */}
      {loading ? (
        <div className="loading-grid">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="product-card skeleton" />
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🔎</div>
          <p className="empty-title">Mahsulot topilmadi</p>
          <p className="empty-sub">Boshqa so'z bilan qidiring</p>
        </div>
      ) : (
        <div className="products-grid">
          {products.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              isFav={favorites.includes(p.id)}
              onFav={() => toggleFavorite(p.id)}
              onAdd={() => addToCart(p)}
              onShare={() => handleShare(p)}
              onClick={() => navigate(`/product/${p.id}`)}
            />
          ))}
        </div>
      )}

      {/* Bottom nav */}
      <nav className="bottom-nav">
        <button className="nav-item active" onClick={() => navigate("/")}>
          <span>🏠</span><span>Do'kon</span>
        </button>
        <button className="nav-item" onClick={() => navigate("/favorites")}>
          <span>❤️</span><span>Sevimlilar</span>
        </button>
        <button className="nav-item cart-nav" onClick={() => navigate("/cart")}>
          <span>🛒</span>
          {cartCount > 0 && <span className="cart-badge">{cartCount}</span>}
          <span>Savat</span>
        </button>
      </nav>
    </div>
  );
}

function ProductCard({ product, isFav, onFav, onAdd, onShare, onClick }) {
  const isDigital = product.product_type === "digital";
  return (
    <div className="product-card" onClick={onClick}>
      {/* Type badge */}
      <div className={`type-badge ${isDigital ? "digital" : "physical"}`}>
        {isDigital ? "💾 DIGITAL" : "📦 JISMONIY"}
      </div>

      {/* Image */}
      <div className="card-img-wrap">
        {product.image_url ? (
          <img src={product.image_url} alt={product.name} className="card-img" />
        ) : (
          <div className="card-img-placeholder">
            {isDigital ? "🔐" : "📦"}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="card-content" onClick={(e) => e.stopPropagation()}>
        <h3 className="card-title">{product.name}</h3>
        {product.category && (
          <span className="card-cat">{product.category.emoji} {product.category.name}</span>
        )}
        <div className="card-price">{product.price.toLocaleString()} so'm</div>

        {/* Actions */}
        <div className="card-actions">
          <button
            className={`fav-btn ${isFav ? "fav-active" : ""}`}
            onClick={onFav}
          >
            {isFav ? "❤️" : "🤍"}
          </button>
          <button className="share-btn" onClick={onShare}>
            🔗
          </button>
          <button className="add-btn" onClick={onAdd}>
            + Savat
          </button>
        </div>
      </div>

      {/* Comic border effect */}
      <div className="card-shadow" />
    </div>
  );
}
