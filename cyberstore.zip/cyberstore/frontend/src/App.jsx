import { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Store from "./Store";
import ProductDetail, { Cart, Favorites, ForceSubscribe } from "./ProductDetail";
import AdminPanel from "./AdminPanel";
import "./styles.css";

const API = import.meta.env.VITE_API_URL || "";

export default function App() {
  const [tg, setTg] = useState(null);
  const [user, setUser] = useState(null);
  const [checkingSubscription, setCheckingSubscription] = useState(true);
  const [unsubscribedChannels, setUnsubscribedChannels] = useState([]);
  const [cart, setCart] = useState([]);
  const [favorites, setFavorites] = useState([]);

  const urlParams = new URLSearchParams(window.location.search);
  const adminMode = urlParams.get("admin") === "1";
  const deepProduct = urlParams.get("product");

  useEffect(() => {
    const tgApp = window.Telegram?.WebApp;
    if (tgApp) {
      tgApp.ready();
      tgApp.expand();
      tgApp.setHeaderColor?.("#0d1117");
      tgApp.setBackgroundColor?.("#0d1117");
      setTg(tgApp);
      const initUser = tgApp.initDataUnsafe?.user;
      if (initUser) {
        setUser(initUser);
        setCheckingSubscription(false);
        loadFavorites(initUser.id);
        fetch(`${API}/api/register`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ telegram_id: initUser.id, username: initUser.username, first_name: initUser.first_name }),
        }).catch(() => {});
      } else {
        setUser({ id: 123456789, first_name: "Agent", username: "dev" });
        setCheckingSubscription(false);
      }
    } else {
      setUser({ id: 123456789, first_name: "Agent", username: "dev" });
      setCheckingSubscription(false);
    }
  }, []);

  async function loadFavorites(telegramId) {
    try {
      const res = await fetch(`${API}/api/favorites/${telegramId}`);
      const data = await res.json();
      if (Array.isArray(data)) setFavorites(data.map((f) => f.product_id));
    } catch {}
  }

  function addToCart(product, qty = 1) {
    setCart((prev) => {
      const existing = prev.find((i) => i.product.id === product.id);
      if (existing) return prev.map((i) => i.product.id === product.id ? { ...i, qty: i.qty + qty } : i);
      return [...prev, { product, qty }];
    });
    tg?.HapticFeedback?.impactOccurred("medium");
  }

  function removeFromCart(productId) { setCart((prev) => prev.filter((i) => i.product.id !== productId)); }

  function updateCartQty(productId, qty) {
    if (qty <= 0) return removeFromCart(productId);
    setCart((prev) => prev.map((i) => i.product.id === productId ? { ...i, qty } : i));
  }

  async function toggleFavorite(productId) {
    if (!user) return;
    try {
      const res = await fetch(`${API}/api/favorites/${user.id}/${productId}`, { method: "POST" });
      const data = await res.json();
      if (data.action === "added") setFavorites((prev) => [...prev, productId]);
      else setFavorites((prev) => prev.filter((id) => id !== productId));
      tg?.HapticFeedback?.impactOccurred("light");
    } catch {}
  }

  const ctx = { tg, user, cart, favorites, addToCart, removeFromCart, updateCartQty, toggleFavorite, deepProduct, API };

  if (checkingSubscription) {
    return (
      <div className="splash">
        <div className="splash-logo">⚡</div>
        <div className="splash-text">CYBERSTORE</div>
        <div className="splash-sub">Yuklanmoqda...</div>
      </div>
    );
  }

  if (unsubscribedChannels.length > 0) {
    return <ForceSubscribe channels={unsubscribedChannels} onDone={() => setUnsubscribedChannels([])} />;
  }

  if (adminMode) return <div className="app-root"><AdminPanel ctx={ctx} /></div>;

  return (
    <div className="app-root">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Store ctx={ctx} />} />
          <Route path="/product/:id" element={<ProductDetail ctx={ctx} />} />
          <Route path="/cart" element={<Cart ctx={ctx} />} />
          <Route path="/favorites" element={<Favorites ctx={ctx} />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}
