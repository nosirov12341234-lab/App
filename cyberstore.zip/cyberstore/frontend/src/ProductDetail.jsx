// ─── ProductDetail.jsx ────────────────────────────────────────────────────────
import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";

const API = import.meta.env.VITE_API_URL || "";

export function ProductDetail({ ctx }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart, toggleFavorite, favorites, tg } = ctx;
  const [product, setProduct] = useState(null);

  useEffect(() => {
    fetch(`${API}/api/products/${id}`).then(r => r.json()).then(setProduct);
  }, [id]);

  if (!product) return <div className="loading-page">Yuklanmoqda...</div>;

  const isFav = favorites.includes(product.id);
  const isDigital = product.product_type === "digital";

  function handleShare() {
    const url = `https://t.me/YourBot?start=prod${product.id}`;
    if (tg?.shareToContact) {
      tg.shareToContact({ text: `${product.name}\n${url}` });
    } else {
      navigator.share?.({ title: product.name, url });
    }
  }

  return (
    <div className="detail-page">
      <button className="back-btn" onClick={() => navigate(-1)}>← Orqaga</button>

      <div className={`detail-type-badge ${isDigital ? "digital" : "physical"}`}>
        {isDigital ? "💾 DIGITAL MAHSULOT" : "📦 JISMONIY MAHSULOT"}
      </div>

      <div className="detail-img-wrap">
        {product.image_url ? (
          <img src={product.image_url} alt={product.name} className="detail-img" />
        ) : (
          <div className="detail-img-placeholder">{isDigital ? "🔐" : "📦"}</div>
        )}
      </div>

      <div className="detail-body">
        <h1 className="detail-name">{product.name}</h1>
        {product.category && (
          <span className="detail-cat">{product.category.emoji} {product.category.name}</span>
        )}
        <div className="detail-price">{product.price.toLocaleString()} so'm</div>

        {isDigital && (
          <div className="digital-info-box">
            <span>🔐</span>
            <p><b>Premium Digital Yetkazish:</b> Buyurtmadan so'ng admin tomonidan <b>shaxsan</b> yetkazib beriladi. Maxsus xizmat!</p>
          </div>
        )}

        <p className="detail-desc">{product.description || "Tavsif yo'q."}</p>

        <div className="detail-actions">
          <button className={`fav-btn-lg ${isFav ? "active" : ""}`} onClick={() => toggleFavorite(product.id)}>
            {isFav ? "❤️ Sevimlilarda" : "🤍 Sevimlilarga"}
          </button>
          <button className="share-btn-lg" onClick={handleShare}>🔗 Ulashish</button>
        </div>

        <button className="add-btn-lg" onClick={() => { addToCart(product); navigate("/cart"); }}>
          🛒 Savatga qo'shish
        </button>
      </div>
    </div>
  );
}

// ─── Cart.jsx ─────────────────────────────────────────────────────────────────
export function Cart({ ctx }) {
  const { cart, removeFromCart, updateCartQty, user, tg } = ctx;
  const navigate = useNavigate();
  const [orderCode, setOrderCode] = useState(null);
  const [note, setNote] = useState("");
  const [ordering, setOrdering] = useState(false);

  const total = cart.reduce((acc, i) => acc + i.product.price * i.qty, 0);

  async function placeOrder() {
    if (!cart.length || !user) return;
    setOrdering(true);
    const res = await fetch(`${API}/api/orders`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        telegram_id: user.id,
        items: cart.map(i => ({ product_id: i.product.id, quantity: i.qty })),
        note,
      }),
    });
    const data = await res.json();
    setOrderCode(data.order_code);
    setOrdering(false);
    if (tg) tg.HapticFeedback?.notificationOccurred("success");
  }

  function contactAdmin() {
    const msg = encodeURIComponent(`Buyurtma kodi: ${orderCode}\nMen buyurtma berdim!`);
    window.open(`https://t.me/YourAdminUsername?text=${msg}`, "_blank");
  }

  if (orderCode) {
    return (
      <div className="success-page">
        <div className="success-icon">🎯</div>
        <h2 className="success-title">MISSIYA BAJARILDI!</h2>
        <div className="order-code-display">
          Buyurtma kodi:<br />
          <span className="code-text">{orderCode}</span>
        </div>
        <p className="success-note">
          Admin bilan bog'laning va kodni yuboring.<br />
          Digital mahsulotlar shaxsan yetkaziladi!
        </p>
        <button className="comic-btn green lg" onClick={contactAdmin}>
          💬 Admin bilan bog'lanish
        </button>
        <button className="comic-btn gray lg" onClick={() => navigate("/")}>
          🏠 Do'konga qaytish
        </button>
      </div>
    );
  }

  return (
    <div className="cart-page">
      <div className="page-header">
        <button className="back-btn" onClick={() => navigate(-1)}>← Orqaga</button>
        <h2>🛒 Savat</h2>
      </div>

      {cart.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🛒</div>
          <p className="empty-title">Savat bo'sh</p>
          <p className="empty-sub">Missiya: Savatni to'ldirish!</p>
          <button className="comic-btn green" onClick={() => navigate("/")}>Do'konga</button>
        </div>
      ) : (
        <>
          <div className="cart-list">
            {cart.map((item) => (
              <div key={item.product.id} className="cart-item">
                <div className="cart-item-img">
                  {item.product.image_url
                    ? <img src={item.product.image_url} alt="" />
                    : <div className="cart-placeholder">{item.product.product_type === "digital" ? "💾" : "📦"}</div>}
                </div>
                <div className="cart-item-info">
                  <div className="cart-item-name">{item.product.name}</div>
                  <div className="cart-item-price">{(item.product.price * item.qty).toLocaleString()} so'm</div>
                  <div className="qty-controls">
                    <button onClick={() => updateCartQty(item.product.id, item.qty - 1)}>−</button>
                    <span>{item.qty}</span>
                    <button onClick={() => updateCartQty(item.product.id, item.qty + 1)}>+</button>
                  </div>
                </div>
                <button className="remove-btn" onClick={() => removeFromCart(item.product.id)}>✕</button>
              </div>
            ))}
          </div>

          <textarea
            className="field-textarea"
            placeholder="📝 Izoh (ixtiyoriy)..."
            value={note}
            onChange={e => setNote(e.target.value)}
          />

          <div className="cart-summary">
            <div className="cart-total">
              <span>Jami:</span>
              <span className="total-price">{total.toLocaleString()} so'm</span>
            </div>
            <button className="add-btn-lg" onClick={placeOrder} disabled={ordering}>
              {ordering ? "Yuborilmoqda..." : "🎯 Buyurtma berish"}
            </button>
          </div>
        </>
      )}
    </div>
  );
}

// ─── Favorites.jsx ────────────────────────────────────────────────────────────
export function Favorites({ ctx }) {
  const { favorites, toggleFavorite, addToCart } = ctx;
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);

  useEffect(() => {
    if (favorites.length === 0) { setProducts([]); return; }
    Promise.all(favorites.map(id => fetch(`${API}/api/products/${id}`).then(r => r.json())))
      .then(setProducts);
  }, [favorites]);

  return (
    <div className="favorites-page">
      <div className="page-header">
        <button className="back-btn" onClick={() => navigate(-1)}>← Orqaga</button>
        <h2>❤️ Sevimlilar</h2>
      </div>
      {products.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">❤️</div>
          <p className="empty-title">Sevimlilar bo'sh</p>
          <button className="comic-btn green" onClick={() => navigate("/")}>Do'konga</button>
        </div>
      ) : (
        <div className="products-grid">
          {products.map(p => (
            <div key={p.id} className="product-card" onClick={() => navigate(`/product/${p.id}`)}>
              <div className="card-img-wrap">
                {p.image_url ? <img src={p.image_url} alt={p.name} className="card-img" /> : <div className="card-img-placeholder">{p.product_type === "digital" ? "💾" : "📦"}</div>}
              </div>
              <div className="card-content">
                <h3 className="card-title">{p.name}</h3>
                <div className="card-price">{p.price.toLocaleString()} so'm</div>
                <div className="card-actions">
                  <button className="fav-btn fav-active" onClick={e => { e.stopPropagation(); toggleFavorite(p.id); }}>❤️</button>
                  <button className="add-btn" onClick={e => { e.stopPropagation(); addToCart(p); navigate("/cart"); }}>+ Savat</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── ForceSubscribe.jsx ───────────────────────────────────────────────────────
export function ForceSubscribe({ channels, onDone }) {
  return (
    <div className="force-sub-page">
      <div className="force-sub-icon">🔒</div>
      <h2 className="force-sub-title">KIRISH BLOKLANDI</h2>
      <div className="agent-bubble center">
        <div className="agent-avatar">🕶️</div>
        <div className="bubble">
          <span className="bubble-text">Agent, kanallarga a'zo bo'lish majburiy!</span>
        </div>
      </div>
      <div className="force-sub-list">
        {channels.map((ch, i) => (
          <a key={i} href={ch.link} target="_blank" rel="noreferrer" className="force-sub-btn">
            📢 {ch.title || ch.id}
          </a>
        ))}
      </div>
      <button className="comic-btn green lg" onClick={onDone}>✅ Tekshirish</button>
    </div>
  );
}

// Default exports for router
export default ProductDetail;
