# 🇺🇿 Uzbekistan OTC Trading Community Bot

## Featurelar

### 📋 Onboarding
- `/start` → Shartlar + Maxfiylik siyosati
- Step-by-step ro'yxatdan o'tish: Ism, Familiya, Yosh, Joylashuv, Maqsad, Rasm
- Chiroyli **Uzbekistan OTC Passport** (Pillow bilan)
- Har foydalanuvchi uchun unikal ID (masalan: `ABC123456`)
- Maxsus bir martalik invite link

### 🛡️ Moderatsiya
- `/warn [sabab]` — ogohlantirish (3 warn = auto ban)
- `/mute1h` — 1 soatga mute
- `/mute1d` — 1 kunga mute
- `/muteall` — butun umrga ban + guruhdan chiqarish
- `/unmute` — mute olib tashlash
- `/ban`, `/unban [id]`, `/kick`
- Auto flood protection (5 sek da 6+ xabar)
- Anti-raid (10 sek da 5+ yangi a'zo)
- Bad words filter

### 📊 Statistika
- `/top` — eng faol 10 a'zo
- `/stats` — guruh statistikasi (admin only)
- `/search [ID/ism]` — foydalanuvchi qidirish + passport

### 📢 Kontent
- `/pin` — xabarni pin qilish (reply qilib)
- `/road1h [xabar]` — har soatda yuborish
- `/road1d [xabar]` — har kunda yuborish
- `/stoproad` — barcha road xabarlarni to'xtatish

### 🤖 Auto Actions
- Yangi a'zo: xush keldi xabari (30 sek da o'chadi)
- Ro'yxatdan o'tmagan user: 1 marta DM ogohlantirish
- `@admins` → adminga xabar + link
- Guruhdan chiqsa/hisob o'chirilsa → adminga to'liq ma'lumot

---

## O'rnatish

```bash
git clone <repo>
cd otc_bot

pip install -r requirements.txt

cp .env.example .env
# .env faylini to'ldiring

python bot.py
```

## .env sozlash

```
BOT_TOKEN=7xxxxxxxxxx:AAF...
ADMIN_ID=123456789          # Sizning Telegram ID
GROUP_ID=-1001234567890     # Guruh ID (-100 bilan)
BOT_USERNAME=otc_mybot      # Bot username @ siz
```

## Guruh sozlamalari

1. Botni guruhga admin qiling
2. Quyidagi ruxsatlarni bering:
   - ✅ Xabarlarni o'chirish
   - ✅ A'zolarni ban/mute qilish
   - ✅ Invite link yaratish
   - ✅ Xabarlarni pin qilish

## Fayl tuzilmasi

```
otc_bot/
├── bot.py              # Asosiy kirish nuqtasi
├── database.py         # SQLite CRUD
├── passport.py         # Passport rasm generatori
├── scheduler.py        # Road message scheduler
├── requirements.txt
├── .env.example
└── handlers/
    ├── onboarding.py   # /start, ro'yxatdan o'tish
    ├── admin.py        # Admin buyruqlari
    └── group.py        # Guruh hodisalari
```
