import os
import re
import asyncio
from datetime import datetime, timedelta
from collections import defaultdict
from aiogram import Router, F, Bot
from aiogram.types import (
    Message, ChatMemberUpdated, ChatPermissions,
    InlineKeyboardMarkup, InlineKeyboardButton
)
from aiogram.filters import ChatMemberUpdatedFilter, JOIN_TRANSITION, LEAVE_TRANSITION, Command
import database as db

router = Router()

ADMIN_ID  = int(os.getenv("ADMIN_ID", "0"))
GROUP_ID  = int(os.getenv("GROUP_ID", "0"))

# Anti-raid tracking
raid_tracker  = defaultdict(list)
RAID_THRESHOLD = 5
RAID_WINDOW    = 10

# Flood tracking
flood_tracker = defaultdict(list)
FLOOD_LIMIT   = 6
FLOOD_WINDOW  = 5

# Users already warned (DM sent once per session)
warned_dm_sent = set()

BAD_WORDS = ["spam_word_1", "spam_word_2"]  # to'ldiring

def build_register_kb():
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="📋 Ro'yxatdan o'tish",
            url=f"https://t.me/{os.getenv('BOT_USERNAME','')}"
        )
    ]])

# ── /toggleguard — admin only ──────────────────────────────────────────────────

@router.message(Command("toggleguard"))
async def cmd_toggleguard(message: Message):
    if message.from_user.id != ADMIN_ID:
        return

    args = message.text.split()
    if len(args) < 2 or args[1].lower() not in ("on", "off"):
        current = "✅ Yoqiq" if db.is_guard_enabled() else "❌ O'chiq"
        await message.reply(
            f"🛡 *Guard holati:* {current}\n\n"
            f"Foydalanish:\n"
            f"`/toggleguard on` — yoqish\n"
            f"`/toggleguard off` — o'chirish",
            parse_mode="Markdown"
        )
        return

    new_val = "1" if args[1].lower() == "on" else "0"
    db.set_setting("guard_enabled", new_val)

    if new_val == "1":
        await message.reply(
            "✅ *Guard YOQILDI!*\n\n"
            "Ro'yxatdan o'tmagan foydalanuvchilarning xabarlari o'chiriladi "
            "va ularga ro'yxatdan o'tish taklif qilinadi.",
            parse_mode="Markdown"
        )
    else:
        await message.reply(
            "❌ *Guard O'CHIRILDI!*\n\n"
            "Barcha foydalanuvchilar xabar yoza oladi.",
            parse_mode="Markdown"
        )

# ── New member joined ──────────────────────────────────────────────────────────

@router.chat_member(ChatMemberUpdatedFilter(JOIN_TRANSITION))
async def on_member_join(event: ChatMemberUpdated, bot: Bot):
    user = event.new_chat_member.user
    now  = datetime.now().timestamp()

    # Anti-raid check
    raid_tracker[event.chat.id] = [
        t for t in raid_tracker[event.chat.id] if now - t < RAID_WINDOW
    ]
    raid_tracker[event.chat.id].append(now)

    if len(raid_tracker[event.chat.id]) >= RAID_THRESHOLD:
        try:
            await bot.ban_chat_member(event.chat.id, user.id)
            await bot.send_message(
                ADMIN_ID,
                f"🚨 *Anti-Raid!* Qisqa vaqtda {RAID_THRESHOLD}+ kishi qo'shildi!\n"
                f"Oxirgi user: @{user.username or user.first_name} ban qilindi.",
                parse_mode="Markdown"
            )
        except:
            pass
        return

    db_user = db.get_user(user.id)

    if db_user and db_user.get("joined_group"):
        db.update_user(user.id, joined_group=1, joined_at=datetime.now().isoformat())
        name = db_user.get("first_name") or user.first_name
        uid  = db_user.get("unique_id", "—")
        try:
            msg = await bot.send_message(
                event.chat.id,
                f"👋 *{name}* guruhga xush keldi!\n🆔 ID: `{uid}`",
                parse_mode="Markdown"
            )
            await asyncio.sleep(30)
            await bot.delete_message(event.chat.id, msg.message_id)
        except:
            pass
    else:
        # Guard yoqiq bo'lsa — DM yuboramiz
        if db.is_guard_enabled() and user.id not in warned_dm_sent:
            warned_dm_sent.add(user.id)
            try:
                await bot.send_message(
                    user.id,
                    "⚠️ Guruhga qo'shilish uchun avval ro'yxatdan o'ting!\n\n"
                    "📋 Shartlar va maxfiylik siyosatini o'qib, quyidagi tugmani bosing:",
                    reply_markup=build_register_kb()
                )
            except:
                pass

# ── Member left / removed ──────────────────────────────────────────────────────

@router.chat_member(ChatMemberUpdatedFilter(LEAVE_TRANSITION))
async def on_member_leave(event: ChatMemberUpdated, bot: Bot):
    user    = event.old_chat_member.user
    db_user = db.get_user(user.id)

    if not db_user:
        return

    is_deleted = user.is_bot
    db.update_user(user.id, joined_group=0, is_active=0)

    text = (
        f"{'🚨 Hisob O\'chirildi!' if is_deleted else '👤 A\'zo Guruhdan Chiqdi'}\n\n"
        f"👤 {db_user.get('first_name','')} {db_user.get('last_name','')}\n"
        f"🆔 Unikal ID: `{db_user.get('unique_id','—')}`\n"
        f"📱 Telegram: @{db_user.get('username','—')} (`{user.id}`)\n"
        f"📍 Joylashuv: {db_user.get('location','—')}\n"
        f"💼 Maqsad: {db_user.get('purpose','—')}\n"
        f"📅 Ro'yxat: {str(db_user.get('registered_at','—'))[:10]}\n"
        f"⏰ Chiqish vaqti: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    )

    try:
        await bot.send_message(ADMIN_ID, text, parse_mode="Markdown")
    except:
        pass

# ── Message handler ────────────────────────────────────────────────────────────

@router.message(F.chat.id == GROUP_ID)
async def on_group_message(message: Message, bot: Bot):
    if not message.from_user:
        return

    user_id = message.from_user.id
    chat_id = message.chat.id
    text    = message.text or message.caption or ""
    now     = datetime.now().timestamp()

    # Log message
    db.log_message(user_id, chat_id)

    # ── Guard: ro'yxatdan o'tmagan user ───────────────────────────────────────
    db_user = db.get_user(user_id)
    if not db_user and db.is_guard_enabled():
        # Xabarni o'chiramiz
        try:
            await message.delete()
        except:
            pass

        # DM faqat 1 marta
        if user_id not in warned_dm_sent:
            warned_dm_sent.add(user_id)
            try:
                await bot.send_message(
                    user_id,
                    "🚫 Guruhda xabar yozish uchun avval ro'yxatdan o'ting!\n\n"
                    "✅ Ro'yxatdan o'tganingizdan so'ng guruhda erkin xabar yoza olasiz.",
                    reply_markup=build_register_kb()
                )
            except:
                pass
        return

    # Guard o'chiq bo'lsa — registered bo'lmasa ham o'tkazib yuboramiz
    if not db_user:
        return

    # ── Flood check ───────────────────────────────────────────────────────────
    flood_tracker[user_id] = [
        t for t in flood_tracker[user_id] if now - t < FLOOD_WINDOW
    ]
    flood_tracker[user_id].append(now)

    if len(flood_tracker[user_id]) >= FLOOD_LIMIT:
        try:
            perms = ChatPermissions(can_send_messages=False)
            await bot.restrict_chat_member(
                chat_id, user_id, permissions=perms,
                until_date=datetime.now() + timedelta(minutes=5)
            )
            await message.reply("🚫 Flood aniqlandi! 5 daqiqaga mute qilindi.")
        except:
            pass
        return

    # ── Bad words filter ──────────────────────────────────────────────────────
    lower_text = text.lower()
    if any(word in lower_text for word in BAD_WORDS):
        try:
            await message.delete()
            await bot.send_message(
                chat_id,
                f"⚠️ @{message.from_user.username or message.from_user.first_name} "
                f"taqiqlangan so'z ishlatdi!"
            )
        except:
            pass
        return

    # ── @admins mention ───────────────────────────────────────────────────────
    if "@admins" in text or "@admin" in text:
        sender = message.from_user
        name   = f"@{sender.username}" if sender.username else sender.first_name
        uid    = db_user.get("unique_id", "—")

        chat_username = message.chat.username
        if chat_username:
            msg_link = f"https://t.me/{chat_username}/{message.message_id}"
        else:
            chat_id_str = str(chat_id).replace("-100", "")
            msg_link = f"https://t.me/c/{chat_id_str}/{message.message_id}"

        preview = text[:120] + ("..." if len(text) > 120 else "")
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="📩 Xabarga o'tish", url=msg_link)
        ]])

        await bot.send_message(
            ADMIN_ID,
            f"📣 *@admins Eslatildi!*\n\n"
            f"👤 {name} (`{sender.id}`)\n"
            f"🆔 ID: `{uid}`\n"
            f"💬 Xabar: _{preview}_",
            parse_mode="Markdown",
            reply_markup=kb
        )
