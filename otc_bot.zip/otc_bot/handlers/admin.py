import os
import io
import re
from datetime import datetime, timedelta
from aiogram import Router, F, Bot
from aiogram.types import Message, ChatPermissions, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
import database as db
import passport as ps

router = Router()

ADMIN_ID  = int(os.getenv("ADMIN_ID", "0"))
GROUP_ID  = int(os.getenv("GROUP_ID", "0"))

def is_admin(user_id):
    return user_id == ADMIN_ID

def admin_only(func):
    async def wrapper(message: Message, *args, **kwargs):
        if not is_admin(message.from_user.id):
            return
        return await func(message, *args, **kwargs)
    wrapper.__name__ = func.__name__
    return wrapper

# ── /search ────────────────────────────────────────────────────────────────────

@router.message(Command("search"))
async def cmd_search(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply("❌ Foydalanish: `/search [ID yoki ism]`", parse_mode="Markdown")
        return

    query   = args[1].strip()
    results = db.search_users(query)

    if not results:
        await message.reply("🔍 Foydalanuvchi topilmadi.")
        return

    for user in results[:3]:
        warns  = db.get_warns(user["telegram_id"])
        status = "✅ Faol" if user.get("is_active") else "🚫 O'chirilgan"
        joined = "✅ Ha" if user.get("joined_group") else "⏳ Yo'q"

        text = (
            f"👤 *{user.get('first_name','')} {user.get('last_name','')}*\n"
            f"🆔 Unikal ID: `{user.get('unique_id','—')}`\n"
            f"📱 Telegram: @{user.get('username','—')} (`{user['telegram_id']}`)\n"
            f"🎂 Yosh: {user.get('age','—')}\n"
            f"📍 Joylashuv: {user.get('location','—')}\n"
            f"💼 Maqsad: {user.get('purpose','—')}\n"
            f"📅 Ro'yxat: {str(user.get('registered_at','—'))[:10]}\n"
            f"👥 Guruhda: {joined}\n"
            f"⚠️ Warnlar: {len(warns)} ta\n"
            f"📊 Status: {status}"
        )

        # Generate fresh passport
        try:
            passport_img = ps.create_passport(user)
            await message.reply_photo(
                photo=io.BytesIO(passport_img),
                caption=text,
                parse_mode="Markdown"
            )
        except:
            await message.reply(text, parse_mode="Markdown")

# ── /warn ──────────────────────────────────────────────────────────────────────

@router.message(Command("warn"))
async def cmd_warn(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    if not message.reply_to_message:
        await message.reply("❌ Ogohlantirish uchun xabarga reply qiling.")
        return

    target    = message.reply_to_message.from_user
    args      = message.text.split(maxsplit=1)
    reason    = args[1] if len(args) > 1 else "Sabab ko'rsatilmagan"

    db.add_warn(target.id, reason, message.from_user.id)
    warns = db.get_warns(target.id)
    count = len(warns)

    if count >= 3:
        try:
            await bot.ban_chat_member(GROUP_ID, target.id)
            db.clear_warns(target.id)
            await message.reply(
                f"🚫 @{target.username or target.first_name} 3 ta ogohlantirish olganligi sababli **ban** qilindi!",
                parse_mode="Markdown"
            )
        except Exception as e:
            await message.reply(f"⚠️ Ban qilishda xato: {e}")
    else:
        await message.reply(
            f"⚠️ *Ogohlantirish berildi!*\n"
            f"👤 {target.first_name}\n"
            f"📝 Sabab: {reason}\n"
            f"⚠️ Jami warn: {count}/3",
            parse_mode="Markdown"
        )
        try:
            await bot.send_message(
                target.id,
                f"⚠️ Siz ogohlantirish oldingiz!\nSabab: {reason}\nJami: {count}/3"
            )
        except:
            pass

# ── /mute variants ─────────────────────────────────────────────────────────────

async def mute_user(bot: Bot, message: Message, until: datetime | None, label: str, permanent=False):
    if not message.reply_to_message:
        await message.reply(f"❌ Mute qilish uchun xabarga reply qiling.")
        return
    target = message.reply_to_message.from_user
    perms  = ChatPermissions(can_send_messages=False)
    try:
        if permanent:
            await bot.ban_chat_member(GROUP_ID, target.id)
            await message.reply(
                f"🔇 @{target.username or target.first_name} **butun umrga** ban qilindi va guruhdan chiqarildi!",
                parse_mode="Markdown"
            )
        else:
            await bot.restrict_chat_member(GROUP_ID, target.id, permissions=perms, until_date=until)
            await message.reply(
                f"🔇 @{target.username or target.first_name} {label} mute qilindi.",
                parse_mode="Markdown"
            )
    except Exception as e:
        await message.reply(f"⚠️ Xato: {e}")

@router.message(Command("mute1h"))
async def mute_1h(message: Message, bot: Bot):
    if not is_admin(message.from_user.id): return
    await mute_user(bot, message, datetime.now() + timedelta(hours=1), "1 soatga")

@router.message(Command("mute1d"))
async def mute_1d(message: Message, bot: Bot):
    if not is_admin(message.from_user.id): return
    await mute_user(bot, message, datetime.now() + timedelta(days=1), "1 kunga")

@router.message(Command("muteall"))
async def mute_all(message: Message, bot: Bot):
    if not is_admin(message.from_user.id): return
    await mute_user(bot, message, None, "butun umrga", permanent=True)

@router.message(Command("unmute"))
async def unmute(message: Message, bot: Bot):
    if not is_admin(message.from_user.id): return
    if not message.reply_to_message:
        await message.reply("❌ Reply qiling.")
        return
    target = message.reply_to_message.from_user
    perms  = ChatPermissions(
        can_send_messages=True, can_send_media_messages=True,
        can_send_polls=True, can_send_other_messages=True,
        can_add_web_page_previews=True
    )
    try:
        await bot.restrict_chat_member(GROUP_ID, target.id, permissions=perms)
        await message.reply(f"🔊 @{target.username or target.first_name} mute olib tashlandi.")
    except Exception as e:
        await message.reply(f"⚠️ Xato: {e}")

@router.message(Command("ban"))
async def cmd_ban(message: Message, bot: Bot):
    if not is_admin(message.from_user.id): return
    if not message.reply_to_message:
        await message.reply("❌ Reply qiling.")
        return
    target = message.reply_to_message.from_user
    try:
        await bot.ban_chat_member(GROUP_ID, target.id)
        await message.reply(f"🚫 @{target.username or target.first_name} ban qilindi.")
    except Exception as e:
        await message.reply(f"⚠️ Xato: {e}")

@router.message(Command("unban"))
async def cmd_unban(message: Message, bot: Bot):
    if not is_admin(message.from_user.id): return
    args = message.text.split()
    if len(args) < 2:
        await message.reply("❌ Foydalanish: /unban [user_id]")
        return
    try:
        await bot.unban_chat_member(GROUP_ID, int(args[1]))
        await message.reply(f"✅ {args[1]} ban olib tashlandi.")
    except Exception as e:
        await message.reply(f"⚠️ Xato: {e}")

@router.message(Command("kick"))
async def cmd_kick(message: Message, bot: Bot):
    if not is_admin(message.from_user.id): return
    if not message.reply_to_message:
        await message.reply("❌ Reply qiling.")
        return
    target = message.reply_to_message.from_user
    try:
        await bot.ban_chat_member(GROUP_ID, target.id)
        await bot.unban_chat_member(GROUP_ID, target.id)
        await message.reply(f"👢 @{target.username or target.first_name} chiqarib yuborildi.")
    except Exception as e:
        await message.reply(f"⚠️ Xato: {e}")

# ── /pin ───────────────────────────────────────────────────────────────────────

@router.message(Command("pin"))
async def cmd_pin(message: Message, bot: Bot):
    if not is_admin(message.from_user.id): return
    if not message.reply_to_message:
        await message.reply("❌ Pin qilish uchun xabarga reply qiling.")
        return
    try:
        await bot.pin_chat_message(GROUP_ID, message.reply_to_message.message_id)
        await message.reply("📌 Xabar pin qilindi!")
    except Exception as e:
        await message.reply(f"⚠️ Xato: {e}")

# ── /road ──────────────────────────────────────────────────────────────────────

@router.message(Command(re.compile(r"road(\d+)([hd])")))
async def cmd_road(message: Message, bot: Bot):
    if not is_admin(message.from_user.id): return

    match = re.search(r"/road(\d+)([hd])\s*(.*)", message.text, re.DOTALL)
    if not match:
        await message.reply("❌ Format: /road1h [xabar] yoki /road1d [xabar]")
        return

    amount   = int(match.group(1))
    unit     = match.group(2)
    msg_text = match.group(3).strip()

    if not msg_text:
        await message.reply("❌ Xabar matni kiriting.")
        return

    seconds  = amount * 3600 if unit == "h" else amount * 86400
    label    = f"{amount} {'soat' if unit == 'h' else 'kun'}"
    chat_id  = message.chat.id

    db.add_road(msg_text, seconds, chat_id, message.from_user.id)
    await message.reply(
        f"✅ Road xabar sozlandi!\n⏱ Har {label}da yuboriladi.\n📝 {msg_text[:60]}..."
        if len(msg_text) > 60 else
        f"✅ Road xabar sozlandi!\n⏱ Har {label}da yuboriladi.\n📝 {msg_text}"
    )

@router.message(Command("stoproad"))
async def cmd_stoproad(message: Message):
    if not is_admin(message.from_user.id): return
    db.stop_all_roads(message.chat.id)
    await message.reply("🛑 Barcha road xabarlar to'xtatildi.")

# ── /top ───────────────────────────────────────────────────────────────────────

@router.message(Command("top"))
async def cmd_top(message: Message):
    chat_id = message.chat.id
    top     = db.get_top_users(chat_id)
    if not top:
        await message.reply("📊 Hali ma'lumot yo'q.")
        return

    medals = ["🥇","🥈","🥉"] + ["4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣","🔟"]
    lines  = ["📊 *Top-10 Eng Faol A'zolar*\n"]
    for i, u in enumerate(top):
        name = f"{u.get('first_name','')} {u.get('last_name','')}".strip() or "Nomaʼlum"
        lines.append(f"{medals[i]} {name} — {u['msg_count']} xabar")

    await message.reply("\n".join(lines), parse_mode="Markdown")

# ── /stats ─────────────────────────────────────────────────────────────────────

@router.message(Command("stats"))
async def cmd_stats(message: Message):
    if not is_admin(message.from_user.id): return
    stats  = db.get_group_stats(message.chat.id)
    users  = db.get_all_users()
    active = sum(1 for u in users if u.get("is_active"))
    joined = sum(1 for u in users if u.get("joined_group"))

    text = (
        f"📊 *Guruh Statistikasi*\n\n"
        f"👥 Jami ro'yxatlar: {len(users)}\n"
        f"✅ Guruhda: {joined}\n"
        f"🟢 Faol hisoblar: {active}\n"
        f"💬 Jami xabarlar: {stats['total_messages']}\n"
        f"👤 Faol userlar: {stats['active_users']}"
    )
    await message.reply(text, parse_mode="Markdown")

# ── /admin ─────────────────────────────────────────────────────────────────────

@router.message(Command("admin"))
async def cmd_admin(message: Message):
    if not is_admin(message.from_user.id): return
    text = (
        "🛠 *Admin Panel — Buyruqlar*\n\n"
        "*Qidiruv:*\n"
        "`/search [ID/ism]` — foydalanuvchi qidirish\n\n"
        "*Moderatsiya:*\n"
        "`/warn [sabab]` — ogohlantirish (reply)\n"
        "`/mute1h` — 1 soatga mute (reply)\n"
        "`/mute1d` — 1 kunga mute (reply)\n"
        "`/muteall` — butun umrga ban (reply)\n"
        "`/unmute` — mute olib tashlash (reply)\n"
        "`/ban` — ban (reply)\n"
        "`/unban [user_id]` — ban olib tashlash\n"
        "`/kick` — guruhdan chiqarish (reply)\n\n"
        "*Kontent:*\n"
        "`/pin` — xabarni pin qilish (reply)\n"
        "`/road1h [xabar]` — soatlab takroriy xabar\n"
        "`/road1d [xabar]` — kunlab takroriy xabar\n"
        "`/stoproad` — barcha road xabarlarni to'xtatish\n\n"
        "*Statistika:*\n"
        "`/top` — eng faol 10 user\n"
        "`/stats` — guruh statistikasi\n\n"
        "*Guard (xabar filtri):*\n"
        "`/toggleguard on` — yoqish (ro'yxatsiz userlar xabari o'chiriladi)\n"
        "`/toggleguard off` — o'chirish (hamma yoza oladi)\n"
        "`/toggleguard` — joriy holat"
    )
    await message.reply(text, parse_mode="Markdown")
