import random
import string
from datetime import datetime
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, ChatPermissions
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import CommandStart
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
import database as db
import passport as ps
import io
import os

router = Router()

GROUP_ID   = int(os.getenv("GROUP_ID", "0"))
ADMIN_ID   = int(os.getenv("ADMIN_ID", "0"))
BOT_TOKEN  = os.getenv("BOT_TOKEN", "")

TERMS_TEXT = """
📋 *SHARTLAR VA FOYDALANISH QOIDALARI*

Uzbekistan OTC Trading Community'ga xush kelibsiz!

*Asosiy qoidalar:*
1. Firibgarlik va manipulyatsiyaga yo'l qo'yilmaydi
2. Haqiqiy ma'lumotlar bilan ro'yxatdan o'ting
3. Boshqa a'zolarga hurmat bilan munosabatda bo'ling
4. Spam va reklama taqiqlanadi
5. Guruh qoidalarini buzganlar ban qilinadi

*Maxfiylik siyosati:*
• Sizning ma'lumotlaringiz faqat guruh ichida ishlatiladi
• Uchinchi tomonlarga ma'lumot berilmaydi
• Istalgan vaqtda hisobingizni o'chirishingiz mumkin

Davom etish uchun qoidalarni qabul qiling 👇
"""

class Registration(StatesGroup):
    waiting_first_name  = State()
    waiting_last_name   = State()
    waiting_age         = State()
    waiting_location    = State()
    waiting_purpose     = State()
    waiting_photo       = State()

def gen_unique_id():
    letters = ''.join(random.choices(string.ascii_uppercase, k=3))
    numbers = ''.join(random.choices(string.digits, k=6))
    return f"{letters}{numbers}"

def accept_kb():
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Qabul qilaman", callback_data="accept_terms"),
        InlineKeyboardButton(text="❌ Rad etaman",    callback_data="decline_terms"),
    ]])

def skip_kb():
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="⏭ O'tkazib yuborish", callback_data="skip_step")
    ]])

@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    user = db.get_user(message.from_user.id)
    if user and user.get("joined_group"):
        await message.answer("✅ Siz allaqachon ro'yxatdan o'tgansiz!", parse_mode="Markdown")
        return

    await state.clear()
    await message.answer(TERMS_TEXT, parse_mode="Markdown", reply_markup=accept_kb())

@router.callback_query(F.data == "decline_terms")
async def decline_terms(call: CallbackQuery, state: FSMContext):
    await call.message.edit_text("❌ Siz qoidalarni rad etdingiz. Qayta urinish uchun /start yuboring.")

@router.callback_query(F.data == "accept_terms")
async def accept_terms(call: CallbackQuery, state: FSMContext):
    uid = gen_unique_id()
    db.add_user(call.from_user.id, call.from_user.username or "", uid)
    await state.set_state(Registration.waiting_first_name)
    await call.message.edit_text(
        "✅ Qoidalar qabul qilindi!\n\n👤 *Ismingizni kiriting:*",
        parse_mode="Markdown"
    )

@router.message(Registration.waiting_first_name)
async def get_first_name(message: Message, state: FSMContext):
    await state.update_data(first_name=message.text.strip())
    await state.set_state(Registration.waiting_last_name)
    await message.answer("👤 *Familiyangizni kiriting:*", parse_mode="Markdown")

@router.message(Registration.waiting_last_name)
async def get_last_name(message: Message, state: FSMContext):
    await state.update_data(last_name=message.text.strip())
    await state.set_state(Registration.waiting_age)
    await message.answer("🎂 *Yoshingizni kiriting:*", parse_mode="Markdown")

@router.message(Registration.waiting_age)
async def get_age(message: Message, state: FSMContext):
    if not message.text.strip().isdigit():
        await message.answer("⚠️ Iltimos, faqat raqam kiriting.")
        return
    await state.update_data(age=int(message.text.strip()))
    await state.set_state(Registration.waiting_location)
    await message.answer("📍 *Joylashuvingizni kiriting* (shahar yoki viloyat):", parse_mode="Markdown")

@router.message(Registration.waiting_location)
async def get_location(message: Message, state: FSMContext):
    await state.update_data(location=message.text.strip())
    await state.set_state(Registration.waiting_purpose)
    await message.answer(
        "💼 *Forumga qo'shilishdan maqsadingiz nima?*\n\nMisol: savdo, ta'lim, investitsiya...",
        parse_mode="Markdown"
    )

@router.message(Registration.waiting_purpose)
async def get_purpose(message: Message, state: FSMContext):
    await state.update_data(purpose=message.text.strip())
    await state.set_state(Registration.waiting_photo)
    await message.answer(
        "📸 *Profilingiz uchun rasm yuboring:*\n_(Yuzingiz aniq ko'ringan rasm)_",
        parse_mode="Markdown",
        reply_markup=skip_kb()
    )

@router.callback_query(F.data == "skip_step", Registration.waiting_photo)
async def skip_photo(call: CallbackQuery, state: FSMContext, bot: Bot):
    await finalize_registration(call.message, state, bot, call.from_user, photo_bytes=None)

@router.message(Registration.waiting_photo, F.photo)
async def get_photo(message: Message, state: FSMContext, bot: Bot):
    photo = message.photo[-1]
    file  = await bot.get_file(photo.file_id)
    buf   = io.BytesIO()
    await bot.download_file(file.file_path, buf)
    photo_bytes = buf.getvalue()
    db.update_user(message.from_user.id, photo_file_id=photo.file_id)
    await finalize_registration(message, state, bot, message.from_user, photo_bytes=photo_bytes)

async def finalize_registration(message, state: FSMContext, bot: Bot, user_tg, photo_bytes=None):
    data   = await state.get_data()
    tg_id  = user_tg.id
    user   = db.get_user(tg_id)
    uid    = user["unique_id"]

    db.update_user(tg_id,
        first_name = data.get("first_name", ""),
        last_name  = data.get("last_name",  ""),
        age        = data.get("age", 0),
        location   = data.get("location",  ""),
        purpose    = data.get("purpose",   ""),
    )

    await message.answer("⏳ *Pasportingiz tayyorlanmoqda...*", parse_mode="Markdown")

    user_data = db.get_user(tg_id)
    passport_img = ps.create_passport(user_data, photo_bytes)

    # Create invite link
    try:
        link_obj = await bot.create_chat_invite_link(
            GROUP_ID,
            member_limit=1,
            name=f"OTC-{uid}"
        )
        invite_link = link_obj.invite_link
        db.update_user(tg_id, invite_link=invite_link)
    except Exception as e:
        invite_link = f"https://t.me/+example_{uid}"

    await state.clear()

    caption = (
        f"🎉 *Tabriklaymiz! Siz ro'yxatdan o'tdingiz!*\n\n"
        f"🆔 Unikal ID: `{uid}`\n"
        f"👤 {data.get('first_name','')} {data.get('last_name','')}\n\n"
        f"Guruhga qo'shilish uchun quyidagi maxsus havoladan foydalaning 👇"
    )

    join_kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🚀 Guruhga qo'shilish", url=invite_link)
    ]])

    await message.answer_photo(
        photo=io.BytesIO(passport_img),
        caption=caption,
        parse_mode="Markdown",
        reply_markup=join_kb
    )
