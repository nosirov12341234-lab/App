import asyncio
from datetime import datetime
from aiogram import Bot
import database as db

async def road_scheduler(bot: Bot):
    """Background task — sends scheduled road messages"""
    while True:
        try:
            roads = db.get_active_roads()
            now   = datetime.now()

            for road in roads:
                last_sent = road.get("last_sent")
                interval  = road["interval_seconds"]

                if last_sent:
                    last_dt  = datetime.fromisoformat(last_sent)
                    elapsed  = (now - last_dt).total_seconds()
                    if elapsed < interval:
                        continue

                try:
                    await bot.send_message(road["chat_id"], road["message_text"])
                    db.update_road_last_sent(road["id"])
                except Exception as e:
                    print(f"[Road] Error sending road #{road['id']}: {e}")

        except Exception as e:
            print(f"[Road] Scheduler error: {e}")

        await asyncio.sleep(30)  # Check every 30 seconds
