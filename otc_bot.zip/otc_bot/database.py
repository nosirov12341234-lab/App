import sqlite3
import os
from datetime import datetime

DB_PATH = "otc_bot.db"

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_conn()
    c = conn.cursor()

    c.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        telegram_id INTEGER UNIQUE,
        username TEXT,
        first_name TEXT,
        last_name TEXT,
        age INTEGER,
        location TEXT,
        purpose TEXT,
        photo_file_id TEXT,
        unique_id TEXT UNIQUE,
        invite_link TEXT,
        joined_group INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1,
        registered_at TEXT,
        joined_at TEXT
    )""")

    c.execute("""
    CREATE TABLE IF NOT EXISTS warns (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id INTEGER,
        reason TEXT,
        admin_id INTEGER,
        created_at TEXT
    )""")

    c.execute("""
    CREATE TABLE IF NOT EXISTS mutes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id INTEGER,
        until TEXT,
        is_permanent INTEGER DEFAULT 0,
        admin_id INTEGER,
        created_at TEXT
    )""")

    c.execute("""
    CREATE TABLE IF NOT EXISTS road_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        message_text TEXT,
        interval_seconds INTEGER,
        chat_id INTEGER,
        admin_id INTEGER,
        is_active INTEGER DEFAULT 1,
        last_sent TEXT,
        created_at TEXT
    )""")

    c.execute("""
    CREATE TABLE IF NOT EXISTS tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reporter_id INTEGER,
        reported_id INTEGER,
        message_text TEXT,
        message_link TEXT,
        status TEXT DEFAULT 'open',
        created_at TEXT
    )""")

    c.execute("""
    CREATE TABLE IF NOT EXISTS group_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id INTEGER,
        chat_id INTEGER,
        created_at TEXT
    )""")

    c.execute("""
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    )""")

    # Default: guard ON
    c.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('guard_enabled', '1')")

    conn.commit()
    conn.close()

# ── Settings ───────────────────────────────────────────

def get_setting(key, default=None):
    conn = get_conn()
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    conn.close()
    return row["value"] if row else default

def set_setting(key, value):
    conn = get_conn()
    conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)", (key, str(value)))
    conn.commit()
    conn.close()

def is_guard_enabled():
    return get_setting("guard_enabled", "1") == "1"

# ── Users ──────────────────────────────────────────────

def add_user(telegram_id, username, unique_id):
    conn = get_conn()
    try:
        conn.execute(
            "INSERT OR IGNORE INTO users (telegram_id, username, unique_id, registered_at) VALUES (?,?,?,?)",
            (telegram_id, username, unique_id, datetime.now().isoformat())
        )
        conn.commit()
    finally:
        conn.close()

def update_user(telegram_id, **kwargs):
    conn = get_conn()
    fields = ", ".join(f"{k}=?" for k in kwargs)
    values = list(kwargs.values()) + [telegram_id]
    conn.execute(f"UPDATE users SET {fields} WHERE telegram_id=?", values)
    conn.commit()
    conn.close()

def get_user(telegram_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE telegram_id=?", (telegram_id,)).fetchone()
    conn.close()
    return dict(row) if row else None

def get_user_by_unique_id(unique_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE unique_id=?", (unique_id,)).fetchone()
    conn.close()
    return dict(row) if row else None

def search_users(query):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM users WHERE unique_id=? OR first_name LIKE ? OR last_name LIKE ? OR username LIKE ?",
        (query, f"%{query}%", f"%{query}%", f"%{query}%")
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_all_users():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM users").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def set_user_inactive(telegram_id):
    conn = get_conn()
    conn.execute("UPDATE users SET is_active=0 WHERE telegram_id=?", (telegram_id,))
    conn.commit()
    conn.close()

# ── Warns ──────────────────────────────────────────────

def add_warn(telegram_id, reason, admin_id):
    conn = get_conn()
    conn.execute(
        "INSERT INTO warns (telegram_id, reason, admin_id, created_at) VALUES (?,?,?,?)",
        (telegram_id, reason, admin_id, datetime.now().isoformat())
    )
    conn.commit()
    conn.close()

def get_warns(telegram_id):
    conn = get_conn()
    rows = conn.execute("SELECT * FROM warns WHERE telegram_id=?", (telegram_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def clear_warns(telegram_id):
    conn = get_conn()
    conn.execute("DELETE FROM warns WHERE telegram_id=?", (telegram_id,))
    conn.commit()
    conn.close()

# ── Road messages ──────────────────────────────────────

def add_road(message_text, interval_seconds, chat_id, admin_id):
    conn = get_conn()
    conn.execute(
        "INSERT INTO road_messages (message_text, interval_seconds, chat_id, admin_id, created_at) VALUES (?,?,?,?,?)",
        (message_text, interval_seconds, chat_id, admin_id, datetime.now().isoformat())
    )
    conn.commit()
    conn.close()

def get_active_roads():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM road_messages WHERE is_active=1").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def stop_all_roads(chat_id=None):
    conn = get_conn()
    if chat_id:
        conn.execute("UPDATE road_messages SET is_active=0 WHERE chat_id=?", (chat_id,))
    else:
        conn.execute("UPDATE road_messages SET is_active=0")
    conn.commit()
    conn.close()

def update_road_last_sent(road_id):
    conn = get_conn()
    conn.execute("UPDATE road_messages SET last_sent=? WHERE id=?", (datetime.now().isoformat(), road_id))
    conn.commit()
    conn.close()

# ── Tickets ────────────────────────────────────────────

def add_ticket(reporter_id, reported_id, message_text, message_link):
    conn = get_conn()
    conn.execute(
        "INSERT INTO tickets (reporter_id, reported_id, message_text, message_link, created_at) VALUES (?,?,?,?,?)",
        (reporter_id, reported_id, message_text, message_link, datetime.now().isoformat())
    )
    conn.commit()
    conn.close()

# ── Stats ──────────────────────────────────────────────

def log_message(telegram_id, chat_id):
    conn = get_conn()
    conn.execute(
        "INSERT INTO group_messages (telegram_id, chat_id, created_at) VALUES (?,?,?)",
        (telegram_id, chat_id, datetime.now().isoformat())
    )
    conn.commit()
    conn.close()

def get_top_users(chat_id, limit=10):
    conn = get_conn()
    rows = conn.execute(
        """SELECT u.first_name, u.last_name, u.unique_id, COUNT(gm.id) as msg_count
           FROM group_messages gm
           JOIN users u ON u.telegram_id = gm.telegram_id
           WHERE gm.chat_id=?
           GROUP BY gm.telegram_id
           ORDER BY msg_count DESC LIMIT ?""",
        (chat_id, limit)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_group_stats(chat_id):
    conn = get_conn()
    total = conn.execute("SELECT COUNT(*) as c FROM group_messages WHERE chat_id=?", (chat_id,)).fetchone()["c"]
    active_users = conn.execute(
        "SELECT COUNT(DISTINCT telegram_id) as c FROM group_messages WHERE chat_id=?", (chat_id,)
    ).fetchone()["c"]
    conn.close()
    return {"total_messages": total, "active_users": active_users}
