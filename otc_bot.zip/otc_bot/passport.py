from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageOps
import os
import math
import io
from datetime import datetime

# Colors — Uzbekistan OTC dark premium theme
BG_COLOR       = (10, 15, 30)
CARD_COLOR     = (18, 25, 50)
ACCENT_BLUE    = (0, 120, 255)
ACCENT_GREEN   = (0, 200, 120)
GOLD           = (212, 175, 55)
WHITE          = (255, 255, 255)
LIGHT_GRAY     = (180, 190, 210)
DARK_GRAY      = (60, 70, 100)
STRIPE_COLOR   = (25, 35, 70)

W, H = 900, 560

def hex_to_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def draw_rounded_rect(draw, xy, radius, fill, outline=None, width=1):
    x1, y1, x2, y2 = xy
    draw.rectangle([x1+radius, y1, x2-radius, y2], fill=fill)
    draw.rectangle([x1, y1+radius, x2, y2-radius], fill=fill)
    draw.ellipse([x1, y1, x1+radius*2, y1+radius*2], fill=fill)
    draw.ellipse([x2-radius*2, y1, x2, y1+radius*2], fill=fill)
    draw.ellipse([x1, y2-radius*2, x1+radius*2, y2], fill=fill)
    draw.ellipse([x2-radius*2, y2-radius*2, x2, y2], fill=fill)
    if outline:
        draw.rounded_rectangle(xy, radius=radius, outline=outline, width=width)

def draw_gradient_bar(img, x1, y1, x2, y2, color1, color2, vertical=True):
    draw = ImageDraw.Draw(img)
    if vertical:
        for i in range(y2 - y1):
            t = i / (y2 - y1)
            r = int(color1[0] + (color2[0] - color1[0]) * t)
            g = int(color1[1] + (color2[1] - color1[1]) * t)
            b = int(color1[2] + (color2[2] - color1[2]) * t)
            draw.line([(x1, y1+i), (x2, y1+i)], fill=(r, g, b))
    else:
        for i in range(x2 - x1):
            t = i / (x2 - x1)
            r = int(color1[0] + (color2[0] - color1[0]) * t)
            g = int(color1[1] + (color2[1] - color1[1]) * t)
            b = int(color1[2] + (color2[2] - color1[2]) * t)
            draw.line([(x1+i, y1), (x1+i, y2)], fill=(r, g, b))

def get_font(size, bold=False):
    font_paths = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf" if bold else "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
    ]
    for path in font_paths:
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size)
            except:
                continue
    return ImageFont.load_default()

def draw_hex_pattern(draw, x, y, size, color, alpha=30):
    """Draw subtle hexagon watermark"""
    points = []
    for i in range(6):
        angle = math.pi / 3 * i - math.pi / 6
        px = x + size * math.cos(angle)
        py = y + size * math.sin(angle)
        points.append((px, py))
    try:
        draw.polygon(points, outline=color + (alpha,) if len(color) == 3 else color)
    except:
        draw.polygon(points, outline=color)

def create_passport(user_data: dict, photo_bytes: bytes = None) -> bytes:
    # Base image
    img = Image.new("RGB", (W, H), BG_COLOR)
    draw = ImageDraw.Draw(img)

    # Background gradient
    draw_gradient_bar(img, 0, 0, W, H, (10, 15, 30), (20, 30, 60), vertical=True)

    # Subtle hex pattern watermark
    for row in range(0, H, 60):
        for col in range(0, W, 70):
            draw_hex_pattern(draw, col, row, 20, DARK_GRAY)

    # Card background
    card_img = Image.new("RGB", (W-60, H-60), CARD_COLOR)
    img.paste(card_img, (30, 30))

    # Top accent bar gradient
    draw_gradient_bar(img, 30, 30, W-30, 100, ACCENT_BLUE, ACCENT_GREEN, vertical=False)

    # Diagonal stripe pattern on top bar
    stripe_img = Image.new("RGBA", (W-60, 70), (0, 0, 0, 0))
    s_draw = ImageDraw.Draw(stripe_img)
    for i in range(-70, W, 20):
        s_draw.line([(i, 0), (i+70, 70)], fill=(255, 255, 255, 15), width=8)
    img.paste(stripe_img, (30, 30), stripe_img)

    # Header text
    font_header = get_font(11, bold=True)
    font_title  = get_font(22, bold=True)
    font_sub    = get_font(11)
    font_label  = get_font(10)
    font_value  = get_font(14, bold=True)
    font_id     = get_font(20, bold=True)
    font_small  = get_font(9)

    draw.text((50, 42), "REPUBLIC OF UZBEKISTAN", font=font_header, fill=WHITE)
    draw.text((50, 57), "OTC TRADING COMMUNITY", font=font_title, fill=WHITE)
    draw.text((50, 83), "MAXSUS RUXSATNOMA  •  SPECIAL PERMIT", font=font_sub, fill=(220, 230, 255))

    # Gold badge top right
    badge_x = W - 120
    draw.ellipse([badge_x, 35, badge_x+80, 95], fill=GOLD)
    draw.ellipse([badge_x+4, 39, badge_x+76, 91], outline=(180, 140, 30), width=2)
    draw.text((badge_x+10, 50), "OTC", font=get_font(18, bold=True), fill=(30, 20, 0))
    draw.text((badge_x+12, 72), "VERIFIED", font=get_font(8, bold=True), fill=(30, 20, 0))

    # Divider line
    draw.line([(30, 105), (W-30, 105)], fill=GOLD, width=1)

    # Photo section
    photo_x, photo_y = 55, 120
    photo_size = 130

    if photo_bytes:
        try:
            photo_img = Image.open(io.BytesIO(photo_bytes)).convert("RGB")
            photo_img = ImageOps.fit(photo_img, (photo_size, photo_size))
            # Circle crop
            mask = Image.new("L", (photo_size, photo_size), 0)
            mask_draw = ImageDraw.Draw(mask)
            mask_draw.ellipse([0, 0, photo_size, photo_size], fill=255)
            photo_circle = Image.new("RGB", (photo_size, photo_size), CARD_COLOR)
            photo_circle.paste(photo_img, mask=mask)
            # Border ring
            ring = Image.new("RGB", (photo_size+8, photo_size+8), CARD_COLOR)
            ring_draw = ImageDraw.Draw(ring)
            ring_draw.ellipse([0, 0, photo_size+8, photo_size+8], outline=GOLD, width=3)
            img.paste(ring, (photo_x-4, photo_y-4))
            img.paste(photo_circle, (photo_x, photo_y))
        except:
            draw.ellipse([photo_x, photo_y, photo_x+photo_size, photo_y+photo_size],
                        outline=GOLD, width=2)
            draw.text((photo_x+35, photo_y+55), "PHOTO", font=font_label, fill=DARK_GRAY)
    else:
        draw.ellipse([photo_x, photo_y, photo_x+photo_size, photo_y+photo_size],
                    outline=GOLD, width=2, fill=(25, 35, 65))
        draw.text((photo_x+35, photo_y+55), "PHOTO", font=font_label, fill=DARK_GRAY)

    # Status badge below photo
    draw.rounded_rectangle([photo_x+10, photo_y+photo_size+8, photo_x+photo_size-10, photo_y+photo_size+28],
                           radius=8, fill=ACCENT_GREEN)
    draw.text((photo_x+25, photo_y+photo_size+12), "✓  ACTIVE MEMBER", font=get_font(9, bold=True), fill=WHITE)

    # Info fields
    info_x = photo_x + photo_size + 30
    info_y = 118
    row_h  = 52

    fields = [
        ("ISM / FAMILIYA", f"{user_data.get('first_name','')} {user_data.get('last_name','')}"),
        ("YOSH / AGE",      str(user_data.get("age", "—"))),
        ("JOYLASHUV / LOCATION", user_data.get("location", "—")),
        ("MAQSAD / PURPOSE",     user_data.get("purpose", "—")),
    ]

    for i, (label, value) in enumerate(fields):
        y = info_y + i * row_h
        # Field background
        draw.rounded_rectangle([info_x, y, W-50, y+42], radius=6, fill=(25, 35, 68))
        draw.line([(info_x, y), (info_x, y+42)], fill=ACCENT_BLUE, width=3)
        draw.text((info_x+10, y+5),  label, font=font_small, fill=LIGHT_GRAY)
        # Truncate long values
        val_display = value[:38] + "…" if len(value) > 38 else value
        draw.text((info_x+10, y+20), val_display, font=font_value, fill=WHITE)

    # Bottom section separator
    sep_y = H - 110
    draw.line([(30, sep_y), (W-30, sep_y)], fill=DARK_GRAY, width=1)

    # Bottom left — unique ID
    draw.text((50, sep_y+10), "UNIKAL RAQAM / UNIQUE ID", font=font_small, fill=LIGHT_GRAY)
    draw.text((50, sep_y+26), f"# {user_data.get('unique_id','—')}", font=font_id, fill=GOLD)

    # Bottom center — date
    reg_date = user_data.get("registered_at", datetime.now().isoformat())[:10]
    draw.text((W//2-50, sep_y+10), "SANA / DATE", font=font_small, fill=LIGHT_GRAY)
    draw.text((W//2-50, sep_y+26), reg_date, font=font_value, fill=WHITE)

    # Bottom right — OTC stamp
    stamp_x = W - 170
    draw.ellipse([stamp_x, sep_y+5, stamp_x+120, sep_y+90], outline=ACCENT_BLUE, width=2)
    draw.ellipse([stamp_x+6, sep_y+11, stamp_x+114, sep_y+84], outline=ACCENT_BLUE, width=1)
    draw.text((stamp_x+15, sep_y+22), "UZBEKISTAN", font=get_font(9, bold=True), fill=ACCENT_BLUE)
    draw.text((stamp_x+30, sep_y+38), "OTC", font=get_font(22, bold=True), fill=ACCENT_BLUE)
    draw.text((stamp_x+20, sep_y+64), "COMMUNITY", font=get_font(9, bold=True), fill=ACCENT_BLUE)

    # MRZ-style bottom strip
    mrz_y = H - 42
    draw.rectangle([30, mrz_y, W-30, H-30], fill=(15, 20, 42))
    unique = user_data.get("unique_id", "000000")
    name_p = f"{user_data.get('last_name','').upper()}<<{user_data.get('first_name','').upper()}"
    mrz1 = f"P<UZB{name_p:<30}"[:44]
    mrz2 = f"OTC{unique:<9}UZB{reg_date.replace('-','')}<<<<<<<<<<<<<<<<<"[:44]
    draw.text((40, mrz_y+4),  mrz1, font=get_font(9), fill=(80, 100, 140))
    draw.text((40, mrz_y+18), mrz2, font=get_font(9), fill=(80, 100, 140))

    # Outer border
    draw.rounded_rectangle([30, 30, W-30, H-30], radius=16, outline=ACCENT_BLUE, width=2)
    draw.rounded_rectangle([32, 32, W-32, H-32], radius=14, outline=(0, 60, 140), width=1)

    # Export
    buf = io.BytesIO()
    img.save(buf, format="PNG", quality=95)
    buf.seek(0)
    return buf.read()
