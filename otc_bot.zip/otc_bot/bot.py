import asyncio
import os
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from dotenv import load_dotenv

import database as db
from handlers import onboarding, admin, group
from scheduler import road_scheduler

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")

async def main():
    db.init_db()
    print("✅ Database initialized")

    bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
    dp  = Dispatcher(storage=MemoryStorage())

    # Register routers
    dp.include_router(onboarding.router)
    dp.include_router(admin.router)
    dp.include_router(group.router)

    # Start road scheduler as background task
    asyncio.create_task(road_scheduler(bot))
    print("✅ Road scheduler started")

    print("🚀 Bot started!")
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())

if __name__ == "__main__":
    asyncio.run(main())
