import asyncio, os, httpx, logging
from telethon import TelegramClient, events
from telethon.sessions import StringSession
from telethon.tl import functions, types

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

API_ID = int(os.getenv("TELEGRAM_API_ID", "0"))
API_HASH = os.getenv("TELEGRAM_API_HASH", "")
SESSION = os.getenv("USERBOT_SESSION", "")
BACKEND = os.getenv("BACKEND_URL", "http://backend:8000")
ADMIN_ID = int(os.getenv("ADMIN_TELEGRAM_ID", "0"))
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
INTERNAL_KEY = os.getenv("INTERNAL_KEY", "")

client = TelegramClient(StringSession(SESSION), API_ID, API_HASH)

async def notify_admin(msg: str):
    try:
        await client.send_message(ADMIN_ID, msg, parse_mode="html")
    except Exception as e:
        logger.error(f"Admin notify: {e}")

async def notify_user(tg_id: int, msg: str):
    async with httpx.AsyncClient(timeout=10) as h:
        try:
            await h.post(
                f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
                json={"chat_id": tg_id, "text": msg, "parse_mode": "HTML"}
            )
        except Exception as e:
            logger.error(f"User notify: {e}")

async def gift_deposit_to_backend(tg_id: int, collection_name: str, image_url: str, lottie_url: str, floor_price: float):
    async with httpx.AsyncClient(timeout=10) as h:
        try:
            r = await h.post(
                f"{BACKEND}/api/admin/gift_deposit",
                headers={"x-internal-key": INTERNAL_KEY},
                json={"telegram_id": tg_id, "collection_name": collection_name, "image_url": image_url, "lottie_url": lottie_url, "floor_price": floor_price}
            )
            return r.status_code == 200
        except Exception as e:
            logger.error(f"Gift deposit: {e}")
            return False

async def get_pending_withdrawals():
    async with httpx.AsyncClient(timeout=10) as h:
        try:
            r = await h.get(f"{BACKEND}/api/admin/withdrawals/internal", headers={"x-internal-key": INTERNAL_KEY})
            if r.status_code == 200:
                return r.json()
        except Exception as e:
            logger.error(f"Fetch withdrawals: {e}")
    return []

async def complete_withdrawal(wid: int):
    async with httpx.AsyncClient(timeout=10) as h:
        try:
            await h.post(f"{BACKEND}/api/admin/withdrawals/{wid}/complete", headers={"x-internal-key": INTERNAL_KEY})
        except Exception as e:
            logger.error(f"Complete withdrawal: {e}")

async def sync_gift_collections():
    """Sync real gift collections from Telegram to backend"""
    try:
        # Get available star gifts
        result = await client(functions.payments.GetStarGiftsRequest(hash=0))
        collections = []
        for gift in result.gifts:
            if hasattr(gift, 'sticker') and gift.sticker:
                # Get sticker file for image
                sticker = gift.sticker
                title = getattr(gift, 'title', f"Gift #{gift.id}")
                stars = getattr(gift, 'stars', 50)
                floor_price = round(stars * 0.013, 3)
                
                # Build lottie URL for animated sticker
                lottie_url = ""
                image_url = ""
                if hasattr(sticker, 'id'):
                    lottie_url = f"https://nft.fragment.com/gift/{title.lower().replace(' ','')}-{gift.id}.lottie.json"
                    image_url = f"https://nft.fragment.com/gift/{title.lower().replace(' ','')}-{gift.id}.webp"
                
                collections.append({
                    "name": title,
                    "slug": title.lower().replace(" ", ""),
                    "image_url": image_url,
                    "lottie_url": lottie_url,
                    "floor_price": floor_price,
                    "gift_id": gift.id,
                })
        
        if collections:
            async with httpx.AsyncClient(timeout=30) as h:
                r = await h.post(
                    f"{BACKEND}/api/admin/collections/sync_from_userbot",
                    headers={"x-internal-key": INTERNAL_KEY},
                    json={"collections": collections}
                )
                if r.status_code == 200:
                    logger.info(f"Synced {len(collections)} gift collections")
                    return len(collections)
    except Exception as e:
        logger.error(f"Sync collections error: {e}")
    return 0

async def get_my_saved_gifts():
    """Get all gifts saved in userbot account"""
    gifts = []
    try:
        me = await client.get_me()
        result = await client(functions.payments.GetSavedStarGiftsRequest(
            peer=me,
            offset="",
            limit=100
        ))
        for saved in result.gifts:
            gift = saved.gift
            title = getattr(gift, 'title', '') or f"Gift #{gift.id}"
            gifts.append({
                "id": saved.msg_id,
                "gift_id": gift.id,
                "title": title,
                "stars": getattr(gift, 'stars', 0),
            })
    except Exception as e:
        logger.error(f"Get saved gifts: {e}")
    return gifts

async def send_gift_to_user(user_tg_id: int, saved_msg_id: int):
    """Transfer saved gift to user"""
    try:
        peer = await client.get_input_entity(user_tg_id)
        await client(functions.payments.TransferStarGiftRequest(
            stargift=types.InputSavedStarGiftUser(
                user_id=await client.get_input_entity(await client.get_me()),
                msg_id=saved_msg_id
            ),
            to_id=peer
        ))
        return True
    except Exception as e:
        logger.error(f"Send gift error: {e}")
        return False

async def process_withdrawals():
    logger.info("Withdrawal processor started")
    while True:
        try:
            withdrawals = await get_pending_withdrawals()
            for w in withdrawals:
                wid = w["id"]
                tg_id = w["user_id"]
                collection = w["collection"]
                username = w.get("username", "")
                logger.info(f"Processing #{wid}: {collection} → @{username}")

                # Get my saved gifts
                my_gifts = await get_my_saved_gifts()
                matching = [g for g in my_gifts if collection.lower() in g["title"].lower()]

                if matching:
                    gift = matching[0]
                    success = await send_gift_to_user(tg_id, gift["id"])
                    if success:
                        await complete_withdrawal(wid)
                        await notify_user(tg_id,
                            f"✅ <b>Gift yuborildi!</b>\n\n"
                            f"🎁 <b>{collection}</b>\n"
                            f"Telegram giflaringizni tekshiring!")
                        logger.info(f"✅ Sent {collection} → {tg_id}")
                    else:
                        await notify_user(tg_id, f"⏳ <b>Gift yuborilmoqda...</b>\n🎁 <b>{collection}</b>")
                else:
                    await notify_admin(
                        f"⚠️ <b>Gift kerak!</b>\n\n"
                        f"🎁 Collection: <b>{collection}</b>\n"
                        f"👤 User: @{username} ({tg_id})\n"
                        f"🆔 Withdraw ID: #{wid}\n\n"
                        f"Hisobingizga <b>{collection}</b> collectionidan gift qo'shing."
                    )
                    await notify_user(tg_id,
                        f"⏳ <b>Gifingiz tayyorlanmoqda...</b>\n\n"
                        f"🎁 <b>{collection}</b>\n"
                        f"5-10 daqiqa ichida yuboriladi.")
        except Exception as e:
            logger.error(f"Withdrawal loop: {e}")
        await asyncio.sleep(30)

# ── Gift incoming handler ──────────────────────────────────────────────────────
@client.on(events.Raw(types.UpdateNewMessage))
async def handle_incoming(event):
    """Detect when someone sends a gift to userbot"""
    try:
        msg = event.message
        if not hasattr(msg, 'action'):
            return
        
        action = msg.action
        action_name = type(action).__name__
        
        # Star gift received
        if 'StarGift' in action_name or 'Gift' in action_name:
            gift = getattr(action, 'gift', None)
            if not gift:
                return
            
            title = getattr(gift, 'title', '') or f"Gift #{getattr(gift,'id',0)}"
            stars = getattr(gift, 'stars', 50)
            floor_price = round(stars * 0.013, 3)
            gift_id = getattr(gift, 'id', 0)
            
            image_url = f"https://nft.fragment.com/gift/{title.lower().replace(' ','')}-{gift_id}.webp"
            lottie_url = f"https://nft.fragment.com/gift/{title.lower().replace(' ','')}-{gift_id}.lottie.json"
            
            # Get sender
            try:
                sender = await client.get_entity(msg.peer_id)
                sender_tg_id = sender.id
                
                success = await gift_deposit_to_backend(
                    tg_id=sender_tg_id,
                    collection_name=title,
                    image_url=image_url,
                    lottie_url=lottie_url,
                    floor_price=floor_price
                )
                
                if success:
                    await notify_user(sender_tg_id,
                        f"✅ <b>Gift qabul qilindi!</b>\n\n"
                        f"🎁 <b>{title}</b>\n"
                        f"💎 Qiymati: ~{floor_price} TON\n\n"
                        f"Gift inventaringizga qo'shildi! Botga o'ting.")
                    logger.info(f"Gift received from {sender_tg_id}: {title}")
            except Exception as e:
                logger.error(f"Handle gift sender: {e}")
    except Exception as e:
        logger.error(f"Handle incoming: {e}")

async def main():
    logger.info("Starting Utonks userbot v3...")
    await client.connect()
    
    if not await client.is_user_authorized():
        logger.error("Session expired! Please re-authorize.")
        return
    
    me = await client.get_me()
    logger.info(f"Logged in as @{me.username} ({me.id})")
    
    # Save userbot username to backend settings
    async with httpx.AsyncClient(timeout=10) as h:
        try:
            await h.put(
                f"{BACKEND}/api/admin/settings",
                headers={"Authorization": "skip"},
                json={"userbot_username": me.username or str(me.id)}
            )
        except:
            pass
    
    await notify_admin(
        f"🚀 <b>Utonks userbot ishga tushdi!</b>\n"
        f"👤 @{me.username}\n"
        f"🎁 Gift qabul qilish: tayyor\n"
        f"📤 Withdrawal: tayyor"
    )
    
    # Sync gift collections on startup
    logger.info("Syncing gift collections from Telegram...")
    count = await sync_gift_collections()
    logger.info(f"Synced {count} collections")
    
    # Start withdrawal processor
    asyncio.create_task(process_withdrawals())
    
    # Re-sync collections every hour
    async def periodic_sync():
        while True:
            await asyncio.sleep(3600)
            await sync_gift_collections()
    asyncio.create_task(periodic_sync())
    
    logger.info("Userbot running...")
    await client.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())
