export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        d1:"#08060F", d2:"#100D20", d3:"#161230", d4:"#1C1740", d5:"#221E4E",
        blue:{m:"#3D6EF8",l:"#5D8BFF",d:"#2952D9"},
        ton:"#0098EA", green:"#00E676", red:"#FF3D57",
        gold:"#FFB800", purple:"#7B4FE9", cyan:"#00D4FF",
      },
      fontFamily: { display: ["'Space Grotesk'","sans-serif"] },
      animation: {
        "float":"float 3s ease-in-out infinite",
        "glow-pulse":"glowPulse 2s ease-in-out infinite",
        "spin-slow":"spin 4s linear infinite",
        "bounce-slow":"bounce 2s ease-in-out infinite",
      },
      keyframes: {
        float:{"0%,100%":{transform:"translateY(0)"},"50%":{transform:"translateY(-8px)"}},
        glowPulse:{"0%,100%":{boxShadow:"0 0 10px rgba(61,110,248,0.3)"},"50%":{boxShadow:"0 0 30px rgba(61,110,248,0.8)"}},
      },
    },
  },
  plugins: [],
};
