import axios from "axios";
const api = axios.create({ baseURL: "/api" });
api.interceptors.request.use(cfg => {
  const d = window.Telegram?.WebApp?.initData;
  if (d) cfg.headers["Authorization"] = `tma ${d}`;
  return cfg;
});
export default api;
