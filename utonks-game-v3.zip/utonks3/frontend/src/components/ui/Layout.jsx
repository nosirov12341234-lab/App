import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useTonConnectUI } from "@tonconnect/ui-react";
import { useStore } from "../../utils/store";
import { TonIcon, Avatar } from "./Icons";
import api from "../../utils/api";

// ── HEADER ────────────────────────────────────────────────────────────────────
export function Header() {
  const { user } = useStore();
  const [showDeposit, setShowDeposit] = useState(false);
  return (
    <>
      <header className="sticky top-0 z-40 px-4 py-3 flex items-center justify-between glass-dark border-b border-white/5">
        <div className="flex items-center gap-3 card px-3 py-2">
          <Avatar url={user?.photo_url} name={user?.first_name} size="w-8 h-8"/>
          <div>
            <p className="text-sm font-semibold leading-none">{user?.first_name || "..."}</p>
            <p className="text-xs text-white/40 mt-0.5">Level {user?.level || 1}</p>
          </div>
        </div>
        <button onClick={() => setShowDeposit(true)} className="flex items-center gap-2 card px-3 py-2 active:scale-95 transition-transform">
          <TonIcon size={16}/>
          <span className="text-sm font-bold">{(user?.balance || 0).toFixed(2)}</span>
          <div className="w-6 h-6 rounded-full bg-blue-m flex items-center justify-center glow-blue text-xs font-bold">+</div>
        </button>
      </header>
      {showDeposit && <DepositModal onClose={() => setShowDeposit(false)}/>}
    </>
  );
}

// ── BOTTOM NAV ────────────────────────────────────────────────────────────────
const NAV = [
  { path: "/inventory", label: "Inventory", emoji: "🎒" },
  { path: "/games", label: "Games", emoji: "🎮" },
  { path: "/profile", label: "Profile", emoji: "👤" },
];

export function BottomNav() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { user } = useStore();
  const isActive = p => pathname.startsWith(p);
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 glass-dark border-t border-white/5 pb-safe">
      <div className="flex items-center justify-around px-2 pt-2 pb-1">
        {NAV.map(item => {
          const active = isActive(item.path);
          return (
            <button key={item.path} onClick={() => navigate(item.path)}
              className={`flex flex-col items-center gap-1 py-2 px-5 rounded-2xl transition-all active:scale-90 ${active ? "bg-blue-m/15" : ""}`}>
              <span className="text-2xl">{item.emoji}</span>
              <span className={`text-xs font-medium ${active ? "text-blue-m" : "text-white/40"}`}>{item.label}</span>
              {active && <div className="w-1 h-1 rounded-full bg-blue-m"/>}
            </button>
          );
        })}
        {user?.is_admin && (
          <button onClick={() => navigate("/admin")}
            className={`flex flex-col items-center gap-1 py-2 px-4 rounded-2xl transition-all active:scale-90 ${isActive("/admin") ? "bg-gold/15" : ""}`}>
            <span className="text-2xl">⚙️</span>
            <span className={`text-xs font-medium ${isActive("/admin") ? "text-gold" : "text-white/40"}`}>Admin</span>
          </button>
        )}
      </div>
    </nav>
  );
}

// ── DEPOSIT MODAL ─────────────────────────────────────────────────────────────
const TABS = [
  { id: "stars", label: "Stars", icon: "⭐", badge: null },
  { id: "ton", label: "TON", icon: null, badge: "+10%" },
  { id: "gifts", label: "Gifts", icon: "🎁", badge: null },
];

export function DepositModal({ onClose }) {
  const [tab, setTab] = useState("ton");
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const { fetchUser, user } = useStore();
  const [tonUI] = useTonConnectUI();

  const quickTon = ["0.5","1","2","5","10"];
  const quickStars = ["50","100","200","500","1000"];

  const handleTon = async () => {
    if (!amount || parseFloat(amount) < 0.1) return;
    setLoading(true);
    try {
      const r = await api.post(`/user/deposit/ton?amount=${amount}`);
      await tonUI.sendTransaction({
        validUntil: Math.floor(Date.now()/1000)+600,
        messages: [{ address: r.data.wallet, amount: String(Math.floor(parseFloat(amount)*1e9)) }],
      });
      setDone(true); setTimeout(() => { fetchUser(); onClose(); }, 2000);
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  const handleStars = async () => {
    if (!amount || parseInt(amount) < 50) return;
    setLoading(true);
    try {
      const r = await api.post(`/user/deposit/stars?stars=${amount}`);
      window.Telegram?.WebApp?.openInvoice?.(r.data.invoice_url, s => { if(s==="paid"){fetchUser();onClose();} });
    } catch {}
    setLoading(false);
  };

  return (
    <AnimatePresence>
      <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}
        className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm"
        onClick={onClose}>
        <motion.div initial={{y:"100%"}} animate={{y:0}} exit={{y:"100%"}}
          transition={{type:"spring",damping:28,stiffness:280}}
          className="w-full bg-d2 rounded-t-3xl p-6 pb-10 border-t border-white/10"
          onClick={e=>e.stopPropagation()}>
          <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-6"/>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-black font-display tracking-wider">DEPOSIT</h2>
            <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/50 active:scale-90">✕</button>
          </div>

          <div className="flex gap-2 mb-6">
            {TABS.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`flex-1 relative flex flex-col items-center gap-1.5 py-3 rounded-2xl border transition-all active:scale-95 ${tab===t.id?"bg-blue-m border-blue-m":"card-elevated border-white/8"}`}>
                {t.badge && <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 bg-green text-black text-xs font-black px-2 py-0.5 rounded-full">{t.badge}</span>}
                {t.icon ? <span className="text-xl">{t.icon}</span> : <TonIcon size={20}/>}
                <span className="text-xs font-bold">{t.label}</span>
              </button>
            ))}
          </div>

          {done ? (
            <div className="text-center py-8 space-y-3">
              <div className="text-5xl">✅</div>
              <p className="text-green font-bold text-xl">Payment sent!</p>
              <p className="text-white/40 text-sm">Balance updating...</p>
            </div>
          ) : tab !== "gifts" ? (
            <div className="space-y-4">
              <div className={`flex items-center gap-3 card-elevated px-4 py-3 border border-white/8 rounded-2xl`}>
                {tab==="ton" ? <TonIcon size={22}/> : <span className="text-2xl">⭐</span>}
                <input type="number" value={amount} onChange={e=>setAmount(e.target.value)}
                  placeholder={tab==="ton"?"Min 0.1 TON":"Min 50 Stars"}
                  className="flex-1 bg-transparent text-white text-lg outline-none font-display"/>
              </div>
              <div className="flex gap-2 flex-wrap">
                {(tab==="ton"?quickTon:quickStars).map(q=>(
                  <button key={q} onClick={()=>setAmount(q)}
                    className={`px-3 py-1.5 rounded-xl text-sm font-bold border transition-all active:scale-95 ${amount===q?"bg-blue-m border-blue-m":"card-elevated border-white/10 text-white/60"}`}>
                    {q}{tab==="ton"?" TON":"⭐"}
                  </button>
                ))}
              </div>
              {amount && tab==="ton" && (
                <div className="bg-green/10 border border-green/25 rounded-xl px-4 py-2.5 flex justify-between items-center">
                  <span className="text-green text-sm">Deposit bonus +10%</span>
                  <span className="text-green font-bold">+{(parseFloat(amount||0)*0.1).toFixed(3)} TON</span>
                </div>
              )}
              <div className="flex gap-3 pt-1">
                <button onClick={onClose} className="flex-1 py-4 rounded-2xl card border border-white/10 font-bold text-white/60 active:scale-95">Cancel</button>
                <button onClick={tab==="ton"?handleTon:handleStars} disabled={loading||!amount}
                  className="flex-1 py-4 btn-blue rounded-2xl disabled:opacity-30">
                  {loading?"...":"Deposit"}
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="card-elevated rounded-2xl p-5 text-center border border-white/8 space-y-3">
                <span className="text-4xl">🎁</span>
                <p className="text-white font-bold">Send gift to userbot</p>
                <p className="text-white/40 text-sm">TON credited at Fragment floor price</p>
                {user?.userbot_username && (
                  <div className="bg-blue-m/15 rounded-xl px-4 py-2.5 border border-blue-m/30">
                    <p className="text-blue-l font-mono font-bold">@{user.userbot_username}</p>
                  </div>
                )}
              </div>
              <div className="bg-blue-m/10 border border-blue-m/25 rounded-xl px-4 py-3">
                <p className="text-blue-l text-sm">💡 Gift auto-detected and added to inventory</p>
              </div>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
