// TonIcon
export function TonIcon({ size = 18, className = "" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 56 56" fill="none" className={className}>
      <circle cx="28" cy="28" r="28" fill="#0098EA"/>
      <path d="M18.1 15.2h19.8c1.4 0 2.2 1.6 1.4 2.8L28 40.8 16.7 18c-.8-1.2 0-2.8 1.4-2.8z" fill="white"/>
    </svg>
  );
}

// GiftMedia - shows lottie or image
export function GiftMedia({ imageUrl, lottieUrl, className = "", size = "w-full h-full" }) {
  if (lottieUrl) {
    return (
      <img
        src={imageUrl || lottieUrl}
        className={`${size} object-contain ${className}`}
        onError={(e) => { e.target.src = imageUrl || ""; }}
        alt="gift"
      />
    );
  }
  if (imageUrl) {
    return <img src={imageUrl} className={`${size} object-contain ${className}`} alt="gift" onError={e => e.target.style.display='none'}/>;
  }
  return <div className={`${size} flex items-center justify-center text-4xl`}>🎁</div>;
}

// Avatar with fallback
export function Avatar({ url, name, size = "w-9 h-9", textSize = "text-sm" }) {
  if (url && !url.includes("undefined") && !url.includes(".svg")) {
    return <img src={url} className={`${size} rounded-full object-cover flex-shrink-0`} onError={e=>e.target.style.display='none'} alt={name}/>;
  }
  const letter = (name || "?")[0].toUpperCase();
  const colors = ["bg-blue-m","bg-purple","bg-green","bg-gold","bg-red","bg-cyan"];
  const color = colors[letter.charCodeAt(0) % colors.length];
  return <div className={`${size} rounded-full ${color} flex items-center justify-center ${textSize} font-bold flex-shrink-0`}>{letter}</div>;
}
