import { useState, useEffect, useRef, useCallback } from "react";
import { useNavigate, useLocation, Routes, Route } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useTonConnectUI, useTonAddress } from "@tonconnect/ui-react";
import api from "../utils/api";
import { useStore } from "../utils/store";
import { TonIcon, GiftMedia, Avatar } from "../components/ui/Icons";
import { DepositModal } from "../components/ui/Layout";

// ── GAMES PAGE ─────────────────────────────────────────────────────────────────
const GAMES = [
  {id:"crash",name:"CRASH",path:"/games/crash",from:"from-blue-600",to:"to-cyan-400",emoji:"🚀",desc:"Fly to moon!"},
  {id:"mines",name:"MINES",path:"/games/mines",from:"from-red-600",to:"to-pink-500",emoji:"💣",desc:"Avoid bombs!"},
  {id:"cases",name:"CASES",path:"/games/cases",from:"from-purple-600",to:"to-violet-500",emoji:"📦",desc:"Open cases!"},
  {id:"upgrade",name:"UPGRADE",path:"/games/upgrade",from:"from-amber-500",to:"to-orange-400",emoji:"⬆️",desc:"Combine gifts!"},
  {id:"zone",name:"ZONE",path:"/games/zone",from:"from-emerald-500",to:"to-teal-400",emoji:"🎯",desc:"Spin the wheel!"},
];

export function GamesPage() {
  const navigate = useNavigate();
  const [online, setOnline] = useState(63);
  useEffect(() => {
    const proto = location.protocol==="https:"?"wss:":"ws:";
    const ws = new WebSocket(`${proto}//${location.host}/api/crash/ws`);
    ws.onmessage = e => { const d=JSON.parse(e.data); if(d.online) setOnline(d.online); };
    return () => ws.close();
  }, []);
  return (
    <div className="px-4 py-4 space-y-5">
      <div className="flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-green animate-pulse"/>
        <span className="text-white/50 text-sm">{online} Online</span>
      </div>
      <div>
        <p className="text-white/40 text-xs font-bold uppercase tracking-widest mb-3">🔥 Games</p>
        <div className="grid grid-cols-2 gap-3">
          {GAMES.map((g,i) => (
            <motion.button key={g.id} initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{delay:i*0.07}}
              onClick={()=>navigate(g.path)}
              className={`relative overflow-hidden rounded-2xl bg-gradient-to-br ${g.from} ${g.to} aspect-[4/3] flex flex-col justify-end p-4 active:scale-95 transition-all`}>
              <div className="absolute inset-0 flex items-center justify-center opacity-15 text-8xl select-none">{g.emoji}</div>
              <div className="relative">
                <p className="font-black text-white text-xl tracking-wider font-display">{g.name}</p>
                <p className="text-white/60 text-xs">{g.desc}</p>
              </div>
            </motion.button>
          ))}
        </div>
      </div>
      <div>
        <p className="text-white/40 text-xs font-bold uppercase tracking-widest mb-3">✨ Bonuses</p>
        <div className="grid grid-cols-2 gap-3">
          {[{name:"PROMOCODE",emoji:"🎫",path:"/games/cases?promo=1"},{name:"DAILY CASE",emoji:"🎁",path:"/games/cases?daily=1"}].map((b,i)=>(
            <motion.button key={b.name} initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{delay:0.38+i*0.07}}
              onClick={()=>navigate(b.path)}
              className="relative overflow-hidden rounded-2xl card border-white/8 aspect-[4/3] flex flex-col justify-end p-4 active:scale-95 transition-all">
              <div className="absolute inset-0 flex items-center justify-center opacity-10 text-8xl">{b.emoji}</div>
              <p className="relative font-black text-white text-base tracking-wider font-display">{b.name}</p>
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── CRASH PAGE ─────────────────────────────────────────────────────────────────
export function CrashPage() {
  const {user,fetchUser} = useStore();
  const [state,setState] = useState("waiting");
  const [multi,setMulti] = useState(1.0);
  const [crashPt,setCrashPt] = useState(null);
  const [history,setHistory] = useState([]);
  const [bets,setBets] = useState([]);
  const [myBet,setMyBet] = useState(null);
  const [cashed,setCashed] = useState(false);
  const [betAmt,setBetAmt] = useState("0.1");
  const [timer,setTimer] = useState(5);
  const [online,setOnline] = useState(63);
  const [selGift,setSelGift] = useState(null);
  const canvasRef = useRef(null);
  const startRef = useRef(null);
  const {inventory} = useStore();

  const drawGraph = useCallback((m) => {
    const c = canvasRef.current; if(!c) return;
    const ctx = c.getContext("2d"); const w=c.width,h=c.height;
    ctx.clearRect(0,0,w,h);
    ctx.strokeStyle="rgba(255,255,255,0.04)"; ctx.lineWidth=1;
    for(let i=1;i<=4;i++){ctx.beginPath();ctx.moveTo(0,h/4*i);ctx.lineTo(w,h/4*i);ctx.stroke();}
    if(!startRef.current) return;
    const elapsed = Date.now()-startRef.current;
    const pts=[];
    for(let t=0;t<=elapsed;t+=80){
      const mm=Math.pow(Math.E,0.00006*t);
      pts.push({x:(t/Math.max(elapsed,1))*w,y:h-((mm-1)/Math.max(m-1,0.01))*h*0.78});
    }
    if(pts.length<2) return;
    const grad=ctx.createLinearGradient(0,0,0,h);
    grad.addColorStop(0,"rgba(61,110,248,0.28)");grad.addColorStop(1,"rgba(61,110,248,0)");
    ctx.beginPath();ctx.moveTo(pts[0].x,h);pts.forEach(p=>ctx.lineTo(p.x,p.y));
    ctx.lineTo(pts[pts.length-1].x,h);ctx.closePath();ctx.fillStyle=grad;ctx.fill();
    ctx.beginPath();pts.forEach((p,i)=>i===0?ctx.moveTo(p.x,p.y):ctx.lineTo(p.x,p.y));
    ctx.strokeStyle="#3D6EF8";ctx.lineWidth=2.5;ctx.stroke();
    const lp=pts[pts.length-1];
    ctx.font="20px serif";ctx.fillText("🚀",lp.x-10,lp.y-10);
  },[]);

  useEffect(()=>{
    const proto=location.protocol==="https:"?"wss:":"ws:";
    const connect=()=>{
      const ws=new WebSocket(`${proto}//${location.host}/api/crash/ws`);
      ws.onmessage=e=>{
        const d=JSON.parse(e.data);
        if(d.type==="state"){setState(d.game_state);setMulti(d.multiplier||1);setHistory(d.history||[]);setOnline(d.online||63);}
        if(d.type==="betting"){setState("betting");setMulti(1);setCrashPt(null);setBets([]);setMyBet(null);setCashed(false);startRef.current=null;let t=5;setTimer(5);const iv=setInterval(()=>{t--;setTimer(t);if(t<=0)clearInterval(iv);},1000);setHistory(d.history||[]);setOnline(d.online||63);}
        if(d.type==="started"){setState("running");setBets(d.bets||[]);startRef.current=Date.now();}
        if(d.type==="tick"){setMulti(d.multiplier);setOnline(d.online||63);drawGraph(d.multiplier);}
        if(d.type==="cashout"){setBets(p=>p.map(b=>b.username===d.username?{...b,cashed:true,cm:d.multiplier}:b));}
        if(d.type==="crashed"){setState("crashed");setCrashPt(d.crash_point);setHistory(d.history||[]);const c=canvasRef.current;if(c){const ctx=c.getContext("2d");ctx.clearRect(0,0,c.width,c.height);ctx.fillStyle="rgba(255,61,87,0.08)";ctx.fillRect(0,0,c.width,c.height);}}
      };
      ws.onclose=()=>setTimeout(connect,2000);
    };
    connect();
  },[drawGraph]);

  const placeBet=async()=>{
    if(state!=="betting"||myBet) return;
    try{
      if(selGift){await api.post(`/crash/bet?amount=${selGift.floor_price}&is_gift=true&inventory_item_id=${selGift.id}`);}
      else{await api.post(`/crash/bet?amount=${betAmt}`);}
      setMyBet(parseFloat(selGift?selGift.floor_price:betAmt));setSelGift(null);await fetchUser();
    }catch(e){window.Telegram?.WebApp?.showAlert(e.response?.data?.detail||"Error");}
  };

  const cashout=async()=>{
    if(state!=="running"||!myBet||cashed) return;
    try{await api.post("/crash/cashout");setCashed(true);await fetchUser();}catch{}
  };

  const mColor=state==="crashed"?"#FF3D57":multi<2?"#fff":multi<5?"#FFB800":"#00E676";
  const availGifts=inventory.filter(i=>!i.is_locked&&i.can_bet);

  return (
    <div className="px-4 py-3 space-y-4">
      <div className="flex gap-2 overflow-x-auto pb-1" style={{scrollbarWidth:"none"}}>
        {[...history].reverse().map((h,i)=>(
          <span key={i} className={`flex-shrink-0 text-xs font-bold px-2.5 py-1 rounded-lg ${h<2?"bg-red/20 text-red":h<5?"bg-gold/20 text-gold":"bg-green/20 text-green"}`}>x{h}</span>
        ))}
      </div>

      <div className="relative card rounded-3xl overflow-hidden border-white/5" style={{height:200}}>
        <canvas ref={canvasRef} width={400} height={200} className="w-full h-full"/>
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className="text-5xl font-black font-display" style={{color:mColor,textShadow:`0 0 30px ${mColor}40`}}>
            {state==="crashed"?`💥 ${crashPt}x`:state==="betting"?`${timer}s`:`${multi.toFixed(2)}x`}
          </span>
          {state==="betting"&&<p className="text-white/40 text-xs mt-1">Place your bets</p>}
        </div>
        <div className="absolute top-3 left-3 flex items-center gap-1.5 bg-d1/80 rounded-lg px-2 py-1">
          <div className="w-1.5 h-1.5 rounded-full bg-green animate-pulse"/>
          <span className="text-white/40 text-xs">{online}</span>
        </div>
      </div>

      <div className="card p-4 border-white/5 space-y-3">
        {selGift ? (
          <div className="flex items-center gap-3 card-elevated rounded-xl px-3 py-2 border border-blue-m/40">
            <div className="w-10 h-10 rounded-lg overflow-hidden bg-d4">
              <GiftMedia imageUrl={selGift.collection_image} lottieUrl={selGift.collection_lottie} size="w-10 h-10"/>
            </div>
            <div className="flex-1"><p className="text-white text-sm font-semibold">{selGift.collection_name}</p><p className="text-white/40 text-xs">{selGift.floor_price} TON</p></div>
            <button onClick={()=>setSelGift(null)} className="text-white/40 text-sm">✕</button>
          </div>
        ) : (
          <div className="flex gap-2">
            <div className="flex-1 flex items-center gap-2 card-elevated rounded-xl px-3 py-2.5 border border-white/8">
              <TonIcon size={16}/>
              <input type="number" value={betAmt} onChange={e=>setBetAmt(e.target.value)} className="flex-1 bg-transparent text-white outline-none text-sm" min="0.01" step="0.1"/>
            </div>
          </div>
        )}
        <div className="flex gap-2">
          {["0.1","0.5","1","5"].map(q=>(
            <button key={q} onClick={()=>{setBetAmt(q);setSelGift(null);}}
              className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition-all ${betAmt===q&&!selGift?"bg-blue-m border-blue-m":"card-elevated border-white/10 text-white/50"}`}>{q}</button>
          ))}
        </div>
        {availGifts.length > 0 && (
          <div>
            <p className="text-white/30 text-xs mb-2">Bet with gift:</p>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {availGifts.slice(0,6).map(g=>(
                <button key={g.id} onClick={()=>{setSelGift(g);}}
                  className={`flex-shrink-0 w-14 rounded-xl overflow-hidden border-2 transition-all ${selGift?.id===g.id?"border-blue-m":"border-white/10"}`}>
                  <GiftMedia imageUrl={g.collection_image} lottieUrl={g.collection_lottie} size="w-14 h-14"/>
                  <p className="text-white text-xs text-center py-0.5 truncate px-1">{g.floor_price}T</p>
                </button>
              ))}
            </div>
          </div>
        )}
        <button onClick={state==="running"&&myBet&&!cashed?cashout:placeBet}
          disabled={(state==="betting"&&!!myBet)||(state==="running"&&(!myBet||cashed))||state==="crashed"}
          className={`w-full py-4 rounded-xl font-bold text-base transition-all active:scale-95 disabled:opacity-35 ${state==="running"&&myBet&&!cashed?"btn-green animate-pulse":"btn-blue"}`}>
          {state==="running"&&myBet&&!cashed?`Cash Out ${(myBet*multi).toFixed(3)} TON`:state==="betting"&&!myBet?"Place Bet":myBet?"✓ Bet placed":"Place Bet"}
        </button>
      </div>

      <div className="space-y-2">
        {bets.slice(0,8).map((b,i)=>(
          <div key={i} className="flex items-center justify-between card rounded-xl px-3 py-2.5 border-white/5">
            <div className="flex items-center gap-2">
              <Avatar url={b.avatar_url} name={b.username} size="w-7 h-7" textSize="text-xs"/>
              <div><p className="text-sm font-medium">{b.username}</p><p className="text-xs text-white/40">{b.amount} TON</p></div>
            </div>
            <div className="flex items-center gap-1">
              {b.cashed?<span className="text-green text-sm font-bold">{(b.amount*(b.cm||1)).toFixed(2)}</span>:<span className="text-white/40 text-sm">{b.amount}</span>}
              <TonIcon size={14}/>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── MINES PAGE ─────────────────────────────────────────────────────────────────
export function MinesPage() {
  const {fetchUser} = useStore();
  const [cells,setCells] = useState(Array(25).fill(null));
  const [revealed,setRevealed] = useState(Array(25).fill(false));
  const [active,setActive] = useState(false);
  const [over,setOver] = useState(false);
  const [won,setWon] = useState(false);
  const [betAmt,setBetAmt] = useState("0.1");
  const [mines,setMines] = useState(3);
  const [multi,setMulti] = useState(1.0);
  const [gid,setGid] = useState(null);

  const start=async()=>{
    try{
      const r=await api.post(`/mines/start?amount=${betAmt}&mines=${mines}`);
      setGid(r.data.game_id);setActive(true);setOver(false);setWon(false);
      setCells(Array(25).fill(null));setRevealed(Array(25).fill(false));setMulti(1.0);
      await fetchUser();
    }catch(e){window.Telegram?.WebApp?.showAlert(e.response?.data?.detail||"Error");}
  };

  const reveal=async(idx)=>{
    if(!active||revealed[idx]||over) return;
    try{
      const r=await api.post(`/mines/reveal?game_id=${gid}&cell=${idx}`);
      const nr=[...revealed];nr[idx]=true;setRevealed(nr);
      const nc=[...cells];
      if(r.data.is_mine){nc[idx]="mine";r.data.all_mines?.forEach(m=>{nc[m]="mine";});setCells(nc);setOver(true);setActive(false);setWon(false);}
      else{nc[idx]="gem";setCells(nc);setMulti(r.data.multiplier);}
    }catch{}
  };

  const cashout=async()=>{
    try{await api.post(`/mines/cashout?game_id=${gid}`);setActive(false);setWon(true);setOver(true);await fetchUser();}catch{}
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-black font-display">💣 MINES</h1>
        {active&&<div className="bg-green/20 border border-green/30 rounded-xl px-3 py-1"><span className="text-green font-bold">{multi.toFixed(2)}x</span></div>}
      </div>
      {over&&(
        <div className={`rounded-2xl p-4 text-center border ${won?"bg-green/10 border-green/25":"bg-red/10 border-red/25"}`}>
          <p className="font-bold text-lg">{won?"🎉 You won!":"💥 Boom! Lost!"}</p>
          {won&&<p className="text-sm text-white/50">{(parseFloat(betAmt)*multi).toFixed(3)} TON</p>}
        </div>
      )}
      <div className="grid grid-cols-5 gap-2">
        {Array(25).fill(null).map((_,i)=>{
          const r=revealed[i],t=cells[i];
          return(
            <motion.button key={i} whileTap={{scale:0.85}} onClick={()=>reveal(i)}
              className={`aspect-square rounded-xl flex items-center justify-center text-xl border transition-all ${!r?"card border-white/8 active:bg-d4":t==="gem"?"bg-blue-m/20 border-blue-m/50":t==="mine"?"bg-red/20 border-red/50":"card border-white/5"}`}>
              {r&&t==="gem"&&"💎"}{r&&t==="mine"&&"💣"}{!r&&over&&cells[i]==="mine"&&"💣"}
            </motion.button>
          );
        })}
      </div>
      <div className="card p-4 border-white/5 space-y-3">
        {!active&&(
          <>
            <div className="flex items-center gap-2 card-elevated rounded-xl px-3 py-2.5 border border-white/8">
              <TonIcon size={16}/><input type="number" value={betAmt} onChange={e=>setBetAmt(e.target.value)} className="flex-1 bg-transparent text-white outline-none text-sm" min="0.01"/>
            </div>
            <div>
              <div className="flex justify-between text-xs text-white/40 mb-2"><span>Mines: {mines}</span><span>{mines>12?"💀 Extreme":mines>7?"🔥 Hard":mines>3?"⚡ Medium":"🌱 Easy"}</span></div>
              <input type="range" min="1" max="20" value={mines} onChange={e=>setMines(parseInt(e.target.value))} className="w-full accent-blue-m"/>
              <div className="flex justify-between text-xs text-white/20 mt-1"><span>1</span><span>20</span></div>
            </div>
            <button onClick={start} className="w-full py-4 btn-blue rounded-2xl">Start Game</button>
          </>
        )}
        {active&&!over&&<button onClick={cashout} className="w-full py-4 btn-green rounded-2xl animate-pulse">Cash Out {(parseFloat(betAmt)*multi).toFixed(3)} TON</button>}
        {over&&<button onClick={()=>{setOver(false);setActive(false);}} className="w-full py-4 btn-blue rounded-2xl">Play Again</button>}
      </div>
    </div>
  );
}

// ── CASES PAGE ─────────────────────────────────────────────────────────────────
export function CasesPage() {
  const [cases,setCases] = useState([]);
  const [opening,setOpening] = useState(false);
  const [result,setResult] = useState(null);
  const [promoCode,setPromoCode] = useState("");
  const [promoResult,setPromoResult] = useState(null);
  const [promoLoading,setPromoLoading] = useState(false);
  const [tab,setTab] = useState("cases");
  const {fetchUser,fetchInventory} = useStore();
  const {search} = useLocation();

  useEffect(()=>{
    api.get("/cases/").then(r=>setCases(r.data));
    if(search.includes("promo=1")) setTab("promo");
    if(search.includes("daily=1")) setTab("daily");
  },[]);

  const openCase=async(c,method="ton")=>{
    setOpening(true);setResult(null);
    try{
      const r=await api.post(`/cases/${c.id}/open?payment_method=${method}`);
      await new Promise(res=>setTimeout(res,2000));
      setResult(r.data.gift);await fetchUser();await fetchInventory();
    }catch(e){window.Telegram?.WebApp?.showAlert(e.response?.data?.detail||"Error");}
    setOpening(false);
  };

  const usePromo=async()=>{
    if(!promoCode.trim()) return;
    setPromoLoading(true);
    try{const r=await api.post(`/user/promocode?code=${promoCode}`);setPromoResult(r.data.reward);await fetchUser();await fetchInventory();}
    catch(e){window.Telegram?.WebApp?.showAlert(e.response?.data?.detail||"Invalid code");}
    setPromoLoading(false);
  };

  return(
    <div className="px-4 py-4 space-y-4">
      <h1 className="text-2xl font-black font-display">📦 CASES</h1>
      <div className="flex gap-2">
        {[["cases","🎁 Cases"],["promo","🎫 Promo"],["daily","⚡ Daily"]].map(([id,label])=>(
          <button key={id} onClick={()=>setTab(id)} className={`flex-1 py-2.5 rounded-xl text-sm font-bold border transition-all ${tab===id?"bg-blue-m border-blue-m":"card-elevated border-white/8 text-white/50"}`}>{label}</button>
        ))}
      </div>

      {tab==="promo"&&(
        <div className="card p-4 border-white/5 space-y-3">
          <div className="flex gap-2">
            <input value={promoCode} onChange={e=>setPromoCode(e.target.value.toUpperCase())} placeholder="UTONKS2025" className="flex-1 card-elevated border border-white/10 rounded-xl px-4 py-3 text-white outline-none font-mono tracking-widest uppercase"/>
            <button onClick={usePromo} disabled={promoLoading} className="px-5 btn-blue rounded-xl disabled:opacity-50">{promoLoading?"...":"✓"}</button>
          </div>
          {promoResult&&<div className="bg-green/10 border border-green/25 rounded-xl p-3 text-center"><p className="text-green font-bold">🎉 Bonus received!</p>{promoResult.type==="ton"&&<p className="text-sm text-white/50">+{promoResult.amount} TON</p>}</div>}
        </div>
      )}

      {tab==="daily"&&(
        <div className="card p-6 border-white/5 text-center space-y-4">
          <span className="text-5xl">🎁</span>
          <p className="text-white font-bold text-lg">Daily Case</p>
          <p className="text-white/40 text-sm">Invite 1 friend to unlock daily case</p>
          <button className="w-full py-4 btn-blue rounded-2xl">Open Daily Case</button>
        </div>
      )}

      {tab==="cases"&&(
        <div className="space-y-4">
          {cases.length===0&&<div className="text-center py-12 text-white/20"><p className="text-4xl mb-3">📦</p><p>No cases yet</p><p className="text-sm mt-1">Admin will add cases</p></div>}
          {cases.map((c,i)=>(
            <motion.div key={c.id} initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{delay:i*0.08}} className="card p-4 border-white/5">
              <div className="flex gap-4 mb-4">
                <div className="w-20 h-20 rounded-2xl overflow-hidden bg-d4 flex-shrink-0 border border-white/8">
                  {c.image_url?<img src={c.image_url} className="w-full h-full object-cover"/>:<div className="w-full h-full flex items-center justify-center text-4xl">📦</div>}
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-white text-lg font-display">{c.name}</h3>
                  <div className="flex gap-2 mt-2">
                    {c.price_ton&&<span className="flex items-center gap-1 text-xs bg-ton/20 text-ton px-2 py-1 rounded-lg font-bold"><TonIcon size={11}/>{c.price_ton}</span>}
                    {c.price_stars&&<span className="text-xs bg-gold/20 text-gold px-2 py-1 rounded-lg font-bold">⭐{c.price_stars}</span>}
                  </div>
                </div>
              </div>
              {c.items?.length>0&&(
                <div className="mb-4">
                  <p className="text-white/25 text-xs uppercase tracking-wider mb-2">Possible prizes</p>
                  <div className="grid grid-cols-3 gap-2">
                    {c.items.slice(0,6).map((item,j)=>(
                      <div key={j} className="card-elevated rounded-xl p-2 text-center border border-white/5">
                        <div className="w-12 h-12 mx-auto rounded-lg overflow-hidden mb-1 bg-d5">
                          <GiftMedia imageUrl={item.collection_image} lottieUrl={item.collection_lottie} size="w-12 h-12"/>
                        </div>
                        <p className="text-white text-xs font-medium truncate">{item.collection_name}</p>
                        <p className="text-white/30 text-xs">{item.probability}%</p>
                        <p className="text-white/20 text-xs">{item.floor_price}T</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              <div className="flex gap-2">
                {c.price_ton&&<button onClick={()=>openCase(c,"ton")} disabled={opening} className="flex-1 py-3 btn-blue rounded-xl text-sm disabled:opacity-40">{opening?"Opening...":c.price_ton+" TON"}</button>}
                {c.price_stars&&<button onClick={()=>openCase(c,"stars")} disabled={opening} className="flex-1 py-3 rounded-xl bg-gold/20 border border-gold/35 text-gold font-bold text-sm active:scale-95 disabled:opacity-40">⭐{c.price_stars}</button>}
              </div>
            </motion.div>
          ))}
        </div>
      )}

      <AnimatePresence>
        {(opening||result)&&(
          <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 z-50 bg-black/85 backdrop-blur flex items-center justify-center px-6">
            <motion.div initial={{scale:0.5,opacity:0}} animate={{scale:1,opacity:1}} exit={{scale:0.5,opacity:0}} className="w-full max-w-sm card rounded-3xl p-8 text-center border-white/10 space-y-5">
              {opening&&!result&&(
                <>
                  <motion.div animate={{rotateY:360}} transition={{duration:0.5,repeat:Infinity,ease:"linear"}} className="text-6xl">📦</motion.div>
                  <p className="text-white font-bold text-xl font-display">Opening...</p>
                  <div className="flex gap-1 justify-center">{[0,1,2].map(i=><motion.div key={i} className="w-2 h-2 bg-blue-m rounded-full" animate={{y:[0,-8,0]}} transition={{delay:i*0.15,repeat:Infinity,duration:0.6}}/>)}</div>
                </>
              )}
              {result&&(
                <>
                  <motion.div initial={{scale:0}} animate={{scale:[0,1.15,1]}} transition={{duration:0.5}} className="w-36 h-36 mx-auto rounded-2xl overflow-hidden border-2 border-blue-m/50 glow-blue">
                    <GiftMedia imageUrl={result.collection_image} lottieUrl={result.collection_lottie} size="w-36 h-36"/>
                  </motion.div>
                  <div>
                    <p className="text-grad-gold font-black text-2xl font-display">YOU WON!</p>
                    <p className="text-white font-bold text-xl mt-1">{result.collection_name}</p>
                    <p className="text-white/40 text-sm">{result.floor_price} TON</p>
                    {result.is_locked&&<p className="text-gold text-xs mt-2">🔒 Sell only</p>}
                  </div>
                  <button onClick={()=>setResult(null)} className="w-full py-4 btn-blue rounded-2xl">Awesome! 🎉</button>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── UPGRADE PAGE ───────────────────────────────────────────────────────────────
export function UpgradePage() {
  const {inventory,fetchUser,fetchInventory} = useStore();
  const [selected,setSelected] = useState([]);
  const [extraTon,setExtraTon] = useState("");
  const [result,setResult] = useState(null);
  const [loading,setLoading] = useState(false);
  const total = selected.reduce((s,i)=>s+i.floor_price,0)+parseFloat(extraTon||0);

  const toggle=(item)=>{
    if(item.is_locked) return;
    const e=selected.find(i=>i.id===item.id);
    setSelected(e?selected.filter(i=>i.id!==item.id):[...selected,item]);
  };

  const upgrade=async()=>{
    if(total<0.1) return;
    setLoading(true);setResult(null);
    try{
      const r=await api.post("/upgrade/start",{inventory_ids:selected.map(i=>i.id),extra_ton:parseFloat(extraTon||0)});
      await new Promise(res=>setTimeout(res,2000));
      setResult(r.data);setSelected([]);setExtraTon("");await fetchUser();await fetchInventory();
    }catch(e){window.Telegram?.WebApp?.showAlert(e.response?.data?.detail||"Error");}
    setLoading(false);
  };

  return(
    <div className="px-4 py-4 space-y-4">
      <h1 className="text-2xl font-black font-display">⬆️ UPGRADE</h1>
      <p className="text-white/40 text-sm">Combine gifts + TON → get closest value gift</p>
      <div className="card p-4 border-white/5 space-y-4">
        {selected.length===0?<p className="text-white/20 text-sm text-center py-3">Select gifts below</p>:(
          <div className="flex flex-wrap gap-2">
            {selected.map(item=>(
              <motion.div key={item.id} initial={{scale:0}} animate={{scale:1}} className="relative">
                <div className="w-16 h-16 rounded-xl overflow-hidden bg-d4 border-2 border-blue-m/50">
                  <GiftMedia imageUrl={item.collection_image} lottieUrl={item.collection_lottie} size="w-16 h-16"/>
                </div>
                <button onClick={()=>toggle(item)} className="absolute -top-1 -right-1 w-5 h-5 bg-red rounded-full text-xs flex items-center justify-center">✕</button>
                <p className="text-xs text-white/40 text-center mt-1">{item.floor_price}T</p>
              </motion.div>
            ))}
          </div>
        )}
        <div className="flex items-center gap-2 card-elevated rounded-xl px-3 py-2.5 border border-white/8">
          <TonIcon size={16}/>
          <input type="number" value={extraTon} onChange={e=>setExtraTon(e.target.value)} placeholder="Extra TON (optional)" className="flex-1 bg-transparent text-white outline-none text-sm" min="0"/>
        </div>
        {total>0&&(
          <div className="flex justify-between items-center py-2 border-t border-white/8">
            <span className="text-white/40 text-sm">Total value:</span>
            <span className="text-white font-bold">{total.toFixed(3)} TON</span>
          </div>
        )}
        <button onClick={upgrade} disabled={total<0.1||loading} className="w-full py-4 rounded-xl font-bold bg-gradient-to-r from-purple to-blue-m text-white disabled:opacity-30 active:scale-95">
          {loading?"⏳ Upgrading...":total>0?`⬆️ Upgrade (${total.toFixed(2)} TON)`:"⬆️ Upgrade"}
        </button>
      </div>
      <div>
        <p className="text-white/30 text-xs uppercase tracking-wider mb-3">Your inventory</p>
        {inventory.filter(i=>!i.is_locked).length===0?<p className="text-white/20 text-sm text-center py-6">No available gifts</p>:(
          <div className="grid grid-cols-3 gap-3">
            {inventory.filter(i=>!i.is_locked).map(item=>{
              const sel=selected.find(i=>i.id===item.id);
              return(
                <button key={item.id} onClick={()=>toggle(item)} className={`rounded-2xl p-3 text-center border-2 transition-all active:scale-95 ${sel?"border-blue-m bg-blue-m/15":"border-transparent card"}`}>
                  <div className="w-12 h-12 mx-auto rounded-xl overflow-hidden mb-2 bg-d4">
                    <GiftMedia imageUrl={item.collection_image} lottieUrl={item.collection_lottie} size="w-12 h-12"/>
                  </div>
                  <p className="text-white text-xs font-medium truncate">{item.collection_name}</p>
                  <p className="text-white/40 text-xs">{item.floor_price} TON</p>
                </button>
              );
            })}
          </div>
        )}
      </div>
      <AnimatePresence>
        {result&&(
          <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 z-50 bg-black/85 backdrop-blur flex items-center justify-center px-6">
            <motion.div initial={{scale:0.5}} animate={{scale:1}} exit={{scale:0.5}} className="w-full max-w-sm card rounded-3xl p-8 text-center border-white/10 space-y-4">
              <div className="w-36 h-36 mx-auto rounded-2xl overflow-hidden border-2 border-purple/50 glow-purple">
                <GiftMedia imageUrl={result.gift?.collection_image} lottieUrl={result.gift?.collection_lottie} size="w-36 h-36"/>
              </div>
              <div>
                <p className="text-grad-gold font-black text-2xl font-display">UPGRADED!</p>
                <p className="text-white font-bold text-xl">{result.gift?.collection_name}</p>
                <p className="text-white/40 text-sm">{result.gift?.floor_price} TON</p>
                {result.change>0&&<p className="text-green text-sm mt-1">+{result.change.toFixed(3)} TON returned</p>}
              </div>
              <button onClick={()=>setResult(null)} className="w-full py-4 btn-blue rounded-2xl">Nice! 🚀</button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── ZONE PAGE ──────────────────────────────────────────────────────────────────
export function ZonePage() {
  const {user,fetchUser} = useStore();
  const [zState,setZState] = useState("betting");
  const [sectors,setSectors] = useState([]);
  const [remaining,setRemaining] = useState(30);
  const [betAmt,setBetAmt] = useState("0.1");
  const [winner,setWinner] = useState(null);
  const [spinning,setSpinning] = useState(false);
  const [targetAngle,setTargetAngle] = useState(0);
  const [rotation,setRotation] = useState(0);
  const canvasRef = useRef(null);

  useEffect(()=>{
    const proto=location.protocol==="https:"?"wss:":"ws:";
    const ws=new WebSocket(`${proto}//${location.host}/api/zone/ws`);
    ws.onmessage=e=>{
      const d=JSON.parse(e.data);
      if(d.type==="zone_state"){setZState(d.state);setSectors(d.sectors||[]);}
      if(d.type==="zone_betting"){setZState("betting");setSectors([]);setWinner(null);setSpinning(false);}
      if(d.type==="zone_tick"){setRemaining(d.remaining);setSectors(d.sectors||[]);drawWheel(d.sectors||[]);}
      if(d.type==="zone_bet_placed"){setSectors(d.sectors||[]);drawWheel(d.sectors||[]);}
      if(d.type==="zone_spinning"){setZState("spinning");setSpinning(true);setTargetAngle(d.target_angle);animateSpin(d.target_angle,d.duration);}
      if(d.type==="zone_finished"){setZState("finished");setSpinning(false);setWinner(d);}
    };
    ws.onclose=()=>{};
    return ()=>ws.close();
  },[]);

  const COLORS = ["#3D6EF8","#7B4FE9","#00E676","#FFB800","#FF3D57","#00D4FF","#FF6B00","#E91E8C"];

  const drawWheel=(sects)=>{
    const c=canvasRef.current; if(!c) return;
    const ctx=c.getContext("2d"); const cx=c.width/2,cy=c.height/2,r=cx-10;
    ctx.clearRect(0,0,c.width,c.height);
    if(sects.length===0){
      ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.fillStyle="#1C1740";ctx.fill();
      ctx.fillStyle="rgba(255,255,255,0.2)";ctx.font="14px Inter";ctx.textAlign="center";ctx.fillText("Place bets!",cx,cy);
      return;
    }
    sects.forEach((s,i)=>{
      const start=(s.start_angle-90)*Math.PI/180;
      const end=(s.end_angle-90)*Math.PI/180;
      ctx.beginPath();ctx.moveTo(cx,cy);ctx.arc(cx,cy,r,start,end);ctx.closePath();
      ctx.fillStyle=COLORS[i%COLORS.length];ctx.fill();
      ctx.strokeStyle="#08060F";ctx.lineWidth=2;ctx.stroke();
      const mid=((s.start_angle+s.end_angle)/2-90)*Math.PI/180;
      const tx=cx+Math.cos(mid)*r*0.65,ty=cy+Math.sin(mid)*r*0.65;
      ctx.fillStyle="#fff";ctx.font="bold 11px Inter";ctx.textAlign="center";
      ctx.fillText(s.username?.slice(0,8)||"",tx,ty-6);
      ctx.font="10px Inter";ctx.fillStyle="rgba(255,255,255,0.7)";
      ctx.fillText(s.percent.toFixed(0)+"%",tx,ty+8);
    });
    ctx.beginPath();ctx.arc(cx,cy,18,0,Math.PI*2);ctx.fillStyle="#08060F";ctx.fill();
    ctx.beginPath();ctx.moveTo(cx,cy-r+5);ctx.lineTo(cx-8,cy-r+22);ctx.lineTo(cx+8,cy-r+22);ctx.closePath();ctx.fillStyle="#FFB800";ctx.fill();
  };

  const animateSpin=(target,duration)=>{
    const start=Date.now();const startRot=rotation;
    const totalRot=360*5+(target-startRot%360+360)%360;
    const animate=()=>{
      const elapsed=Date.now()-start;const progress=Math.min(elapsed/duration,1);
      const ease=1-Math.pow(1-progress,4);
      const currentRot=startRot+totalRot*ease;
      setRotation(currentRot);
      const c=canvasRef.current;
      if(c){const ctx=c.getContext("2d");ctx.clearRect(0,0,c.width,c.height);ctx.save();ctx.translate(c.width/2,c.height/2);ctx.rotate(currentRot*Math.PI/180);ctx.translate(-c.width/2,-c.height/2);drawWheel(sectors);ctx.restore();}
      if(progress<1) requestAnimationFrame(animate);
    };
    requestAnimationFrame(animate);
  };

  const placeBet=async()=>{
    if(zState!=="betting") return;
    try{await api.post(`/zone/bet?amount=${betAmt}`);await fetchUser();}
    catch(e){window.Telegram?.WebApp?.showAlert(e.response?.data?.detail||"Error");}
  };

  const totalPot=sectors.reduce((s,sec)=>s+sec.amount,0);
  const mySlice=sectors.find(s=>s.user_id===String(user?.id));

  return(
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-black font-display">🎯 ZONE</h1>
        {zState==="betting"&&<div className="bg-gold/20 border border-gold/30 rounded-xl px-3 py-1"><span className="text-gold font-bold">{remaining}s</span></div>}
      </div>
      <div className="card p-4 border-white/5 flex flex-col items-center gap-3">
        <canvas ref={canvasRef} width={280} height={280} className="rounded-full"/>
        {zState==="finished"&&winner&&(
          <motion.div initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} className={`w-full rounded-2xl p-4 text-center border ${!winner.is_fake_winner?"bg-green/10 border-green/25":"bg-blue-m/10 border-blue-m/25"}`}>
            <p className="font-bold text-lg">🏆 {winner.winner_username} won!</p>
            <p className="text-white/60 text-sm">{winner.payout?.toFixed(3)} TON from {winner.total_pot?.toFixed(3)} TON pot</p>
          </motion.div>
        )}
        <div className="grid grid-cols-3 gap-3 w-full">
          <div className="card-elevated rounded-xl p-2.5 text-center border border-white/5">
            <p className="text-white/40 text-xs">Pot</p>
            <p className="text-white font-bold">{totalPot.toFixed(2)}</p>
          </div>
          <div className="card-elevated rounded-xl p-2.5 text-center border border-white/5">
            <p className="text-white/40 text-xs">Players</p>
            <p className="text-white font-bold">{sectors.length}</p>
          </div>
          <div className="card-elevated rounded-xl p-2.5 text-center border border-white/5">
            <p className="text-white/40 text-xs">My chance</p>
            <p className="text-white font-bold">{mySlice?.percent?.toFixed(1)||0}%</p>
          </div>
        </div>
      </div>
      {zState==="betting"&&(
        <div className="card p-4 border-white/5 space-y-3">
          <div className="flex items-center gap-2 card-elevated rounded-xl px-3 py-2.5 border border-white/8">
            <TonIcon size={16}/>
            <input type="number" value={betAmt} onChange={e=>setBetAmt(e.target.value)} className="flex-1 bg-transparent text-white outline-none text-sm" min="0.01" step="0.1"/>
          </div>
          <div className="flex gap-2">
            {["0.1","0.5","1","5","10"].map(q=>(
              <button key={q} onClick={()=>setBetAmt(q)} className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition-all ${betAmt===q?"bg-blue-m border-blue-m":"card-elevated border-white/10 text-white/50"}`}>{q}</button>
            ))}
          </div>
          <button onClick={placeBet} className="w-full py-4 btn-blue rounded-2xl">Enter Zone 🎯</button>
        </div>
      )}
      {sectors.length>0&&(
        <div className="space-y-2">
          <p className="text-white/30 text-xs uppercase tracking-wider">Current bets</p>
          {sectors.map((s,i)=>(
            <div key={i} className="flex items-center justify-between card rounded-xl px-3 py-2.5 border-white/5">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{background:COLORS[i%COLORS.length]}}/>
                <span className="text-sm font-medium">{s.username}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-white/40 text-sm">{s.amount.toFixed(2)} TON</span>
                <span className="text-white/30 text-xs">{s.percent.toFixed(1)}%</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── INVENTORY PAGE ─────────────────────────────────────────────────────────────
export function InventoryPage() {
  const {inventory,fetchInventory} = useStore();
  const [sel,setSel] = useState(null);
  const [loading,setLoading] = useState(false);
  const [toast,setToast] = useState(null);
  useEffect(()=>{fetchInventory();},[]);
  const showToast=(msg,type="ok")=>{setToast({msg,type});setTimeout(()=>setToast(null),3000);};

  const sell=async(item)=>{
    setLoading(true);
    try{const r=await api.post(`/inventory/${item.id}/sell`);showToast(`✅ Sold: +${r.data.amount.toFixed(3)} TON`);setSel(null);await fetchInventory();}
    catch(e){showToast(e.response?.data?.detail||"Error","err");}
    setLoading(false);
  };
  const withdraw=async(item)=>{
    setLoading(true);
    try{await api.post(`/inventory/${item.id}/withdraw`);showToast("⏳ Gift is being sent...");setSel(null);await fetchInventory();}
    catch(e){showToast(e.response?.data?.detail||"Error","err");}
    setLoading(false);
  };

  function Timer({target}){
    const [left,setLeft]=useState("");
    useEffect(()=>{
      const calc=()=>{const d=new Date(target)-new Date();if(d<=0){setLeft("");return;}const h=Math.floor(d/3600000),m=Math.floor((d%3600000)/60000),s=Math.floor((d%60000)/1000);setLeft(`${h}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`);};
      calc();const t=setInterval(calc,1000);return()=>clearInterval(t);
    },[target]);
    if(!left) return null;
    return <p className="text-gold text-xs mt-1">{left}</p>;
  }

  return(
    <div className="px-4 py-4">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-black font-display">🎒 INVENTORY</h1>
        <span className="text-white/30 text-sm">{inventory.length} items</span>
      </div>
      {inventory.length===0?(
        <div className="text-center py-20"><p className="text-5xl mb-4">📭</p><p className="text-white/30">Inventory empty</p><p className="text-white/20 text-sm mt-1">Open cases or deposit gifts</p></div>
      ):(
        <div className="grid grid-cols-3 gap-3">
          {inventory.map((item,i)=>(
            <motion.button key={item.id} initial={{opacity:0,scale:0.8}} animate={{opacity:1,scale:1}} transition={{delay:i*0.04}}
              onClick={()=>setSel(item)}
              className="relative card rounded-2xl p-3 text-center border-white/5 active:scale-95 transition-all">
              {item.is_locked&&<div className="absolute top-2 left-2 w-5 h-5 bg-gold rounded-full flex items-center justify-center text-xs">🔒</div>}
              <div className="w-16 h-16 mx-auto rounded-xl overflow-hidden mb-2 bg-d4">
                <GiftMedia imageUrl={item.collection_image} lottieUrl={item.collection_lottie} size="w-16 h-16"/>
              </div>
              <p className="text-white text-xs font-semibold truncate">{item.collection_name}</p>
              <p className="text-white/40 text-xs">{item.floor_price} TON</p>
              {item.withdraw_available_at&&!item.can_withdraw&&<Timer target={item.withdraw_available_at}/>}
            </motion.button>
          ))}
        </div>
      )}
      <AnimatePresence>
        {sel&&(
          <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 z-50 bg-black/75 backdrop-blur flex items-end justify-center" onClick={()=>setSel(null)}>
            <motion.div initial={{y:"100%"}} animate={{y:0}} exit={{y:"100%"}} transition={{type:"spring",damping:28}} className="w-full bg-d2 rounded-t-3xl p-6 pb-10 border-t border-white/10" onClick={e=>e.stopPropagation()}>
              <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-5"/>
              <div className="flex items-center gap-4 mb-5">
                <div className="w-20 h-20 rounded-2xl overflow-hidden bg-d4 flex-shrink-0 border border-white/8">
                  <GiftMedia imageUrl={sel.collection_image} lottieUrl={sel.collection_lottie} size="w-20 h-20"/>
                </div>
                <div>
                  <h3 className="text-white font-bold text-xl">{sel.collection_name}</h3>
                  <p className="text-white/40">{sel.floor_price} TON</p>
                  <span className={`text-xs px-2 py-0.5 rounded-lg mt-1 inline-block font-medium ${sel.source==="deposit"?"bg-green/20 text-green":sel.source==="daily_case"?"bg-gold/20 text-gold":sel.source==="promocode"?"bg-purple/20 text-purple":"bg-blue-m/20 text-blue-l"}`}>{sel.source}</span>
                  {sel.is_locked&&<p className="text-gold text-xs mt-1">🔒 Sell only</p>}
                </div>
              </div>
              <div className="space-y-2">
                <button onClick={()=>sell(sel)} disabled={loading} className="w-full py-4 btn-blue rounded-2xl disabled:opacity-40">
                  💰 Sell ({(sel.floor_price*0.85).toFixed(3)} TON) <span className="text-white/50 text-xs">-15%</span>
                </button>
                {!sel.is_locked&&sel.can_withdraw&&(
                  <button onClick={()=>withdraw(sel)} disabled={loading} className="w-full py-4 card rounded-2xl border border-white/10 font-bold active:scale-95 disabled:opacity-40">📤 Withdraw to Telegram</button>
                )}
                {!sel.is_locked&&!sel.can_withdraw&&(
                  <div className="w-full py-4 card rounded-2xl border border-white/10 text-white/30 text-center text-sm">⏳ Withdraw timer active</div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {toast&&(
          <motion.div initial={{opacity:0,y:50}} animate={{opacity:1,y:0}} exit={{opacity:0,y:50}} className={`fixed bottom-24 left-4 right-4 z-50 py-3 px-4 rounded-2xl text-center font-semibold ${toast.type==="err"?"bg-red/90":"bg-green/90"} text-white`}>{toast.msg}</motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── PROFILE PAGE ───────────────────────────────────────────────────────────────
const LEVELS=[
  {level:1,percent:10,min:0,emoji:"🍪",name:"Beginner"},
  {level:2,percent:12,min:25,emoji:"🐸",name:"Pro"},
  {level:3,percent:14,min:100,emoji:"⌚",name:"Expert"},
  {level:4,percent:18,min:500,emoji:"💎",name:"Legend"},
];

export function ProfilePage() {
  const {user,fetchUser} = useStore();
  const [txs,setTxs] = useState([]);
  const [missions,setMissions] = useState([]);
  const [showLevels,setShowLevels] = useState(false);
  const [showDeposit,setShowDeposit] = useState(false);
  const [tonUI] = useTonConnectUI();
  const wallet = useTonAddress();
  useEffect(()=>{fetchUser();api.get("/user/transactions").then(r=>setTxs(r.data));api.get("/user/missions").then(r=>setMissions(r.data));});
  const copy=()=>{navigator.clipboard.writeText(user?.referral_link||"");window.Telegram?.WebApp?.showAlert("Copied! ✅");};
  const level=LEVELS.find(l=>l.level===(user?.level||1))||LEVELS[0];
  const nextLevel=LEVELS.find(l=>l.level===(user?.level||1)+1);

  const txLabel=(t)=>({deposit_ton:"TON Deposit",deposit_stars:"Stars Deposit",deposit_gift:"Gift Deposit",withdraw_gift:"Gift Withdraw",sell_gift:"Gift Sold",bet_win:"Game Win",bet_lose:"Game Bet",zone_win:"Zone Win",zone_bet:"Zone Bet",referral_bonus:"Referral Bonus",case_open:"Case Opened",upgrade:"Upgrade",promocode:"Promocode",mission_reward:"Mission Reward"}[t]||t);

  const completeMission=async(mid)=>{
    try{await api.post(`/user/missions/${mid}/complete`);fetchUser();api.get("/user/missions").then(r=>setMissions(r.data));}
    catch(e){window.Telegram?.WebApp?.showAlert(e.response?.data?.detail||"Error");}
  };

  return(
    <div className="px-4 py-4 space-y-4">
      <div className="card rounded-3xl p-5 border-white/5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Avatar url={user?.photo_url} name={user?.first_name} size="w-16 h-16" textSize="text-2xl"/>
              <div className="absolute -bottom-1 -right-1 bg-d1 rounded-lg px-1.5 py-0.5 text-sm border border-white/10">{level.emoji}</div>
            </div>
            <div>
              <p className="text-white font-bold text-xl">{user?.first_name}</p>
              <p className="text-white/40 text-sm">Level {user?.level} · {level.name}</p>
            </div>
          </div>
          <button onClick={()=>tonUI.openModal()} className="card-elevated rounded-xl px-3 py-2 border border-white/8 text-xs font-mono text-white/50 active:scale-95 max-w-[120px] truncate">
            {wallet?`${wallet.slice(0,6)}...${wallet.slice(-4)}`:"Connect Wallet"}
          </button>
        </div>
        <button onClick={()=>setShowDeposit(true)} className="w-full py-4 btn-blue rounded-2xl text-lg flex items-center justify-center gap-2">↑ Deposit</button>
      </div>

      {missions.length>0&&(
        <div className="card rounded-3xl p-5 border-white/5 space-y-3">
          <h2 className="text-white font-bold">🎯 Missions</h2>
          {missions.map(m=>(
            <div key={m.id} className={`card-elevated rounded-2xl p-4 border ${m.completed?"border-green/25":"border-white/5"}`}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <p className="text-white font-semibold">{m.title}</p>
                  <p className="text-white/40 text-xs mt-1">{m.description}</p>
                  {m.reward_ton&&<p className="text-green text-xs mt-1">+{m.reward_ton} TON</p>}
                </div>
                {m.completed?(
                  <span className="text-green text-xl flex-shrink-0">✅</span>
                ):(
                  <button onClick={()=>completeMission(m.id)} className="px-3 py-1.5 bg-blue-m rounded-lg text-white text-xs font-bold flex-shrink-0 active:scale-95">Claim</button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="card rounded-3xl p-5 border-white/5 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-white font-bold text-lg">Referrals</h2>
          <button onClick={()=>setShowLevels(!showLevels)} className="text-blue-l text-sm active:scale-95">Levels →</button>
        </div>
        <div className="card-elevated rounded-2xl p-4 flex items-center justify-between border border-white/5">
          <div>
            <p className="text-white font-black text-2xl font-display">Level {user?.level}</p>
            <p className="text-white/40 text-sm">{level.percent}% from net income</p>
            {nextLevel&&<p className="text-white/25 text-xs mt-1">Next: {nextLevel.min} TON deposits</p>}
          </div>
          <span className="text-5xl">{level.emoji}</span>
        </div>
        {showLevels&&(
          <div className="space-y-2">
            {LEVELS.map(l=>(
              <div key={l.level} className={`rounded-2xl p-3 flex items-center justify-between border ${l.level===(user?.level||1)?"bg-blue-m/10 border-blue-m/30":"card-elevated border-white/5"}`}>
                <div><p className="text-white font-bold">Level {l.level} · {l.name}</p><p className="text-white/40 text-xs">{l.percent}% · from {l.min} TON</p></div>
                <span className="text-3xl">{l.emoji}</span>
              </div>
            ))}
          </div>
        )}
        <div className="grid grid-cols-3 gap-2">
          {[["👥",user?.referral_count||0,"Friends"],["💎",(user?.total_referral_deposits||0).toFixed(1)+" T","Deposited"],["💰",(user?.referral_earnings||0).toFixed(2)+" T","Earned"]].map(([icon,val,label])=>(
            <div key={label} className="card-elevated rounded-2xl p-3 text-center border border-white/5">
              <span className="text-2xl">{icon}</span><p className="text-white font-bold text-sm mt-1">{val}</p><p className="text-white/30 text-xs">{label}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="card rounded-3xl p-5 border-white/5 space-y-3">
        <h2 className="text-white font-bold">Referral link</h2>
        <button onClick={copy} className="w-full card-elevated rounded-2xl px-4 py-3 flex items-center justify-between border border-white/8 active:scale-95">
          <span className="text-white/50 text-sm font-mono truncate">{user?.referral_link||"..."}</span>
          <span className="text-white/30 ml-2 flex-shrink-0">📋</span>
        </button>
        <div className="grid grid-cols-2 gap-3">
          {[["Available",(user?.referral_earnings||0).toFixed(2)],["Total earned",(user?.referral_earnings||0).toFixed(2)]].map(([l,v])=>(
            <div key={l} className="card-elevated rounded-2xl p-3 text-center border border-white/5"><p className="text-white/30 text-xs mb-1">{l}</p><p className="text-white font-bold">{v} TON</p></div>
          ))}
        </div>
        <p className="text-white/20 text-xs text-center">Balance updates once a day</p>
      </div>

      <div className="card rounded-3xl p-5 border-white/5 space-y-3">
        <h2 className="text-white font-bold">Transaction history</h2>
        {txs.length===0?<p className="text-white/20 text-sm text-center py-4">No transactions yet</p>:(
          <div className="space-y-2">
            {txs.map(tx=>(
              <div key={tx.id} className="flex items-center justify-between card-elevated rounded-2xl px-4 py-3 border border-white/5">
                <div><p className="text-white text-sm font-medium">{txLabel(tx.type)}</p><p className="text-white/30 text-xs">{new Date(tx.created_at).toLocaleString()}</p></div>
                <div className="flex items-center gap-1.5">
                  <span className={`font-bold text-sm ${tx.amount>=0?"text-green":"text-red"}`}>{tx.amount>=0?"+":""}{tx.amount.toFixed(3)}</span>
                  <TonIcon size={14}/>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showDeposit&&<DepositModal onClose={()=>setShowDeposit(false)}/>}
    </div>
  );
}

// ── ADMIN PAGE ─────────────────────────────────────────────────────────────────
function AdminLogin({onSuccess}){
  const [pw,setPw]=useState("");const [err,setErr]=useState(false);const [loading,setLoading]=useState(false);
  const submit=async()=>{setLoading(true);setErr(false);try{await api.post(`/admin/auth?password=${pw}`);onSuccess();}catch{setErr(true);}setLoading(false);};
  return(
    <div className="min-h-screen flex items-center justify-center px-6 bg-d1">
      <motion.div initial={{opacity:0,y:30}} animate={{opacity:1,y:0}} className="w-full max-w-sm card rounded-3xl p-8 border-white/10 space-y-5">
        <div className="text-center"><span className="text-5xl">🛡️</span><h2 className="text-2xl font-black font-display mt-3 text-grad-gold">ADMIN PANEL</h2><p className="text-white/40 text-sm mt-1">Enter admin password</p></div>
        <div className={`flex items-center gap-3 card-elevated rounded-2xl px-4 py-3 border ${err?"border-red":"border-white/10"}`}>
          <span>🔑</span>
          <input type="password" value={pw} onChange={e=>setPw(e.target.value)} onKeyDown={e=>e.key==="Enter"&&submit()} placeholder="Password" className="flex-1 bg-transparent text-white outline-none"/>
        </div>
        {err&&<p className="text-red text-sm text-center">❌ Wrong password</p>}
        <button onClick={submit} disabled={loading||!pw} className="w-full py-4 rounded-2xl bg-gold text-black font-bold text-lg active:scale-95 disabled:opacity-40 glow-gold">{loading?"Checking...":"Enter Admin Panel"}</button>
      </motion.div>
    </div>
  );
}

function AdminHome(){
  const navigate=useNavigate();const [stats,setStats]=useState(null);
  useEffect(()=>{api.get("/admin/stats").then(r=>setStats(r.data));},[]);
  const menu=[
    {label:"📦 Cases",sub:"Manage game cases",path:"/admin/cases"},
    {label:"🎁 Collections",sub:"Add & manage gift collections",path:"/admin/collections"},
    {label:"📤 Withdrawals",sub:`${stats?.pending_withdrawals||0} pending`,path:"/admin/withdrawals",badge:stats?.pending_withdrawals},
    {label:"👥 Users",sub:`${stats?.total_users||0} registered`,path:"/admin/users"},
    {label:"🤖 Fake Bots",sub:"Manipulation bots",path:"/admin/fakebots"},
    {label:"🎯 Missions",sub:"Tasks & rewards",path:"/admin/missions"},
    {label:"🎫 Promocodes",sub:"Create promo codes",path:"/admin/promocodes"},
    {label:"⚙️ Settings",sub:"Platform settings",path:"/admin/settings"},
  ];
  return(
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center justify-between"><h1 className="text-2xl font-black font-display text-grad-gold">ADMIN</h1><span className="text-2xl">⚙️</span></div>
      {stats&&(
        <div className="grid grid-cols-2 gap-3">
          {[["👥",stats.total_users,"Users"],["💰",stats.total_deposited?.toFixed(1)+" TON","Deposited"],["📤",stats.pending_withdrawals,"Pending"],["📈",stats.total_profit?.toFixed(1)+" TON","Profit"]].map(([icon,val,label])=>(
            <div key={label} className="card rounded-2xl p-4 border-white/5"><span className="text-2xl">{icon}</span><p className="text-white font-bold text-xl mt-1">{val}</p><p className="text-white/40 text-xs">{label}</p></div>
          ))}
        </div>
      )}
      <div className="space-y-2">
        {menu.map(item=>(
          <button key={item.path} onClick={()=>navigate(item.path)} className="w-full card rounded-2xl px-4 py-4 flex items-center justify-between border-white/5 active:scale-98 transition-all">
            <div className="text-left"><p className="text-white font-semibold">{item.label}</p><p className="text-white/40 text-xs mt-0.5">{item.sub}</p></div>
            <div className="flex items-center gap-2">
              {item.badge>0&&<span className="bg-red text-white text-xs font-bold px-2 py-0.5 rounded-full">{item.badge}</span>}
              <span className="text-white/30">→</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function AdminCollections(){
  const navigate=useNavigate();const [cols,setCols]=useState([]);const [form,setForm]=useState({name:"",slug:"",image_url:"",lottie_url:"",floor_price:""});const [show,setShow]=useState(false);
  useEffect(()=>{api.get("/admin/collections").then(r=>setCols(r.data));},[]);
  const save=async()=>{
    try{await api.post("/admin/collections/add",{name:form.name,slug:form.slug||form.name.toLowerCase().replace(/ /g,""),image_url:form.image_url,lottie_url:form.lottie_url,floor_price:parseFloat(form.floor_price)||0});
    window.Telegram?.WebApp?.showAlert("✅ Added!");setShow(false);setForm({name:"",slug:"",image_url:"",lottie_url:"",floor_price:""});api.get("/admin/collections").then(r=>setCols(r.data));}
    catch(e){window.Telegram?.WebApp?.showAlert(e.response?.data?.detail||"Error");}
  };
  return(
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center justify-between"><div className="flex items-center gap-3"><button onClick={()=>navigate("/admin")} className="text-white/50">←</button><h1 className="text-xl font-black font-display">Collections</h1></div><button onClick={()=>setShow(!show)} className="px-4 py-2 btn-blue rounded-xl text-sm">+ Add</button></div>
      {show&&(
        <div className="card p-4 border-white/10 space-y-3">
          <p className="text-white/50 text-xs">Add collection manually (URL from nft.fragment.com)</p>
          {[["name","Collection name","Plush Pepe"],["slug","Slug (auto if empty)","plushpepe"],["image_url","Image URL (.webp)","https://nft.fragment.com/gift/..."],["lottie_url","Lottie URL (.json, optional)",""],["floor_price","Floor price (TON)","5.0"]].map(([key,label,ph])=>(
            <div key={key}><p className="text-white/40 text-xs mb-1">{label}</p><input className="w-full card-elevated rounded-xl px-4 py-2.5 text-white outline-none border border-white/8 text-sm" placeholder={ph} value={form[key]} onChange={e=>setForm({...form,[key]:e.target.value})}/></div>
          ))}
          {form.image_url&&<div className="flex items-center gap-3"><div className="w-16 h-16 rounded-xl overflow-hidden bg-d4"><GiftMedia imageUrl={form.image_url} lottieUrl={form.lottie_url} size="w-16 h-16"/></div><p className="text-white/40 text-xs">Preview</p></div>}
          <div className="flex gap-2"><button onClick={()=>setShow(false)} className="flex-1 py-3 card border border-white/10 rounded-xl text-white/50 font-semibold">Cancel</button><button onClick={save} className="flex-1 py-3 btn-green rounded-xl">Save</button></div>
        </div>
      )}
      <p className="text-white/30 text-xs text-center">{cols.length} collections</p>
      <div className="grid grid-cols-3 gap-3">
        {cols.map(c=>(
          <div key={c.id} className="card rounded-2xl p-3 text-center border-white/5">
            <div className="w-14 h-14 mx-auto rounded-xl overflow-hidden bg-d4 mb-2"><GiftMedia imageUrl={c.image_url} lottieUrl={c.lottie_url} size="w-14 h-14"/></div>
            <p className="text-white text-xs font-medium truncate">{c.name}</p>
            <p className="text-white/40 text-xs">{c.floor_price?.toFixed(2)} TON</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminCases(){
  const navigate=useNavigate();const [cases,setCases]=useState([]);const [cols,setCols]=useState([]);const [show,setShow]=useState(false);
  const [form,setForm]=useState({name:"",image_url:"",price_ton:"",price_stars:"",sort_order:0,items:[]});
  useEffect(()=>{api.get("/admin/cases").then(r=>setCases(r.data));api.get("/admin/collections").then(r=>setCols(r.data));},[]);
  const addItem=(col)=>{if(form.items.find(i=>i.collection_id===col.id))return;setForm({...form,items:[...form.items,{collection_id:col.id,collection_name:col.name,collection_image:col.image_url,collection_lottie:col.lottie_url,probability:10}]});};
  const save=async()=>{
    try{await api.post("/admin/cases",{name:form.name,image_url:form.image_url,price_ton:form.price_ton?parseFloat(form.price_ton):null,price_stars:form.price_stars?parseInt(form.price_stars):null,sort_order:parseInt(form.sort_order),items:form.items.map(i=>({collection_id:i.collection_id,probability:parseFloat(i.probability)}))});
    setShow(false);setForm({name:"",image_url:"",price_ton:"",price_stars:"",sort_order:0,items:[]});api.get("/admin/cases").then(r=>setCases(r.data));}
    catch(e){window.Telegram?.WebApp?.showAlert(e.response?.data?.detail||"Error");}
  };
  const del=async(id)=>{await api.delete(`/admin/cases/${id}`);setCases(cases.filter(c=>c.id!==id));};

  return(
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center justify-between"><div className="flex items-center gap-3"><button onClick={()=>navigate("/admin")} className="text-white/50">←</button><h1 className="text-xl font-black font-display">Cases</h1></div><button onClick={()=>setShow(!show)} className="px-4 py-2 btn-blue rounded-xl text-sm">+ New</button></div>
      {show&&(
        <div className="card p-4 border-white/10 space-y-3">
          <input className="w-full card-elevated rounded-xl px-4 py-3 text-white outline-none border border-white/8" placeholder="Case name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
          <input className="w-full card-elevated rounded-xl px-4 py-3 text-white outline-none border border-white/8 text-sm" placeholder="Image URL" value={form.image_url} onChange={e=>setForm({...form,image_url:e.target.value})}/>
          <div className="grid grid-cols-2 gap-2">
            <input className="card-elevated rounded-xl px-4 py-3 text-white outline-none border border-white/8" type="number" placeholder="Price TON" value={form.price_ton} onChange={e=>setForm({...form,price_ton:e.target.value})}/>
            <input className="card-elevated rounded-xl px-4 py-3 text-white outline-none border border-white/8" type="number" placeholder="Price Stars" value={form.price_stars} onChange={e=>setForm({...form,price_stars:e.target.value})}/>
          </div>
          <p className="text-white/40 text-sm">Select gift collections:</p>
          <div className="grid grid-cols-4 gap-2 max-h-44 overflow-y-auto">
            {cols.map(c=>(
              <button key={c.id} onClick={()=>addItem(c)} className={`rounded-xl p-2 text-center border transition-all active:scale-95 ${form.items.find(i=>i.collection_id===c.id)?"border-blue-m bg-blue-m/20":"border-white/8 card-elevated"}`}>
                <div className="w-10 h-10 mx-auto rounded-lg overflow-hidden bg-d5 mb-1"><GiftMedia imageUrl={c.image_url} lottieUrl={c.lottie_url} size="w-10 h-10"/></div>
                <p className="text-white text-xs truncate">{c.name}</p>
              </button>
            ))}
          </div>
          {form.items.length>0&&(
            <div className="space-y-2">
              <p className="text-white/40 text-sm">Set probabilities (%):</p>
              {form.items.map((item,i)=>(
                <div key={i} className="flex items-center gap-2 card-elevated rounded-xl px-3 py-2 border border-white/8">
                  <div className="w-8 h-8 rounded-lg overflow-hidden flex-shrink-0"><GiftMedia imageUrl={item.collection_image} lottieUrl={item.collection_lottie} size="w-8 h-8"/></div>
                  <p className="text-white text-sm flex-1 truncate">{item.collection_name}</p>
                  <input type="number" value={item.probability} onChange={e=>{const ni=[...form.items];ni[i].probability=e.target.value;setForm({...form,items:ni});}} className="w-14 card rounded-lg px-2 py-1 text-white text-sm outline-none text-center border border-white/10"/>
                  <span className="text-white/30 text-xs">%</span>
                  <button onClick={()=>setForm({...form,items:form.items.filter((_,j)=>j!==i)})} className="text-red text-sm">✕</button>
                </div>
              ))}
            </div>
          )}
          <div className="flex gap-2"><button onClick={()=>setShow(false)} className="flex-1 py-3 card border border-white/10 rounded-xl text-white/50 font-semibold">Cancel</button><button onClick={save} className="flex-1 py-3 btn-green rounded-xl">Save Case</button></div>
        </div>
      )}
      <div className="space-y-3">
        {cases.map(c=>(
          <div key={c.id} className="card rounded-2xl p-4 flex items-center gap-3 border-white/5">
            <div className="w-14 h-14 rounded-xl overflow-hidden bg-d4 flex-shrink-0 border border-white/8">
              {c.image_url?<img src={c.image_url} className="w-full h-full object-cover"/>:<div className="w-full h-full flex items-center justify-center text-2xl">📦</div>}
            </div>
            <div className="flex-1"><p className="text-white font-bold">{c.name}</p><div className="flex gap-2 mt-1">{c.price_ton&&<span className="text-xs bg-ton/20 text-ton px-2 py-0.5 rounded-lg">{c.price_ton} TON</span>}{c.price_stars&&<span className="text-xs bg-gold/20 text-gold px-2 py-0.5 rounded-lg">⭐{c.price_stars}</span>}{!c.is_active&&<span className="text-xs bg-red/20 text-red px-2 py-0.5 rounded-lg">Hidden</span>}</div></div>
            <button onClick={()=>del(c.id)} className="px-3 py-2 bg-red/20 text-red rounded-xl text-sm active:scale-95">🗑</button>
          </div>
        ))}
        {cases.length===0&&<p className="text-white/20 text-center py-8">No cases yet</p>}
      </div>
    </div>
  );
}

function AdminWithdrawals(){
  const navigate=useNavigate();const [list,setList]=useState([]);
  useEffect(()=>{api.get("/admin/withdrawals").then(r=>setList(r.data));},[]);
  const complete=async(id)=>{await api.post(`/admin/withdrawals/${id}/complete_admin`);setList(list.filter(w=>w.id!==id));};
  return(
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center gap-3"><button onClick={()=>navigate("/admin")} className="text-white/50">←</button><h1 className="text-xl font-black font-display">Withdrawals</h1><span className="bg-red/20 text-red text-xs font-bold px-2 py-0.5 rounded-full">{list.length}</span></div>
      {list.length===0?<div className="text-center py-12 text-white/20"><p className="text-4xl mb-3">✅</p><p>No pending withdrawals</p></div>:(
        <div className="space-y-3">
          {list.map(w=>(
            <div key={w.id} className="card rounded-2xl p-4 border-white/5 space-y-3">
              <div className="flex justify-between"><div><p className="text-white font-bold">🎁 {w.collection}</p><p className="text-white/50 text-sm">@{w.username} · {w.user_id}</p><p className="text-white/30 text-xs">{new Date(w.created_at).toLocaleString()}</p></div><span className="text-white/30 text-sm">#{w.id}</span></div>
              <div className="bg-blue-m/10 border border-blue-m/20 rounded-xl px-3 py-2 text-xs text-blue-l">💡 Send <b>{w.collection}</b> to @{w.username} ({w.user_id}) then mark done</div>
              <button onClick={()=>complete(w.id)} className="w-full py-3 btn-green rounded-xl">✅ Gift Sent — Mark Done</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function AdminUsers(){
  const navigate=useNavigate();const [users,setUsers]=useState([]);
  useEffect(()=>{api.get("/admin/users").then(r=>setUsers(r.data));},[]);
  const toggleBan=async(u)=>{await api.post(`/admin/users/${u.id}/ban`);setUsers(users.map(x=>x.id===u.id?{...x,is_banned:!x.is_banned}:x));};
  return(
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center gap-3"><button onClick={()=>navigate("/admin")} className="text-white/50">←</button><h1 className="text-xl font-black font-display">Users ({users.length})</h1></div>
      <div className="space-y-2">
        {users.map(u=>(
          <div key={u.id} className="card rounded-2xl px-4 py-3 flex items-center justify-between border-white/5">
            <div><p className="text-white font-medium">{u.username?`@${u.username}`:u.first_name||`ID:${u.telegram_id}`}</p><p className="text-white/30 text-xs">{u.balance?.toFixed(2)} TON · {new Date(u.created_at).toLocaleDateString()}</p></div>
            <div className="flex items-center gap-2">
              {u.is_admin&&<span className="text-xs bg-gold/20 text-gold px-2 py-0.5 rounded-lg">Admin</span>}
              <button onClick={()=>toggleBan(u)} className={`text-xs px-3 py-1.5 rounded-lg font-semibold active:scale-95 ${u.is_banned?"bg-green/20 text-green":"bg-red/20 text-red"}`}>{u.is_banned?"Unban":"Ban"}</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminFakeBots(){
  const navigate=useNavigate();const [bots,setBots]=useState([]);const [form,setForm]=useState({username:"",avatar_url:""});
  useEffect(()=>{api.get("/admin/fake_bots").then(r=>setBots(r.data));},[]);
  const add=async()=>{await api.post("/admin/fake_bots",form);setForm({username:"",avatar_url:""});api.get("/admin/fake_bots").then(r=>setBots(r.data));};
  const del=async(id)=>{await api.delete(`/admin/fake_bots/${id}`);setBots(bots.filter(b=>b.id!==id));};
  return(
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center gap-3"><button onClick={()=>navigate("/admin")} className="text-white/50">←</button><h1 className="text-xl font-black font-display">Fake Bots</h1></div>
      <div className="card p-4 border-white/10 space-y-3">
        <p className="text-white/50 text-sm">Add fake bot for manipulation</p>
        <input className="w-full card-elevated rounded-xl px-4 py-3 text-white outline-none border border-white/8" placeholder="Username" value={form.username} onChange={e=>setForm({...form,username:e.target.value})}/>
        <input className="w-full card-elevated rounded-xl px-4 py-3 text-white outline-none border border-white/8 text-sm" placeholder="Avatar URL (optional)" value={form.avatar_url} onChange={e=>setForm({...form,avatar_url:e.target.value})}/>
        <button onClick={add} className="w-full py-3 btn-blue rounded-xl">+ Add Bot</button>
      </div>
      <div className="space-y-2">
        {bots.map(b=>(
          <div key={b.id} className="card rounded-2xl px-4 py-3 flex items-center justify-between border-white/5">
            <div className="flex items-center gap-2">
              <Avatar url={b.avatar_url} name={b.username} size="w-8 h-8" textSize="text-xs"/>
              <p className="text-white font-medium">{b.username}</p>
            </div>
            <button onClick={()=>del(b.id)} className="px-3 py-1.5 bg-red/20 text-red rounded-lg text-sm active:scale-95">Remove</button>
          </div>
        ))}
        {bots.length===0&&<p className="text-white/20 text-center py-6">No fake bots. System uses defaults.</p>}
      </div>
    </div>
  );
}

function AdminMissions(){
  const navigate=useNavigate();const [missions,setMissions]=useState([]);const [form,setForm]=useState({title:"",description:"",type:"subscribe_channel",target_value:"",reward_ton:""});
  useEffect(()=>{api.get("/admin/missions").then(r=>setMissions(r.data));},[]);
  const create=async()=>{await api.post("/admin/missions",{...form,reward_ton:parseFloat(form.reward_ton)||null});setForm({title:"",description:"",type:"subscribe_channel",target_value:"",reward_ton:""});api.get("/admin/missions").then(r=>setMissions(r.data));};
  const del=async(id)=>{await api.delete(`/admin/missions/${id}`);setMissions(missions.filter(m=>m.id!==id));};
  return(
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center gap-3"><button onClick={()=>navigate("/admin")} className="text-white/50">←</button><h1 className="text-xl font-black font-display">Missions</h1></div>
      <div className="card p-4 border-white/10 space-y-3">
        <input className="w-full card-elevated rounded-xl px-4 py-3 text-white outline-none border border-white/8" placeholder="Mission title" value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/>
        <input className="w-full card-elevated rounded-xl px-4 py-3 text-white outline-none border border-white/8" placeholder="Description" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/>
        <select className="w-full card-elevated rounded-xl px-4 py-3 text-white outline-none border border-white/8" value={form.type} onChange={e=>setForm({...form,type:e.target.value})}>
          <option value="subscribe_channel">Subscribe to channel</option>
          <option value="invite_friends">Invite friends</option>
          <option value="make_deposit">Make deposit</option>
        </select>
        <input className="w-full card-elevated rounded-xl px-4 py-3 text-white outline-none border border-white/8" placeholder="Target (e.g. @channel or count)" value={form.target_value} onChange={e=>setForm({...form,target_value:e.target.value})}/>
        <input className="w-full card-elevated rounded-xl px-4 py-3 text-white outline-none border border-white/8" type="number" placeholder="Reward TON" value={form.reward_ton} onChange={e=>setForm({...form,reward_ton:e.target.value})}/>
        <button onClick={create} className="w-full py-3 btn-blue rounded-xl">+ Create Mission</button>
      </div>
      <div className="space-y-2">
        {missions.map(m=>(
          <div key={m.id} className="card rounded-2xl p-4 border-white/5">
            <div className="flex justify-between items-start">
              <div><p className="text-white font-semibold">{m.title}</p><p className="text-white/40 text-xs mt-1">{m.description}</p>{m.reward_ton&&<p className="text-green text-xs mt-1">+{m.reward_ton} TON</p>}</div>
              <button onClick={()=>del(m.id)} className="px-2 py-1 bg-red/20 text-red rounded-lg text-xs">Del</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminPromocodes(){
  const navigate=useNavigate();const [cols,setCols]=useState([]);const [promos,setPromos]=useState([]);
  const [form,setForm]=useState({code:"",reward_type:"ton",reward_ton:"",reward_collection_id:"",max_uses:"1"});
  useEffect(()=>{api.get("/admin/collections").then(r=>setCols(r.data));api.get("/admin/promocodes").then(r=>setPromos(r.data));},[]);
  const create=async()=>{
    try{await api.post("/admin/promocodes",{code:form.code.toUpperCase(),reward_type:form.reward_type,reward_ton:form.reward_ton?parseFloat(form.reward_ton):null,reward_collection_id:form.reward_collection_id?parseInt(form.reward_collection_id):null,max_uses:parseInt(form.max_uses)});
    window.Telegram?.WebApp?.showAlert("✅ Created!");setForm({code:"",reward_type:"ton",reward_ton:"",reward_collection_id:"",max_uses:"1"});api.get("/admin/promocodes").then(r=>setPromos(r.data));}
    catch(e){window.Telegram?.WebApp?.showAlert(e.response?.data?.detail||"Error");}
  };
  return(
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center gap-3"><button onClick={()=>navigate("/admin")} className="text-white/50">←</button><h1 className="text-xl font-black font-display">Promocodes</h1></div>
      <div className="card p-4 border-white/10 space-y-3">
        <input className="w-full card-elevated rounded-xl px-4 py-3 text-white outline-none border border-white/8 font-mono uppercase tracking-widest" placeholder="UTONKS2025" value={form.code} onChange={e=>setForm({...form,code:e.target.value})}/>
        <div className="grid grid-cols-2 gap-2">
          {[["ton","💎 TON"],["gift","🎁 Gift"]].map(([id,label])=>(
            <button key={id} onClick={()=>setForm({...form,reward_type:id})} className={`py-3 rounded-xl text-sm font-bold border transition-all ${form.reward_type===id?"bg-blue-m border-blue-m":"card-elevated border-white/8 text-white/50"}`}>{label}</button>
          ))}
        </div>
        {form.reward_type==="ton"&&<input className="w-full card-elevated rounded-xl px-4 py-3 text-white outline-none border border-white/8" type="number" placeholder="TON amount" value={form.reward_ton} onChange={e=>setForm({...form,reward_ton:e.target.value})}/>}
        {form.reward_type==="gift"&&<select className="w-full card-elevated rounded-xl px-4 py-3 text-white outline-none border border-white/8" value={form.reward_collection_id} onChange={e=>setForm({...form,reward_collection_id:e.target.value})}><option value="">Select collection</option>{cols.map(c=><option key={c.id} value={c.id}>{c.name} ({c.floor_price?.toFixed(2)} TON)</option>)}</select>}
        <div className="flex items-center gap-2"><span className="text-white/40 text-sm">Max uses:</span><input className="flex-1 card-elevated rounded-xl px-4 py-2 text-white outline-none border border-white/8" type="number" value={form.max_uses} onChange={e=>setForm({...form,max_uses:e.target.value})}/></div>
        <button onClick={create} className="w-full py-4 btn-blue rounded-xl">Create Promocode</button>
      </div>
      <div className="space-y-2">
        {promos.map(p=>(
          <div key={p.id} className="card rounded-2xl px-4 py-3 border-white/5 flex items-center justify-between">
            <div><p className="text-white font-mono font-bold">{p.code}</p><p className="text-white/40 text-xs">{p.reward_type==="ton"?`+${p.reward_ton} TON`:"Gift"} · {p.used_count}/{p.max_uses} used</p></div>
            <span className={`text-xs px-2 py-1 rounded-lg ${p.is_active?"bg-green/20 text-green":"bg-red/20 text-red"}`}>{p.is_active?"Active":"Expired"}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminSettings(){
  const navigate=useNavigate();const [settings,setSettings]=useState({});const [loading,setLoading]=useState(false);
  useEffect(()=>{api.get("/admin/settings").then(r=>setSettings(r.data));},[]);
  const save=async()=>{setLoading(true);await api.put("/admin/settings",settings);setLoading(false);window.Telegram?.WebApp?.showAlert("✅ Saved!");};
  const fields=[
    ["stars_to_ton_rate","1 Star = ? TON"],["min_deposit_stars","Min deposit Stars"],["min_deposit_ton","Min deposit TON"],
    ["deposit_bonus_ton_percent","TON deposit bonus %"],["sell_commission_percent","Sell commission %"],
    ["upgrade_commission_percent","Upgrade commission %"],["crash_house_edge","Crash house edge (0-1)"],
    ["mines_house_edge","Mines house edge (0-1)"],["zone_commission_percent","Zone commission %"],
    ["zone_bet_duration","Zone bet duration (sec)"],["fake_online_min","Fake online min"],["fake_online_max","Fake online max"],
    ["platform_ton_wallet","Platform TON wallet"],["admin_password","Admin password"],
  ];
  return(
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center gap-3"><button onClick={()=>navigate("/admin")} className="text-white/50">←</button><h1 className="text-xl font-black font-display">Settings</h1></div>
      <div className="space-y-3">
        {fields.map(([key,label])=>(
          <div key={key} className="card rounded-2xl p-4 border-white/5">
            <label className="text-white/40 text-xs uppercase tracking-wider mb-2 block">{label}</label>
            <input type={key.includes("password")?"password":"text"} value={settings[key]||""} onChange={e=>setSettings({...settings,[key]:e.target.value})} className="w-full card-elevated rounded-xl px-4 py-2.5 text-white outline-none border border-white/8 text-sm"/>
          </div>
        ))}
      </div>
      <button onClick={save} disabled={loading} className="w-full py-4 btn-blue rounded-2xl disabled:opacity-40">
        {loading?"Saving...":"💾 Save Settings"}
      </button>
    </div>
  );
}

export function AdminPage(){
  const {adminVerified,setAdminVerified} = useStore();
  if(!adminVerified) return <AdminLogin onSuccess={()=>setAdminVerified(true)}/>;
  return(
    <Routes>
      <Route path="/" element={<AdminHome/>}/>
      <Route path="/cases" element={<AdminCases/>}/>
      <Route path="/collections" element={<AdminCollections/>}/>
      <Route path="/withdrawals" element={<AdminWithdrawals/>}/>
      <Route path="/users" element={<AdminUsers/>}/>
      <Route path="/fakebots" element={<AdminFakeBots/>}/>
      <Route path="/missions" element={<AdminMissions/>}/>
      <Route path="/promocodes" element={<AdminPromocodes/>}/>
      <Route path="/settings" element={<AdminSettings/>}/>
    </Routes>
  );
}
