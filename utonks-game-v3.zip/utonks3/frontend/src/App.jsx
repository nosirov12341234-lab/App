import { useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { TonConnectUIProvider } from "@tonconnect/ui-react";
import { useStore } from "./utils/store";
import { Header, BottomNav } from "./components/ui/Layout";
import {
  GamesPage, CrashPage, MinesPage, CasesPage,
  UpgradePage, ZonePage, InventoryPage, ProfilePage, AdminPage
} from "./pages/AllPages";

const MANIFEST_URL = "/tonconnect-manifest.json";

export default function App() {
  const { fetchUser, fetchInventory, setLoading } = useStore();

  useEffect(() => {
    const tg = window.Telegram?.WebApp;
    if (tg) {
      tg.ready();
      tg.expand();
      tg.setHeaderColor("#08060F");
      tg.setBackgroundColor("#08060F");
    }
    const init = async () => {
      await fetchUser();
      await fetchInventory();
      setLoading(false);
    };
    init();
  }, []);

  return (
    <TonConnectUIProvider manifestUrl={MANIFEST_URL}>
      <BrowserRouter>
        <div className="flex flex-col min-h-screen bg-d1 text-white">
          <Header />
          <main className="flex-1 pb-24 overflow-y-auto">
            <Routes>
              <Route path="/" element={<Navigate to="/games" replace />} />
              <Route path="/games" element={<GamesPage />} />
              <Route path="/games/crash" element={<CrashPage />} />
              <Route path="/games/mines" element={<MinesPage />} />
              <Route path="/games/cases" element={<CasesPage />} />
              <Route path="/games/upgrade" element={<UpgradePage />} />
              <Route path="/games/zone" element={<ZonePage />} />
              <Route path="/inventory" element={<InventoryPage />} />
              <Route path="/profile" element={<ProfilePage />} />
              <Route path="/admin/*" element={<AdminPage />} />
            </Routes>
          </main>
          <BottomNav />
        </div>
      </BrowserRouter>
    </TonConnectUIProvider>
  );
}
