from sqlalchemy import Column, Integer, BigInteger, String, Float, Boolean, DateTime, ForeignKey, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, unique=True, nullable=False)
    username = Column(String(255))
    first_name = Column(String(255))
    photo_url = Column(String(512))
    balance = Column(Float, default=0.0)
    level = Column(Integer, default=1)
    is_admin = Column(Boolean, default=False)
    is_banned = Column(Boolean, default=False)
    referral_code = Column(String(32), unique=True)
    referred_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    referral_earnings = Column(Float, default=0.0)
    total_referral_deposits = Column(Float, default=0.0)
    last_daily_case = Column(DateTime, nullable=True)
    daily_case_referral_done = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class GiftCollection(Base):
    __tablename__ = "gift_collections"
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    slug = Column(String(255), unique=True)
    image_url = Column(String(512))
    lottie_url = Column(String(512))
    floor_price = Column(Float, default=0.0)
    is_active = Column(Boolean, default=True)
    last_updated = Column(DateTime, default=datetime.utcnow)

class Case(Base):
    __tablename__ = "cases"
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    image_url = Column(String(512))
    price_ton = Column(Float, nullable=True)
    price_stars = Column(Integer, nullable=True)
    is_active = Column(Boolean, default=True)
    is_daily = Column(Boolean, default=False)
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

class CaseItem(Base):
    __tablename__ = "case_items"
    id = Column(Integer, primary_key=True)
    case_id = Column(Integer, ForeignKey("cases.id"))
    collection_id = Column(Integer, ForeignKey("gift_collections.id"))
    probability = Column(Float, nullable=False)

class InventoryItem(Base):
    __tablename__ = "inventory"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    collection_id = Column(Integer, ForeignKey("gift_collections.id"), nullable=True)
    collection_name = Column(String(255))
    collection_image = Column(String(512))
    collection_lottie = Column(String(512))
    floor_price = Column(Float, default=0.0)
    source = Column(String(32), default="case")
    is_locked = Column(Boolean, default=False)
    withdraw_available_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class WithdrawRequest(Base):
    __tablename__ = "withdraw_requests"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    inventory_item_id = Column(Integer, ForeignKey("inventory.id"), nullable=True)
    collection_name = Column(String(255))
    telegram_id = Column(BigInteger)
    username = Column(String(255))
    status = Column(String(32), default="pending")
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)

class Transaction(Base):
    __tablename__ = "transactions"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    type = Column(String(64))
    amount = Column(Float)
    description = Column(String(512))
    created_at = Column(DateTime, default=datetime.utcnow)

class CrashGame(Base):
    __tablename__ = "crash_games"
    id = Column(Integer, primary_key=True)
    crash_point = Column(Float)
    started_at = Column(DateTime, default=datetime.utcnow)
    ended_at = Column(DateTime, nullable=True)

class CrashBet(Base):
    __tablename__ = "crash_bets"
    id = Column(Integer, primary_key=True)
    game_id = Column(Integer, ForeignKey("crash_games.id"))
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    username = Column(String(255))
    avatar_url = Column(String(512))
    amount = Column(Float)
    is_fake = Column(Boolean, default=False)
    cashout_multiplier = Column(Float, nullable=True)
    payout = Column(Float, nullable=True)

# Zone game
class ZoneGame(Base):
    __tablename__ = "zone_games"
    id = Column(Integer, primary_key=True)
    status = Column(String(32), default="betting")
    winner_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    total_pot = Column(Float, default=0.0)
    commission_percent = Column(Float, default=5.0)
    started_at = Column(DateTime, default=datetime.utcnow)
    ended_at = Column(DateTime, nullable=True)

class ZoneBet(Base):
    __tablename__ = "zone_bets"
    id = Column(Integer, primary_key=True)
    game_id = Column(Integer, ForeignKey("zone_games.id"))
    user_id = Column(Integer, ForeignKey("users.id"))
    username = Column(String(255))
    avatar_url = Column(String(512))
    amount = Column(Float)
    is_fake = Column(Boolean, default=False)
    won = Column(Boolean, default=False)

class Settings(Base):
    __tablename__ = "settings"
    id = Column(Integer, primary_key=True)
    key = Column(String(255), unique=True)
    value = Column(Text)

class Promocode(Base):
    __tablename__ = "promocodes"
    id = Column(Integer, primary_key=True)
    code = Column(String(64), unique=True)
    reward_type = Column(String(32))
    reward_collection_id = Column(Integer, ForeignKey("gift_collections.id"), nullable=True)
    reward_ton = Column(Float, nullable=True)
    max_uses = Column(Integer, default=1)
    used_count = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class PromocodeUse(Base):
    __tablename__ = "promocode_uses"
    id = Column(Integer, primary_key=True)
    promocode_id = Column(Integer, ForeignKey("promocodes.id"))
    user_id = Column(Integer, ForeignKey("users.id"))
    used_at = Column(DateTime, default=datetime.utcnow)

# Fake bots for manipulation
class FakeBot(Base):
    __tablename__ = "fake_bots"
    id = Column(Integer, primary_key=True)
    username = Column(String(255))
    avatar_url = Column(String(512))
    is_active = Column(Boolean, default=True)

# Missions
class Mission(Base):
    __tablename__ = "missions"
    id = Column(Integer, primary_key=True)
    title = Column(String(255))
    description = Column(String(512))
    type = Column(String(32))  # subscribe_channel, invite_friends, make_deposit
    target_value = Column(String(255))  # channel username or count
    reward_ton = Column(Float, nullable=True)
    reward_collection_id = Column(Integer, ForeignKey("gift_collections.id"), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class MissionComplete(Base):
    __tablename__ = "mission_completes"
    id = Column(Integer, primary_key=True)
    mission_id = Column(Integer, ForeignKey("missions.id"))
    user_id = Column(Integer, ForeignKey("users.id"))
    completed_at = Column(DateTime, default=datetime.utcnow)
