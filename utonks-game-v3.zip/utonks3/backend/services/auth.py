import hashlib, hmac, json, os, secrets, string
from urllib.parse import unquote
from fastapi import HTTPException, Header, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from models.database import User
from models.db import get_db

BOT_TOKEN = os.getenv("BOT_TOKEN", "")

def verify_init_data(init_data: str) -> dict:
    parsed = {}
    for item in init_data.split("&"):
        if "=" in item:
            k, v = item.split("=", 1)
            parsed[k] = unquote(v)
    hash_val = parsed.pop("hash", "")
    check_str = "\n".join(f"{k}={v}" for k, v in sorted(parsed.items()))
    secret = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    expected = hmac.new(secret, check_str.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, hash_val):
        raise HTTPException(status_code=401, detail="Invalid auth")
    return json.loads(parsed.get("user", "{}"))

async def get_or_create_user(db: AsyncSession, tg_user: dict, ref: str = None) -> User:
    r = await db.execute(select(User).where(User.telegram_id == tg_user["id"]))
    user = r.scalar_one_or_none()
    if not user:
        code = "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8))
        ref_id = None
        if ref:
            rr = await db.execute(select(User).where(User.referral_code == ref))
            referrer = rr.scalar_one_or_none()
            if referrer:
                ref_id = referrer.id
        user = User(
            telegram_id=tg_user["id"],
            username=tg_user.get("username"),
            first_name=tg_user.get("first_name", "User"),
            photo_url=tg_user.get("photo_url"),
            referral_code=code,
            referred_by=ref_id,
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)
    else:
        user.username = tg_user.get("username", user.username)
        user.first_name = tg_user.get("first_name", user.first_name)
        await db.commit()
    return user

async def get_current_user(
    authorization: str = Header(...),
    db: AsyncSession = Depends(get_db)
) -> User:
    if not authorization.startswith("tma "):
        raise HTTPException(status_code=401, detail="Invalid auth")
    tg_user = verify_init_data(authorization[4:])
    user = await get_or_create_user(db, tg_user)
    if user.is_banned:
        raise HTTPException(status_code=403, detail="Banned")
    return user
