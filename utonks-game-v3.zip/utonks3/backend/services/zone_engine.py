import asyncio, random, math
from typing import List, Dict, Optional

class ZoneEngine:
    def __init__(self):
        self.state = "betting"  # betting, spinning, finished
        self.bets: Dict = {}
        self.fake_bets: Dict = {}
        self.connections: List = []
        self.winner = None
        self.ball_angle = 0.0
        self.total_pot = 0.0

    async def broadcast(self, msg: dict):
        dead = []
        for ws in self.connections:
            try:
                await ws.send_json(msg)
            except:
                dead.append(ws)
        for ws in dead:
            if ws in self.connections:
                self.connections.remove(ws)

    def get_sectors(self) -> list:
        """Calculate sectors based on bet amounts"""
        all_bets = {**self.bets, **self.fake_bets}
        total = sum(b["amount"] for b in all_bets.values())
        if total == 0:
            return []
        sectors = []
        angle = 0.0
        for uid, bet in all_bets.items():
            pct = bet["amount"] / total
            sectors.append({
                "user_id": uid,
                "username": bet["username"],
                "avatar_url": bet.get("avatar_url", ""),
                "amount": bet["amount"],
                "percent": round(pct * 100, 2),
                "start_angle": angle,
                "end_angle": angle + pct * 360,
                "is_fake": bet.get("is_fake", False),
            })
            angle += pct * 360
        return sectors

    async def run(self, db_factory, settings_getter):
        while True:
            try:
                await self._game(db_factory, settings_getter)
            except Exception as e:
                print(f"Zone error: {e}")
                await asyncio.sleep(3)

    async def _game(self, db_factory, settings_getter):
        self.state = "betting"
        self.bets = {}
        self.fake_bets = {}
        self.winner = None
        self.total_pot = 0.0
        duration = int(await settings_getter("zone_bet_duration") or 30)

        await self.broadcast({"type": "zone_betting", "duration": duration * 1000})

        # Countdown
        for i in range(duration):
            await asyncio.sleep(1)
            remaining = duration - i - 1
            await self.broadcast({"type": "zone_tick", "remaining": remaining, "sectors": self.get_sectors()})

        # Add fake bets if needed
        real_count = len([b for b in self.bets.values() if not b.get("is_fake")])
        if real_count < 3:
            fake_names = ["Wolf99", "TonKing", "CryptoX", "MoonBoy", "StarWin"]
            for i in range(random.randint(2, 4)):
                amt = round(random.uniform(0.5, 10.0), 2)
                self.fake_bets[f"zfake_{i}"] = {
                    "username": random.choice(fake_names),
                    "avatar_url": "",
                    "amount": amt,
                    "is_fake": True,
                }

        all_bets = {**self.bets, **self.fake_bets}
        self.total_pot = sum(b["amount"] for b in all_bets.values())
        sectors = self.get_sectors()

        if not sectors:
            await asyncio.sleep(3)
            return

        # Spinning
        self.state = "spinning"
        spin_duration = int(await settings_getter("zone_spin_duration") or 8)

        # Pick winner based on probability
        total = sum(b["amount"] for b in all_bets.values())
        rand = random.uniform(0, total)
        cumulative = 0
        winner_uid = None
        winner_bet = None
        for uid, bet in all_bets.items():
            cumulative += bet["amount"]
            if rand <= cumulative:
                winner_uid = uid
                winner_bet = bet
                break

        # Find winning angle (middle of winner's sector)
        winner_sector = next((s for s in sectors if s["user_id"] == winner_uid), sectors[0])
        target_angle = (winner_sector["start_angle"] + winner_sector["end_angle"]) / 2

        await self.broadcast({
            "type": "zone_spinning",
            "sectors": sectors,
            "target_angle": target_angle,
            "duration": spin_duration * 1000,
        })

        await asyncio.sleep(spin_duration)

        # Calculate payout
        commission = float(await settings_getter("zone_commission_percent") or 5) / 100
        payout = round(self.total_pot * (1 - commission), 6)

        self.state = "finished"
        self.winner = winner_bet

        await self.broadcast({
            "type": "zone_finished",
            "winner_username": winner_bet["username"] if winner_bet else "",
            "winner_avatar": winner_bet.get("avatar_url", "") if winner_bet else "",
            "payout": payout,
            "total_pot": self.total_pot,
            "is_fake_winner": winner_bet.get("is_fake", False) if winner_bet else True,
        })

        # Save to DB
        if winner_uid and not winner_bet.get("is_fake"):
            async with db_factory() as db:
                from models.database import User, Transaction
                from sqlalchemy import select
                r = await db.execute(select(User).where(User.id == int(winner_uid)))
                winner_user = r.scalar_one_or_none()
                if winner_user:
                    winner_user.balance += payout
                    db.add(Transaction(
                        user_id=int(winner_uid),
                        type="zone_win",
                        amount=payout,
                        description=f"Zone win! Pot: {self.total_pot} TON"
                    ))
                    await db.commit()

        await asyncio.sleep(5)

    async def place_bet(self, user_id, username, avatar_url, amount) -> bool:
        if self.state != "betting":
            return False
        key = str(user_id)
        if key in self.bets:
            self.bets[key]["amount"] += amount
        else:
            self.bets[key] = {
                "username": username,
                "avatar_url": avatar_url,
                "amount": amount,
                "is_fake": False,
            }
        return True

zone_engine = ZoneEngine()
