import asyncio, os, logging
from aiogram import Bot, Dispatcher, Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram.filters import CommandStart

logging.basicConfig(level=logging.INFO)
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
WEBAPP_URL = os.getenv("WEBAPP_URL", "")
BOT_USERNAME = os.getenv("BOT_USERNAME", "utonks_bot")
LOGO_URL = "https://raw.githubusercontent.com/nosirov12341234-lab/App/main/icon.png"

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()
router = Router()

START_TEXT = """🎮 <b>Utonks Game</b> — TON Gift Gaming Platform!

🚀 <b>CRASH</b> — Fly to the moon, cash out in time!
💣 <b>MINES</b> — Avoid bombs, collect gems!
📦 <b>CASES</b> — Open cases, win Telegram gifts!
⬆️ <b>UPGRADE</b> — Combine gifts for bigger prizes!
🎯 <b>ZONE</b> — Spin the wheel, win the whole pot!

💎 Deposit with <b>TON</b> or <b>⭐ Stars</b>
🎁 Win real <b>Telegram Gifts</b>!
👥 Invite friends — earn <b>10–18%</b> commission!

🔥 <b>Play now and win big!</b>"""

@router.message(CommandStart())
async def start(message: Message):
    args = message.text.split()
    ref = args[1] if len(args) > 1 else None
    url = f"{WEBAPP_URL}?ref={ref}" if ref else WEBAPP_URL
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎮 Play Utonks Game", web_app=WebAppInfo(url=url))],
        [InlineKeyboardButton(text="📢 Channel", url="https://t.me/utonksgame"),
         InlineKeyboardButton(text="💬 Support", url="https://t.me/utonkssupport")]
    ])
    try:
        await message.answer_photo(
            photo=LOGO_URL,
            caption=START_TEXT,
            reply_markup=kb,
            parse_mode="HTML"
        )
    except:
        await message.answer(START_TEXT, reply_markup=kb, parse_mode="HTML")

dp.include_router(router)

async def main():
    logging.info("Utonks bot starting...")
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
