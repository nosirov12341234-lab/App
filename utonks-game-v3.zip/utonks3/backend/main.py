from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import asyncio, sys, os

sys.path.insert(0, os.path.dirname(__file__))

from models.db import init_db, AsyncSessionLocal
from routers.all_routers import (
    user_router, cases_router, inv_router, crash_router,
    mines_router, upgrade_router, zone_router, admin_router
)
from services.crash_engine import crash_engine
from services.zone_engine import zone_engine
from services.settings import get_setting

async def _get(key):
    async with AsyncSessionLocal() as db:
        return await get_setting(db, key)

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    asyncio.create_task(crash_engine.run(AsyncSessionLocal, _get))
    asyncio.create_task(zone_engine.run(AsyncSessionLocal, _get))
    yield

app = FastAPI(title="Utonks Game v3", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

app.include_router(user_router, prefix="/api")
app.include_router(cases_router, prefix="/api")
app.include_router(inv_router, prefix="/api")
app.include_router(crash_router, prefix="/api")
app.include_router(mines_router, prefix="/api")
app.include_router(upgrade_router, prefix="/api")
app.include_router(zone_router, prefix="/api")
app.include_router(admin_router, prefix="/api")

@app.get("/health")
async def health():
    return {"status": "ok", "crash": crash_engine.state, "zone": zone_engine.state}
