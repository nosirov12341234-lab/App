from fastapi import APIRouter, Depends, HTTPException, Header, WebSocket, WebSocketDisconnect
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from models.db import get_db, AsyncSessionLocal
from models.database import *
from services.auth import get_current_user
from services.settings import get_setting, set_setting, get_all_settings
from services.crash_engine import crash_engine
from services.zone_engine import zone_engine
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime, timedelta
import random, json, os, asyncio

# ── USER ──────────────────────────────────────────────────────────────────────
user_router = APIRouter(prefix="/user", tags=["user"])
BOT_USERNAME = os.getenv("BOT_USERNAME", "utonks_bot")

@user_router.get("/me")
async def me(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    ref_count = (await db.execute(select(func.count(User.id)).where(User.referred_by == user.id))).scalar() or 0
    level = 1
    for threshold, lvl in [(500,4),(100,3),(25,2),(0,1)]:
        if user.total_referral_deposits >= threshold:
            level = lvl; break
    percents = {1:10,2:12,3:14,4:18}
    userbot = await get_setting(db, "userbot_username")
    return {
        "id": user.id, "telegram_id": user.telegram_id,
        "username": user.username, "first_name": user.first_name,
        "photo_url": user.photo_url, "balance": user.balance,
        "level": level, "is_admin": user.is_admin,
        "referral_code": user.referral_code,
        "referral_link": f"https://t.me/{BOT_USERNAME}?start={user.referral_code}",
        "referral_count": ref_count,
        "referral_earnings": user.referral_earnings,
        "referral_percent": percents.get(level, 10),
        "total_referral_deposits": user.total_referral_deposits,
        "userbot_username": userbot,
    }

@user_router.get("/transactions")
async def transactions(limit: int = 20, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    r = await db.execute(select(Transaction).where(Transaction.user_id == user.id).order_by(Transaction.created_at.desc()).limit(limit))
    return [{"id": t.id, "type": t.type, "amount": t.amount, "description": t.description, "created_at": t.created_at.isoformat()} for t in r.scalars().all()]

@user_router.post("/deposit/ton")
async def deposit_ton(amount: float, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    min_dep = float(await get_setting(db, "min_deposit_ton"))
    if amount < min_dep:
        raise HTTPException(400, f"Minimum {min_dep} TON")
    wallet = await get_setting(db, "platform_ton_wallet") or os.getenv("PLATFORM_TON_WALLET", "")
    bonus = float(await get_setting(db, "deposit_bonus_ton_percent"))
    return {"wallet": wallet, "amount": amount, "memo": f"utonks_{user.telegram_id}", "bonus_percent": bonus, "bonus_amount": round(amount*bonus/100, 6)}

@user_router.post("/deposit/stars")
async def deposit_stars(stars: int, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    min_s = int(await get_setting(db, "min_deposit_stars"))
    if stars < min_s:
        raise HTTPException(400, f"Minimum {min_s} Stars")
    rate = float(await get_setting(db, "stars_to_ton_rate"))
    return {"stars": stars, "ton_equivalent": round(stars*rate, 6), "rate": rate}

@user_router.post("/promocode")
async def use_promo(code: str, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    r = await db.execute(select(Promocode).where(Promocode.code == code.upper(), Promocode.is_active == True))
    promo = r.scalar_one_or_none()
    if not promo: raise HTTPException(404, "Invalid code")
    if promo.used_count >= promo.max_uses: raise HTTPException(400, "Expired")
    used = await db.execute(select(PromocodeUse).where(PromocodeUse.promocode_id == promo.id, PromocodeUse.user_id == user.id))
    if used.scalar_one_or_none(): raise HTTPException(400, "Already used")
    reward = {}
    if promo.reward_type == "gift" and promo.reward_collection_id:
        cr = await db.execute(select(GiftCollection).where(GiftCollection.id == promo.reward_collection_id))
        col = cr.scalar_one_or_none()
        if col:
            db.add(InventoryItem(user_id=user.id, collection_id=col.id, collection_name=col.name, collection_image=col.image_url, collection_lottie=col.lottie_url, floor_price=col.floor_price, source="promocode", is_locked=True))
            reward = {"type":"gift","collection":col.name,"image":col.image_url,"lottie":col.lottie_url}
    elif promo.reward_type == "ton" and promo.reward_ton:
        user.balance += promo.reward_ton
        db.add(Transaction(user_id=user.id, type="promocode", amount=promo.reward_ton, description=f"Promo: {code}"))
        reward = {"type":"ton","amount":promo.reward_ton}
    promo.used_count += 1
    db.add(PromocodeUse(promocode_id=promo.id, user_id=user.id))
    await db.commit()
    return {"success": True, "reward": reward}

@user_router.get("/missions")
async def get_missions(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    r = await db.execute(select(Mission).where(Mission.is_active == True))
    missions = r.scalars().all()
    completed_r = await db.execute(select(MissionComplete.mission_id).where(MissionComplete.user_id == user.id))
    completed_ids = {row[0] for row in completed_r.all()}
    return [{"id": m.id, "title": m.title, "description": m.description, "type": m.type, "target_value": m.target_value, "reward_ton": m.reward_ton, "completed": m.id in completed_ids} for m in missions]

@user_router.post("/missions/{mid}/complete")
async def complete_mission(mid: int, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    r = await db.execute(select(Mission).where(Mission.id == mid, Mission.is_active == True))
    mission = r.scalar_one_or_none()
    if not mission: raise HTTPException(404, "Not found")
    used = await db.execute(select(MissionComplete).where(MissionComplete.mission_id == mid, MissionComplete.user_id == user.id))
    if used.scalar_one_or_none(): raise HTTPException(400, "Already completed")
    if mission.reward_ton:
        user.balance += mission.reward_ton
        db.add(Transaction(user_id=user.id, type="mission_reward", amount=mission.reward_ton, description=f"Mission: {mission.title}"))
    db.add(MissionComplete(mission_id=mid, user_id=user.id))
    await db.commit()
    return {"success": True, "reward_ton": mission.reward_ton}

# ── CASES ─────────────────────────────────────────────────────────────────────
cases_router = APIRouter(prefix="/cases", tags=["cases"])

@cases_router.get("/")
async def get_cases(db: AsyncSession = Depends(get_db)):
    r = await db.execute(select(Case).where(Case.is_active == True).order_by(Case.sort_order))
    out = []
    for c in r.scalars().all():
        items_r = await db.execute(select(CaseItem, GiftCollection).join(GiftCollection, CaseItem.collection_id == GiftCollection.id).where(CaseItem.case_id == c.id))
        items = items_r.all()
        out.append({"id":c.id,"name":c.name,"image_url":c.image_url,"price_ton":c.price_ton,"price_stars":c.price_stars,"is_daily":c.is_daily,"items":[{"collection_id":col.id,"collection_name":col.name,"collection_image":col.image_url,"collection_lottie":col.lottie_url,"floor_price":col.floor_price,"probability":round(item.probability*100,1)} for item,col in items]})
    return out

@cases_router.post("/{case_id}/open")
async def open_case(case_id: int, payment_method: str = "ton", db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    r = await db.execute(select(Case).where(Case.id == case_id, Case.is_active == True))
    case = r.scalar_one_or_none()
    if not case: raise HTTPException(404, "Not found")
    is_locked = False; tx_amount = 0
    if case.is_daily:
        if not user.daily_case_referral_done: raise HTTPException(400, "Need 1 referral")
        if user.last_daily_case and (datetime.utcnow()-user.last_daily_case).total_seconds() < 86400: raise HTTPException(400, "Already opened today")
        user.last_daily_case = datetime.utcnow(); user.daily_case_referral_done = False; source = "daily_case"; is_locked = True
    else:
        if payment_method == "ton":
            if not case.price_ton: raise HTTPException(400, "TON not available")
            if user.balance < case.price_ton: raise HTTPException(400, "Insufficient balance")
            user.balance -= case.price_ton; tx_amount = -case.price_ton
        elif payment_method == "stars":
            rate = float(await get_setting(db, "stars_to_ton_rate"))
            price = (case.price_stars or 0) * rate
            if user.balance < price: raise HTTPException(400, "Insufficient balance")
            user.balance -= price; tx_amount = -price
        source = "case"
    items_r = await db.execute(select(CaseItem, GiftCollection).join(GiftCollection, CaseItem.collection_id == GiftCollection.id).where(CaseItem.case_id == case_id))
    items = items_r.all()
    if not items: raise HTTPException(400, "Case has no items")
    weights = [item.probability for item, _ in items]
    sel_item, sel_col = random.choices(items, weights=weights, k=1)[0]
    inv = InventoryItem(user_id=user.id, collection_id=sel_col.id, collection_name=sel_col.name, collection_image=sel_col.image_url, collection_lottie=sel_col.lottie_url, floor_price=sel_col.floor_price, source=source, is_locked=is_locked, withdraw_available_at=datetime.utcnow()+timedelta(hours=1) if not is_locked else None)
    db.add(inv)
    if tx_amount != 0: db.add(Transaction(user_id=user.id, type="case_open", amount=tx_amount, description=f"{case.name} → {sel_col.name}"))
    await db.commit(); await db.refresh(inv)
    return {"success":True,"gift":{"id":inv.id,"collection_name":sel_col.name,"collection_image":sel_col.image_url,"collection_lottie":sel_col.lottie_url,"floor_price":sel_col.floor_price,"is_locked":is_locked}}

# ── INVENTORY ─────────────────────────────────────────────────────────────────
inv_router = APIRouter(prefix="/inventory", tags=["inventory"])

@inv_router.get("/")
async def get_inv(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    r = await db.execute(select(InventoryItem).where(InventoryItem.user_id == user.id).order_by(InventoryItem.created_at.desc()))
    now = datetime.utcnow()
    return [{"id":i.id,"collection_name":i.collection_name,"collection_image":i.collection_image,"collection_lottie":i.collection_lottie,"floor_price":i.floor_price,"source":i.source,"is_locked":i.is_locked,"can_withdraw":not i.is_locked and (i.withdraw_available_at is None or i.withdraw_available_at<=now),"can_bet":not i.is_locked,"withdraw_available_at":i.withdraw_available_at.isoformat() if i.withdraw_available_at else None,"created_at":i.created_at.isoformat()} for i in r.scalars().all()]

@inv_router.post("/{item_id}/sell")
async def sell(item_id: int, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    r = await db.execute(select(InventoryItem).where(InventoryItem.id == item_id, InventoryItem.user_id == user.id))
    item = r.scalar_one_or_none()
    if not item: raise HTTPException(404, "Not found")
    commission = float(await get_setting(db, "sell_commission_percent")) / 100
    price = round(item.floor_price*(1-commission), 6)
    user.balance += price
    db.add(Transaction(user_id=user.id, type="sell_gift", amount=price, description=f"Sold: {item.collection_name}"))
    await db.delete(item); await db.commit()
    return {"success":True,"amount":price,"balance":user.balance}

@inv_router.post("/{item_id}/withdraw")
async def withdraw(item_id: int, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    r = await db.execute(select(InventoryItem).where(InventoryItem.id == item_id, InventoryItem.user_id == user.id))
    item = r.scalar_one_or_none()
    if not item: raise HTTPException(404, "Not found")
    if item.is_locked: raise HTTPException(400, "Gift is locked")
    now = datetime.utcnow()
    if item.withdraw_available_at and item.withdraw_available_at > now: raise HTTPException(400, "Not available yet")
    req = WithdrawRequest(user_id=user.id, inventory_item_id=item.id, collection_name=item.collection_name, telegram_id=user.telegram_id, username=user.username or str(user.telegram_id))
    db.add(req); await db.commit(); await db.refresh(req)
    return {"success":True,"withdraw_id":req.id,"message":"⏳ Gift yuborilmoqda..."}

# ── CRASH ─────────────────────────────────────────────────────────────────────
crash_router = APIRouter(prefix="/crash", tags=["crash"])

@crash_router.websocket("/ws")
async def crash_ws(websocket: WebSocket):
    await websocket.accept()
    crash_engine.connections.append(websocket)
    crash_engine.real_online += 1
    await websocket.send_json({"type":"state","game_state":crash_engine.state,"multiplier":crash_engine.multiplier,"history":crash_engine.history[-6:],"online":crash_engine.fake_online()})
    try:
        while True:
            data = await websocket.receive_text()
            if json.loads(data).get("type") == "ping":
                await websocket.send_json({"type":"pong"})
    except WebSocketDisconnect:
        pass
    finally:
        if websocket in crash_engine.connections: crash_engine.connections.remove(websocket)
        crash_engine.real_online = max(0, crash_engine.real_online-1)

@crash_router.post("/bet")
async def crash_bet(amount: float, is_gift: bool = False, inventory_item_id: int = None, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    if crash_engine.state != "betting": raise HTTPException(400, "Betting closed")
    if is_gift and inventory_item_id:
        r = await db.execute(select(InventoryItem).where(InventoryItem.id == inventory_item_id, InventoryItem.user_id == user.id))
        item = r.scalar_one_or_none()
        if not item or item.is_locked: raise HTTPException(400, "Invalid gift")
        amount = item.floor_price
        await db.delete(item); await db.commit()
    else:
        if user.balance < amount or amount < 0.01: raise HTTPException(400, "Invalid amount")
        user.balance -= amount; await db.commit()
    await crash_engine.place_bet(user.id, user.username or user.first_name, user.photo_url or "", amount, is_gift, inventory_item_id)
    return {"success":True,"amount":amount}

@crash_router.post("/cashout")
async def crash_cashout(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    payout = await crash_engine.cashout(user.id)
    if payout is None: raise HTTPException(400, "Cannot cashout")
    user.balance += payout
    db.add(Transaction(user_id=user.id, type="bet_win", amount=payout, description=f"Crash x{crash_engine.multiplier}"))
    await db.commit()
    return {"success":True,"payout":payout,"multiplier":crash_engine.multiplier}

# ── MINES ─────────────────────────────────────────────────────────────────────
mines_router = APIRouter(prefix="/mines", tags=["mines"])
mines_games = {}

@mines_router.post("/start")
async def mines_start(amount: float, mines: int = 3, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    if mines < 1 or mines > 20: raise HTTPException(400, "Mines: 1-20")
    if amount < 0.01 or user.balance < amount: raise HTTPException(400, "Invalid amount")
    user.balance -= amount
    mine_pos = random.sample(range(25), mines)
    gid = f"{user.id}_{random.randint(10000,99999)}"
    mines_games[gid] = {"user_id":user.id,"amount":amount,"mines":mine_pos,"revealed":[],"multiplier":1.0,"active":True}
    db.add(Transaction(user_id=user.id, type="bet_lose", amount=-amount, description="Mines bet"))
    await db.commit()
    return {"game_id":gid}

@mines_router.post("/reveal")
async def mines_reveal(game_id: str, cell: int, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    game = mines_games.get(game_id)
    if not game or game["user_id"] != user.id or not game["active"]: raise HTTPException(400, "Invalid game")
    if cell in game["revealed"]: raise HTTPException(400, "Already revealed")
    if cell in game["mines"]:
        game["active"] = False
        return {"is_mine":True,"all_mines":game["mines"]}
    game["revealed"].append(cell)
    safe = 25 - len(game["mines"])
    house = float(await get_setting(db, "mines_house_edge"))
    n = len(game["revealed"])
    multi = round(((safe/(safe-n+1))*(1-house))**n, 3)
    game["multiplier"] = multi
    return {"is_mine":False,"multiplier":multi}

@mines_router.post("/cashout")
async def mines_cashout(game_id: str, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    game = mines_games.get(game_id)
    if not game or game["user_id"] != user.id or not game["active"]: raise HTTPException(400, "Invalid game")
    if not game["revealed"]: raise HTTPException(400, "Reveal at least 1")
    payout = round(game["amount"]*game["multiplier"], 6)
    game["active"] = False
    user.balance += payout
    db.add(Transaction(user_id=user.id, type="bet_win", amount=payout, description=f"Mines x{game['multiplier']}"))
    await db.commit()
    del mines_games[game_id]
    return {"payout":payout,"multiplier":game["multiplier"]}

# ── UPGRADE ───────────────────────────────────────────────────────────────────
upgrade_router = APIRouter(prefix="/upgrade", tags=["upgrade"])

class UpgradeReq(BaseModel):
    inventory_ids: List[int]
    extra_ton: float = 0.0

@upgrade_router.post("/start")
async def upgrade_start(data: UpgradeReq, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    total = data.extra_ton
    items = []
    for iid in data.inventory_ids:
        r = await db.execute(select(InventoryItem).where(InventoryItem.id == iid, InventoryItem.user_id == user.id))
        item = r.scalar_one_or_none()
        if not item or item.is_locked: raise HTTPException(400, f"Invalid item {iid}")
        total += item.floor_price; items.append(item)
    if total < 0.1: raise HTTPException(400, "Minimum 0.1 TON")
    if data.extra_ton > 0 and user.balance < data.extra_ton: raise HTTPException(400, "Insufficient balance")
    if data.extra_ton > 0: user.balance -= data.extra_ton
    for item in items: await db.delete(item)
    commission = float(await get_setting(db, "upgrade_commission_percent")) / 100
    budget = total * (1 - commission)
    r = await db.execute(select(GiftCollection).where(GiftCollection.is_active == True, GiftCollection.floor_price > 0))
    cols = r.scalars().all()
    if not cols:
        user.balance += budget; await db.commit()
        raise HTTPException(400, "No gifts, refunded")
    best = min(cols, key=lambda c: abs(c.floor_price - budget))
    change = max(round(budget - best.floor_price, 6), 0)
    new_item = InventoryItem(user_id=user.id, collection_id=best.id, collection_name=best.name, collection_image=best.image_url, collection_lottie=best.lottie_url, floor_price=best.floor_price, source="upgrade")
    db.add(new_item)
    if change > 0: user.balance += change
    db.add(Transaction(user_id=user.id, type="upgrade", amount=-total, description=f"Upgrade → {best.name}"))
    await db.commit(); await db.refresh(new_item)
    return {"success":True,"gift":{"id":new_item.id,"collection_name":best.name,"collection_image":best.image_url,"collection_lottie":best.lottie_url,"floor_price":best.floor_price},"change":change}

# ── ZONE ──────────────────────────────────────────────────────────────────────
zone_router = APIRouter(prefix="/zone", tags=["zone"])

@zone_router.websocket("/ws")
async def zone_ws(websocket: WebSocket):
    await websocket.accept()
    zone_engine.connections.append(websocket)
    await websocket.send_json({"type":"zone_state","state":zone_engine.state,"sectors":zone_engine.get_sectors()})
    try:
        while True:
            data = await websocket.receive_text()
            if json.loads(data).get("type") == "ping":
                await websocket.send_json({"type":"pong"})
    except WebSocketDisconnect:
        pass
    finally:
        if websocket in zone_engine.connections: zone_engine.connections.remove(websocket)

@zone_router.post("/bet")
async def zone_bet(amount: float, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    if zone_engine.state != "betting": raise HTTPException(400, "Betting closed")
    if user.balance < amount or amount < 0.01: raise HTTPException(400, "Invalid amount")
    user.balance -= amount
    db.add(Transaction(user_id=user.id, type="zone_bet", amount=-amount, description="Zone bet"))
    await db.commit()
    await zone_engine.place_bet(user.id, user.username or user.first_name, user.photo_url or "", amount)
    await zone_engine.broadcast({"type":"zone_bet_placed","username":user.username or user.first_name,"amount":amount,"sectors":zone_engine.get_sectors()})
    return {"success":True}

# ── ADMIN ─────────────────────────────────────────────────────────────────────
admin_router = APIRouter(prefix="/admin", tags=["admin"])

async def internal_auth(x_internal_key: str = Header(...)):
    if x_internal_key != os.getenv("INTERNAL_KEY", ""):
        raise HTTPException(403, "Forbidden")

async def require_admin(user: User = Depends(get_current_user)):
    if not user.is_admin: raise HTTPException(403, "Admin only")
    return user

class CaseCreate(BaseModel):
    name: str
    image_url: str
    price_ton: Optional[float] = None
    price_stars: Optional[int] = None
    is_daily: bool = False
    sort_order: int = 0
    items: List[dict]

class PromoCreate(BaseModel):
    code: str
    reward_type: str
    reward_collection_id: Optional[int] = None
    reward_ton: Optional[float] = None
    max_uses: int = 1

class MissionCreate(BaseModel):
    title: str
    description: str
    type: str
    target_value: str
    reward_ton: Optional[float] = None

class FakeBotCreate(BaseModel):
    username: str
    avatar_url: str = ""

@admin_router.post("/auth")
async def admin_auth(password: str, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    pw = await get_setting(db, "admin_password")
    if password != pw: raise HTTPException(403, "Wrong password")
    if not user.is_admin: raise HTTPException(403, "Not admin")
    return {"success":True}

@admin_router.get("/stats")
async def stats(db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    users = (await db.execute(select(func.count(User.id)))).scalar()
    deposited = (await db.execute(select(func.sum(Transaction.amount)).where(Transaction.type.in_(["deposit_ton","deposit_stars","deposit_gift"])))).scalar() or 0
    pending = (await db.execute(select(func.count(WithdrawRequest.id)).where(WithdrawRequest.status == "pending"))).scalar()
    profit = abs((await db.execute(select(func.sum(Transaction.amount)).where(Transaction.type.in_(["bet_lose","case_open","upgrade"])))).scalar() or 0)
    return {"total_users":users,"total_deposited":round(deposited,2),"pending_withdrawals":pending,"total_profit":round(profit,2)}

@admin_router.get("/collections")
async def get_cols(db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(GiftCollection).where(GiftCollection.is_active == True).order_by(GiftCollection.name))
    return [{"id":c.id,"name":c.name,"slug":c.slug,"image_url":c.image_url,"lottie_url":c.lottie_url,"floor_price":c.floor_price} for c in r.scalars().all()]

@admin_router.post("/collections/add")
async def add_collection(data: dict, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    slug = data.get("slug") or data["name"].lower().replace(" ","")
    r = await db.execute(select(GiftCollection).where(GiftCollection.slug == slug))
    existing = r.scalar_one_or_none()
    if existing:
        existing.name = data["name"]; existing.image_url = data.get("image_url",""); existing.lottie_url = data.get("lottie_url",""); existing.floor_price = data.get("floor_price",0)
    else:
        db.add(GiftCollection(name=data["name"],slug=slug,image_url=data.get("image_url",""),lottie_url=data.get("lottie_url",""),floor_price=data.get("floor_price",0)))
    await db.commit()
    return {"success":True}

@admin_router.post("/collections/sync_from_userbot")
async def sync_from_userbot(data: dict, db: AsyncSession = Depends(get_db), _=Depends(internal_auth)):
    """Called by userbot to sync real gift collections"""
    collections = data.get("collections", [])
    count = 0
    for col in collections:
        slug = col.get("slug","")
        if not slug: continue
        r = await db.execute(select(GiftCollection).where(GiftCollection.slug == slug))
        existing = r.scalar_one_or_none()
        if existing:
            existing.floor_price = col.get("floor_price", existing.floor_price)
            existing.image_url = col.get("image_url", existing.image_url)
            existing.lottie_url = col.get("lottie_url", existing.lottie_url)
        else:
            db.add(GiftCollection(name=col.get("name",slug),slug=slug,image_url=col.get("image_url",""),lottie_url=col.get("lottie_url",""),floor_price=col.get("floor_price",0)))
        count += 1
    await db.commit()
    return {"success":True,"synced":count}

@admin_router.post("/gift_deposit")
async def gift_deposit(data: dict, db: AsyncSession = Depends(get_db), _=Depends(internal_auth)):
    """Userbot calls this when user sends gift"""
    tg_id = data.get("telegram_id")
    collection_name = data.get("collection_name","")
    image_url = data.get("image_url","")
    lottie_url = data.get("lottie_url","")
    floor_price = data.get("floor_price",0.0)
    r = await db.execute(select(User).where(User.telegram_id == tg_id))
    user = r.scalar_one_or_none()
    if not user: raise HTTPException(404, "User not found")
    col_r = await db.execute(select(GiftCollection).where(GiftCollection.name == collection_name))
    col = col_r.scalar_one_or_none()
    item = InventoryItem(user_id=user.id, collection_id=col.id if col else None, collection_name=collection_name, collection_image=image_url, collection_lottie=lottie_url, floor_price=floor_price, source="deposit", is_locked=False)
    db.add(item)
    db.add(Transaction(user_id=user.id, type="deposit_gift", amount=floor_price, description=f"Gift deposit: {collection_name}"))
    await db.commit()
    return {"success":True}

@admin_router.get("/cases")
async def get_cases_admin(db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(Case).order_by(Case.sort_order))
    return [{"id":c.id,"name":c.name,"image_url":c.image_url,"price_ton":c.price_ton,"price_stars":c.price_stars,"is_active":c.is_active,"is_daily":c.is_daily} for c in r.scalars().all()]

@admin_router.post("/cases")
async def create_case(data: CaseCreate, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    case = Case(name=data.name,image_url=data.image_url,price_ton=data.price_ton,price_stars=data.price_stars,is_daily=data.is_daily,sort_order=data.sort_order)
    db.add(case); await db.flush()
    total = sum(i["probability"] for i in data.items)
    for item in data.items:
        db.add(CaseItem(case_id=case.id,collection_id=item["collection_id"],probability=item["probability"]/total))
    await db.commit()
    return {"success":True,"id":case.id}

@admin_router.put("/cases/{case_id}")
async def update_case(case_id: int, data: CaseCreate, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(Case).where(Case.id == case_id))
    case = r.scalar_one_or_none()
    if not case: raise HTTPException(404, "Not found")
    case.name=data.name; case.image_url=data.image_url; case.price_ton=data.price_ton; case.price_stars=data.price_stars; case.sort_order=data.sort_order
    old = await db.execute(select(CaseItem).where(CaseItem.case_id == case_id))
    for i in old.scalars().all(): await db.delete(i)
    total = sum(i["probability"] for i in data.items)
    for item in data.items:
        db.add(CaseItem(case_id=case.id,collection_id=item["collection_id"],probability=item["probability"]/total))
    await db.commit()
    return {"success":True}

@admin_router.delete("/cases/{case_id}")
async def delete_case(case_id: int, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(Case).where(Case.id == case_id))
    case = r.scalar_one_or_none()
    if not case: raise HTTPException(404, "Not found")
    case.is_active = False; await db.commit()
    return {"success":True}

@admin_router.get("/withdrawals")
async def get_withdrawals(db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(WithdrawRequest).where(WithdrawRequest.status == "pending").order_by(WithdrawRequest.created_at))
    return [{"id":w.id,"user_id":w.telegram_id,"username":w.username,"collection":w.collection_name,"created_at":w.created_at.isoformat()} for w in r.scalars().all()]

@admin_router.get("/withdrawals/internal")
async def get_withdrawals_internal(db: AsyncSession = Depends(get_db), _=Depends(internal_auth)):
    r = await db.execute(select(WithdrawRequest).where(WithdrawRequest.status == "pending").order_by(WithdrawRequest.created_at))
    return [{"id":w.id,"user_id":w.telegram_id,"username":w.username,"collection":w.collection_name,"created_at":w.created_at.isoformat()} for w in r.scalars().all()]

@admin_router.post("/withdrawals/{wid}/complete")
async def complete_withdrawal(wid: int, db: AsyncSession = Depends(get_db), _=Depends(internal_auth)):
    r = await db.execute(select(WithdrawRequest).where(WithdrawRequest.id == wid))
    w = r.scalar_one_or_none()
    if not w: raise HTTPException(404, "Not found")
    w.status = "completed"; w.completed_at = datetime.utcnow()
    if w.inventory_item_id:
        ir = await db.execute(select(InventoryItem).where(InventoryItem.id == w.inventory_item_id))
        item = ir.scalar_one_or_none()
        if item: await db.delete(item)
    await db.commit()
    return {"success":True}

@admin_router.post("/withdrawals/{wid}/complete_admin")
async def complete_withdrawal_admin(wid: int, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(WithdrawRequest).where(WithdrawRequest.id == wid))
    w = r.scalar_one_or_none()
    if not w: raise HTTPException(404, "Not found")
    w.status = "completed"; w.completed_at = datetime.utcnow()
    if w.inventory_item_id:
        ir = await db.execute(select(InventoryItem).where(InventoryItem.id == w.inventory_item_id))
        item = ir.scalar_one_or_none()
        if item: await db.delete(item)
    await db.commit()
    return {"success":True}

@admin_router.get("/users")
async def get_users(limit: int = 50, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(User).order_by(User.created_at.desc()).limit(limit))
    return [{"id":u.id,"telegram_id":u.telegram_id,"username":u.username,"first_name":u.first_name,"balance":u.balance,"is_admin":u.is_admin,"is_banned":u.is_banned,"created_at":u.created_at.isoformat()} for u in r.scalars().all()]

@admin_router.post("/users/{uid}/ban")
async def ban_user(uid: int, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(User).where(User.id == uid))
    u = r.scalar_one_or_none()
    if not u: raise HTTPException(404, "Not found")
    u.is_banned = not u.is_banned; await db.commit()
    return {"success":True,"is_banned":u.is_banned}

@admin_router.get("/fake_bots")
async def get_fake_bots(db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(FakeBot).where(FakeBot.is_active == True))
    return [{"id":b.id,"username":b.username,"avatar_url":b.avatar_url} for b in r.scalars().all()]

@admin_router.post("/fake_bots")
async def create_fake_bot(data: FakeBotCreate, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    db.add(FakeBot(username=data.username, avatar_url=data.avatar_url))
    await db.commit()
    r = await db.execute(select(FakeBot).where(FakeBot.is_active == True))
    crash_engine.fake_bots = [{"username":b.username,"avatar_url":b.avatar_url} for b in r.scalars().all()]
    return {"success":True}

@admin_router.delete("/fake_bots/{bid}")
async def delete_fake_bot(bid: int, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(FakeBot).where(FakeBot.id == bid))
    b = r.scalar_one_or_none()
    if not b: raise HTTPException(404, "Not found")
    b.is_active = False; await db.commit()
    r = await db.execute(select(FakeBot).where(FakeBot.is_active == True))
    crash_engine.fake_bots = [{"username":b.username,"avatar_url":b.avatar_url} for b in r.scalars().all()]
    return {"success":True}

@admin_router.get("/missions")
async def get_missions_admin(db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(Mission))
    return [{"id":m.id,"title":m.title,"description":m.description,"type":m.type,"target_value":m.target_value,"reward_ton":m.reward_ton,"is_active":m.is_active} for m in r.scalars().all()]

@admin_router.post("/missions")
async def create_mission(data: MissionCreate, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    db.add(Mission(title=data.title,description=data.description,type=data.type,target_value=data.target_value,reward_ton=data.reward_ton))
    await db.commit()
    return {"success":True}

@admin_router.delete("/missions/{mid}")
async def delete_mission(mid: int, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(Mission).where(Mission.id == mid))
    m = r.scalar_one_or_none()
    if not m: raise HTTPException(404, "Not found")
    m.is_active = False; await db.commit()
    return {"success":True}

@admin_router.post("/promocodes")
async def create_promo(data: PromoCreate, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    db.add(Promocode(code=data.code.upper(),reward_type=data.reward_type,reward_collection_id=data.reward_collection_id,reward_ton=data.reward_ton,max_uses=data.max_uses))
    await db.commit()
    return {"success":True}

@admin_router.get("/promocodes")
async def get_promos(db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    r = await db.execute(select(Promocode).order_by(Promocode.created_at.desc()))
    return [{"id":p.id,"code":p.code,"reward_type":p.reward_type,"reward_ton":p.reward_ton,"max_uses":p.max_uses,"used_count":p.used_count,"is_active":p.is_active} for p in r.scalars().all()]

@admin_router.get("/settings")
async def get_settings_admin(db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    return await get_all_settings(db)

@admin_router.put("/settings")
async def update_settings(settings: dict, db: AsyncSession = Depends(get_db), admin: User = Depends(require_admin)):
    for k, v in settings.items(): await set_setting(db, k, str(v))
    return {"success":True}
