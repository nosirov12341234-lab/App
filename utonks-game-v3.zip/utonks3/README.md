# 🎮 Utonks Game v3

## O'yinlar
- 🚀 **CRASH** — Multiplier o'sadi, o'z vaqtida cash out!
- 💣 **MINES** — 5×5 grid, minalardan qoching!
- 📦 **CASES** — Real Telegram gift rasmlar bilan case oching!
- ⬆️ **UPGRADE** — Giftlarni birlashtiring → yangi gift!
- 🎯 **ZONE** — Spinning wheel, katta stake = katta imkoniyat!

## Yangiliklar v3
- ✅ Real gift rasmlari (Fragment CDN)
- ✅ TON Connect manifest muammosi hal qilindi
- ✅ Avatar SVG muammosi hal qilindi
- ✅ Zone o'yini qo'shildi
- ✅ Missions tizimi
- ✅ Fake bots admin paneldan boshqarish
- ✅ Admin parol himoyasi
- ✅ Gift deposit (userbot orqali avtomatik)
- ✅ Professional dark dizayn

## VPS ga deploy

### 1. Fayllarni yuklash
```bash
cd /home/ubuntu/utonks
sudo docker compose down

wget https://github.com/nosirov12341234-lab/App/raw/main/utonks-game-v3.zip
unzip utonks-game-v3.zip
cp -r utonks3/* .
rm -rf utonks3 utonks-game-v3.zip
```

### 2. TON Connect manifest URL ni yangilash
```bash
# Cloudflare URL ni oling
sudo docker compose logs cloudflared 2>/dev/null | grep trycloudflare

# manifest faylini yangilang
sed -i 's|https://utonksgame.com|https://YOUR_URL.trycloudflare.com|g' frontend/public/tonconnect-manifest.json
```

### 3. DB migration (agar eski DB bor bo'lsa)
```bash
sudo docker compose up -d db
sudo docker compose exec db psql -U utonks -d utonks -c "
ALTER TABLE withdraw_requests ALTER COLUMN status TYPE VARCHAR(32) USING status::text::VARCHAR;
DROP TYPE IF EXISTS withdrawstatus CASCADE;
ALTER TABLE inventory ADD COLUMN IF NOT EXISTS collection_lottie VARCHAR(512);
CREATE TABLE IF NOT EXISTS zone_games (id SERIAL PRIMARY KEY, status VARCHAR(32) DEFAULT 'betting', winner_user_id INTEGER, total_pot FLOAT DEFAULT 0, commission_percent FLOAT DEFAULT 5, started_at TIMESTAMP DEFAULT NOW(), ended_at TIMESTAMP);
CREATE TABLE IF NOT EXISTS zone_bets (id SERIAL PRIMARY KEY, game_id INTEGER, user_id INTEGER, username VARCHAR(255), avatar_url VARCHAR(512), amount FLOAT, is_fake BOOLEAN DEFAULT FALSE, won BOOLEAN DEFAULT FALSE);
CREATE TABLE IF NOT EXISTS fake_bots (id SERIAL PRIMARY KEY, username VARCHAR(255), avatar_url VARCHAR(512), is_active BOOLEAN DEFAULT TRUE);
CREATE TABLE IF NOT EXISTS missions (id SERIAL PRIMARY KEY, title VARCHAR(255), description VARCHAR(512), type VARCHAR(32), target_value VARCHAR(255), reward_ton FLOAT, reward_collection_id INTEGER, is_active BOOLEAN DEFAULT TRUE, created_at TIMESTAMP DEFAULT NOW());
CREATE TABLE IF NOT EXISTS mission_completes (id SERIAL PRIMARY KEY, mission_id INTEGER, user_id INTEGER, completed_at TIMESTAMP DEFAULT NOW());
"
```

### 4. Build va ishga tushirish
```bash
sudo docker compose up --build -d

# Cloudflare URL ni oling
sudo docker compose logs cloudflared 2>/dev/null | grep trycloudflare

# URL ni .env ga saqlang
sed -i 's|WEBAPP_URL=.*|WEBAPP_URL=https://YOUR_URL.trycloudflare.com|' .env
```

### 5. Admin yaratish
```bash
sudo docker compose exec db psql -U utonks -d utonks -c \
"UPDATE users SET is_admin = true WHERE telegram_id = YOUR_TELEGRAM_ID;"
```

### 6. Collections qo'shish
Admin panel → Collections → Add (Fragment URL dan)

Format: `https://nft.fragment.com/gift/GIFTNAME-ID.webp`

Masalan:
- `https://nft.fragment.com/gift/plushpepe-1.webp`
- `https://nft.fragment.com/gift/heartlocket-1.webp`

## Admin parol
Default: `admin123`
Admin panel → Settings → admin_password dan o'zgartiring
