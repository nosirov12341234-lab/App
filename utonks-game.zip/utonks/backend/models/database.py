from sqlalchemy import Column, Integer, BigInteger, String, Float, Boolean, DateTime, ForeignKey, Enum, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime
import enum

Base = declarative_base()

class TransactionType(str, enum.Enum):
    DEPOSIT_TON = "deposit_ton"
    DEPOSIT_STARS = "deposit_stars"
    DEPOSIT_GIFT = "deposit_gift"
    WITHDRAW_GIFT = "withdraw_gift"
    SELL_GIFT = "sell_gift"
    BET_WIN = "bet_win"
    BET_LOSE = "bet_lose"
    REFERRAL_BONUS = "referral_bonus"
    CASE_OPEN = "case_open"
    UPGRADE = "upgrade"
    PROMOCODE = "promocode"

class WithdrawStatus(str, enum.Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

class GiftSource(str, enum.Enum):
    CASE = "case"
    DEPOSIT = "deposit"
    DAILY_CASE = "daily_case"
    PROMOCODE = "promocode"
    UPGRADE = "upgrade"

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, unique=True, nullable=False)
    username = Column(String(255))
    first_name = Column(String(255))
    photo_url = Column(String(512))
    balance = Column(Float, default=0.0)
    stars_balance = Column(Float, default=0.0)
    level = Column(Integer, default=1)
    is_admin = Column(Boolean, default=False)
    is_banned = Column(Boolean, default=False)
    referral_code = Column(String(32), unique=True)
    referred_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    referral_earnings = Column(Float, default=0.0)
    total_deposited = Column(Float, default=0.0)
    total_referral_deposits = Column(Float, default=0.0)
    last_daily_case = Column(DateTime, nullable=True)
    daily_case_referral_done = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    inventory = relationship("InventoryItem", back_populates="user")
    transactions = relationship("Transaction", back_populates="user")
    withdrawals = relationship("WithdrawRequest", back_populates="user")

class GiftCollection(Base):
    __tablename__ = "gift_collections"
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    slug = Column(String(255), unique=True)
    image_url = Column(String(512))
    floor_price = Column(Float, default=0.0)
    is_active = Column(Boolean, default=True)
    ton_api_id = Column(String(255))
    last_updated = Column(DateTime, default=datetime.utcnow)

class Case(Base):
    __tablename__ = "cases"
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    image_url = Column(String(512))
    price_ton = Column(Float, nullable=True)
    price_stars = Column(Integer, nullable=True)
    is_active = Column(Boolean, default=True)
    is_daily = Column(Boolean, default=False)
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    items = relationship("CaseItem", back_populates="case")

class CaseItem(Base):
    __tablename__ = "case_items"
    id = Column(Integer, primary_key=True)
    case_id = Column(Integer, ForeignKey("cases.id"))
    collection_id = Column(Integer, ForeignKey("gift_collections.id"))
    probability = Column(Float, nullable=False)
    case = relationship("Case", back_populates="items")
    collection = relationship("GiftCollection")

class InventoryItem(Base):
    __tablename__ = "inventory"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    collection_id = Column(Integer, ForeignKey("gift_collections.id"))
    collection_name = Column(String(255))
    collection_image = Column(String(512))
    floor_price = Column(Float)
    source = Column(Enum(GiftSource))
    is_locked = Column(Boolean, default=False)
    withdraw_available_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("User", back_populates="inventory")
    collection = relationship("GiftCollection")

class WithdrawRequest(Base):
    __tablename__ = "withdraw_requests"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    inventory_item_id = Column(Integer, ForeignKey("inventory.id"))
    collection_name = Column(String(255))
    status = Column(Enum(WithdrawStatus), default=WithdrawStatus.PENDING)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
    user = relationship("User", back_populates="withdrawals")

class Transaction(Base):
    __tablename__ = "transactions"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    type = Column(Enum(TransactionType))
    amount = Column(Float)
    description = Column(String(512))
    meta = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("User", back_populates="transactions")

class CrashGame(Base):
    __tablename__ = "crash_games"
    id = Column(Integer, primary_key=True)
    crash_point = Column(Float)
    started_at = Column(DateTime)
    ended_at = Column(DateTime, nullable=True)
    total_bets = Column(Float, default=0.0)
    total_payout = Column(Float, default=0.0)
    bets = relationship("CrashBet", back_populates="game")

class CrashBet(Base):
    __tablename__ = "crash_bets"
    id = Column(Integer, primary_key=True)
    game_id = Column(Integer, ForeignKey("crash_games.id"))
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    username = Column(String(255))
    avatar_url = Column(String(512))
    amount = Column(Float)
    is_gift_bet = Column(Boolean, default=False)
    inventory_item_id = Column(Integer, nullable=True)
    is_fake = Column(Boolean, default=False)
    cashout_multiplier = Column(Float, nullable=True)
    payout = Column(Float, nullable=True)
    game = relationship("CrashGame", back_populates="bets")

class Settings(Base):
    __tablename__ = "settings"
    id = Column(Integer, primary_key=True)
    key = Column(String(255), unique=True)
    value = Column(Text)

class Promocode(Base):
    __tablename__ = "promocodes"
    id = Column(Integer, primary_key=True)
    code = Column(String(64), unique=True)
    reward_type = Column(String(32))
    reward_collection_id = Column(Integer, ForeignKey("gift_collections.id"), nullable=True)
    reward_ton = Column(Float, nullable=True)
    reward_stars = Column(Integer, nullable=True)
    max_uses = Column(Integer, default=1)
    used_count = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    uses = relationship("PromocodeUse", back_populates="promocode")

class PromocodeUse(Base):
    __tablename__ = "promocode_uses"
    id = Column(Integer, primary_key=True)
    promocode_id = Column(Integer, ForeignKey("promocodes.id"))
    user_id = Column(Integer, ForeignKey("users.id"))
    used_at = Column(DateTime, default=datetime.utcnow)
    promocode = relationship("Promocode", back_populates="uses")
