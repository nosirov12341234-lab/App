import asyncio
import os
import logging
from aiogram import Bot, Dispatcher, Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram.filters import CommandStart, Command
from aiogram.fsm.storage.memory import MemoryStorage

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
WEBAPP_URL = os.getenv("WEBAPP_URL", "https://utonks.trycloudflare.com")
ADMIN_ID = int(os.getenv("ADMIN_TELEGRAM_ID", "0"))

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
router = Router()

@router.message(CommandStart())
async def start_handler(message: Message):
    args = message.text.split()
    ref_code = args[1] if len(args) > 1 else None
    
    webapp_url = WEBAPP_URL
    if ref_code:
        webapp_url = f"{WEBAPP_URL}?ref={ref_code}"
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="🚀 Utonks Game ochish",
            web_app=WebAppInfo(url=webapp_url)
        )],
        [InlineKeyboardButton(
            text="📢 Kanal",
            url="https://t.me/utonksgame"
        )]
    ])
    
    await message.answer(
        "🎮 <b>Utonks Game</b>ga xush kelibsiz!\n\n"
        "🚀 Crash, 💣 Mines, 📦 Cases, ⬆️ Upgrade\n"
        "🎁 TON giflar bilan o'ynang va yuting!\n\n"
        "💎 TON va ⭐ Stars bilan depozit qiling",
        reply_markup=keyboard,
        parse_mode="HTML"
    )

@router.message(Command("admin"))
async def admin_panel(message: Message):
    if message.from_user.id != ADMIN_ID:
        return
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="⚙️ Admin Panel",
            web_app=WebAppInfo(url=f"{WEBAPP_URL}/admin")
        )]
    ])
    await message.answer("Admin panel:", reply_markup=keyboard)

dp.include_router(router)

async def main():
    logger.info("Starting Utonks bot...")
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
