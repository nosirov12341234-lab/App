from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import asyncio
import os

from .models.db import init_db, AsyncSessionLocal
from .routers import cases, inventory, crash, user, admin, mines, upgrade
from .services.crash_engine import crash_engine
from .services.settings import get_setting

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    asyncio.create_task(
        crash_engine.run_game_loop(
            db_session_factory=AsyncSessionLocal,
            settings_getter=_get_setting_async,
        )
    )
    yield

async def _get_setting_async(key: str) -> str:
    async with AsyncSessionLocal() as db:
        return await get_setting(db, key)

app = FastAPI(title="Utonks Game API", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(user.router, prefix="/api")
app.include_router(cases.router, prefix="/api")
app.include_router(inventory.router, prefix="/api")
app.include_router(crash.router, prefix="/api")
app.include_router(mines.router, prefix="/api")
app.include_router(upgrade.router, prefix="/api")
app.include_router(admin.router, prefix="/api")

@app.get("/health")
async def health():
    return {"status": "ok", "game": crash_engine.game_state}
