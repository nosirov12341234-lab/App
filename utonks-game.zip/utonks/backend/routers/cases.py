from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..models.db import get_db
from ..models.database import Case, CaseItem, GiftCollection, InventoryItem, User, Transaction, TransactionType, GiftSource
from ..services.auth import get_current_user
from ..services.settings import get_setting
from datetime import datetime, timedelta
import random

router = APIRouter(prefix="/cases", tags=["cases"])

@router.get("/")
async def get_cases(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Case).where(Case.is_active == True).order_by(Case.sort_order)
    )
    cases = result.scalars().all()
    
    out = []
    for c in cases:
        items_result = await db.execute(
            select(CaseItem, GiftCollection)
            .join(GiftCollection, CaseItem.collection_id == GiftCollection.id)
            .where(CaseItem.case_id == c.id)
        )
        items = items_result.all()
        
        out.append({
            "id": c.id,
            "name": c.name,
            "image_url": c.image_url,
            "price_ton": c.price_ton,
            "price_stars": c.price_stars,
            "is_daily": c.is_daily,
            "items": [
                {
                    "collection_id": col.id,
                    "collection_name": col.name,
                    "collection_image": col.image_url,
                    "floor_price": col.floor_price,
                    "probability": item.probability,
                }
                for item, col in items
            ]
        })
    
    return out

@router.post("/{case_id}/open")
async def open_case(
    case_id: int,
    payment_method: str = "ton",
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    # Get case
    result = await db.execute(select(Case).where(Case.id == case_id, Case.is_active == True))
    case = result.scalar_one_or_none()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")

    # Daily case check
    if case.is_daily:
        # Check referral requirement
        if not user.daily_case_referral_done:
            raise HTTPException(status_code=400, detail="Need 1 referral to open daily case")
        
        if user.last_daily_case:
            time_diff = datetime.utcnow() - user.last_daily_case
            if time_diff.total_seconds() < 86400:
                raise HTTPException(status_code=400, detail="Daily case already opened today")
        
        user.last_daily_case = datetime.utcnow()
        user.daily_case_referral_done = False
        source = GiftSource.DAILY_CASE
        is_locked = True
    else:
        # Check balance and deduct
        if payment_method == "ton":
            if not case.price_ton:
                raise HTTPException(status_code=400, detail="TON payment not available")
            if user.balance < case.price_ton:
                raise HTTPException(status_code=400, detail="Insufficient balance")
            user.balance -= case.price_ton
            tx_amount = -case.price_ton
        elif payment_method == "stars":
            if not case.price_stars:
                raise HTTPException(status_code=400, detail="Stars payment not available")
            stars_rate = float(await get_setting(db, "stars_to_ton_rate"))
            price_in_ton = case.price_stars * stars_rate
            if user.balance < price_in_ton:
                raise HTTPException(status_code=400, detail="Insufficient balance")
            user.balance -= price_in_ton
            tx_amount = -price_in_ton
        
        source = GiftSource.CASE
        is_locked = False

    # Get case items and roll
    items_result = await db.execute(
        select(CaseItem, GiftCollection)
        .join(GiftCollection, CaseItem.collection_id == GiftCollection.id)
        .where(CaseItem.case_id == case_id)
    )
    items = items_result.all()
    
    if not items:
        raise HTTPException(status_code=400, detail="Case has no items")

    # Weighted random selection
    weights = [item.probability for item, _ in items]
    selected_item, selected_collection = random.choices(items, weights=weights, k=1)[0]

    # Add to inventory
    withdraw_available_at = datetime.utcnow() + timedelta(seconds=3600) if not is_locked else None
    
    inventory_item = InventoryItem(
        user_id=user.id,
        collection_id=selected_collection.id,
        collection_name=selected_collection.name,
        collection_image=selected_collection.image_url,
        floor_price=selected_collection.floor_price,
        source=source,
        is_locked=is_locked,
        withdraw_available_at=withdraw_available_at,
    )
    db.add(inventory_item)

    # Transaction
    if not case.is_daily:
        tx = Transaction(
            user_id=user.id,
            type=TransactionType.CASE_OPEN,
            amount=tx_amount,
            description=f"Case: {case.name} → {selected_collection.name}",
        )
        db.add(tx)

    await db.commit()
    await db.refresh(inventory_item)

    return {
        "success": True,
        "gift": {
            "id": inventory_item.id,
            "collection_name": selected_collection.name,
            "collection_image": selected_collection.image_url,
            "floor_price": selected_collection.floor_price,
            "is_locked": is_locked,
        }
    }
