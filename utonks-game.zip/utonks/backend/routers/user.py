from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from ..models.db import get_db
from ..models.database import User, Transaction, TransactionType
from ..services.auth import get_current_user
from ..services.settings import get_setting
import os

router = APIRouter(prefix="/user", tags=["user"])
BOT_USERNAME = os.getenv("BOT_USERNAME", "UtonksBot")

@router.get("/me")
async def get_me(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    # Count referrals
    ref_result = await db.execute(
        select(func.count(User.id)).where(User.referred_by == user.id)
    )
    referral_count = ref_result.scalar() or 0

    # Referral level
    level_thresholds = [
        (float(await get_setting(db, "referral_level4_min_ton")), 4),
        (float(await get_setting(db, "referral_level3_min_ton")), 3),
        (float(await get_setting(db, "referral_level2_min_ton")), 2),
        (0, 1),
    ]
    level = 1
    for threshold, lvl in level_thresholds:
        if user.total_referral_deposits >= threshold:
            level = lvl
            break

    level_percents = {1: 10, 2: 12, 3: 14, 4: 18}

    return {
        "id": user.id,
        "telegram_id": user.telegram_id,
        "username": user.username,
        "first_name": user.first_name,
        "photo_url": user.photo_url,
        "balance": user.balance,
        "level": level,
        "is_admin": user.is_admin,
        "referral_code": user.referral_code,
        "referral_link": f"https://t.me/{BOT_USERNAME}?start={user.referral_code}",
        "referral_count": referral_count,
        "referral_earnings": user.referral_earnings,
        "referral_percent": level_percents.get(level, 10),
        "total_referral_deposits": user.total_referral_deposits,
    }

@router.get("/transactions")
async def get_transactions(
    limit: int = 20,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Transaction)
        .where(Transaction.user_id == user.id)
        .order_by(Transaction.created_at.desc())
        .limit(limit)
    )
    transactions = result.scalars().all()
    
    return [
        {
            "id": t.id,
            "type": t.type.value,
            "amount": t.amount,
            "description": t.description,
            "created_at": t.created_at.isoformat(),
        }
        for t in transactions
    ]

@router.post("/deposit/ton")
async def initiate_ton_deposit(
    amount: float,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    min_deposit = float(await get_setting(db, "min_deposit_ton"))
    if amount < min_deposit:
        raise HTTPException(status_code=400, detail=f"Minimum deposit is {min_deposit} TON")
    
    # Generate unique memo for TON transaction
    memo = f"utonks_{user.telegram_id}_{int(amount * 1000)}"
    wallet = os.getenv("PLATFORM_TON_WALLET", "")
    
    bonus_percent = float(await get_setting(db, "deposit_bonus_ton_percent"))
    
    return {
        "wallet": wallet,
        "amount": amount,
        "memo": memo,
        "bonus_percent": bonus_percent,
        "bonus_amount": round(amount * bonus_percent / 100, 6),
    }

@router.post("/deposit/stars")
async def initiate_stars_deposit(
    stars_amount: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    min_stars = int(await get_setting(db, "min_deposit_stars"))
    if stars_amount < min_stars:
        raise HTTPException(status_code=400, detail=f"Minimum deposit is {min_stars} Stars")
    
    rate = float(await get_setting(db, "stars_to_ton_rate"))
    ton_amount = round(stars_amount * rate, 6)
    
    return {
        "stars_amount": stars_amount,
        "ton_equivalent": ton_amount,
        "rate": rate,
        "invoice_url": f"tg://invoice",
    }

@router.post("/promocode")
async def use_promocode(
    code: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    from ..models.database import Promocode, PromocodeUse, InventoryItem, GiftSource, GiftCollection
    from sqlalchemy import select
    from datetime import datetime

    result = await db.execute(
        select(Promocode).where(
            Promocode.code == code.upper(),
            Promocode.is_active == True,
        )
    )
    promo = result.scalar_one_or_none()
    if not promo:
        raise HTTPException(status_code=404, detail="Invalid promocode")

    if promo.used_count >= promo.max_uses:
        raise HTTPException(status_code=400, detail="Promocode expired")

    # Check if user already used this code
    use_result = await db.execute(
        select(PromocodeUse).where(
            PromocodeUse.promocode_id == promo.id,
            PromocodeUse.user_id == user.id,
        )
    )
    if use_result.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Already used this promocode")

    reward = {}
    
    if promo.reward_type == "gift" and promo.reward_collection_id:
        col_result = await db.execute(
            select(GiftCollection).where(GiftCollection.id == promo.reward_collection_id)
        )
        col = col_result.scalar_one_or_none()
        if col:
            item = InventoryItem(
                user_id=user.id,
                collection_id=col.id,
                collection_name=col.name,
                collection_image=col.image_url,
                floor_price=col.floor_price,
                source=GiftSource.PROMOCODE,
                is_locked=True,
            )
            db.add(item)
            reward = {"type": "gift", "collection": col.name, "image": col.image_url}
    
    elif promo.reward_type == "ton" and promo.reward_ton:
        user.balance += promo.reward_ton
        tx = Transaction(
            user_id=user.id,
            type=TransactionType.PROMOCODE,
            amount=promo.reward_ton,
            description=f"Promocode: {code}",
        )
        db.add(tx)
        reward = {"type": "ton", "amount": promo.reward_ton}

    promo.used_count += 1
    use = PromocodeUse(promocode_id=promo.id, user_id=user.id)
    db.add(use)
    await db.commit()

    return {"success": True, "reward": reward}
