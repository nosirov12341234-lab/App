from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from ..models.db import get_db
from ..models.database import (
    User, Case, CaseItem, GiftCollection, Transaction,
    WithdrawRequest, WithdrawStatus, Promocode, Settings
)
from ..services.auth import get_current_user
from ..services.settings import get_all_settings, set_setting
from ..services.ton_api import sync_collections_to_db
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

router = APIRouter(prefix="/admin", tags=["admin"])

async def require_admin(user: User = Depends(get_current_user)):
    if not user.is_admin:
        raise HTTPException(status_code=403, detail="Admin only")
    return user

class CaseCreate(BaseModel):
    name: str
    image_url: str
    price_ton: Optional[float] = None
    price_stars: Optional[int] = None
    is_daily: bool = False
    sort_order: int = 0
    items: List[dict]

class PromocodeCreate(BaseModel):
    code: str
    reward_type: str
    reward_collection_id: Optional[int] = None
    reward_ton: Optional[float] = None
    reward_stars: Optional[int] = None
    max_uses: int = 1

@router.get("/stats")
async def get_stats(
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_admin),
):
    user_count = await db.execute(select(func.count(User.id)))
    total_users = user_count.scalar()

    tx_result = await db.execute(
        select(func.sum(Transaction.amount)).where(
            Transaction.type.in_(["deposit_ton", "deposit_stars", "deposit_gift"])
        )
    )
    total_deposited = tx_result.scalar() or 0

    pending_result = await db.execute(
        select(func.count(WithdrawRequest.id)).where(
            WithdrawRequest.status == WithdrawStatus.PENDING
        )
    )
    pending_withdrawals = pending_result.scalar()

    return {
        "total_users": total_users,
        "total_deposited": total_deposited,
        "pending_withdrawals": pending_withdrawals,
    }

@router.get("/collections")
async def get_collections(
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_admin),
):
    result = await db.execute(select(GiftCollection).where(GiftCollection.is_active == True))
    cols = result.scalars().all()
    return [{"id": c.id, "name": c.name, "slug": c.slug, "image_url": c.image_url, "floor_price": c.floor_price} for c in cols]

@router.post("/collections/sync")
async def sync_collections(
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_admin),
):
    count = await sync_collections_to_db(db)
    return {"success": True, "synced": count}

@router.post("/cases")
async def create_case(
    data: CaseCreate,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_admin),
):
    case = Case(
        name=data.name,
        image_url=data.image_url,
        price_ton=data.price_ton,
        price_stars=data.price_stars,
        is_daily=data.is_daily,
        sort_order=data.sort_order,
    )
    db.add(case)
    await db.flush()

    total_prob = sum(item["probability"] for item in data.items)
    for item in data.items:
        case_item = CaseItem(
            case_id=case.id,
            collection_id=item["collection_id"],
            probability=item["probability"] / total_prob,
        )
        db.add(case_item)

    await db.commit()
    return {"success": True, "case_id": case.id}

@router.put("/cases/{case_id}")
async def update_case(
    case_id: int,
    data: CaseCreate,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_admin),
):
    result = await db.execute(select(Case).where(Case.id == case_id))
    case = result.scalar_one_or_none()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")

    case.name = data.name
    case.image_url = data.image_url
    case.price_ton = data.price_ton
    case.price_stars = data.price_stars
    case.sort_order = data.sort_order

    # Delete old items
    old_items = await db.execute(select(CaseItem).where(CaseItem.case_id == case_id))
    for item in old_items.scalars().all():
        await db.delete(item)

    # Add new items
    total_prob = sum(item["probability"] for item in data.items)
    for item in data.items:
        case_item = CaseItem(
            case_id=case.id,
            collection_id=item["collection_id"],
            probability=item["probability"] / total_prob,
        )
        db.add(case_item)

    await db.commit()
    return {"success": True}

@router.delete("/cases/{case_id}")
async def delete_case(
    case_id: int,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_admin),
):
    result = await db.execute(select(Case).where(Case.id == case_id))
    case = result.scalar_one_or_none()
    if not case:
        raise HTTPException(status_code=404, detail="Not found")
    case.is_active = False
    await db.commit()
    return {"success": True}

@router.get("/withdrawals")
async def get_withdrawals(
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_admin),
):
    result = await db.execute(
        select(WithdrawRequest, User)
        .join(User, WithdrawRequest.user_id == User.id)
        .where(WithdrawRequest.status == WithdrawStatus.PENDING)
        .order_by(WithdrawRequest.created_at)
    )
    rows = result.all()
    return [
        {
            "id": w.id,
            "user_id": u.telegram_id,
            "username": u.username,
            "collection": w.collection_name,
            "created_at": w.created_at.isoformat(),
        }
        for w, u in rows
    ]

@router.post("/withdrawals/{withdraw_id}/complete")
async def complete_withdrawal(
    withdraw_id: int,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_admin),
):
    result = await db.execute(select(WithdrawRequest).where(WithdrawRequest.id == withdraw_id))
    withdraw = result.scalar_one_or_none()
    if not withdraw:
        raise HTTPException(status_code=404, detail="Not found")
    
    withdraw.status = WithdrawStatus.COMPLETED
    withdraw.completed_at = datetime.utcnow()
    
    # Delete from inventory
    inv_result = await db.execute(
        select(InventoryItem := __import__('backend.models.database', fromlist=['InventoryItem']).InventoryItem)
        .where(InventoryItem.id == withdraw.inventory_item_id)
    )
    item = inv_result.scalar_one_or_none()
    if item:
        await db.delete(item)
    
    await db.commit()
    return {"success": True}

@router.post("/promocodes")
async def create_promocode(
    data: PromocodeCreate,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_admin),
):
    promo = Promocode(
        code=data.code.upper(),
        reward_type=data.reward_type,
        reward_collection_id=data.reward_collection_id,
        reward_ton=data.reward_ton,
        reward_stars=data.reward_stars,
        max_uses=data.max_uses,
    )
    db.add(promo)
    await db.commit()
    return {"success": True}

@router.get("/settings")
async def get_settings(
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_admin),
):
    return await get_all_settings(db)

@router.put("/settings")
async def update_settings(
    settings: dict,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_admin),
):
    for key, value in settings.items():
        await set_setting(db, key, str(value))
    return {"success": True}

@router.get("/users")
async def get_users(
    limit: int = 50,
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_admin),
):
    result = await db.execute(
        select(User).order_by(User.created_at.desc()).limit(limit).offset(offset)
    )
    users = result.scalars().all()
    return [
        {
            "id": u.id,
            "telegram_id": u.telegram_id,
            "username": u.username,
            "balance": u.balance,
            "is_banned": u.is_banned,
            "created_at": u.created_at.isoformat(),
        }
        for u in users
    ]

@router.post("/users/{user_id}/ban")
async def ban_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_admin),
):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.is_banned = not user.is_banned
    await db.commit()
    return {"success": True, "is_banned": user.is_banned}
