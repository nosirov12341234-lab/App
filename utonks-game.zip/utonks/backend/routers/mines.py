from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..models.db import get_db
from ..models.database import User, Transaction, TransactionType, InventoryItem
from ..services.auth import get_current_user
from ..services.settings import get_setting
import random

router = APIRouter(prefix="/mines", tags=["mines"])

# In-memory game sessions
games = {}

@router.post("/start")
async def start_game(
    amount: float,
    mines: int = 3,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if mines < 1 or mines > 20:
        raise HTTPException(status_code=400, detail="Mines must be 1-20")
    if amount < 0.01:
        raise HTTPException(status_code=400, detail="Min bet 0.01 TON")
    if user.balance < amount:
        raise HTTPException(status_code=400, detail="Insufficient balance")

    user.balance -= amount

    # Generate mine positions
    mine_positions = random.sample(range(25), mines)
    game_id = f"{user.id}_{random.randint(10000, 99999)}"

    games[game_id] = {
        "user_id": user.id,
        "amount": amount,
        "mines": mine_positions,
        "revealed": [],
        "multiplier": 1.0,
        "active": True,
    }

    tx = Transaction(
        user_id=user.id,
        type=TransactionType.BET_LOSE,
        amount=-amount,
        description=f"Mines bet ({mines} mines)",
    )
    db.add(tx)
    await db.commit()

    return {"game_id": game_id, "mines_count": mines}

@router.post("/reveal")
async def reveal_cell(
    game_id: str,
    cell: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    game = games.get(game_id)
    if not game or game["user_id"] != user.id or not game["active"]:
        raise HTTPException(status_code=400, detail="Invalid game")

    if cell in game["revealed"]:
        raise HTTPException(status_code=400, detail="Already revealed")

    if cell in game["mines"]:
        game["active"] = False
        return {
            "is_mine": True,
            "all_mines": game["mines"],
        }

    game["revealed"].append(cell)
    safe = 25 - len(game["mines"])
    revealed = len(game["revealed"])

    house_edge = float(await get_setting(db, "mines_house_edge"))
    multiplier = round(
        ((safe / (safe - revealed + 1)) * (1 - house_edge)) ** revealed,
        3
    )
    game["multiplier"] = multiplier

    return {"is_mine": False, "multiplier": multiplier}

@router.post("/cashout")
async def cashout(
    game_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    game = games.get(game_id)
    if not game or game["user_id"] != user.id or not game["active"]:
        raise HTTPException(status_code=400, detail="Invalid game")

    if len(game["revealed"]) == 0:
        raise HTTPException(status_code=400, detail="Reveal at least one cell")

    payout = round(game["amount"] * game["multiplier"], 6)
    game["active"] = False

    user.balance += payout

    tx = Transaction(
        user_id=user.id,
        type=TransactionType.BET_WIN,
        amount=payout,
        description=f"Mines cashout x{game['multiplier']}",
    )
    db.add(tx)
    await db.commit()

    del games[game_id]

    return {"payout": payout, "multiplier": game["multiplier"]}
