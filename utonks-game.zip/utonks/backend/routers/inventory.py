from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..models.db import get_db
from ..models.database import InventoryItem, User, Transaction, TransactionType, WithdrawRequest, WithdrawStatus, GiftSource
from ..services.auth import get_current_user
from ..services.settings import get_setting
from datetime import datetime

router = APIRouter(prefix="/inventory", tags=["inventory"])

@router.get("/")
async def get_inventory(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(InventoryItem)
        .where(InventoryItem.user_id == user.id)
        .order_by(InventoryItem.created_at.desc())
    )
    items = result.scalars().all()
    
    now = datetime.utcnow()
    return [
        {
            "id": item.id,
            "collection_name": item.collection_name,
            "collection_image": item.collection_image,
            "floor_price": item.floor_price,
            "source": item.source.value,
            "is_locked": item.is_locked,
            "can_withdraw": not item.is_locked and (
                item.withdraw_available_at is None or item.withdraw_available_at <= now
            ),
            "can_sell": True,
            "can_bet": not item.is_locked,
            "withdraw_available_at": item.withdraw_available_at.isoformat() if item.withdraw_available_at else None,
            "created_at": item.created_at.isoformat(),
        }
        for item in items
    ]

@router.post("/{item_id}/sell")
async def sell_gift(
    item_id: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(InventoryItem).where(
            InventoryItem.id == item_id,
            InventoryItem.user_id == user.id
        )
    )
    item = result.scalar_one_or_none()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")

    commission = float(await get_setting(db, "sell_commission_percent")) / 100
    sell_price = round(item.floor_price * (1 - commission), 6)

    user.balance += sell_price
    
    tx = Transaction(
        user_id=user.id,
        type=TransactionType.SELL_GIFT,
        amount=sell_price,
        description=f"Sold: {item.collection_name} (commission {commission*100}%)",
    )
    db.add(tx)
    await db.delete(item)
    await db.commit()

    return {"success": True, "amount": sell_price, "balance": user.balance}

@router.post("/{item_id}/withdraw")
async def withdraw_gift(
    item_id: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(InventoryItem).where(
            InventoryItem.id == item_id,
            InventoryItem.user_id == user.id
        )
    )
    item = result.scalar_one_or_none()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")

    if item.is_locked:
        raise HTTPException(status_code=400, detail="Gift is locked (sell only)")

    now = datetime.utcnow()
    if item.withdraw_available_at and item.withdraw_available_at > now:
        raise HTTPException(status_code=400, detail="Withdraw not available yet")

    # Create withdraw request
    withdraw = WithdrawRequest(
        user_id=user.id,
        inventory_item_id=item.id,
        collection_name=item.collection_name,
        status=WithdrawStatus.PENDING,
    )
    db.add(withdraw)
    await db.commit()
    await db.refresh(withdraw)

    return {
        "success": True,
        "withdraw_id": withdraw.id,
        "status": "pending",
        "message": "⏳ Gifingiz yuborilmoqda..."
    }
