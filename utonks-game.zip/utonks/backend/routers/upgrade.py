from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..models.db import get_db
from ..models.database import User, Transaction, TransactionType, InventoryItem, GiftCollection, GiftSource
from ..services.auth import get_current_user
from ..services.settings import get_setting
from pydantic import BaseModel
from typing import List
from datetime import datetime

router = APIRouter(prefix="/upgrade", tags=["upgrade"])

class UpgradeRequest(BaseModel):
    inventory_ids: List[int]
    extra_ton: float = 0.0

@router.post("/start")
async def start_upgrade(
    data: UpgradeRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if not data.inventory_ids and data.extra_ton <= 0:
        raise HTTPException(status_code=400, detail="Add gifts or TON")

    total = data.extra_ton

    # Validate and collect inventory items
    items = []
    for item_id in data.inventory_ids:
        result = await db.execute(
            select(InventoryItem).where(
                InventoryItem.id == item_id,
                InventoryItem.user_id == user.id,
            )
        )
        item = result.scalar_one_or_none()
        if not item:
            raise HTTPException(status_code=404, detail=f"Item {item_id} not found")
        if item.is_locked:
            raise HTTPException(status_code=400, detail="Locked items cannot be upgraded")
        total += item.floor_price
        items.append(item)

    if total < 0.1:
        raise HTTPException(status_code=400, detail="Minimum upgrade value is 0.1 TON")

    # Deduct extra TON
    if data.extra_ton > 0:
        if user.balance < data.extra_ton:
            raise HTTPException(status_code=400, detail="Insufficient balance")
        user.balance -= data.extra_ton

    # Delete used inventory items
    for item in items:
        await db.delete(item)

    # Commission
    commission_pct = float(await get_setting(db, "upgrade_commission_percent")) / 100
    budget = total * (1 - commission_pct)

    # Find closest gift by floor price
    result = await db.execute(
        select(GiftCollection)
        .where(GiftCollection.is_active == True, GiftCollection.floor_price > 0)
        .order_by(
            (GiftCollection.floor_price - budget) * (GiftCollection.floor_price - budget)
        )
        .limit(10)
    )
    collections = result.scalars().all()

    if not collections:
        # Refund
        user.balance += budget
        await db.commit()
        raise HTTPException(status_code=400, detail="No suitable gift found, refunded")

    # Pick closest
    best = min(collections, key=lambda c: abs(c.floor_price - budget))
    change = round(budget - best.floor_price, 6)

    # Add to inventory
    new_item = InventoryItem(
        user_id=user.id,
        collection_id=best.id,
        collection_name=best.name,
        collection_image=best.image_url,
        floor_price=best.floor_price,
        source=GiftSource.UPGRADE,
        is_locked=False,
    )
    db.add(new_item)

    # Refund change
    if change > 0:
        user.balance += change

    tx = Transaction(
        user_id=user.id,
        type=TransactionType.UPGRADE,
        amount=-total,
        description=f"Upgrade → {best.name}",
    )
    db.add(tx)
    await db.commit()
    await db.refresh(new_item)

    return {
        "success": True,
        "gift": {
            "id": new_item.id,
            "collection_name": best.name,
            "collection_image": best.image_url,
            "floor_price": best.floor_price,
        },
        "change": max(change, 0),
        "commission": round(total * commission_pct, 6),
    }
