from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..models.db import get_db, AsyncSessionLocal
from ..models.database import User, Transaction, TransactionType, InventoryItem
from ..services.auth import get_current_user, verify_telegram_webapp
from ..services.crash_engine import crash_engine
from ..services.settings import get_setting
import json

router = APIRouter(prefix="/crash", tags=["crash"])

@router.websocket("/ws")
async def crash_websocket(websocket: WebSocket):
    await websocket.accept()
    crash_engine.connections.append(websocket)
    crash_engine.real_online += 1
    
    # Send current state
    await websocket.send_json({
        "type": "state",
        "game_state": crash_engine.game_state,
        "multiplier": crash_engine.multiplier,
        "history": crash_engine.history[-6:],
        "online": crash_engine.get_fake_online_count(),
    })
    
    try:
        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)
            
            if msg["type"] == "ping":
                await websocket.send_json({"type": "pong"})
    except WebSocketDisconnect:
        pass
    finally:
        if websocket in crash_engine.connections:
            crash_engine.connections.remove(websocket)
        crash_engine.real_online = max(0, crash_engine.real_online - 1)

@router.post("/bet")
async def place_bet(
    amount: float,
    is_gift: bool = False,
    inventory_item_id: int = None,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if crash_engine.game_state != "betting":
        raise HTTPException(status_code=400, detail="Betting phase ended")

    if is_gift and inventory_item_id:
        # Gift bet
        result = await db.execute(
            select(InventoryItem).where(
                InventoryItem.id == inventory_item_id,
                InventoryItem.user_id == user.id,
            )
        )
        item = result.scalar_one_or_none()
        if not item:
            raise HTTPException(status_code=404, detail="Item not found")
        if item.is_locked:
            raise HTTPException(status_code=400, detail="Gift is locked")
        
        amount = item.floor_price
        await db.delete(item)
        await db.commit()
    else:
        if user.balance < amount:
            raise HTTPException(status_code=400, detail="Insufficient balance")
        if amount < 0.01:
            raise HTTPException(status_code=400, detail="Minimum bet is 0.01 TON")
        user.balance -= amount
        await db.commit()

    success = await crash_engine.place_bet(
        user_id=user.id,
        username=user.username or user.first_name,
        avatar=user.photo_url or "",
        amount=amount,
        is_gift=is_gift,
        inventory_item_id=inventory_item_id,
    )

    return {"success": success, "amount": amount}

@router.post("/cashout")
async def cashout(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    payout = await crash_engine.cashout(user.id)
    if payout is None:
        raise HTTPException(status_code=400, detail="Cannot cashout now")

    user.balance += payout
    
    tx = Transaction(
        user_id=user.id,
        type=TransactionType.BET_WIN,
        amount=payout,
        description=f"Crash cashout x{crash_engine.multiplier}",
    )
    db.add(tx)
    await db.commit()

    return {"success": True, "payout": payout, "multiplier": crash_engine.multiplier}

@router.get("/history")
async def get_history():
    return {"history": crash_engine.history[-20:]}
