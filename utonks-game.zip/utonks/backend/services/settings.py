from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..models.database import Settings

DEFAULTS = {
    "stars_to_ton_rate": "0.013",
    "min_deposit_stars": "50",
    "min_deposit_ton": "0.1",
    "deposit_bonus_ton_percent": "10",
    "deposit_bonus_crypto_percent": "10",
    "sell_commission_percent": "15",
    "upgrade_commission_percent": "5",
    "crash_house_edge": "0.05",
    "mines_house_edge": "0.05",
    "withdraw_lock_seconds": "3600",
    "fake_online_min": "50",
    "fake_online_max": "70",
    "referral_level1_percent": "10",
    "referral_level2_percent": "12",
    "referral_level3_percent": "14",
    "referral_level4_percent": "18",
    "referral_level2_min_ton": "25",
    "referral_level3_min_ton": "100",
    "referral_level4_min_ton": "500",
}

async def get_setting(db: AsyncSession, key: str) -> str:
    result = await db.execute(select(Settings).where(Settings.key == key))
    setting = result.scalar_one_or_none()
    if setting:
        return setting.value
    return DEFAULTS.get(key, "")

async def set_setting(db: AsyncSession, key: str, value: str):
    result = await db.execute(select(Settings).where(Settings.key == key))
    setting = result.scalar_one_or_none()
    if setting:
        setting.value = value
    else:
        db.add(Settings(key=key, value=value))
    await db.commit()

async def get_all_settings(db: AsyncSession) -> dict:
    result = await db.execute(select(Settings))
    settings = result.scalars().all()
    data = dict(DEFAULTS)
    for s in settings:
        data[s.key] = s.value
    return data
