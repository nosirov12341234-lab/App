import httpx
import os
from typing import Optional
import asyncio

TON_API_KEY = os.getenv("TON_API_KEY", "")
TON_API_BASE = "https://tonapi.io/v2"

headers = {
    "Authorization": f"Bearer {TON_API_KEY}",
    "Content-Type": "application/json"
}

async def get_all_gift_collections() -> list:
    """Get all gift collections from TON API"""
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(
                f"{TON_API_BASE}/gifts/collections",
                headers=headers
            )
            if response.status_code == 200:
                data = response.json()
                return data.get("collections", [])
    except Exception as e:
        print(f"TON API error: {e}")
    return []

async def get_collection_floor_price(collection_slug: str) -> Optional[float]:
    """Get floor price for a collection"""
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(
                f"{TON_API_BASE}/gifts/collections/{collection_slug}",
                headers=headers
            )
            if response.status_code == 200:
                data = response.json()
                floor_nanoton = data.get("floor_price", 0)
                return floor_nanoton / 1e9
    except Exception as e:
        print(f"TON API error: {e}")
    return None

async def get_collection_info(collection_slug: str) -> Optional[dict]:
    """Get collection info including image"""
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(
                f"{TON_API_BASE}/gifts/collections/{collection_slug}",
                headers=headers
            )
            if response.status_code == 200:
                return response.json()
    except Exception as e:
        print(f"TON API error: {e}")
    return None

async def sync_collections_to_db(db):
    """Sync TON API collections to database"""
    from sqlalchemy import select
    from ..models.database import GiftCollection
    from datetime import datetime

    collections = await get_all_gift_collections()
    for col in collections:
        slug = col.get("slug") or col.get("name", "").lower().replace(" ", "-")
        result = await db.execute(
            select(GiftCollection).where(GiftCollection.slug == slug)
        )
        existing = result.scalar_one_or_none()
        
        floor_nanoton = col.get("floor_price", 0)
        floor_ton = floor_nanoton / 1e9 if floor_nanoton else 0
        
        image_url = col.get("image") or col.get("cover_image") or ""
        
        if existing:
            existing.floor_price = floor_ton
            existing.image_url = image_url
            existing.last_updated = datetime.utcnow()
        else:
            new_col = GiftCollection(
                name=col.get("name", slug),
                slug=slug,
                image_url=image_url,
                floor_price=floor_ton,
                ton_api_id=col.get("id", ""),
            )
            db.add(new_col)
    
    await db.commit()
    return len(collections)
