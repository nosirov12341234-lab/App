import hashlib
import hmac
import json
import os
from urllib.parse import unquote, parse_qs
from fastapi import HTTPException, Header
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..models.database import User
import secrets
import string

BOT_TOKEN = os.getenv("BOT_TOKEN", "")

def verify_telegram_webapp(init_data: str) -> dict:
    """Verify Telegram WebApp initData"""
    parsed = {}
    for item in init_data.split("&"):
        if "=" in item:
            key, val = item.split("=", 1)
            parsed[key] = unquote(val)
    
    hash_value = parsed.pop("hash", "")
    
    data_check_string = "\n".join(
        f"{k}={v}" for k, v in sorted(parsed.items())
    )
    
    secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    expected_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
    
    if not hmac.compare_digest(expected_hash, hash_value):
        raise HTTPException(status_code=401, detail="Invalid Telegram data")
    
    user_data = json.loads(parsed.get("user", "{}"))
    return user_data

async def get_or_create_user(db: AsyncSession, tg_user: dict, ref_code: str = None) -> User:
    """Get existing user or create new one"""
    result = await db.execute(
        select(User).where(User.telegram_id == tg_user["id"])
    )
    user = result.scalar_one_or_none()
    
    if not user:
        # Generate referral code
        referral_code = "".join(
            secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8)
        )
        
        referred_by_id = None
        if ref_code:
            ref_result = await db.execute(
                select(User).where(User.referral_code == ref_code)
            )
            referrer = ref_result.scalar_one_or_none()
            if referrer:
                referred_by_id = referrer.id
        
        user = User(
            telegram_id=tg_user["id"],
            username=tg_user.get("username"),
            first_name=tg_user.get("first_name", "User"),
            photo_url=tg_user.get("photo_url"),
            referral_code=referral_code,
            referred_by=referred_by_id,
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)
    else:
        # Update user info
        user.username = tg_user.get("username", user.username)
        user.first_name = tg_user.get("first_name", user.first_name)
        await db.commit()
    
    return user

async def get_current_user(
    authorization: str = Header(...),
    db: AsyncSession = None
) -> User:
    """FastAPI dependency to get current user from Telegram WebApp token"""
    if not authorization.startswith("tma "):
        raise HTTPException(status_code=401, detail="Invalid authorization")
    
    init_data = authorization[4:]
    tg_user = verify_telegram_webapp(init_data)
    user = await get_or_create_user(db, tg_user)
    
    if user.is_banned:
        raise HTTPException(status_code=403, detail="User is banned")
    
    return user
