import asyncio
import random
import math
import time
from typing import Dict, List, Optional
from datetime import datetime
import json

# Fake bot names for manipulation
FAKE_BOTS = [
    {"username": "CryptoWolf", "avatar": "🐺"},
    {"username": "TON_Hunter", "avatar": "🎯"},
    {"username": "GiftKing", "avatar": "👑"},
    {"username": "StarPlayer", "avatar": "⭐"},
    {"username": "RocketMan", "avatar": "🚀"},
    {"username": "DiamondHands", "avatar": "💎"},
    {"username": "MoonShot", "avatar": "🌙"},
    {"username": "TonWhale", "avatar": "🐋"},
]

class CrashGameEngine:
    def __init__(self):
        self.current_game = None
        self.game_state = "waiting"  # waiting, betting, running, crashed
        self.multiplier = 1.0
        self.crash_point = 1.0
        self.bets: Dict = {}
        self.fake_bets: Dict = {}
        self.start_time = None
        self.connections: List = []
        self.online_count = 0
        self.real_online = 0
        
        # Game history (last 6 crash points)
        self.history: List[float] = [1.01, 3.16, 1.64, 10.19, 1.08, 1.07]

    def generate_crash_point(self, house_edge: float = 0.05, honeymoon: bool = False) -> float:
        """Generate crash point with house edge"""
        if honeymoon:
            # New user mode - high crash points
            return round(random.uniform(8.0, 25.0), 2)
        
        r = random.random()
        # House edge formula
        if r < house_edge:
            return round(random.uniform(1.0, 1.5), 2)
        
        # Normal distribution with occasional big wins
        crash = (1 - house_edge) / (1 - r)
        return round(min(crash, 100.0), 2)

    def get_fake_online_count(self) -> int:
        """Returns fake online count if real < 50"""
        if self.real_online < 50:
            base = random.randint(50, 70)
            variation = random.randint(-5, 5)
            return base + variation
        return self.real_online

    def should_add_fake_bets(self) -> bool:
        """Add fake bets if no real bets"""
        real_bet_count = len([b for b in self.bets.values() if not b.get("is_fake")])
        return real_bet_count == 0

    def generate_fake_bets(self, crash_point: float) -> List[dict]:
        """Generate fake bets for manipulation"""
        fake_bets = []
        num_fakes = random.randint(2, 5)
        
        for i in range(num_fakes):
            bot = random.choice(FAKE_BOTS)
            amount = round(random.uniform(0.5, 30.0), 2)
            
            # Fake bots cash out before crash
            cashout_at = round(random.uniform(1.5, crash_point * 0.9), 2)
            
            fake_bets.append({
                "username": bot["username"],
                "avatar": bot["avatar"],
                "amount": amount,
                "cashout_at": cashout_at,
                "is_fake": True,
                "cashed_out": False,
            })
        
        return fake_bets

    def calculate_multiplier(self, elapsed_ms: float) -> float:
        """Calculate current multiplier based on elapsed time"""
        return round(math.pow(math.e, 0.00006 * elapsed_ms), 2)

    async def broadcast(self, message: dict):
        """Send message to all connected clients"""
        if not self.connections:
            return
        dead = []
        for ws in self.connections:
            try:
                await ws.send_json(message)
            except:
                dead.append(ws)
        for ws in dead:
            self.connections.remove(ws)

    async def run_game_loop(self, db_session_factory, settings_getter):
        """Main game loop"""
        while True:
            try:
                await self._run_single_game(db_session_factory, settings_getter)
            except Exception as e:
                print(f"Crash game error: {e}")
                await asyncio.sleep(3)

    async def _run_single_game(self, db_session_factory, settings_getter):
        """Run a single crash game"""
        # BETTING PHASE (5 seconds)
        self.game_state = "betting"
        self.bets = {}
        self.fake_bets = {}
        self.multiplier = 1.0

        # Get settings
        house_edge = float(await settings_getter("crash_house_edge") or 0.05)
        
        # Generate crash point
        self.crash_point = self.generate_crash_point(house_edge)

        await self.broadcast({
            "type": "betting_phase",
            "duration": 5000,
            "online": self.get_fake_online_count(),
            "history": self.history[-6:],
        })

        await asyncio.sleep(5)

        # Add fake bets if needed
        if self.should_add_fake_bets():
            self.fake_bets = {
                f"fake_{i}": bet 
                for i, bet in enumerate(self.generate_fake_bets(self.crash_point))
            }

        all_bets = {**self.bets, **self.fake_bets}
        await self.broadcast({
            "type": "game_started",
            "bets": [
                {
                    "username": b["username"],
                    "avatar": b.get("avatar", ""),
                    "amount": b["amount"],
                    "is_gift": b.get("is_gift", False),
                }
                for b in all_bets.values()
            ]
        })

        # RUNNING PHASE
        self.game_state = "running"
        self.start_time = time.time() * 1000

        while True:
            elapsed = time.time() * 1000 - self.start_time
            self.multiplier = self.calculate_multiplier(elapsed)

            # Check fake bot cashouts
            for bet_id, bet in self.fake_bets.items():
                if not bet["cashed_out"] and self.multiplier >= bet["cashout_at"]:
                    bet["cashed_out"] = True
                    await self.broadcast({
                        "type": "cashout",
                        "username": bet["username"],
                        "multiplier": self.multiplier,
                        "amount": round(bet["amount"] * self.multiplier, 3),
                        "is_fake": True,
                    })

            await self.broadcast({
                "type": "tick",
                "multiplier": self.multiplier,
                "online": self.get_fake_online_count(),
            })

            if self.multiplier >= self.crash_point:
                break

            await asyncio.sleep(0.1)

        # CRASHED
        self.game_state = "crashed"
        self.history.append(self.crash_point)
        if len(self.history) > 10:
            self.history.pop(0)

        await self.broadcast({
            "type": "crashed",
            "crash_point": self.crash_point,
            "history": self.history[-6:],
        })

        # Save game to DB
        async with db_session_factory() as db:
            from ..models.database import CrashGame, CrashBet, Transaction, TransactionType
            from sqlalchemy import select

            game = CrashGame(
                crash_point=self.crash_point,
                started_at=datetime.fromtimestamp(self.start_time / 1000),
                ended_at=datetime.utcnow(),
            )
            db.add(game)
            await db.flush()

            # Process real bets - losers
            for user_id, bet in self.bets.items():
                if not bet.get("cashed_out"):
                    tx = Transaction(
                        user_id=int(user_id),
                        type=TransactionType.BET_LOSE,
                        amount=-bet["amount"],
                        description=f"Crash x{self.crash_point} - lose",
                    )
                    db.add(tx)

            await db.commit()

        await asyncio.sleep(3)

    async def place_bet(self, user_id: int, username: str, avatar: str, amount: float, 
                        is_gift: bool = False, inventory_item_id: int = None) -> bool:
        """Place a real bet"""
        if self.game_state != "betting":
            return False
        
        self.bets[str(user_id)] = {
            "username": username,
            "avatar": avatar,
            "amount": amount,
            "is_gift": is_gift,
            "inventory_item_id": inventory_item_id,
            "cashed_out": False,
            "is_fake": False,
        }
        return True

    async def cashout(self, user_id: int) -> Optional[float]:
        """Cash out current bet"""
        if self.game_state != "running":
            return None
        
        bet = self.bets.get(str(user_id))
        if not bet or bet.get("cashed_out"):
            return None
        
        bet["cashed_out"] = True
        bet["cashout_multiplier"] = self.multiplier
        payout = round(bet["amount"] * self.multiplier, 6)
        bet["payout"] = payout

        await self.broadcast({
            "type": "cashout",
            "username": bet["username"],
            "multiplier": self.multiplier,
            "amount": payout,
            "is_fake": False,
        })

        return payout


# Global game engine instance
crash_engine = CrashGameEngine()
