import React, { useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { TonConnectUIProvider } from "@tonconnect/ui-react";
import { useStore } from "./utils/store";
import BottomNav from "./components/ui/BottomNav";
import Header from "./components/ui/Header";
import GamesPage from "./pages/GamesPage";
import InventoryPage from "./pages/InventoryPage";
import ProfilePage from "./pages/ProfilePage";
import CrashPage from "./pages/CrashPage";
import MinesPage from "./pages/MinesPage";
import CasesPage from "./pages/CasesPage";
import UpgradePage from "./pages/UpgradePage";
import AdminPage from "./pages/AdminPage";

const MANIFEST_URL = import.meta.env.VITE_TON_MANIFEST || "https://utonks.com/tonconnect-manifest.json";

export default function App() {
  const { fetchUser, fetchInventory, user, setLoading } = useStore();

  useEffect(() => {
    window.Telegram?.WebApp?.ready();
    window.Telegram?.WebApp?.expand();
    window.Telegram?.WebApp?.setHeaderColor("#0D0B1A");
    window.Telegram?.WebApp?.setBackgroundColor("#0D0B1A");

    const init = async () => {
      await fetchUser();
      await fetchInventory();
      setLoading(false);
    };
    init();
  }, []);

  return (
    <TonConnectUIProvider manifestUrl={MANIFEST_URL}>
      <BrowserRouter>
        <div className="flex flex-col min-h-screen bg-bg-primary">
          <Header />
          <main className="flex-1 pb-20">
            <Routes>
              <Route path="/" element={<Navigate to="/games" replace />} />
              <Route path="/games" element={<GamesPage />} />
              <Route path="/games/crash" element={<CrashPage />} />
              <Route path="/games/mines" element={<MinesPage />} />
              <Route path="/games/cases" element={<CasesPage />} />
              <Route path="/games/upgrade" element={<UpgradePage />} />
              <Route path="/inventory" element={<InventoryPage />} />
              <Route path="/profile" element={<ProfilePage />} />
              {user?.is_admin && <Route path="/admin/*" element={<AdminPage />} />}
            </Routes>
          </main>
          <BottomNav />
        </div>
      </BrowserRouter>
    </TonConnectUIProvider>
  );
}
