import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useStore } from "../../utils/store";

const navItems = [
  {
    path: "/inventory",
    label: "Inventory",
    icon: (active) => (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <rect x="2" y="3" width="9" height="9" rx="2" fill={active ? "#3B6EF8" : "#ffffff40"} />
        <rect x="13" y="3" width="9" height="9" rx="2" fill={active ? "#3B6EF8" : "#ffffff40"} />
        <rect x="2" y="14" width="9" height="9" rx="2" fill={active ? "#3B6EF8" : "#ffffff40"} />
        <rect x="13" y="14" width="9" height="9" rx="2" fill={active ? "#3B6EF8" : "#ffffff40"} />
      </svg>
    ),
  },
  {
    path: "/games",
    label: "Games",
    icon: (active) => (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <rect x="2" y="7" width="20" height="14" rx="3" fill={active ? "#3B6EF8" : "#ffffff40"} />
        <circle cx="8" cy="14" r="2" fill={active ? "white" : "#ffffff60"} />
        <circle cx="16" cy="14" r="2" fill={active ? "white" : "#ffffff60"} />
        <path d="M12 3L15 7H9L12 3Z" fill={active ? "#3B6EF8" : "#ffffff40"} />
      </svg>
    ),
  },
  {
    path: "/profile",
    label: "Profile",
    icon: (active) => (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="8" r="4" fill={active ? "#3B6EF8" : "#ffffff40"} />
        <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" stroke={active ? "#3B6EF8" : "#ffffff40"} strokeWidth="2" strokeLinecap="round" />
        <rect x="8" y="18" width="8" height="2" rx="1" fill={active ? "#3B6EF8" : "#ffffff40"} />
      </svg>
    ),
  },
];

export default function BottomNav() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { user } = useStore();

  const isActive = (path) => pathname.startsWith(path);

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-bg-secondary/95 backdrop-blur border-t border-white/5">
      <div className="flex items-center justify-around px-4 py-2 pb-safe">
        {navItems.map((item) => {
          const active = isActive(item.path);
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="flex flex-col items-center gap-1 py-2 px-6 rounded-2xl transition-all active:scale-90"
            >
              {item.icon(active)}
              <span className={`text-xs font-medium transition-colors ${active ? "text-accent-blue" : "text-white/40"}`}>
                {item.label}
              </span>
              {active && (
                <div className="w-1 h-1 rounded-full bg-accent-blue" />
              )}
            </button>
          );
        })}

        {user?.is_admin && (
          <button
            onClick={() => navigate("/admin")}
            className="flex flex-col items-center gap-1 py-2 px-4 rounded-2xl transition-all active:scale-90"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L3 7v5c0 5.25 3.75 10.15 9 11.35C17.25 22.15 21 17.25 21 12V7L12 2z" fill={isActive("/admin") ? "#FFB800" : "#ffffff40"} />
              <path d="M9 12l2 2 4-4" stroke="white" strokeWidth="2" strokeLinecap="round" />
            </svg>
            <span className={`text-xs font-medium ${isActive("/admin") ? "text-accent-gold" : "text-white/40"}`}>
              Admin
            </span>
          </button>
        )}
      </div>
    </nav>
  );
}
