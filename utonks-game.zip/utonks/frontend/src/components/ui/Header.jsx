import React, { useState } from "react";
import { useStore } from "../../utils/store";
import DepositModal from "./DepositModal";

export default function Header() {
  const { user } = useStore();
  const [showDeposit, setShowDeposit] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-40 px-4 py-3 flex items-center justify-between bg-bg-primary/95 backdrop-blur border-b border-white/5">
        {/* User info */}
        <div className="flex items-center gap-3 bg-bg-card rounded-2xl px-3 py-2">
          {user?.photo_url ? (
            <img src={user.photo_url} className="w-8 h-8 rounded-full object-cover" />
          ) : (
            <div className="w-8 h-8 rounded-full bg-accent-purple flex items-center justify-center text-xs font-bold">
              {user?.first_name?.[0] || "U"}
            </div>
          )}
          <div>
            <p className="text-sm font-semibold text-white leading-none">
              {user?.first_name || "Loading..."}
            </p>
            <p className="text-xs text-white/40">Level {user?.level || 1}</p>
          </div>
        </div>

        {/* Balance */}
        <button
          onClick={() => setShowDeposit(true)}
          className="flex items-center gap-2 bg-bg-card rounded-2xl px-3 py-2 active:scale-95 transition-transform"
        >
          <TonIcon />
          <span className="text-sm font-bold text-white">
            {user?.balance?.toFixed(2) || "0.00"}
          </span>
          <div className="w-6 h-6 rounded-full bg-accent-blue flex items-center justify-center">
            <span className="text-xs font-bold">+</span>
          </div>
        </button>
      </header>

      {showDeposit && <DepositModal onClose={() => setShowDeposit(false)} />}
    </>
  );
}

function TonIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 56 56" fill="none">
      <circle cx="28" cy="28" r="28" fill="#0098EA" />
      <path d="M18.1 15.2h19.8c1.4 0 2.2 1.6 1.4 2.8L28 40.8 16.7 18c-.8-1.2 0-2.8 1.4-2.8z" fill="white" />
    </svg>
  );
}
