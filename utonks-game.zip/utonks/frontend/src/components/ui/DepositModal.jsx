import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import api from "../../utils/api";
import { useStore } from "../../utils/store";
import { useTonConnectUI } from "@tonconnect/ui-react";

const TABS = ["Stars", "TON", "Gifts"];

export default function DepositModal({ onClose }) {
  const [tab, setTab] = useState("TON");
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const { fetchUser } = useStore();
  const [tonConnectUI] = useTonConnectUI();

  const handleTonDeposit = async () => {
    if (!amount || parseFloat(amount) <= 0) return;
    setLoading(true);
    try {
      const res = await api.post(`/user/deposit/ton?amount=${amount}`);
      const { wallet, memo, amount: amt } = res.data;
      await tonConnectUI.sendTransaction({
        validUntil: Math.floor(Date.now() / 1000) + 600,
        messages: [
          {
            address: wallet,
            amount: String(Math.floor(amt * 1e9)),
            payload: btoa(memo),
          },
        ],
      });
      await fetchUser();
      onClose();
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  const handleStarsDeposit = async () => {
    if (!amount) return;
    setLoading(true);
    try {
      const res = await api.post(`/user/deposit/stars?stars_amount=${amount}`);
      window.Telegram?.WebApp?.openInvoice?.(res.data.invoice_url, (status) => {
        if (status === "paid") {
          fetchUser();
          onClose();
        }
      });
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div
          initial={{ y: "100%" }}
          animate={{ y: 0 }}
          exit={{ y: "100%" }}
          transition={{ type: "spring", damping: 25 }}
          className="w-full bg-bg-secondary rounded-t-3xl p-6 pb-10"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Handle */}
          <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-6" />

          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold font-display tracking-wider">DEPOSIT</h2>
            <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/60">✕</button>
          </div>

          {/* Tabs */}
          <div className="flex gap-3 mb-6">
            {TABS.map((t) => {
              const active = tab === t;
              const hasBadge = t === "TON" || t === "Crypto";
              return (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={`flex-1 relative flex flex-col items-center gap-1 py-3 rounded-2xl border transition-all ${
                    active
                      ? "bg-accent-blue border-accent-blue"
                      : "bg-bg-card border-white/10"
                  }`}
                >
                  {hasBadge && (
                    <span className="absolute -top-2 left-1/2 -translate-x-1/2 bg-accent-green text-black text-xs font-bold px-2 py-0.5 rounded-full">
                      +10%
                    </span>
                  )}
                  <TabIcon type={t} active={active} />
                  <span className="text-xs font-medium">{t}</span>
                </button>
              );
            })}
          </div>

          {/* Content */}
          {tab === "TON" && (
            <div className="space-y-4">
              <div className="bg-bg-card rounded-2xl px-4 py-3 flex items-center gap-3">
                <TonIcon />
                <input
                  type="number"
                  placeholder="0.1 TON"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="flex-1 bg-transparent text-white text-lg outline-none"
                />
              </div>
              <p className="text-center text-xs text-white/40">MIN. AMOUNT: 0.1 TON</p>
              {amount && (
                <div className="bg-accent-green/10 border border-accent-green/30 rounded-xl px-4 py-2 text-center">
                  <p className="text-accent-green text-sm">+10% bonus = +{(parseFloat(amount || 0) * 0.1).toFixed(3)} TON</p>
                </div>
              )}
              <div className="flex gap-3">
                <button onClick={onClose} className="flex-1 py-4 rounded-2xl bg-bg-card text-white font-semibold">Cancel</button>
                <button
                  onClick={handleTonDeposit}
                  disabled={loading}
                  className="flex-1 py-4 rounded-2xl bg-accent-blue text-white font-bold disabled:opacity-50"
                >
                  {loading ? "..." : "Deposit"}
                </button>
              </div>
            </div>
          )}

          {tab === "Stars" && (
            <div className="space-y-4">
              <div className="bg-bg-card rounded-2xl px-4 py-3 flex items-center gap-3">
                <span className="text-2xl">⭐</span>
                <input
                  type="number"
                  placeholder="50 Stars"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="flex-1 bg-transparent text-white text-lg outline-none"
                />
              </div>
              <p className="text-center text-xs text-white/40">MIN. AMOUNT: 50 Stars</p>
              <div className="flex gap-3">
                <button onClick={onClose} className="flex-1 py-4 rounded-2xl bg-bg-card text-white font-semibold">Cancel</button>
                <button
                  onClick={handleStarsDeposit}
                  disabled={loading}
                  className="flex-1 py-4 rounded-2xl bg-accent-blue text-white font-bold disabled:opacity-50"
                >
                  {loading ? "..." : "Deposit"}
                </button>
              </div>
            </div>
          )}

          {tab === "Gifts" && (
            <div className="space-y-4">
              <div className="bg-bg-card rounded-2xl p-4 text-center">
                <p className="text-white/60 text-sm mb-2">Gift yuboring va balansga TON tushsin</p>
                <p className="text-white/40 text-xs">Narx: Fragment floor price bo'yicha</p>
              </div>
              <button className="w-full py-4 rounded-2xl bg-accent-blue text-white font-bold flex items-center justify-center gap-2">
                <span>🎁</span> Send gifts
              </button>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

function TabIcon({ type, active }) {
  const color = active ? "white" : "rgba(255,255,255,0.5)";
  if (type === "Stars") return <span className="text-xl">⭐</span>;
  if (type === "TON") return <TonIcon size={20} />;
  if (type === "Gifts") return <span className="text-xl">🎁</span>;
}

function TonIcon({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 56 56" fill="none">
      <circle cx="28" cy="28" r="28" fill="#0098EA" />
      <path d="M18.1 15.2h19.8c1.4 0 2.2 1.6 1.4 2.8L28 40.8 16.7 18c-.8-1.2 0-2.8 1.4-2.8z" fill="white" />
    </svg>
  );
}
