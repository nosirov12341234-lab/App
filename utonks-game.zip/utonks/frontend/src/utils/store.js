import { create } from "zustand";
import api from "./api";

export const useStore = create((set, get) => ({
  user: null,
  inventory: [],
  loading: true,

  fetchUser: async () => {
    try {
      const res = await api.get("/user/me");
      set({ user: res.data });
    } catch (e) {
      console.error(e);
    }
  },

  fetchInventory: async () => {
    try {
      const res = await api.get("/inventory/");
      set({ inventory: res.data });
    } catch (e) {
      console.error(e);
    }
  },

  setLoading: (loading) => set({ loading }),
}));
