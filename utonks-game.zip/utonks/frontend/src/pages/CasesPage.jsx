import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useSearchParams } from "react-router-dom";
import api from "../utils/api";
import { useStore } from "../utils/store";

export default function CasesPage() {
  const [cases, setCases] = useState([]);
  const [opening, setOpening] = useState(false);
  const [result, setResult] = useState(null);
  const [showPromo, setShowPromo] = useState(false);
  const [promoCode, setPromoCode] = useState("");
  const [promoLoading, setPromoLoading] = useState(false);
  const [promoResult, setPromoResult] = useState(null);
  const [searchParams] = useSearchParams();
  const { fetchUser, fetchInventory } = useStore();

  useEffect(() => {
    api.get("/cases/").then((r) => setCases(r.data));
    if (searchParams.get("tab") === "promo") setShowPromo(true);
  }, []);

  const openCase = async (caseItem, method = "ton") => {
    setOpening(true);
    setResult(null);
    try {
      const res = await api.post(`/cases/${caseItem.id}/open?payment_method=${method}`);
      // Animate spin
      await new Promise((r) => setTimeout(r, 2000));
      setResult(res.data.gift);
      await fetchUser();
      await fetchInventory();
    } catch (e) {
      alert(e.response?.data?.detail || "Error");
    }
    setOpening(false);
  };

  const usePromo = async () => {
    if (!promoCode.trim()) return;
    setPromoLoading(true);
    try {
      const res = await api.post(`/user/promocode?code=${promoCode}`);
      setPromoResult(res.data.reward);
      await fetchUser();
      await fetchInventory();
    } catch (e) {
      alert(e.response?.data?.detail || "Invalid code");
    }
    setPromoLoading(false);
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <h1 className="text-2xl font-black font-display">📦 CASES</h1>

      {/* Promo + Daily tabs */}
      <div className="flex gap-2">
        <button
          onClick={() => setShowPromo(!showPromo)}
          className={`flex-1 py-2 rounded-xl text-sm font-semibold transition-all ${showPromo ? "bg-accent-blue text-white" : "bg-bg-card text-white/60"}`}
        >
          🎫 Promocode
        </button>
        <button className="flex-1 py-2 rounded-xl bg-bg-card text-white/60 text-sm font-semibold">
          🎁 Daily Case
        </button>
      </div>

      {/* Promocode panel */}
      <AnimatePresence>
        {showPromo && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-bg-card rounded-2xl p-4 space-y-3"
          >
            <p className="text-white/60 text-sm">Promocode kiriting</p>
            <div className="flex gap-2">
              <input
                type="text"
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                placeholder="UTONKS2025"
                className="flex-1 bg-bg-elevated rounded-xl px-4 py-3 text-white outline-none font-mono tracking-widest"
              />
              <button
                onClick={usePromo}
                disabled={promoLoading}
                className="px-4 py-3 bg-accent-blue rounded-xl text-white font-bold disabled:opacity-50"
              >
                {promoLoading ? "..." : "✓"}
              </button>
            </div>
            {promoResult && (
              <motion.div
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-accent-green/20 border border-accent-green/40 rounded-xl p-3 text-center"
              >
                <p className="text-accent-green font-bold">🎉 Bonus olindi!</p>
                {promoResult.type === "ton" && <p className="text-sm text-white/60">+{promoResult.amount} TON</p>}
                {promoResult.type === "gift" && <p className="text-sm text-white/60">{promoResult.collection}</p>}
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Cases grid */}
      <div className="space-y-3">
        {cases.map((c, i) => (
          <motion.div
            key={c.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-bg-card rounded-2xl p-4"
          >
            {/* Case header */}
            <div className="flex items-center gap-4 mb-4">
              <div className="w-20 h-20 rounded-2xl bg-bg-elevated overflow-hidden flex-shrink-0">
                {c.image_url ? (
                  <img src={c.image_url} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-4xl">📦</div>
                )}
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-white text-lg">{c.name}</h3>
                <div className="flex gap-2 mt-1">
                  {c.price_ton && (
                    <span className="text-xs bg-ton/20 text-ton px-2 py-1 rounded-lg font-bold">
                      {c.price_ton} TON
                    </span>
                  )}
                  {c.price_stars && (
                    <span className="text-xs bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded-lg font-bold">
                      ⭐ {c.price_stars}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Possible gifts */}
            <div className="mb-4">
              <p className="text-white/40 text-xs mb-2">Mumkin bo'lgan giftlar:</p>
              <div className="grid grid-cols-3 gap-2">
                {c.items?.slice(0, 6).map((item, j) => (
                  <div key={j} className="bg-bg-elevated rounded-xl p-2 text-center">
                    <div className="w-10 h-10 mx-auto rounded-lg overflow-hidden mb-1">
                      {item.collection_image ? (
                        <img src={item.collection_image} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full bg-bg-card flex items-center justify-center text-xl">🎁</div>
                      )}
                    </div>
                    <p className="text-white text-xs font-medium truncate">{item.collection_name}</p>
                    <p className="text-white/40 text-xs">{(item.probability * 100).toFixed(0)}%</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Open buttons */}
            <div className="flex gap-2">
              {c.price_ton && (
                <button
                  onClick={() => openCase(c, "ton")}
                  disabled={opening}
                  className="flex-1 py-3 rounded-xl bg-accent-blue text-white font-bold text-sm active:scale-95 transition-all disabled:opacity-50"
                >
                  {opening ? "Ochilmoqda..." : `${c.price_ton} TON`}
                </button>
              )}
              {c.price_stars && (
                <button
                  onClick={() => openCase(c, "stars")}
                  disabled={opening}
                  className="flex-1 py-3 rounded-xl bg-yellow-500/20 border border-yellow-500/40 text-yellow-400 font-bold text-sm active:scale-95 transition-all disabled:opacity-50"
                >
                  ⭐ {c.price_stars}
                </button>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Opening animation modal */}
      <AnimatePresence>
        {(opening || result) && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur flex items-center justify-center"
          >
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.5, opacity: 0 }}
              className="bg-bg-card rounded-3xl p-8 mx-6 text-center space-y-4"
            >
              {opening && !result && (
                <>
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 0.5, repeat: Infinity, ease: "linear" }}
                    className="text-6xl mx-auto w-fit"
                  >
                    📦
                  </motion.div>
                  <p className="text-white font-bold text-xl">Ochilmoqda...</p>
                </>
              )}
              {result && (
                <>
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: [0, 1.2, 1] }}
                    transition={{ duration: 0.5 }}
                    className="w-32 h-32 mx-auto rounded-2xl overflow-hidden"
                  >
                    {result.collection_image ? (
                      <img src={result.collection_image} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-bg-elevated flex items-center justify-center text-6xl">🎁</div>
                    )}
                  </motion.div>
                  <div>
                    <p className="text-accent-gold font-black text-2xl font-display">YUTDINGIZ!</p>
                    <p className="text-white font-bold text-xl mt-1">{result.collection_name}</p>
                    <p className="text-white/60 text-sm">{result.floor_price} TON</p>
                    {result.is_locked && (
                      <p className="text-yellow-400 text-xs mt-2">🔒 Faqat Sell qilish mumkin</p>
                    )}
                  </div>
                  <button
                    onClick={() => setResult(null)}
                    className="w-full py-3 rounded-xl bg-accent-blue text-white font-bold"
                  >
                    Yaxshi!
                  </button>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
