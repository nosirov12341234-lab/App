import React, { useState } from "react";
import { motion } from "framer-motion";
import api from "../utils/api";
import { useStore } from "../utils/store";

const GRID_SIZE = 25;

export default function MinesPage() {
  const { user, fetchUser } = useStore();
  const [gameActive, setGameActive] = useState(false);
  const [cells, setCells] = useState(Array(GRID_SIZE).fill(null)); // null | "gem" | "mine"
  const [revealed, setRevealed] = useState(Array(GRID_SIZE).fill(false));
  const [betAmount, setBetAmount] = useState("0.1");
  const [minesCount, setMinesCount] = useState(3);
  const [multiplier, setMultiplier] = useState(1.0);
  const [gameOver, setGameOver] = useState(false);
  const [won, setWon] = useState(false);
  const [gameId, setGameId] = useState(null);

  const startGame = async () => {
    try {
      const res = await api.post(`/mines/start?amount=${betAmount}&mines=${minesCount}`);
      setGameId(res.data.game_id);
      setGameActive(true);
      setGameOver(false);
      setWon(false);
      setCells(Array(GRID_SIZE).fill(null));
      setRevealed(Array(GRID_SIZE).fill(false));
      setMultiplier(1.0);
      await fetchUser();
    } catch (e) {
      alert(e.response?.data?.detail || "Error");
    }
  };

  const revealCell = async (index) => {
    if (!gameActive || revealed[index] || gameOver) return;
    try {
      const res = await api.post(`/mines/reveal?game_id=${gameId}&cell=${index}`);
      const newRevealed = [...revealed];
      newRevealed[index] = true;
      setRevealed(newRevealed);

      if (res.data.is_mine) {
        const newCells = [...cells];
        newCells[index] = "mine";
        // Show all mines
        res.data.all_mines?.forEach((mi) => { newCells[mi] = "mine"; });
        setCells(newCells);
        setGameOver(true);
        setGameActive(false);
        setWon(false);
      } else {
        const newCells = [...cells];
        newCells[index] = "gem";
        setCells(newCells);
        setMultiplier(res.data.multiplier);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const cashout = async () => {
    if (!gameActive || gameOver) return;
    try {
      const res = await api.post(`/mines/cashout?game_id=${gameId}`);
      setGameActive(false);
      setWon(true);
      setGameOver(true);
      await fetchUser();
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="px-4 py-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-black font-display text-white">💣 MINES</h1>
        {gameActive && (
          <div className="bg-accent-green/20 border border-accent-green/40 rounded-xl px-3 py-1">
            <span className="text-accent-green font-bold">{multiplier.toFixed(2)}x</span>
          </div>
        )}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-5 gap-2">
        {Array(GRID_SIZE).fill(null).map((_, i) => {
          const isRevealed = revealed[i];
          const cellType = cells[i];
          return (
            <motion.button
              key={i}
              whileTap={{ scale: 0.9 }}
              onClick={() => revealCell(i)}
              className={`aspect-square rounded-xl flex items-center justify-center text-2xl transition-all ${
                !isRevealed
                  ? "bg-bg-card border border-white/10 active:bg-bg-elevated"
                  : cellType === "gem"
                  ? "bg-accent-blue/20 border border-accent-blue/50"
                  : cellType === "mine"
                  ? "bg-red-500/20 border border-red-500/50"
                  : "bg-bg-card"
              }`}
            >
              {isRevealed && cellType === "gem" && "💎"}
              {isRevealed && cellType === "mine" && "💣"}
              {!isRevealed && gameOver && cells[i] === "mine" && "💣"}
            </motion.button>
          );
        })}
      </div>

      {/* Result overlay */}
      {gameOver && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`rounded-2xl p-4 text-center ${
            won ? "bg-accent-green/20 border border-accent-green/40" : "bg-red-500/20 border border-red-500/40"
          }`}
        >
          <p className="text-lg font-bold">{won ? "🎉 Yutdingiz!" : "💥 Yutqazdingiz!"}</p>
          {won && <p className="text-sm text-white/60">{(parseFloat(betAmount) * multiplier).toFixed(3)} TON</p>}
        </motion.div>
      )}

      {/* Controls */}
      <div className="bg-bg-card rounded-2xl p-4 space-y-4">
        {!gameActive && (
          <>
            <div className="space-y-2">
              <label className="text-white/60 text-sm">Bet miqdori (TON)</label>
              <div className="flex items-center gap-2 bg-bg-elevated rounded-xl px-3 py-2">
                <TonIcon />
                <input
                  type="number"
                  value={betAmount}
                  onChange={(e) => setBetAmount(e.target.value)}
                  className="flex-1 bg-transparent text-white outline-none"
                  min="0.01"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-white/60 text-sm">Minalar soni: {minesCount}</label>
              <input
                type="range"
                min="1"
                max="20"
                value={minesCount}
                onChange={(e) => setMinesCount(parseInt(e.target.value))}
                className="w-full accent-accent-blue"
              />
              <div className="flex justify-between text-xs text-white/40">
                <span>1 (xavfsiz)</span>
                <span>20 (xavfli)</span>
              </div>
            </div>
            <button
              onClick={startGame}
              className="w-full py-4 rounded-xl bg-accent-blue text-white font-bold text-lg active:scale-95 transition-transform"
            >
              O'ynash
            </button>
          </>
        )}

        {gameActive && !gameOver && (
          <button
            onClick={cashout}
            className="w-full py-4 rounded-xl bg-accent-green text-black font-bold text-lg active:scale-95 transition-transform animate-pulse"
          >
            Cash Out {(parseFloat(betAmount) * multiplier).toFixed(3)} TON
          </button>
        )}

        {gameOver && (
          <button
            onClick={() => { setGameOver(false); setGameActive(false); }}
            className="w-full py-4 rounded-xl bg-accent-blue text-white font-bold text-lg active:scale-95 transition-transform"
          >
            Qaytadan
          </button>
        )}
      </div>
    </div>
  );
}

function TonIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 56 56" fill="none">
      <circle cx="28" cy="28" r="28" fill="#0098EA" />
      <path d="M18.1 15.2h19.8c1.4 0 2.2 1.6 1.4 2.8L28 40.8 16.7 18c-.8-1.2 0-2.8 1.4-2.8z" fill="white" />
    </svg>
  );
}
