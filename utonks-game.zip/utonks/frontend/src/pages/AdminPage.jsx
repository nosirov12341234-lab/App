import React, { useEffect, useState } from "react";
import { Routes, Route, useNavigate, useLocation } from "react-router-dom";
import api from "../utils/api";

export default function AdminPage() {
  return (
    <Routes>
      <Route path="/" element={<AdminHome />} />
      <Route path="/cases" element={<AdminCases />} />
      <Route path="/settings" element={<AdminSettings />} />
      <Route path="/users" element={<AdminUsers />} />
      <Route path="/withdrawals" element={<AdminWithdrawals />} />
      <Route path="/promocodes" element={<AdminPromocodes />} />
    </Routes>
  );
}

function AdminHome() {
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);

  useEffect(() => {
    api.get("/admin/stats").then((r) => setStats(r.data));
  }, []);

  const menu = [
    { label: "📦 Cases", path: "/admin/cases" },
    { label: "⚙️ Settings", path: "/admin/settings" },
    { label: "👥 Users", path: "/admin/users" },
    { label: "📤 Withdrawals", path: "/admin/withdrawals" },
    { label: "🎫 Promocodes", path: "/admin/promocodes" },
  ];

  return (
    <div className="px-4 py-4 space-y-4">
      <h1 className="text-2xl font-black font-display text-accent-gold">⚙️ ADMIN</h1>

      {stats && (
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-bg-card rounded-2xl p-3 text-center">
            <p className="text-2xl font-bold text-white">{stats.total_users}</p>
            <p className="text-white/40 text-xs">Users</p>
          </div>
          <div className="bg-bg-card rounded-2xl p-3 text-center">
            <p className="text-2xl font-bold text-white">{stats.total_deposited?.toFixed(1)}</p>
            <p className="text-white/40 text-xs">TON deposited</p>
          </div>
          <div className="bg-bg-card rounded-2xl p-3 text-center">
            <p className="text-2xl font-bold text-accent-gold">{stats.pending_withdrawals}</p>
            <p className="text-white/40 text-xs">Pending</p>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {menu.map((item) => (
          <button
            key={item.path}
            onClick={() => navigate(item.path)}
            className="w-full bg-bg-card rounded-2xl px-4 py-4 text-left flex items-center justify-between active:scale-95 transition-all"
          >
            <span className="text-white font-semibold">{item.label}</span>
            <span className="text-white/40">→</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function AdminCases() {
  const [cases, setCases] = useState([]);
  const [collections, setCollections] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", image_url: "", price_ton: "", price_stars: "", items: [] });
  const navigate = useNavigate();

  useEffect(() => {
    api.get("/cases/").then((r) => setCases(r.data));
    api.get("/admin/collections").then((r) => setCollections(r.data));
  }, []);

  const syncCollections = async () => {
    await api.post("/admin/collections/sync");
    const r = await api.get("/admin/collections");
    setCollections(r.data);
    alert("Sync tugadi!");
  };

  const addItem = (col) => {
    if (form.items.find((i) => i.collection_id === col.id)) return;
    setForm({ ...form, items: [...form.items, { collection_id: col.id, collection_name: col.name, probability: 10 }] });
  };

  const saveCase = async () => {
    try {
      await api.post("/admin/cases", {
        name: form.name,
        image_url: form.image_url,
        price_ton: form.price_ton ? parseFloat(form.price_ton) : null,
        price_stars: form.price_stars ? parseInt(form.price_stars) : null,
        items: form.items.map((i) => ({ collection_id: i.collection_id, probability: parseFloat(i.probability) })),
      });
      setShowForm(false);
      const r = await api.get("/cases/");
      setCases(r.data);
    } catch (e) {
      alert(e.response?.data?.detail || "Error");
    }
  };

  const deleteCase = async (id) => {
    if (!confirm("O'chirishni tasdiqlaysizmi?")) return;
    await api.delete(`/admin/cases/${id}`);
    setCases(cases.filter((c) => c.id !== id));
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center justify-between">
        <button onClick={() => navigate("/admin")} className="text-white/60">← Back</button>
        <h1 className="text-xl font-black font-display">Cases</h1>
        <button onClick={syncCollections} className="text-accent-blue text-sm">Sync API</button>
      </div>

      <button
        onClick={() => setShowForm(!showForm)}
        className="w-full py-3 rounded-2xl bg-accent-blue text-white font-bold"
      >
        + Yangi case
      </button>

      {showForm && (
        <div className="bg-bg-card rounded-2xl p-4 space-y-3">
          <input className="w-full bg-bg-elevated rounded-xl px-4 py-3 text-white outline-none" placeholder="Case nomi" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input className="w-full bg-bg-elevated rounded-xl px-4 py-3 text-white outline-none" placeholder="Rasm URL" value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} />
          <div className="grid grid-cols-2 gap-2">
            <input className="bg-bg-elevated rounded-xl px-4 py-3 text-white outline-none" placeholder="Narx TON" type="number" value={form.price_ton} onChange={(e) => setForm({ ...form, price_ton: e.target.value })} />
            <input className="bg-bg-elevated rounded-xl px-4 py-3 text-white outline-none" placeholder="Narx Stars" type="number" value={form.price_stars} onChange={(e) => setForm({ ...form, price_stars: e.target.value })} />
          </div>

          <p className="text-white/60 text-sm">Giftlar qo'shish:</p>
          <div className="grid grid-cols-3 gap-2 max-h-40 overflow-y-auto">
            {collections.map((col) => (
              <button key={col.id} onClick={() => addItem(col)} className="bg-bg-elevated rounded-xl p-2 text-center active:scale-95">
                {col.image_url && <img src={col.image_url} className="w-8 h-8 mx-auto rounded-lg mb-1 object-cover" />}
                <p className="text-white text-xs truncate">{col.name}</p>
              </button>
            ))}
          </div>

          {form.items.length > 0 && (
            <div className="space-y-2">
              <p className="text-white/60 text-sm">Ehtimolliklar (%):</p>
              {form.items.map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <p className="text-white text-sm flex-1">{item.collection_name}</p>
                  <input
                    type="number"
                    value={item.probability}
                    onChange={(e) => {
                      const newItems = [...form.items];
                      newItems[i].probability = e.target.value;
                      setForm({ ...form, items: newItems });
                    }}
                    className="w-16 bg-bg-elevated rounded-lg px-2 py-1 text-white text-sm outline-none"
                  />
                  <span className="text-white/40 text-xs">%</span>
                  <button onClick={() => setForm({ ...form, items: form.items.filter((_, j) => j !== i) })} className="text-red-400 text-sm">✕</button>
                </div>
              ))}
            </div>
          )}

          <button onClick={saveCase} className="w-full py-3 rounded-xl bg-accent-green text-black font-bold">Saqlash</button>
        </div>
      )}

      <div className="space-y-3">
        {cases.map((c) => (
          <div key={c.id} className="bg-bg-card rounded-2xl p-4 flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl overflow-hidden bg-bg-elevated">
              {c.image_url ? <img src={c.image_url} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center">📦</div>}
            </div>
            <div className="flex-1">
              <p className="text-white font-bold">{c.name}</p>
              <p className="text-white/40 text-xs">{c.price_ton && `${c.price_ton} TON`} {c.price_stars && `· ⭐${c.price_stars}`}</p>
            </div>
            <button onClick={() => deleteCase(c.id)} className="text-red-400 text-sm px-3 py-1 bg-red-500/10 rounded-lg">O'chirish</button>
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminSettings() {
  const [settings, setSettings] = useState({});
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    api.get("/admin/settings").then((r) => setSettings(r.data));
  }, []);

  const save = async () => {
    setLoading(true);
    await api.put("/admin/settings", settings);
    setLoading(false);
    alert("Saqlandi!");
  };

  const fields = [
    { key: "stars_to_ton_rate", label: "1 Star = ? TON" },
    { key: "min_deposit_stars", label: "Min deposit (Stars)" },
    { key: "min_deposit_ton", label: "Min deposit (TON)" },
    { key: "deposit_bonus_ton_percent", label: "TON deposit bonus %" },
    { key: "sell_commission_percent", label: "Sell komissiya %" },
    { key: "crash_house_edge", label: "Crash house edge (0-1)" },
    { key: "mines_house_edge", label: "Mines house edge (0-1)" },
    { key: "fake_online_min", label: "Fake online min" },
    { key: "fake_online_max", label: "Fake online max" },
  ];

  return (
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate("/admin")} className="text-white/60">← Back</button>
        <h1 className="text-xl font-black font-display">Settings</h1>
      </div>
      <div className="space-y-3">
        {fields.map((f) => (
          <div key={f.key} className="bg-bg-card rounded-2xl p-4">
            <label className="text-white/60 text-xs mb-2 block">{f.label}</label>
            <input
              type="text"
              value={settings[f.key] || ""}
              onChange={(e) => setSettings({ ...settings, [f.key]: e.target.value })}
              className="w-full bg-bg-elevated rounded-xl px-4 py-2 text-white outline-none"
            />
          </div>
        ))}
      </div>
      <button onClick={save} disabled={loading} className="w-full py-4 rounded-2xl bg-accent-blue text-white font-bold disabled:opacity-50">
        {loading ? "Saqlanmoqda..." : "Saqlash"}
      </button>
    </div>
  );
}

function AdminUsers() {
  const [users, setUsers] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    api.get("/admin/users").then((r) => setUsers(r.data));
  }, []);

  const toggleBan = async (u) => {
    await api.post(`/admin/users/${u.id}/ban`);
    setUsers(users.map((usr) => usr.id === u.id ? { ...usr, is_banned: !usr.is_banned } : usr));
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate("/admin")} className="text-white/60">← Back</button>
        <h1 className="text-xl font-black font-display">Users ({users.length})</h1>
      </div>
      <div className="space-y-2">
        {users.map((u) => (
          <div key={u.id} className="bg-bg-card rounded-2xl px-4 py-3 flex items-center justify-between">
            <div>
              <p className="text-white font-medium">{u.username || `ID: ${u.telegram_id}`}</p>
              <p className="text-white/40 text-xs">{u.balance?.toFixed(2)} TON · {new Date(u.created_at).toLocaleDateString()}</p>
            </div>
            <button
              onClick={() => toggleBan(u)}
              className={`text-xs px-3 py-1 rounded-lg font-semibold ${u.is_banned ? "bg-accent-green/20 text-accent-green" : "bg-red-500/20 text-red-400"}`}
            >
              {u.is_banned ? "Unban" : "Ban"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminWithdrawals() {
  const [withdrawals, setWithdrawals] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    api.get("/admin/withdrawals").then((r) => setWithdrawals(r.data));
  }, []);

  const complete = async (id) => {
    await api.post(`/admin/withdrawals/${id}/complete`);
    setWithdrawals(withdrawals.filter((w) => w.id !== id));
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate("/admin")} className="text-white/60">← Back</button>
        <h1 className="text-xl font-black font-display">Withdrawals ({withdrawals.length})</h1>
      </div>
      {withdrawals.length === 0 ? (
        <p className="text-white/30 text-center py-10">Pending withdrawal yo'q</p>
      ) : (
        <div className="space-y-2">
          {withdrawals.map((w) => (
            <div key={w.id} className="bg-bg-card rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-bold">{w.collection}</p>
                  <p className="text-white/40 text-sm">@{w.username} · #{w.id}</p>
                  <p className="text-white/30 text-xs">{new Date(w.created_at).toLocaleString()}</p>
                </div>
              </div>
              <button
                onClick={() => complete(w.id)}
                className="w-full py-3 rounded-xl bg-accent-green text-black font-bold text-sm active:scale-95"
              >
                ✅ Bajarildi (gift yuborildi)
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function AdminPromocodes() {
  const [form, setForm] = useState({ code: "", reward_type: "ton", reward_ton: "", max_uses: "1", reward_collection_id: "" });
  const [collections, setCollections] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    api.get("/admin/collections").then((r) => setCollections(r.data));
  }, []);

  const create = async () => {
    try {
      await api.post("/admin/promocodes", {
        code: form.code.toUpperCase(),
        reward_type: form.reward_type,
        reward_ton: form.reward_ton ? parseFloat(form.reward_ton) : null,
        reward_collection_id: form.reward_collection_id ? parseInt(form.reward_collection_id) : null,
        max_uses: parseInt(form.max_uses),
      });
      alert("Promocode yaratildi!");
      setForm({ code: "", reward_type: "ton", reward_ton: "", max_uses: "1", reward_collection_id: "" });
    } catch (e) {
      alert(e.response?.data?.detail || "Error");
    }
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate("/admin")} className="text-white/60">← Back</button>
        <h1 className="text-xl font-black font-display">Promocodes</h1>
      </div>
      <div className="bg-bg-card rounded-2xl p-4 space-y-3">
        <input className="w-full bg-bg-elevated rounded-xl px-4 py-3 text-white outline-none font-mono uppercase tracking-widest" placeholder="UTONKS2025" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} />
        <div className="grid grid-cols-2 gap-2">
          <button onClick={() => setForm({ ...form, reward_type: "ton" })} className={`py-3 rounded-xl font-bold text-sm ${form.reward_type === "ton" ? "bg-accent-blue text-white" : "bg-bg-elevated text-white/60"}`}>TON reward</button>
          <button onClick={() => setForm({ ...form, reward_type: "gift" })} className={`py-3 rounded-xl font-bold text-sm ${form.reward_type === "gift" ? "bg-accent-blue text-white" : "bg-bg-elevated text-white/60"}`}>Gift reward</button>
        </div>
        {form.reward_type === "ton" && (
          <input className="w-full bg-bg-elevated rounded-xl px-4 py-3 text-white outline-none" type="number" placeholder="TON miqdori" value={form.reward_ton} onChange={(e) => setForm({ ...form, reward_ton: e.target.value })} />
        )}
        {form.reward_type === "gift" && (
          <select className="w-full bg-bg-elevated rounded-xl px-4 py-3 text-white outline-none" value={form.reward_collection_id} onChange={(e) => setForm({ ...form, reward_collection_id: e.target.value })}>
            <option value="">Collection tanlang</option>
            {collections.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        )}
        <input className="w-full bg-bg-elevated rounded-xl px-4 py-3 text-white outline-none" type="number" placeholder="Max foydalanish soni" value={form.max_uses} onChange={(e) => setForm({ ...form, max_uses: e.target.value })} />
        <button onClick={create} className="w-full py-4 rounded-xl bg-accent-blue text-white font-bold active:scale-95">Yaratish</button>
      </div>
    </div>
  );
}
