import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import api from "../utils/api";
import { useStore } from "../utils/store";

export default function UpgradePage() {
  const { inventory, fetchUser, fetchInventory } = useStore();
  const [selectedItems, setSelectedItems] = useState([]);
  const [extraTon, setExtraTon] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const totalValue = selectedItems.reduce((sum, item) => sum + item.floor_price, 0) + parseFloat(extraTon || 0);

  const toggleItem = (item) => {
    if (item.is_locked) return;
    const exists = selectedItems.find((i) => i.id === item.id);
    if (exists) {
      setSelectedItems(selectedItems.filter((i) => i.id !== item.id));
    } else {
      setSelectedItems([...selectedItems, item]);
    }
  };

  const doUpgrade = async () => {
    if (totalValue < 0.1) return;
    setLoading(true);
    setResult(null);
    try {
      const res = await api.post("/upgrade/start", {
        inventory_ids: selectedItems.map((i) => i.id),
        extra_ton: parseFloat(extraTon || 0),
      });
      await new Promise((r) => setTimeout(r, 2000));
      setResult(res.data);
      setSelectedItems([]);
      setExtraTon("");
      await fetchUser();
      await fetchInventory();
    } catch (e) {
      alert(e.response?.data?.detail || "Error");
    }
    setLoading(false);
  };

  const sellableInventory = inventory.filter((i) => !i.is_locked);

  return (
    <div className="px-4 py-4 space-y-4">
      <h1 className="text-2xl font-black font-display">⬆️ UPGRADE</h1>
      <p className="text-white/40 text-sm">
        Gift va TON qo'shing — yaqin narxdagi yangi gift oling
      </p>

      {/* Selected items */}
      <div className="bg-bg-card rounded-2xl p-4 space-y-3">
        <p className="text-white/60 text-sm font-medium">Qo'shilgan giftlar:</p>
        {selectedItems.length === 0 ? (
          <p className="text-white/30 text-sm text-center py-4">Quyidan gift tanlang</p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {selectedItems.map((item) => (
              <motion.div
                key={item.id}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="relative"
              >
                <div className="w-16 h-16 rounded-xl overflow-hidden bg-bg-elevated">
                  {item.collection_image ? (
                    <img src={item.collection_image} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-2xl">🎁</div>
                  )}
                </div>
                <button
                  onClick={() => toggleItem(item)}
                  className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs flex items-center justify-center"
                >
                  ✕
                </button>
                <p className="text-xs text-white/60 text-center mt-1">{item.floor_price} TON</p>
              </motion.div>
            ))}
          </div>
        )}

        {/* Extra TON */}
        <div className="flex items-center gap-2 bg-bg-elevated rounded-xl px-3 py-2">
          <TonIcon />
          <input
            type="number"
            value={extraTon}
            onChange={(e) => setExtraTon(e.target.value)}
            placeholder="Qo'shimcha TON (ixtiyoriy)"
            className="flex-1 bg-transparent text-white outline-none text-sm"
            min="0"
          />
        </div>

        {/* Total */}
        {totalValue > 0 && (
          <div className="flex items-center justify-between py-2 border-t border-white/10">
            <span className="text-white/60 text-sm">Jami:</span>
            <span className="text-white font-bold">{totalValue.toFixed(3)} TON</span>
          </div>
        )}

        <button
          onClick={doUpgrade}
          disabled={totalValue < 0.1 || loading}
          className="w-full py-4 rounded-xl bg-gradient-to-r from-accent-purple to-accent-blue text-white font-bold disabled:opacity-40 active:scale-95 transition-all"
        >
          {loading ? "⏳ Upgrade qilinmoqda..." : `⬆️ Upgrade (${totalValue.toFixed(2)} TON)`}
        </button>
      </div>

      {/* Inventory to select from */}
      <div>
        <p className="text-white/60 text-sm mb-3">Inventaringiz:</p>
        {sellableInventory.length === 0 ? (
          <p className="text-white/30 text-sm text-center py-6">Gift yo'q</p>
        ) : (
          <div className="grid grid-cols-3 gap-3">
            {sellableInventory.map((item) => {
              const isSelected = selectedItems.find((i) => i.id === item.id);
              return (
                <button
                  key={item.id}
                  onClick={() => toggleItem(item)}
                  className={`rounded-2xl p-3 text-center transition-all border-2 active:scale-95 ${
                    isSelected
                      ? "border-accent-blue bg-accent-blue/20"
                      : "border-transparent bg-bg-card"
                  }`}
                >
                  <div className="w-12 h-12 mx-auto rounded-xl overflow-hidden mb-2">
                    {item.collection_image ? (
                      <img src={item.collection_image} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-bg-elevated flex items-center justify-center text-2xl">🎁</div>
                    )}
                  </div>
                  <p className="text-white text-xs font-medium truncate">{item.collection_name}</p>
                  <p className="text-white/60 text-xs">{item.floor_price} TON</p>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Result modal */}
      <AnimatePresence>
        {result && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur flex items-center justify-center"
          >
            <motion.div
              initial={{ scale: 0.5 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.5 }}
              className="bg-bg-card rounded-3xl p-8 mx-6 text-center space-y-4"
            >
              <div className="w-32 h-32 mx-auto rounded-2xl overflow-hidden">
                {result.gift?.collection_image ? (
                  <img src={result.gift.collection_image} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-bg-elevated flex items-center justify-center text-6xl">🎁</div>
                )}
              </div>
              <div>
                <p className="text-accent-gold font-black text-2xl font-display">UPGRADE!</p>
                <p className="text-white font-bold text-xl">{result.gift?.collection_name}</p>
                <p className="text-white/60 text-sm">{result.gift?.floor_price} TON</p>
                {result.change > 0 && (
                  <p className="text-accent-green text-sm mt-1">+{result.change.toFixed(3)} TON qaytarildi</p>
                )}
              </div>
              <button
                onClick={() => setResult(null)}
                className="w-full py-3 rounded-xl bg-accent-blue text-white font-bold"
              >
                Ajoyib!
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function TonIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 56 56" fill="none">
      <circle cx="28" cy="28" r="28" fill="#0098EA" />
      <path d="M18.1 15.2h19.8c1.4 0 2.2 1.6 1.4 2.8L28 40.8 16.7 18c-.8-1.2 0-2.8 1.4-2.8z" fill="white" />
    </svg>
  );
}
