import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import api from "../utils/api";

const GAMES = [
  {
    id: "crash",
    name: "CRASH",
    path: "/games/crash",
    gradient: "from-blue-600 to-cyan-500",
    description: "Rocket to the moon!",
    emoji: "🚀",
  },
  {
    id: "mines",
    name: "MINES",
    path: "/games/mines",
    gradient: "from-red-600 to-pink-500",
    description: "Avoid the bombs!",
    emoji: "💣",
  },
  {
    id: "cases",
    name: "CASES",
    path: "/games/cases",
    gradient: "from-purple-600 to-indigo-500",
    description: "Open gift cases!",
    emoji: "📦",
  },
  {
    id: "upgrade",
    name: "UPGRADE",
    path: "/games/upgrade",
    gradient: "from-amber-500 to-orange-500",
    description: "Upgrade your gifts!",
    emoji: "⬆️",
  },
];

const BONUSES = [
  { id: "promo", name: "PROMOCODE", emoji: "🎫", path: "/games/cases?tab=promo" },
  { id: "daily", name: "DAILY CASE", emoji: "🎁", path: "/games/cases?tab=daily" },
];

export default function GamesPage() {
  const navigate = useNavigate();
  const [liveBets, setLiveBets] = useState([]);
  const [onlineCount, setOnlineCount] = useState(63);

  // Fetch live crash bets for ticker
  useEffect(() => {
    const ws = new WebSocket(`${import.meta.env.VITE_WS_URL || "ws://localhost:8000"}/api/crash/ws`);
    ws.onmessage = (e) => {
      const data = JSON.parse(e.data);
      if (data.type === "tick" && data.online) {
        setOnlineCount(data.online);
      }
    };
    return () => ws.close();
  }, []);

  return (
    <div className="px-4 py-4 space-y-6">
      {/* Online indicator */}
      <div className="flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-accent-green animate-pulse" />
        <span className="text-white/60 text-sm">{onlineCount} Online</span>
      </div>

      {/* Live bets ticker */}
      <LiveBetsTicker />

      {/* Stonks Games */}
      <div>
        <h2 className="text-white/80 font-semibold mb-3 flex items-center gap-2">
          <span>🔥</span> Utonks Games
        </h2>
        <div className="grid grid-cols-2 gap-3">
          {GAMES.map((game, i) => (
            <motion.button
              key={game.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              onClick={() => navigate(game.path)}
              className={`relative overflow-hidden rounded-2xl bg-gradient-to-br ${game.gradient} aspect-[4/3] flex items-end p-4 active:scale-95 transition-transform`}
            >
              <div className="absolute inset-0 flex items-center justify-center opacity-20 text-8xl">
                {game.emoji}
              </div>
              <span className="relative font-black text-white text-xl tracking-wider font-display">
                {game.name}
              </span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Bonuses */}
      <div>
        <h2 className="text-white/80 font-semibold mb-3 flex items-center gap-2">
          <span>✨</span> Bonuses
        </h2>
        <div className="grid grid-cols-2 gap-3">
          {BONUSES.map((bonus, i) => (
            <motion.button
              key={bonus.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + i * 0.1 }}
              onClick={() => navigate(bonus.path)}
              className="relative overflow-hidden rounded-2xl bg-bg-card border border-white/10 aspect-[4/3] flex items-end p-4 active:scale-95 transition-transform"
            >
              <div className="absolute inset-0 flex items-center justify-center opacity-10 text-8xl">
                {bonus.emoji}
              </div>
              <span className="relative font-black text-white text-base tracking-wider font-display">
                {bonus.name}
              </span>
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}

function LiveBetsTicker() {
  const [bets, setBets] = useState([
    { name: "Alex", amount: 3.94, collection: "Plush Pepe" },
    { name: "Maria", amount: 0.39, collection: "Heart" },
    { name: "Crypto", amount: 10, collection: "Star" },
    { name: "Whale", amount: 0.19, collection: "Rose" },
  ]);

  return (
    <div className="flex gap-3 overflow-x-auto pb-1 scrollbar-none">
      {bets.map((bet, i) => (
        <div
          key={i}
          className="flex-shrink-0 bg-bg-card rounded-2xl px-3 py-2 flex flex-col items-center gap-1 min-w-[80px]"
        >
          <div className="w-10 h-10 rounded-xl bg-bg-elevated flex items-center justify-center text-2xl">
            🎁
          </div>
          <span className="text-xs font-bold text-white">{bet.amount} TON</span>
          <div className="w-full h-0.5 bg-accent-blue rounded-full" />
        </div>
      ))}
    </div>
  );
}
