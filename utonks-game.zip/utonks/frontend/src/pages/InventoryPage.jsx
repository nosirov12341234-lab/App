import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import api from "../utils/api";
import { useStore } from "../utils/store";

export default function InventoryPage() {
  const { inventory, fetchInventory } = useStore();
  const [selected, setSelected] = useState(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [toast, setToast] = useState(null);

  useEffect(() => { fetchInventory(); }, []);

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const sellItem = async (item) => {
    setActionLoading(true);
    try {
      const res = await api.post(`/inventory/${item.id}/sell`);
      showToast(`✅ Sotildi: +${res.data.amount.toFixed(3)} TON`);
      setSelected(null);
      await fetchInventory();
    } catch (e) {
      showToast(e.response?.data?.detail || "Xato", "error");
    }
    setActionLoading(false);
  };

  const withdrawItem = async (item) => {
    setActionLoading(true);
    try {
      await api.post(`/inventory/${item.id}/withdraw`);
      showToast("⏳ Gift yuborilmoqda...");
      setSelected(null);
      await fetchInventory();
    } catch (e) {
      showToast(e.response?.data?.detail || "Xato", "error");
    }
    setActionLoading(false);
  };

  return (
    <div className="px-4 py-4">
      <h1 className="text-2xl font-black font-display mb-4">🎒 INVENTORY</h1>

      {inventory.length === 0 ? (
        <div className="text-center py-20 text-white/30">
          <p className="text-5xl mb-4">📭</p>
          <p>Inventar bo'sh</p>
          <p className="text-sm mt-2">Case oching yoki gift depozit qiling</p>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-3">
          {inventory.map((item, i) => (
            <motion.button
              key={item.id}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.05 }}
              onClick={() => setSelected(item)}
              className="relative bg-bg-card rounded-2xl p-3 text-center active:scale-95 transition-all border border-white/5"
            >
              {item.is_locked && (
                <div className="absolute top-2 left-2 w-5 h-5 bg-accent-gold rounded-full flex items-center justify-center">
                  <span className="text-xs">🔒</span>
                </div>
              )}
              <div className="w-16 h-16 mx-auto rounded-xl overflow-hidden mb-2 bg-bg-elevated">
                {item.collection_image ? (
                  <img src={item.collection_image} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-3xl">🎁</div>
                )}
              </div>
              <p className="text-white text-xs font-medium truncate">{item.collection_name}</p>
              <p className="text-white/60 text-xs">{item.floor_price} TON</p>
              {item.withdraw_available_at && !item.can_withdraw && (
                <WithdrawTimer target={item.withdraw_available_at} />
              )}
            </motion.button>
          ))}
        </div>
      )}

      {/* Item action modal */}
      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur flex items-end justify-center"
            onClick={() => setSelected(null)}
          >
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25 }}
              className="w-full bg-bg-secondary rounded-t-3xl p-6 pb-10 space-y-4"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-10 h-1 bg-white/20 rounded-full mx-auto" />

              <div className="flex items-center gap-4">
                <div className="w-20 h-20 rounded-2xl overflow-hidden bg-bg-elevated flex-shrink-0">
                  {selected.collection_image ? (
                    <img src={selected.collection_image} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-4xl">🎁</div>
                  )}
                </div>
                <div>
                  <h3 className="text-white font-bold text-xl">{selected.collection_name}</h3>
                  <p className="text-white/60">{selected.floor_price} TON</p>
                  {selected.is_locked && (
                    <span className="text-xs bg-accent-gold/20 text-accent-gold px-2 py-0.5 rounded-lg mt-1 inline-block">
                      🔒 Sell only
                    </span>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <button
                  onClick={() => sellItem(selected)}
                  disabled={actionLoading}
                  className="w-full py-4 rounded-2xl bg-accent-blue text-white font-bold active:scale-95 transition-all disabled:opacity-50"
                >
                  💰 Sotish ({(selected.floor_price * 0.85).toFixed(3)} TON)
                </button>

                {!selected.is_locked && selected.can_withdraw && (
                  <button
                    onClick={() => withdrawItem(selected)}
                    disabled={actionLoading}
                    className="w-full py-4 rounded-2xl bg-bg-card border border-white/10 text-white font-bold active:scale-95 transition-all disabled:opacity-50"
                  >
                    📤 Withdraw (Telegramga yuborish)
                  </button>
                )}

                {!selected.is_locked && !selected.can_withdraw && (
                  <div className="w-full py-4 rounded-2xl bg-bg-card border border-white/10 text-white/40 text-center text-sm">
                    ⏳ Withdraw kutilmoqda...
                  </div>
                )}

                {!selected.is_locked && selected.can_bet && (
                  <button className="w-full py-4 rounded-2xl bg-bg-card border border-white/10 text-white/60 font-bold active:scale-95 transition-all">
                    🎰 Bet qilish (Crash/Mines)
                  </button>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={`fixed bottom-24 left-4 right-4 z-50 py-3 px-4 rounded-2xl text-center font-semibold ${
              toast.type === "error" ? "bg-red-500/90" : "bg-accent-green/90"
            } text-white`}
          >
            {toast.msg}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function WithdrawTimer({ target }) {
  const [left, setLeft] = useState("");
  useEffect(() => {
    const calc = () => {
      const diff = new Date(target) - new Date();
      if (diff <= 0) { setLeft(""); return; }
      const h = Math.floor(diff / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setLeft(`${h}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`);
    };
    calc();
    const t = setInterval(calc, 1000);
    return () => clearInterval(t);
  }, [target]);
  if (!left) return null;
  return <p className="text-accent-gold text-xs mt-1">{left}</p>;
}
