import React, { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import api from "../utils/api";
import { useStore } from "../utils/store";

const WS_URL = import.meta.env.VITE_WS_URL || "ws://localhost:8000";

export default function CrashPage() {
  const { user, fetchUser } = useStore();
  const [gameState, setGameState] = useState("waiting");
  const [multiplier, setMultiplier] = useState(1.0);
  const [crashPoint, setCrashPoint] = useState(null);
  const [history, setHistory] = useState([]);
  const [bets, setBets] = useState([]);
  const [myBet, setMyBet] = useState(null);
  const [myCashedOut, setMyCashedOut] = useState(false);
  const [betAmount, setBetAmount] = useState("0.1");
  const [betPhaseTimer, setBetPhaseTimer] = useState(5);
  const [online, setOnline] = useState(63);
  const wsRef = useRef(null);
  const canvasRef = useRef(null);
  const animRef = useRef(null);
  const startTimeRef = useRef(null);

  // WebSocket connection
  useEffect(() => {
    const connect = () => {
      const ws = new WebSocket(`${WS_URL}/api/crash/ws`);
      wsRef.current = ws;

      ws.onmessage = (e) => {
        const data = JSON.parse(e.data);
        handleMessage(data);
      };

      ws.onclose = () => {
        setTimeout(connect, 2000);
      };
    };
    connect();
    return () => wsRef.current?.close();
  }, []);

  const handleMessage = useCallback((data) => {
    switch (data.type) {
      case "state":
        setGameState(data.game_state);
        setMultiplier(data.multiplier || 1.0);
        setHistory(data.history || []);
        setOnline(data.online || 63);
        break;
      case "betting_phase":
        setGameState("betting");
        setMultiplier(1.0);
        setCrashPoint(null);
        setBets([]);
        setMyBet(null);
        setMyCashedOut(false);
        startTimeRef.current = null;
        let timer = 5;
        const interval = setInterval(() => {
          timer -= 1;
          setBetPhaseTimer(timer);
          if (timer <= 0) clearInterval(interval);
        }, 1000);
        setBetPhaseTimer(5);
        setOnline(data.online || 63);
        setHistory(data.history || []);
        break;
      case "game_started":
        setGameState("running");
        setBets(data.bets || []);
        startTimeRef.current = Date.now();
        break;
      case "tick":
        setMultiplier(data.multiplier);
        setOnline(data.online || 63);
        drawGraph(data.multiplier);
        break;
      case "cashout":
        setBets((prev) =>
          prev.map((b) =>
            b.username === data.username
              ? { ...b, cashed_out: true, cashout_multi: data.multiplier }
              : b
          )
        );
        break;
      case "crashed":
        setGameState("crashed");
        setCrashPoint(data.crash_point);
        setHistory(data.history || []);
        if (canvasRef.current) {
          const ctx = canvasRef.current.getContext("2d");
          drawCrashed(ctx, data.crash_point);
        }
        break;
    }
  }, []);

  const drawGraph = (mult) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const w = canvas.width;
    const h = canvas.height;

    ctx.clearRect(0, 0, w, h);

    // Grid
    ctx.strokeStyle = "rgba(255,255,255,0.05)";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 5; i++) {
      ctx.beginPath();
      ctx.moveTo(0, (h / 5) * i);
      ctx.lineTo(w, (h / 5) * i);
      ctx.stroke();
    }

    // Curve
    const elapsed = Date.now() - (startTimeRef.current || Date.now());
    const points = [];
    for (let t = 0; t <= elapsed; t += 100) {
      const m = Math.pow(Math.E, 0.00006 * t);
      const x = (t / elapsed) * w;
      const y = h - ((m - 1) / (mult - 1 || 1)) * h * 0.8;
      points.push({ x, y });
    }

    if (points.length < 2) return;

    // Gradient fill
    const gradient = ctx.createLinearGradient(0, 0, 0, h);
    gradient.addColorStop(0, "rgba(59,110,248,0.3)");
    gradient.addColorStop(1, "rgba(59,110,248,0)");

    ctx.beginPath();
    ctx.moveTo(points[0].x, h);
    points.forEach((p) => ctx.lineTo(p.x, p.y));
    ctx.lineTo(points[points.length - 1].x, h);
    ctx.closePath();
    ctx.fillStyle = gradient;
    ctx.fill();

    // Line
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    points.forEach((p) => ctx.lineTo(p.x, p.y));
    ctx.strokeStyle = "#3B6EF8";
    ctx.lineWidth = 2.5;
    ctx.stroke();

    // Rocket at end
    const last = points[points.length - 1];
    ctx.font = "24px serif";
    ctx.fillText("🚀", last.x - 12, last.y - 8);
  };

  const drawCrashed = (ctx, cp) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "rgba(255,61,87,0.1)";
    ctx.fillRect(0, 0, w, h);
    ctx.font = "bold 48px sans-serif";
    ctx.fillStyle = "#FF3D57";
    ctx.textAlign = "center";
    ctx.fillText(`💥 ${cp}x`, w / 2, h / 2);
  };

  const handleBet = async () => {
    if (gameState !== "betting" || myBet) return;
    try {
      await api.post(`/crash/bet?amount=${betAmount}`);
      setMyBet(parseFloat(betAmount));
      await fetchUser();
    } catch (e) {
      alert(e.response?.data?.detail || "Error");
    }
  };

  const handleCashout = async () => {
    if (gameState !== "running" || !myBet || myCashedOut) return;
    try {
      const res = await api.post("/crash/cashout");
      setMyCashedOut(true);
      await fetchUser();
    } catch (e) {
      console.error(e);
    }
  };

  const multColor = gameState === "crashed"
    ? "#FF3D57"
    : multiplier < 2 ? "#ffffff" : multiplier < 5 ? "#FFB800" : "#00E676";

  return (
    <div className="flex flex-col h-full px-4 py-4 space-y-4">
      {/* History */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
        {history.slice().reverse().map((h, i) => (
          <span
            key={i}
            className={`flex-shrink-0 text-xs font-bold px-2 py-1 rounded-lg ${
              h < 2 ? "bg-red-500/20 text-red-400" :
              h < 5 ? "bg-yellow-500/20 text-yellow-400" :
              "bg-green-500/20 text-green-400"
            }`}
          >
            x{h}
          </span>
        ))}
      </div>

      {/* Game Area */}
      <div className="relative bg-bg-card rounded-3xl overflow-hidden" style={{ height: 220 }}>
        <canvas
          ref={canvasRef}
          width={400}
          height={220}
          className="w-full h-full"
        />

        {/* Multiplier overlay */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <motion.div
            key={gameState}
            animate={{ scale: gameState === "crashed" ? [1, 1.2, 1] : 1 }}
            className="text-center"
          >
            <span
              className="text-6xl font-black font-display"
              style={{ color: multColor, textShadow: `0 0 30px ${multColor}60` }}
            >
              {gameState === "crashed"
                ? `${crashPoint}x`
                : gameState === "betting"
                ? "WAITING"
                : `${multiplier.toFixed(2)}x`}
            </span>
            {gameState === "betting" && (
              <p className="text-white/40 text-sm mt-1">Starting in {betPhaseTimer}s</p>
            )}
          </motion.div>
        </div>

        {/* Online */}
        <div className="absolute top-3 left-3 flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-accent-green animate-pulse" />
          <span className="text-white/40 text-xs">{online}</span>
        </div>
      </div>

      {/* Bet controls */}
      <div className="bg-bg-card rounded-2xl p-4 space-y-3">
        <div className="flex gap-3">
          {/* TON Bet */}
          <div className="flex-1 space-y-2">
            <div className="flex items-center gap-2 bg-bg-elevated rounded-xl px-3 py-2">
              <TonIcon />
              <input
                type="number"
                value={betAmount}
                onChange={(e) => setBetAmount(e.target.value)}
                className="flex-1 bg-transparent text-white outline-none text-sm"
                min="0.01"
                step="0.1"
              />
            </div>
            <button
              onClick={gameState === "running" && myBet && !myCashedOut ? handleCashout : handleBet}
              disabled={
                (gameState === "betting" && !!myBet) ||
                (gameState === "running" && (!myBet || myCashedOut)) ||
                gameState === "crashed"
              }
              className={`w-full py-3 rounded-xl font-bold text-sm transition-all active:scale-95 ${
                gameState === "running" && myBet && !myCashedOut
                  ? "bg-accent-green text-black animate-pulse-glow"
                  : gameState === "betting" && !myBet
                  ? "bg-accent-blue text-white"
                  : "bg-bg-elevated text-white/40"
              }`}
            >
              {gameState === "running" && myBet && !myCashedOut
                ? `Cash Out ${(myBet * multiplier).toFixed(3)} TON`
                : gameState === "betting" && !myBet
                ? "Bet TON"
                : myBet
                ? "✓ Bet placed"
                : "Bet TON"}
            </button>
          </div>

          {/* Gift Bet */}
          <button className="flex flex-col items-center justify-center gap-1 bg-bg-elevated rounded-xl px-4 py-3 text-white/40">
            <span className="text-xl">🎁</span>
            <span className="text-xs">Gift</span>
          </button>
        </div>
      </div>

      {/* Bets list */}
      <div className="space-y-2">
        {bets.map((bet, i) => (
          <div key={i} className="flex items-center justify-between bg-bg-card rounded-xl px-3 py-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-bg-elevated flex items-center justify-center text-sm">
                {bet.avatar || "👤"}
              </div>
              <div>
                <p className="text-sm font-medium text-white">{bet.username}</p>
                <p className="text-xs text-white/40">{bet.amount} TON</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {bet.cashed_out ? (
                <span className="text-accent-green text-sm font-bold">
                  {(bet.amount * bet.cashout_multi).toFixed(2)} TON
                </span>
              ) : (
                <span className="text-white/40 text-sm">{bet.amount} TON</span>
              )}
              <TonIcon />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function TonIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 56 56" fill="none">
      <circle cx="28" cy="28" r="28" fill="#0098EA" />
      <path d="M18.1 15.2h19.8c1.4 0 2.2 1.6 1.4 2.8L28 40.8 16.7 18c-.8-1.2 0-2.8 1.4-2.8z" fill="white" />
    </svg>
  );
}
