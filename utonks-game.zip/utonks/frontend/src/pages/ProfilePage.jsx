import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useTonConnectUI, useTonAddress } from "@tonconnect/ui-react";
import api from "../utils/api";
import { useStore } from "../utils/store";

const LEVEL_INFO = [
  { level: 1, percent: 10, min: 0, emoji: "🍪", name: "Newbie" },
  { level: 2, percent: 12, min: 25, emoji: "🐸", name: "Slime" },
  { level: 3, percent: 14, min: 100, emoji: "⌚", name: "Gold Watch" },
  { level: 4, percent: 18, min: 500, emoji: "🍇", name: "Diamond" },
];

export default function ProfilePage() {
  const { user, fetchUser } = useStore();
  const [transactions, setTransactions] = useState([]);
  const [showReferralLevels, setShowReferralLevels] = useState(false);
  const [tonConnectUI] = useTonConnectUI();
  const walletAddress = useTonAddress();

  useEffect(() => {
    fetchUser();
    api.get("/user/transactions").then((r) => setTransactions(r.data));
  }, []);

  const copyReferral = () => {
    navigator.clipboard.writeText(user?.referral_link || "");
    window.Telegram?.WebApp?.showAlert("Nusxalandi! ✅");
  };

  const currentLevel = LEVEL_INFO.find((l) => l.level === user?.level) || LEVEL_INFO[0];
  const nextLevel = LEVEL_INFO.find((l) => l.level === (user?.level || 1) + 1);

  return (
    <div className="px-4 py-4 space-y-4">
      {/* User card */}
      <div className="bg-bg-card rounded-3xl p-4 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              {user?.photo_url ? (
                <img src={user.photo_url} className="w-14 h-14 rounded-2xl object-cover" />
              ) : (
                <div className="w-14 h-14 rounded-2xl bg-accent-purple flex items-center justify-center text-2xl font-bold">
                  {user?.first_name?.[0] || "U"}
                </div>
              )}
              <div className="absolute -bottom-1 -right-1 bg-bg-card rounded-lg px-1.5 py-0.5 text-xs font-bold text-accent-gold">
                {currentLevel.emoji}
              </div>
            </div>
            <div>
              <p className="text-white font-bold text-lg">{user?.first_name}</p>
              <p className="text-white/40 text-sm">Level {user?.level} · {currentLevel.name}</p>
            </div>
          </div>

          {/* TON Connect */}
          <button
            onClick={() => tonConnectUI.openModal()}
            className="bg-bg-elevated rounded-xl px-3 py-2 text-xs text-white/60 font-mono"
          >
            {walletAddress
              ? `${walletAddress.slice(0, 6)}...${walletAddress.slice(-4)}`
              : "Connect Wallet"}
          </button>
        </div>

        {/* Headphones / Globe icons placeholder row */}
        <div className="flex items-center justify-between opacity-30">
          <span className="text-2xl">🎧</span>
          <span className="text-2xl">🌐</span>
        </div>

        {/* Deposit button */}
        <button
          onClick={() => document.querySelector("[data-deposit-btn]")?.click()}
          className="w-full py-4 rounded-2xl bg-accent-blue text-white font-bold text-lg flex items-center justify-center gap-2 active:scale-95 transition-all"
        >
          ↑ Deposit
        </button>
      </div>

      {/* Referrals */}
      <div className="bg-bg-card rounded-3xl p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-white font-bold text-lg">Referrals</h2>
          <button
            onClick={() => setShowReferralLevels(!showReferralLevels)}
            className="text-accent-blue text-sm"
          >
            Levels →
          </button>
        </div>

        {/* Current level card */}
        <div className="bg-bg-elevated rounded-2xl p-4 flex items-center justify-between">
          <div>
            <p className="text-white font-black text-2xl">Level {user?.level}</p>
            <p className="text-white/60 text-sm">{currentLevel.percent}% from net income</p>
          </div>
          <span className="text-5xl">{currentLevel.emoji}</span>
        </div>

        {/* Referral system levels modal */}
        {showReferralLevels && (
          <div className="space-y-3">
            {LEVEL_INFO.map((lvl) => (
              <div
                key={lvl.level}
                className={`rounded-2xl p-4 flex items-center justify-between ${
                  lvl.level === user?.level ? "bg-accent-blue/20 border border-accent-blue/40" : "bg-bg-elevated"
                }`}
              >
                <div>
                  <p className="text-white font-bold text-lg">Level {lvl.level}</p>
                  <p className="text-white/60 text-sm">{lvl.percent}% from net income</p>
                  {lvl.min > 0 && (
                    <p className="text-white/40 text-xs">From {lvl.min} TON in referral deposits</p>
                  )}
                </div>
                <span className="text-4xl">{lvl.emoji}</span>
              </div>
            ))}
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-bg-elevated rounded-2xl p-3 text-center">
            <span className="text-2xl">👥</span>
            <p className="text-white font-bold text-xl">{user?.referral_count || 0}</p>
            <p className="text-white/40 text-xs">Total referrals</p>
          </div>
          <div className="bg-bg-elevated rounded-2xl p-3 text-center">
            <TonIcon />
            <p className="text-white font-bold text-xl">{user?.total_referral_deposits?.toFixed(1) || 0}</p>
            <p className="text-white/40 text-xs">Referral activity</p>
          </div>
          <div className="bg-bg-elevated rounded-2xl p-3 text-center">
            <TonIcon />
            <p className="text-white font-bold text-xl">{user?.referral_earnings?.toFixed(2) || 0}</p>
            <p className="text-white/40 text-xs">Total earned</p>
          </div>
        </div>
      </div>

      {/* Referral link */}
      <div className="bg-bg-card rounded-3xl p-4 space-y-3">
        <h2 className="text-white font-bold">Referral link</h2>
        <button
          onClick={copyReferral}
          className="w-full bg-bg-elevated rounded-2xl px-4 py-3 flex items-center justify-between active:scale-95 transition-all"
        >
          <span className="text-white/60 text-sm font-mono truncate">{user?.referral_link || "..."}</span>
          <span className="text-white/40 ml-2 flex-shrink-0">📋</span>
        </button>

        {/* Available / Total */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-bg-elevated rounded-2xl p-3 text-center">
            <p className="text-white/40 text-xs mb-1">Available balance</p>
            <p className="text-white font-bold">{user?.referral_earnings?.toFixed(1) || "0.0"} TON</p>
          </div>
          <div className="bg-bg-elevated rounded-2xl p-3 text-center">
            <p className="text-white/40 text-xs mb-1">Total earned</p>
            <p className="text-white font-bold">{user?.referral_earnings?.toFixed(1) || "0.0"} TON</p>
          </div>
        </div>
        <p className="text-white/30 text-xs text-center">Balance updates once a day</p>
      </div>

      {/* Transaction history */}
      <div className="bg-bg-card rounded-3xl p-4 space-y-3">
        <h2 className="text-white font-bold">Transaction history</h2>
        {transactions.length === 0 ? (
          <p className="text-white/30 text-sm text-center py-4">Hali tranzaksiya yo'q</p>
        ) : (
          <div className="space-y-2">
            {transactions.map((tx) => (
              <div key={tx.id} className="flex items-center justify-between bg-bg-elevated rounded-2xl px-4 py-3">
                <div>
                  <p className="text-white text-sm font-medium">{txLabel(tx.type)}</p>
                  <p className="text-white/40 text-xs">{new Date(tx.created_at).toLocaleString()}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`font-bold ${tx.amount >= 0 ? "text-accent-green" : "text-red-400"}`}>
                    {tx.amount >= 0 ? "+" : ""}{tx.amount.toFixed(3)} TON
                  </span>
                  {tx.amount >= 0 && <span className="text-accent-green">✓</span>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function txLabel(type) {
  const map = {
    deposit_ton: "TON Deposit",
    deposit_stars: "Stars Deposit",
    deposit_gift: "Gift Deposit",
    withdraw_gift: "Gift Withdraw",
    sell_gift: "Gift Sold",
    bet_win: "Game Win",
    bet_lose: "Game Bet",
    referral_bonus: "Referral Bonus",
    case_open: "Case Opened",
    upgrade: "Upgrade",
    promocode: "Promocode",
  };
  return map[type] || type;
}

function TonIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 56 56" fill="none" className="mx-auto mb-1">
      <circle cx="28" cy="28" r="28" fill="#0098EA" />
      <path d="M18.1 15.2h19.8c1.4 0 2.2 1.6 1.4 2.8L28 40.8 16.7 18c-.8-1.2 0-2.8 1.4-2.8z" fill="white" />
    </svg>
  );
}
