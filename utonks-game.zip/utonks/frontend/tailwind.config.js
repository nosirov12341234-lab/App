/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: {
          primary: "#0D0B1A",
          secondary: "#13102A",
          card: "#1A1735",
          elevated: "#201D40",
        },
        accent: {
          blue: "#3B6EF8",
          purple: "#7B4FE9",
          cyan: "#00D4FF",
          green: "#00E676",
          red: "#FF3D57",
          gold: "#FFB800",
        },
        ton: "#0098EA",
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        body: ["'Inter'", "sans-serif"],
      },
      animation: {
        "crash-fly": "crashFly 0.3s ease-out",
        "win-pop": "winPop 0.5s cubic-bezier(0.36, 0.07, 0.19, 0.97)",
        "pulse-glow": "pulseGlow 2s infinite",
        "float": "float 3s ease-in-out infinite",
        "spin-slow": "spin 3s linear infinite",
      },
      keyframes: {
        crashFly: {
          "0%": { transform: "translateX(-100px) translateY(100px)", opacity: 0 },
          "100%": { transform: "translateX(0) translateY(0)", opacity: 1 },
        },
        winPop: {
          "0%, 100%": { transform: "scale(1)" },
          "50%": { transform: "scale(1.2)" },
        },
        pulseGlow: {
          "0%, 100%": { boxShadow: "0 0 10px rgba(59, 110, 248, 0.3)" },
          "50%": { boxShadow: "0 0 30px rgba(59, 110, 248, 0.8)" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-10px)" },
        },
      },
    },
  },
  plugins: [],
};
