import asyncio
import os
import httpx
from telethon import TelegramClient, events
from telethon.tl.functions.payments import GetStarsGiftOptionsRequest
import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

API_ID = int(os.getenv("TELEGRAM_API_ID", "0"))
API_HASH = os.getenv("TELEGRAM_API_HASH", "")
SESSION_STRING = os.getenv("USERBOT_SESSION", "")
BACKEND_URL = os.getenv("BACKEND_URL", "http://backend:8000")
ADMIN_ID = int(os.getenv("ADMIN_TELEGRAM_ID", "0"))
BOT_TOKEN = os.getenv("BOT_TOKEN", "")

client = TelegramClient("userbot", API_ID, API_HASH)

async def get_pending_withdrawals():
    """Get pending withdrawals from backend"""
    async with httpx.AsyncClient() as http:
        try:
            resp = await http.get(
                f"{BACKEND_URL}/api/admin/withdrawals",
                headers={"X-Internal-Key": os.getenv("INTERNAL_KEY", "")}
            )
            if resp.status_code == 200:
                return resp.json()
        except Exception as e:
            logger.error(f"Error fetching withdrawals: {e}")
    return []

async def get_my_gifts():
    """Get all gifts in userbot account"""
    try:
        gifts = await client.get_my_gifts()
        result = []
        async for gift in gifts:
            result.append({
                "id": gift.id,
                "collection": gift.title or "",
                "slug": getattr(gift, 'slug', ''),
            })
        return result
    except Exception as e:
        logger.error(f"Error getting gifts: {e}")
        return []

async def send_gift_to_user(user_telegram_id: int, gift_id: int) -> bool:
    """Send a specific gift to user"""
    try:
        await client.send_gift(user_telegram_id, gift_id)
        return True
    except Exception as e:
        logger.error(f"Error sending gift: {e}")
        return False

async def notify_admin(message: str):
    """Send notification to admin"""
    try:
        await client.send_message(ADMIN_ID, message)
    except Exception as e:
        logger.error(f"Error notifying admin: {e}")

async def notify_user_bot(user_telegram_id: int, message: str):
    """Notify user via bot"""
    async with httpx.AsyncClient() as http:
        try:
            await http.post(
                f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
                json={"chat_id": user_telegram_id, "text": message, "parse_mode": "HTML"}
            )
        except Exception as e:
            logger.error(f"Error notifying user: {e}")

async def complete_withdrawal(withdraw_id: int):
    """Mark withdrawal as completed in backend"""
    async with httpx.AsyncClient() as http:
        try:
            await http.post(
                f"{BACKEND_URL}/api/admin/withdrawals/{withdraw_id}/complete",
                headers={"X-Internal-Key": os.getenv("INTERNAL_KEY", "")}
            )
        except Exception as e:
            logger.error(f"Error completing withdrawal: {e}")

async def process_withdrawals():
    """Main withdrawal processing loop"""
    logger.info("Starting withdrawal processor...")
    
    while True:
        try:
            withdrawals = await get_pending_withdrawals()
            
            for withdrawal in withdrawals:
                withdraw_id = withdrawal["id"]
                user_tg_id = withdrawal["user_id"]
                collection_name = withdrawal["collection"]
                
                logger.info(f"Processing withdrawal #{withdraw_id}: {collection_name} → @{withdrawal['username']}")
                
                # Get my gifts
                my_gifts = await get_my_gifts()
                
                # Find matching gift
                matching = [
                    g for g in my_gifts 
                    if collection_name.lower() in g["collection"].lower()
                ]
                
                if matching:
                    gift = matching[0]
                    success = await send_gift_to_user(user_tg_id, gift["id"])
                    
                    if success:
                        await complete_withdrawal(withdraw_id)
                        await notify_user_bot(
                            user_tg_id,
                            f"✅ <b>Gift yuborildi!</b>\n\n"
                            f"🎁 <b>{collection_name}</b>\n"
                            f"Tabriklaymiz! Gift Telegram'ingizga keldi."
                        )
                        logger.info(f"✅ Gift sent: {collection_name} → {user_tg_id}")
                    else:
                        await notify_user_bot(
                            user_tg_id,
                            f"⏳ <b>Gifingiz tayyorlanmoqda...</b>\n\n"
                            f"🎁 <b>{collection_name}</b>\n"
                            f"Tez orada yuboriladi."
                        )
                else:
                    # Gift not found - notify admin
                    await notify_admin(
                        f"⚠️ <b>Gift kerak!</b>\n\n"
                        f"🎁 Collection: <b>{collection_name}</b>\n"
                        f"👤 User: @{withdrawal['username']} ({user_tg_id})\n"
                        f"🆔 Withdraw ID: #{withdraw_id}\n\n"
                        f"Hisobingizga shu collectiondan gift qo'shing."
                    )
                    await notify_user_bot(
                        user_tg_id,
                        f"⏳ <b>Gifingiz tayyorlanmoqda...</b>\n\n"
                        f"🎁 <b>{collection_name}</b>\n"
                        f"5-10 daqiqa ichida yuboriladi."
                    )
                    logger.warning(f"⚠️ Gift not found: {collection_name}")
        
        except Exception as e:
            logger.error(f"Withdrawal loop error: {e}")
        
        await asyncio.sleep(30)  # Check every 30 seconds

async def main():
    logger.info("Starting Utonks userbot...")
    
    if SESSION_STRING:
        await client.start(session=SESSION_STRING)
    else:
        await client.start()
    
    me = await client.get_me()
    logger.info(f"Userbot started as: @{me.username} ({me.id})")
    
    await notify_admin(f"🚀 Utonks userbot ishga tushdi!\n👤 @{me.username}")
    
    await process_withdrawals()

if __name__ == "__main__":
    asyncio.run(main())
