# 🎮 Utonks Game

Telegram Mini App — Gift based gaming platform.

## O'yinlar
- 🚀 **Crash** — multiplier o'sib boradi, o'z vaqtida cash out qiling
- 💣 **Mines** — 5x5 grid, minalardan qoching
- 📦 **Cases** — gift case oching
- ⬆️ **Upgrade** — gift + TON → yangi gift

## Stack
- **Frontend**: React + Vite + Tailwind + TON Connect
- **Backend**: FastAPI + Aiogram 3 + PostgreSQL
- **Userbot**: Telethon (gift yuborish)
- **Deploy**: Docker + Cloudflare Tunnel

## Boshlash

### 1. .env fayl yarating
```bash
cp .env.example .env
# .env faylini to'ldiring
```

### 2. Userbot session olish
```bash
cd userbot
pip install telethon
python -c "
from telethon.sync import TelegramClient
from telethon.sessions import StringSession
api_id = int(input('API ID: '))
api_hash = input('API Hash: ')
with TelegramClient(StringSession(), api_id, api_hash) as client:
    print('SESSION:', client.session.save())
"
```
Chiqgan sessionni `.env` da `USERBOT_SESSION=` ga qo'ying.

### 3. Cloudflare Tunnel sozlash
```bash
# cloudflared o'rnating
# Tunnel yarating va token oling
# .env da CLOUDFLARE_TUNNEL_TOKEN= ga qo'ying
```

### 4. Docker bilan ishga tushirish
```bash
docker-compose up --build -d
```

### 5. Botni sozlash
BotFather da Mini App URL ni Cloudflare tunnel URL ga o'rnating.

### 6. Admin yaratish
```sql
UPDATE users SET is_admin = true WHERE telegram_id = YOUR_ID;
```

### 7. TON API kolleksiyalarini sync qilish
Admin panelda → "Sync API" tugmasini bosing.

## Admin panel
Mini App ichida — faqat admin Telegram ID si kirsa ko'rinadi.

## Deployment
```bash
# VPS da
git clone ...
cd utonks
cp .env.example .env
# .env to'ldiring
docker-compose up -d
```
